<?php
if (!empty($config['UseChangelogTicker'])) {
	$changelogCache = new Cache('engine/cache/changelog');
	$changelogCache->useMemory(false);
	$changelogsTicker = $changelogCache->load();

	if ($changelogsTicker === false || $changelogsTicker === null) {
		$changelogsTicker = db()->fetchAll("
			SELECT `id`, `text`, `time`, `report_id`, `status`
			FROM `znote_changelog`
			ORDER BY `id` DESC;
		");
		if (is_array($changelogsTicker)) {
			$changelogCache->setContent($changelogsTicker);
			$changelogCache->save();
		}
	}

	if (isset($changelogsTicker) && !empty($changelogsTicker) && $changelogsTicker !== false) {
		tco_box_open(t('news.changelog_ticker'), 'newsticker', 'NewsTicker');
		for ($i = 0; $i < count($changelogsTicker) && $i < 5; $i++):
			list($tcoCat, $tcoText) = tco_changelog_split((string)($changelogsTicker[$i]['text'] ?? ''));
			$tcoTime = (int)($changelogsTicker[$i]['time'] ?? 0);
			?>
			<div id="TickerEntry-<?= $i ?>" class="Row">
				<div class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
					<div class="NewsTickerIcon" style="background-image:url(<?= theme_asset(tco_changelog_icon($tcoCat)) ?>)"></div>
					<div id="TickerEntry-<?= $i ?>-Button" class="NewsTickerExtend" data-plus="<?= theme_asset('plus.gif') ?>" data-minus="<?= theme_asset('minus.gif') ?>" style="background-image:url(<?= theme_asset('plus.gif') ?>)"></div>
					<div class="NewsTickerText">
						<span class="NewsTickerDate"><?= h(date('M d Y', $tcoTime)) ?> - </span>
						<span class="NewsTickerTime"><?= h(date('H:i', $tcoTime)) ?></span>
						<div class="NewsTickerTextContainer">
							<div class="NewsTickerShortText"><p><?= znote_bbcode_raw($tcoText) ?></p></div>
							<div class="NewsTickerFullText"><p><?= znote_bbcode_raw($tcoText) ?></p></div>
						</div>
					</div>
				</div>
			</div>
		<?php endfor; ?>
		<?php
		tco_box_close();
	}
}

tco_box_open(t_default('tco.nav.latestnews', 'Latest News'), 'news');

if ($news) {
	$total_news = count($news);
	$page_amount = ceil($total_news / $config['news_per_page']);
	$current = $config['news_per_page'] * $page;

	if ($view !== '') {
		$si = false;
		if (ctype_digit($view) === false) {
			for ($i = 0; $i < count($news); $i++) if ($view === urlencode($news[$i]['title'])) $si = $i;
		} else {
			for ($i = 0; $i < count($news); $i++) if ((int)$view === (int)$news[$i]['id']) $si = $i;
		}

		if ($si !== false) {
			tco_news_entry($news[$si]);
		} else {
			echo '<p>' . t('news.not_found_text') . '</p>';
		}
	} else {
		for ($i = $current; $i < $current + $config['news_per_page']; $i++) {
			if (!isset($news[$i])) continue;
			tco_news_entry($news[$i], '?view=' . urlencode($news[$i]['title']));
		}

		tco_news_pagination($page, (int)$page_amount);
	}
} else {
	echo '<p>' . t('news.none') . '</p>';
}

tco_box_close();
