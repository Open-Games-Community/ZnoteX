<?php require_once __DIR__ . '/parts/nav.php'; ?>
<div id="MenuColumn">
	<?php require __DIR__ . '/parts/loginbox.php'; ?>
	<?php require __DIR__ . '/parts/menu.php'; ?>
</div>
