(function () {
	'use strict';

	var root = document.getElementById('webshop');
	if (!root) return;

	root.querySelectorAll('.tco-shop-filters button').forEach(function (button) {
		button.addEventListener('click', function () {
			var filter = button.getAttribute('data-filter') || 'all';
			root.querySelectorAll('.tco-shop-filters button').forEach(function (item) {
				item.classList.toggle('is-active', item === button);
			});
			root.querySelectorAll('.tco-offer-card[data-offer-group]').forEach(function (card) {
				card.hidden = filter !== 'all' && card.getAttribute('data-offer-group') !== filter;
			});
		});
	});

	root.querySelectorAll('.needconfirmation').forEach(function (button) {
		button.addEventListener('click', function (event) {
			var name = button.getAttribute('data-item-name') || 'this offer';
			var cost = button.getAttribute('data-item-cost') || '0';
			if (!window.confirm('Do you really want to purchase ' + name + ' for ' + cost + ' points?')) {
				event.preventDefault();
			}
		});
	});

	var progress = document.getElementById('tcoWebshopProgress');
	var error = document.getElementById('tcoPaymentSelectionError');
	var selectedPrice = '';
	var selectedPoints = '';
	var selectedProvider = '';
	var selectedProviderLabel = '';
	var selectedCurrency = '';

	function updateAvailableProviders() {
		var product = root.querySelector('input[name="tco-point-package"]:checked');
		var allowed = product ? (product.getAttribute('data-providers') || '').split(',') : [];
		root.querySelectorAll('input[name="tco-payment-provider"]').forEach(function (provider) {
			var configured = provider.getAttribute('data-enabled') === '1';
			var compatible = provider.value === 'paygol' || !product || allowed.indexOf(provider.value) !== -1;
			provider.disabled = !configured || !compatible;
			provider.closest('.tco-payment-method').classList.toggle('is-disabled', provider.disabled);
			if (provider.disabled) provider.checked = false;
		});
	}

	function readSelection() {
		var product = root.querySelector('input[name="tco-point-package"]:checked');
		var provider = root.querySelector('input[name="tco-payment-provider"]:checked');
		selectedPrice = product ? product.value : '';
		selectedPoints = product ? product.getAttribute('data-points') || '' : '';
		selectedProvider = provider ? provider.value : '';
		selectedCurrency = provider ? provider.getAttribute('data-currency') || '' : '';
		selectedProviderLabel = provider
			? (provider.closest('.tco-payment-method').querySelector('.tco-payment-label').textContent || provider.value)
			: '';
		if (provider && provider.getAttribute('data-unit-price')) {
			selectedPrice = (Number(selectedPoints) * Number(provider.getAttribute('data-unit-price'))).toFixed(2);
		}
		return !!(product && provider);
	}

	function updateSummaries() {
		root.querySelectorAll('.tco-order-summary').forEach(function (summary) {
			summary.textContent = selectedPoints + ' Points - ' + selectedPrice + ' ' + selectedCurrency + ' - ' + selectedProviderLabel;
		});
	}

	function setStage(stage) {
		root.querySelectorAll('.tco-payment-stage').forEach(function (element) {
			element.classList.toggle('is-active', element.getAttribute('data-payment-stage') === String(stage));
		});
		if (progress) {
			progress.setAttribute('data-step', String(stage));
			progress.querySelectorAll('.tco-progress-step').forEach(function (step) {
				var icon = step.querySelector('img');
				var completed = Number(step.getAttribute('data-step')) <= stage;
				if (icon) icon.src = icon.getAttribute(completed ? 'data-green' : 'data-blue');
			});
		}
		if (stage >= 2) updateSummaries();
		if (stage === 3) {
			root.querySelectorAll('.tco-checkout-form').forEach(function (form) {
				form.classList.toggle(
					'is-active',
					form.getAttribute('data-provider') === selectedProvider && form.getAttribute('data-price') === selectedPrice
				);
			});
		}
		var activeStage = root.querySelector('.tco-payment-stage.is-active');
		if (activeStage) activeStage.scrollIntoView({ block: 'nearest' });
	}

	root.querySelectorAll('[data-payment-next]').forEach(function (button) {
		button.addEventListener('click', function () {
			var stage = Number(button.getAttribute('data-payment-next'));
			if (stage === 2 && !readSelection()) {
				if (error) error.textContent = 'Select a point package and an available payment method.';
				return;
			}
			if (error) error.textContent = '';
			setStage(stage);
		});
	});

	root.querySelectorAll('[data-payment-back]').forEach(function (button) {
		button.addEventListener('click', function () {
			setStage(Number(button.getAttribute('data-payment-back')));
		});
	});

	root.querySelectorAll('input[name="tco-payment-provider"]').forEach(function (provider) {
		provider.addEventListener('change', function () {
			var selectedProduct = root.querySelector('input[name="tco-point-package"]:checked');
			if (!selectedProduct || (selectedProduct.getAttribute('data-providers') || '').split(',').indexOf(provider.value) === -1) {
				var replacement = Array.from(root.querySelectorAll('input[name="tco-point-package"]')).find(function (product) {
					return (product.getAttribute('data-providers') || '').split(',').indexOf(provider.value) !== -1;
				});
				if (replacement) replacement.checked = true;
			}
			updateAvailableProviders();
			var currency = provider.getAttribute('data-currency') || '';
			root.querySelectorAll('.tco-point-package').forEach(function (card) {
				var product = card.querySelector('input[name="tco-point-package"]');
				var price = card.querySelector('.tco-service-price');
				if (!product || !price || (product.getAttribute('data-providers') || '').split(',').indexOf(provider.value) === -1) return;
				var amount = price.getAttribute('data-base-price') || '0';
				if (provider.getAttribute('data-unit-price')) amount = (Number(price.getAttribute('data-points')) * Number(provider.getAttribute('data-unit-price'))).toFixed(2);
				price.textContent = amount + ' ' + currency;
			});
		});
	});

	root.querySelectorAll('input[name="tco-point-package"]').forEach(function (product) {
		product.addEventListener('change', function () {
			var provider = root.querySelector('input[name="tco-payment-provider"]:checked');
			if (provider && (product.getAttribute('data-providers') || '').split(',').indexOf(provider.value) === -1) provider.checked = false;
			updateAvailableProviders();
		});
	});
	updateAvailableProviders();
})();
