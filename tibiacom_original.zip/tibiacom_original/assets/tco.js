document.addEventListener('DOMContentLoaded', function () {
	// Every left-menu group opens and closes independently: several can stay
	// open at once, and the whole set survives navigation and refreshes.
	var tcoMenuStorageKey = 'tco_open_menus';

	function tcoReadOpenMenus() {
		try {
			var raw = window.localStorage.getItem(tcoMenuStorageKey);
			var list = raw ? JSON.parse(raw) : [];
			return Array.isArray(list) ? list : [];
		} catch (e) {
			return [];
		}
	}

	function tcoWriteOpenMenus(list) {
		try {
			window.localStorage.setItem(tcoMenuStorageKey, JSON.stringify(list));
		} catch (e) {}
	}

	function tcoSetMenuOpen(id, open) {
		var list = tcoReadOpenMenus();
		var at = list.indexOf(id);
		if (open && at === -1) {
			list.push(id);
		} else if (!open && at !== -1) {
			list.splice(at, 1);
		}
		tcoWriteOpenMenus(list);
	}

	function tcoApplyMenuState(id, open) {
		var submenu = document.getElementById(id + '_Submenu');
		var toggle = document.querySelector('.tco-menu-toggle[data-target="' + id + '"]');
		if (!submenu || !toggle) return;
		submenu.style.display = open ? 'block' : 'none';
		var extend = toggle.querySelector('.Extend');
		if (extend) {
			extend.style.backgroundImage = "url('" + extend.getAttribute(open ? 'data-minus' : 'data-plus') + "')";
		}
	}

	// The server already flags today's active section as open (MenuItemOpen) -
	// merge that into the remembered set rather than letting one override the
	// other, so the active page's group never collapses on its own.
	document.querySelectorAll('#Menu .menuitem.MenuItemOpen').forEach(function (group) {
		tcoSetMenuOpen(group.id, true);
	});

	tcoReadOpenMenus().forEach(function (id) {
		tcoApplyMenuState(id, true);
	});

	document.querySelectorAll('.tco-menu-toggle').forEach(function (toggle) {
		toggle.addEventListener('click', function () {
			var id = toggle.getAttribute('data-target');
			var submenu = document.getElementById(id + '_Submenu');
			if (!submenu) return;
			var open = submenu.style.display === 'block';
			tcoApplyMenuState(id, !open);
			tcoSetMenuOpen(id, !open);
		});
	});

	document.querySelectorAll('#Menu .Submenu a').forEach(function (link) {
		link.addEventListener('click', function () {
			var group = link.closest('.menuitem');
			if (!group) return;
			tcoSetMenuOpen(group.id, true);
		});
	});

	document.querySelectorAll('#MobileMenu .Level1Entry[data-tco-toggle]').forEach(function (entry) {
		entry.addEventListener('click', function () {
			var open = entry.classList.contains('Level1ItemOpen');
			document.querySelectorAll('#MobileMenu .Level1Entry.Level1ItemOpen').forEach(function (other) {
				if (other !== entry) {
					other.classList.remove('Level1ItemOpen');
					other.parentElement.querySelectorAll('.Level2Block').forEach(function (row) {
						row.style.display = 'none';
					});
				}
			});
			entry.classList.toggle('Level1ItemOpen', !open);
			entry.parentElement.querySelectorAll('.Level2Block').forEach(function (row) {
				row.style.display = open ? 'none' : 'list-item';
			});
		});
	});

	var tcoMobileMenuIcon = document.getElementById('MobileMenuIcon');
	var tcoMobileShortMenuIcon = document.getElementById('MobileShortMenuIcon');
	if (tcoMobileMenuIcon && tcoMobileShortMenuIcon) {
		tcoMobileMenuIcon.addEventListener('change', function () {
			if (tcoMobileMenuIcon.checked) {
				tcoMobileShortMenuIcon.checked = false;
			}
		});
		tcoMobileShortMenuIcon.addEventListener('change', function () {
			if (tcoMobileShortMenuIcon.checked) {
				tcoMobileMenuIcon.checked = false;
			}
		});
	}

	document.querySelectorAll('#NewsTicker .Row').forEach(function (row) {
		row.addEventListener('click', function () {
			var open = row.classList.toggle('TickerOpen');
			var btn = row.querySelector('.NewsTickerExtend');
			if (btn) btn.style.backgroundImage = "url('" + btn.getAttribute(open ? 'data-minus' : 'data-plus') + "')";
		});
	});

	document.querySelectorAll('img[data-over][data-out]').forEach(function (img) {
		var target = img.parentElement || img;
		target.addEventListener('mouseover', function () { img.src = img.getAttribute('data-over'); });
		target.addEventListener('mouseout', function () { img.src = img.getAttribute('data-out'); });
	});

	document.querySelectorAll('form[data-confirm]').forEach(function (form) {
		form.addEventListener('submit', function (event) {
			if (!window.confirm(form.getAttribute('data-confirm'))) {
				event.preventDefault();
			}
		});
	});
});
