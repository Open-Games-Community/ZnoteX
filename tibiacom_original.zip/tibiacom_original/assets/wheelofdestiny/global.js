
/* ----------------- */
/* Caps Lock Warning */
/* ----------------- */

//indicator for pw rules
var g_IsValidPW = null;
//indicator if caps lock is currently active
var g_CapsLockIsEnabled = null;

// disable built in caps lock warning of microsoft browsers (IE > 9 and Edge)
if (typeof document.msCapsLockWarningOff !== 'undefined') {
  document.msCapsLockWarningOff = true;
}

// add required event listeners for caps lock protection
function AddCapsLockEventListeners() {
  // add event listeners for caps lock protection to protected fields
  $('input[type=password]').on("keyup", function (e) {
    ShowOrHideCapsLockWarning(e);
  });
  $('input[type=password]').on("focus", function (e) {
    ShowOrHideCapsLockWarning(e);
  });
  $('input[type=password]').on("blur", function () {
    HideCapsLockWarning();
  });
  // add global event listeners for caps lock protection to the document
  $(document).on("keydown", function (e) {
    CheckForCapsLockItself(e);
  });
  $(document).on("keypress", function (e) {
    CheckPressedKey(e);
  });
}

// check if caps lock itself was presse
function CheckForCapsLockItself(e)
{
  e = e || event;
  if (e.keyCode == 20 && g_CapsLockIsEnabled !== null) {
    g_CapsLockIsEnabled = !g_CapsLockIsEnabled;
  }
}

// check the pressed key
function CheckPressedKey(e)
{
  e = e || event;
  var chr = GetChar(e);
  if (!chr) {
    // we can not process special keys
    return;
  }
  if (chr.toLowerCase() == chr.toUpperCase()) {
    // we can not process caseless symbols (e.g. whitespace) do detect the Caps Lock state
    return;
  }
  g_CapsLockIsEnabled = (chr.toLowerCase() == chr && e.shiftKey) || (chr.toUpperCase() == chr && !e.shiftKey);
}

// get pressed character
function GetChar(e)
{
  if (e.which == null) {
    return String.fromCharCode(e.keyCode); // IE
  }
  if (e.which != 0 && e.charCode != 0) {
    return String.fromCharCode(e.which); // rest
  }
  return null;
}

// show or hide the caps lock warning
function ShowOrHideCapsLockWarning()
{
  if (g_CapsLockIsEnabled) {
    var l_PasswordFields = $('input[type=password]');
    var l_Top = ($(':focus').offset().top + 18);
    var l_Left = ($(':focus').offset().left + 18);
    $('#CapsLockWarning').css({top: l_Top, left: l_Left});
    $('#CapsLockWarning').show();
  } else {
    $('#CapsLockWarning').hide();
  }
}

// hide the caps lock warning
function HideCapsLockWarning()
{
  $('#CapsLockWarning').hide();
}

/* -------------------------------- */
/* Password validation and strength */
/* -------------------------------- */

$(document).ready(function() {
  // apply adjustments for small screens if required
  if (typeof LoadMobileCSS !== 'undefined' && LoadMobileCSS) {
    CheckForMobileAdjustments();
    $(window).on("resize", function() {
      CheckForMobileAdjustments();
    });
    // register mobile menu events
    $('#MobileShortMenuIcon').on("click", function() {
      $('#MobileMenuIcon').prop('checked', false);
    });
    $('#MobileMenuIcon').on("click", function() {
      $('#MobileShortMenuIcon').prop('checked', false);
    });
    $('#MobileShortMenuIcon, #MobileMenuIcon').on("change", function() {
      CheckForMenuPosition();
    });
  }
});

/**
* Ensure the whole menu is accessible on mobile screens.
* @return void
*/
function CheckForMenuPosition()
{
  if ($('#MobileMenuIcon').is(':checked')) {
    $('#MobileMenu').css('height', '100%');
    $('#MobileMenu').css('overflow-y', 'scroll');
  } else {
    $('#MobileMenu').css('height', '70px');
    $('#MobileMenu').css('overflow-y', 'unset');
  }
}

/**
* On small screens content adjustments have to be applied.
* @return void
*/
function CheckForMobileAdjustments()
{
  // apply layout adjustments only if required
  if (window.matchMedia('(max-width: 768px)').matches) {
    // remove mouse over tool tips in webshop
    if ($('.Content > #webshop').length > 0 && $('#HelperDivContainer').length > 0) {
      $('#HelperDivContainer').remove();
    }
    // set adjustment values
    var AvailableScreenWidth = window.screen.availWidth;
    if (window.matchMedia("(orientation: landscape)").matches) {
      // avoid a problem in iOS
      if (window.screen.availHeight > AvailableScreenWidth) {
        AvailableScreenWidth = window.screen.availHeight;
      }
    }
    var ImageSizeBuffer = 20;
    var TableSizeBuffer = 30;
    var TableEventCalenderBuffer = 40;
    var ObserverInputBuffer = 70;
    var ObserverInnerTableBuffer = ReportTableBuffer = 50;
    var ReportTableBufferForum = 57;
    var ForumImageBuffer = 62;
    var AuctionFilterTableBuffer = 67;
    // set maximum content image width
    $('.BoxContent img').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - ImageSizeBuffer));
    });
    $('#soundtrack .BoxContent .AudioAmbianceScreenshot').each(function() {
      $(this).css('max-width',  parseInt($('.ControlPanelImage').css('width')) - 12);
    });
    // make oversized tables horizontal scrollable
    $('.TableContainer .InnerTableContainer').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - TableSizeBuffer));
    });
    $('#soundtrack .TableContainer .InnerTableContainer').each(function() {
      $(this).css('overflow', 'clip');
    });
    $('.TableContainer .TableScrollbarWrapper').each(function() {
      $(this).css('width', ((AvailableScreenWidth) - TableSizeBuffer));
    });
    // adjusted event schedule inner table
    $(' #EventSchedule .TableContainer .InnerTableContainer').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - TableEventCalenderBuffer));
    });
    // adjusted images in the forum
    $('.ThreadReviewPosting img, .PostText img').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - ForumImageBuffer));
    });
    // adjust connect tibia observer section, so no scrolling is necessary
    $('#ConnectTibiaObserver .TableContentContainer div').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - ObserverInnerTableBuffer));
    });
    $('#ConnectTibiaObserver #TibiaObserverTokenInput').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - ObserverInputBuffer));
    });
    // adjust reporting screen, so no scrolling is necessary
    $('#reason_description, #translation_input, #comment_input, #reasonid_select').each(function() {
      $(this).css('width', ((AvailableScreenWidth) - ReportTableBuffer));
    });
    // adjust reporting in the forum screen, so no scrolling is necessary
    $('.ForumReport').each(function() {
      $(this).css('width', ((AvailableScreenWidth) - ReportTableBufferForum));
    });
    // adjust wheel of destiny elements, so no scrolling is necessary
    $('#WheelOfDestinySelection > td:nth-child(2)').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - TableSizeBuffer));
    });
    // adjust search in the char bazaar section, so no scrolling is necessary
    $('.AuctionInputSearch, .AuctionFilterCategory').each(function() {
      $(this).css('width', ((AvailableScreenWidth) - AuctionFilterTableBuffer));
      if ($(this).hasClass('AuctionFilterCategory')) {
        $(this).css('width', parseInt($(this).css('width')) + 8);
      }
    });
    // adjust reporting in the forum screen, so no scrolling is necessary
    $('.InInputResetButton').each(function() {
      $(this).css('left', parseInt($('.AuctionInputSearch').css('width')) - parseInt($(this).css('width'))*0.75 );
    });
    // adjust oversized tables
    $('.TableContainer').each(function() {
      var TableScrollbarWrapper = $(this).find('.TableScrollbarWrapper');
      var InnerTableContainer = $(this).find('.InnerTableContainer');
      var ScrollWidth = $(this).find('.InnerTableContainer')[0].scrollWidth;
      if (ScrollWidth > ((AvailableScreenWidth) - TableSizeBuffer)) {
        $(this).find('.TableScrollbarContainer').width(ScrollWidth);
        InnerTableContainer.css('margin-bottom', 5);
        TableScrollbarWrapper.css('display', 'block');
        // when the upper scroll bar was moved we move the content
        TableScrollbarWrapper.on('scroll', function(Event) {
          InnerTableContainer.scrollLeft(Event.target.scrollLeft);
        });
        // when the content was moved we move the upper scrollbar
        InnerTableContainer.on('scroll', function(Event) {
          TableScrollbarWrapper.scrollLeft(Event.target.scrollLeft);
        });
      } else {
        TableScrollbarWrapper.css('display', 'none');
        InnerTableContainer.css('margin-bottom', 0);
      }
    });
    // news section ajdustments
    // problems in the latest news section due to images with
    // fixed size larger then the screen have to be avoided
    var NewsImageBuffer = 20;
    var NewsTableBuffer = 20;
    var Attributes = ['width','height','vspace','hspace'];
    $('.Content .NewsTable img').each(function() {
      RememberAndRemoveAttributes($(this), Attributes);
    });
    $('.Content .NewsTable img').each(function() {
      $(this).css('max-width', ((AvailableScreenWidth) - NewsImageBuffer));
    });
    $('.Content .NewsTable figure').each(function() {
      $(this).css('margin-left', 0);
    });
    $('.Content .NewsTable figure').each(function() {
      $(this).css('margin-right', 0);
    });
    // horizontal scrollable tables are required
    $('.Content .NewsTable .NewsTableContainer table').each(function() {
      $(this).css('display', 'block');
    });
    $('.Content .NewsTable .NewsTableContainer table').each(function() {
      $(this).css('width', 'unset');
    });
    $('.Content .NewsTable .NewsTableContainer table').each(function() {
      $(this).css('height', 'unset');
    });
    $('.Content .NewsTable .NewsTableContainer table').each(function() {
      $(this).css('overflow-x', 'scroll');
    });
    $('.Content .NewsTable .NewsTableContainer table').each(function() {
      $(this).css('max-width', (AvailableScreenWidth) - NewsTableBuffer);
    });
  } else {
    $('.TableContainer .InnerTableContainer').each(function() {
      $(this).css('max-width', 'unset');
    });
    $('.TableContainer .TableScrollbarWrapper').each(function() {
      $(this).css('width', 'unset');
    });
    // adjust reporting in the forum screen, so no scrolling is necessary
    $('.PlayButton, .PauseButton').each(function() {
      $(this).css('left', '50%' - parseInt($(this).css('width'))*0.5);
    });
    $('.AuctionInputSearch, .AuctionFilterCategory').each(function() {
      $(this).css('width', '');
    });    
    $('.InInputResetButton').each(function() {
      $(this).css('left', '');
    });
    var Attributes = ['width','height','vspace','hspace'];
    $('.Content .NewsTable img').each(function() {
      RestoreAttributes($(this), Attributes);
    });
 }
  // return from function
  return;
}


// Remember the original values of specified attributes for an element and then remove those attributes.
function RememberAndRemoveAttributes($Element, AttributeList) {
  AttributeList.forEach(function(Attribute){
    var Key = 'original-'+Attribute;
    if (!$Element.data(Key)) {
      var Value = $Element.attr(Attribute);
      if (Value != null) {
        $Element.data(Key, Value);
      }
    }
    $Element.removeAttr(Attribute);
  });
}

// Restore original attributes to an element based on a list of attribute names.
function RestoreAttributes($Element, AttributeList) {
  AttributeList.forEach(function(Attribute){
    var Value = $Element.data('original-' + Attribute);
    if (Value != null) {
      $Element.attr(Attribute, Value);
    }
  });
}

/* -------------------------------- */
/* Password validation and strength */
/* -------------------------------- */

$(document).ready(function() {
  // check if we have to initialize a password strength checker
  g_PasswordToolTipIsActive = 0;
  if ($('.PWStrengthContainer').length > 0) {
    g_PasswordToolTipIsActive = 1;
  }
  if ($('#password1').length > 0) {
    $("#password1").on("change", function() {
      // required to avoid problems with autofilled passwords
      CheckPasswordStrength($('#password1').val());
    });
    $("#password1").on("keyup", function() {
      CheckPasswordStrength($('#password1').val());
    });
    if ($('#password1').val().length > 0) {
      CheckPasswordStrength($('#password1').val());
    }
    $(".Themeboxes").css({zIndex: 10})
  }
});

/**
* Executes password validation and sets password strength indicator.
* @param a_Password  The password to validate.
* @return void
*/
function CheckPasswordStrength(a_Password)
{
  if (a_Password.length > 0) {
    // show the tool tip
    $('.PWStrengthToolTip').show();
    // hide certain error messages in regular forms
    $('#password_errormessage .CanBeHiddenWhenToolTipIsOn').hide();
    // hide all password error messages on landing page
    $('.BoxInputText #password_errormessage').hide();
  }
  // set values
  l_Feedback = 'very weak';
  l_CSSClass = 'PWStrengthIndicator';
  l_Warning = '';
  l_Suggestions = '';
  l_Result = {'score': 0, 'feedback': {'warning': '', 'suggestions': Array(0)}};
  // validate password rules
  g_IsValidPW = ValidatePassword(a_Password);
  if (g_IsValidPW && typeof zxcvbn === "function") {
    // check password strength
    l_Result = zxcvbn(a_Password);
  }
  // set result
  if (l_Result.score > 3) {
    l_Feedback = 'strong';
    l_CSSClass += ' PWStrengthLevel4';
  } else if (l_Result.score == 3) {
    l_Feedback = 'medium';
    l_CSSClass += ' PWStrengthLevel3';
  } else if (l_Result.score == 2) {
    l_Feedback = 'weak';
    l_CSSClass += ' PWStrengthLevel2';
  } else if (l_Result.score == 1) {
    l_Feedback = 'very weak';
    l_CSSClass += ' PWStrengthLevel1';
  } else {
    l_Feedback = 'very weak';
    l_CSSClass += ' PWStrengthLevel0';
  }
  $('.PWStrengthIndicator').text(l_Feedback);
  $('.PWStrengthIndicator').attr('class', l_CSSClass);
  $('.PWStrengthSuggestions').text(l_Suggestions);
  $('.PWStrengthWarning').text(l_Warning);
  if (l_Result.score <= 2) {
    if (l_Result.feedback.warning.length > 0) {
      l_Warning += l_Result.feedback.warning;
      $('.PWStrengthWarning').append('<div class="PWStrengthToolTipHeadline" >Warning</div>');
      $('.PWStrengthWarning').append('<div>' + l_Warning + '</div>');
    }
    if (l_Result.feedback.suggestions.length > 0) {
      $('.PWStrengthSuggestions').append('<div class="PWStrengthToolTipHeadline" >Tip</div>');
      for(var i = 0; i < l_Result.feedback.suggestions.length; i++ ) {
        $('.PWStrengthSuggestions').append('<div>' + l_Result.feedback.suggestions[i] + '</div>');
      }
    }
  }
  if (g_IsValidPW) {
    $('.PWStrengthToolTip').hide();
  }
}


/**
* Validates the password and sets tool tip indicators.
* @param a_Password      The password to validate.
* @return l_ReturnValue  True when all rules are fulfilled otherwise false
*/
function ValidatePassword(a_Password)
{
  var l_ReturnValue = true;
  var PWRules = [
    [62, ((a_Password.length >= 30 || a_Password.length < 10) ? false : true)],
    [63, ((a_Password.match(/[^!-~]+/) !== null) ? false : true)],
    [65, ((a_Password.match(/^[A-Za-z]*$/) !== null) ? false : true)],
    [84, ((a_Password.match(/[a-z]/) === null) ? false : true)],
    [85, ((a_Password.match(/[A-Z]/) === null) ? false : true)],
    [86, ((a_Password.match(/[0-9]/) === null) ? false : true)]
  ];
  // check the rules
  for (var i = 0; i < PWRules.length; i++ ) {
    if (PWRules[i][1] == true) {
      $('#PWRule' + PWRules[i][0]).removeClass('InputIndicatorNotOK');
      $('#PWRule' + PWRules[i][0]).addClass('InputIndicatorOK');
    } else {
      l_ReturnValue = false;
      $('#PWRule' + PWRules[i][0]).addClass('InputIndicatorNotOK');
      $('#PWRule' + PWRules[i][0]).removeClass('InputIndicatorOK');
    }
  }
  // return result
  return l_ReturnValue;
}


function TogglePassword(button) {
    const input = button.previousElementSibling;
    const isPassword = input.type === 'password';
    input.type = isPassword ? 'text' : 'password';
    button.setAttribute('aria-pressed', isPassword);
}

/* ---------------- */
/* Cookie Functions */
/* ---------------- */

/**
* Set the value of a cookie
* @param a_Name string                 The name of the cookie.
* @param a_Value string                The value of the cookie.
* @param a_ExpireDateUTCString string  The expirey date of the cookie.
* @return void
*/
function SetCookie(a_Name, a_Value, a_ExpireDateUTCString)
{
  // if an expire date is provided we use that value otherwise no expires will be set
  var l_CookieExpireString = '';
  if (a_ExpireDateUTCString != false) {
    l_CookieExpireString += ' expires=' + a_ExpireDateUTCString + ';';
  }
  // set the cookie
  document.cookie = a_Name + '=' + encodeURIComponent(a_Value) + '; domain=' + JS_COOKIE_DOMAIN + '; SameSite=None; Secure;' + l_CookieExpireString + ' path=/;';
  // return from function
  return;
}

/**
* Get the value of a cookie.
* @param a_Name string                   The name of the cookie.
* @return l_RequestedCookieValue string  The value of the requested cookie (or null if not found).
*/
function GetCookieValue(a_Name)
{
  var l_RequestedCookieValue = null;
  var l_ConsentCookieEQ = a_Name + '=';
  var l_AllCookies = document.cookie.split(';');
  for(var i = 0; i < l_AllCookies.length; i++) {
    var l_SingleCookie = l_AllCookies[i];
    while (l_SingleCookie.charAt(0) == ' ') {
      l_SingleCookie = l_SingleCookie.substring(1, l_SingleCookie.length);
    }
    if (l_SingleCookie.indexOf(l_ConsentCookieEQ) == 0) {
      l_RequestedCookieValue = decodeURIComponent(l_SingleCookie.substring(l_ConsentCookieEQ.length,l_SingleCookie.length));
      break;
    }
  }
  // return the value
  return l_RequestedCookieValue;
}

/* -------------- */
/* Cookie Consent */
/* -------------- */

// hide the cookie details dialog
function HideCookieDialog()
{
  $('#cookiedialogbox').hide();
}

// hide the cookie details dialog
function ShowCookieDialog()
{
  $('#cookiedialogbox').show();
}

// hide the cookie details dialog
function HideCookieDetails()
{
  $('#cookiedetailsbox').hide();
}

// hide the cookie details dialog
function ShowCookieDetails()
{
  $('#cookiedetailsbox').show();
}

// Set the Consent Cookie
function SetConsentCookie(consent, acceptall)
{
  // determine user settings
  let cc_advertising = false;
  let cc_social = false;
  let cc_reown = false;
  if (consent == true) {
    if (acceptall == true) {
      cc_advertising = true;
      cc_social = true;
      cc_reown = true;
    } else {
      cc_advertising = $("#cc_advertising").is(':checked');
      cc_social = $('#cc_social').is(':checked');
      cc_reown = $('#cc_reown').is(':checked');
    }
  }
  // build JSON Object and store it in cookies
  const settings = {
    consent: consent,
    advertising: cc_advertising,
    socialmedia: cc_social,
    walletconnect: cc_reown // cookies is still named walletconnect after it was rebranded to reown to ensure we don't have to fetch the consent again
  };
  // set the cookie
  SetCookie('CookieConsentPreferences', JSON.stringify(settings), GetConsentCookieExpireDateUTCString());
  // reload the site
  const reloadUrl = window.location.href.split('#')[0];
  if (window.history.replaceState) {
    window.history.replaceState(null, '', reloadUrl);
  }
  window.location = reloadUrl;
}

// Prolong the expire date of the consent cookie
function ProlongConsentCookie()
{
  // get the cookie values
  var l_ConsentCookie = GetCookieValue('CookieConsentPreferences');
  // if the cookie exists
  if (l_ConsentCookie != null) {
    // we prolong its validity
    SetCookie('CookieConsentPreferences', l_ConsentCookie, GetConsentCookieExpireDateUTCString());
    // and hide the cookie dialog if it should still be visible due to CDN caching
    $('#cookiedialogbox').hide();
  }
}

// Get the expire date of the consent cookie
function GetConsentCookieExpireDateUTCString()
{
  var l_ExpireDate = new Date;
  l_ExpireDate.setFullYear(l_ExpireDate.getFullYear() + 1);
  // return the expire data as UTC string
  return l_ExpireDate.toUTCString();
}

// Execute commands after the page is completly loaded
$(document).ready(function() {
  // Prolong the constent cookie validity if it is already set
  var l_CurrentDomain = window.location.host.toString();
  var l_CookieDomain = JS_COOKIE_DOMAIN;
  if ((l_CookieDomain.includes(l_CurrentDomain) == true) || (l_CurrentDomain.includes(l_CookieDomain) == true)) {
    ProlongConsentCookie();
  }
});

/**
* Filter the fansite list.
* @param a_Element string  The ID of the element to filter.
* @return void
*/
function FansiteFilterAction(a_Element)
{
  // "all" filters can not get unselected
  if (a_Element == 'Language_All' || a_Element == 'SocialMedia_All' || a_Element == 'Content_All') {
    if ($('#' + a_Element).hasClass('FilterIsActive')) {
      return;
    }
  }
  // check for filter "All" and set corresponding elements active
  if (a_Element == 'Language_All') {
    $('.FilterElementLanguage').addClass('FilterIsActive');
  } else if (a_Element == 'SocialMedia_All') {
    $('.FilterElementSocialMedia').addClass('FilterIsActive');
  } else if (a_Element == 'Content_All') {
    $('.FilterElementContent').addClass('FilterIsActive');
  }
  // set or unset the selected element
  if ($('#' + a_Element).hasClass('FilterIsActive')) {
    $('#' + a_Element).removeClass('FilterIsActive');
  } else {
    $('#' + a_Element).addClass('FilterIsActive');
  }
  // check for filter elements and unset corresponding "All" filter
  if ($('#' + a_Element).hasClass('FilterElementLanguage')) {
    $('.FilterLanguageAll').removeClass('FilterIsActive');
  } else if ($('#' + a_Element).hasClass('FilterElementSocialMedia')) {
    $('.FilterSocialMediaAll').removeClass('FilterIsActive');
  } else if ($('#' + a_Element).hasClass('FilterElementContent')) {
    $('.FilterContentAll').removeClass('FilterIsActive');
  }
  // if no elements are selected set "all" filter
  if ($('.FilterElementLanguage').hasClass('FilterIsActive') == false) {
    $('#Language_All').addClass('FilterIsActive');
  }
  if ($('.FilterElementSocialMedia').hasClass('FilterIsActive') == false) {
    $('#SocialMedia_All').addClass('FilterIsActive');
  }
  if ($('.FilterElementContent').hasClass('FilterIsActive') == false) {
    $('#Content_All').addClass('FilterIsActive');
  }
  // get filtered rows
  var l_Filter = '';
  // get all selected language filter
  l_Filter = '.FilterElementLanguage.FilterIsActive';
  if ($('#Language_All').hasClass('FilterIsActive')) {
    l_Filter = '.FilterElementLanguage';
  }
  var l_ActiveLanguageList = $(l_Filter).not('.FilterAll').map(function() {
    return '.Filter' + $(this).attr('id');
  }).get().join(', ');
  var l_LanguageRows = $(l_ActiveLanguageList).map(function() {
    return '#' + $(this).attr('id');
  }).get();
  // get all selected social media filter
  l_Filter = '.FilterElementSocialMedia.FilterIsActive';
  if ($('#SocialMedia_All').hasClass('FilterIsActive')) {
    l_Filter = '.FilterElementLanguage';
  }
  var l_ActiveSocialMediaList = $(l_Filter).not('.FilterAll').map(function() {
    return '.Filter' + $(this).attr('id');
  }).get().join(', ');
  var l_SocialMediaRows = $(l_ActiveSocialMediaList).map(function() {
    return '#' + $(this).attr('id');
  }).get();
  // get all selected content filter
  l_Filter = '.FilterElementContent.FilterIsActive';
  if ($('#Content_All').hasClass('FilterIsActive')) {
    l_Filter = '.FilterElementLanguage';
  }
  var l_ActiveContentList = $(l_Filter).not('.FilterAll').map(function() {
    return '.Filter' + $(this).attr('id');
  }).get().join(', ');
  var l_ContentRows = $(l_ActiveContentList).map(function() {
    return '#' + $(this).attr('id');
  }).get();
  // get rows where all filters apply
  var l_FilteredListRowIDs = $(l_LanguageRows).filter(l_SocialMediaRows).filter(l_ContentRows).get().join(', ');
  // hide all rows
  $('.FilterResultRow').hide();
  // show selected rows
  $(l_FilteredListRowIDs).show();
  // check for filter "All" and unset other elements
  if (a_Element == 'Language_All') {
    $('.FilterElementLanguage').removeClass('FilterIsActive');
  } else if (a_Element == 'SocialMedia_All') {
    $('.FilterElementSocialMedia').removeClass('FilterIsActive');
  } else if (a_Element == 'Content_All') {
    $('.FilterElementContent').removeClass('FilterIsActive');
  }
  // return from function
  return;
}


/* ------- */
/* Various */
/* ------- */

// function for mouse-over and click events of non-content-buttons
function MouseOverBigButton(source)
{
  var firstChild = $(source).children().first();
  if (firstChild.length) {
    firstChild.css('visibility', 'visible');
  }
}
function MouseOutBigButton(source)
{
  var firstChild = $(source).children().first();
  if (firstChild.length) {
    firstChild.css('visibility', 'hidden');
  }
}

/**
* Copy the value of an input by a button click.
* @param a_SourceID string     The id of the button.
* @param a_FormInputID string  The id of the form input field containg the value to copy.
* @return void
*/
function CopyContentOfFormInput(a_SourceID, a_FormInputID)
{
  // copy code option
  $("#" + a_SourceID).on("click", function() {
    $("#" + a_FormInputID).select();
    document.execCommand("copy");
  });
  // mark the whole content of the input field
  $("#" + a_FormInputID).on("click", function() {
    $(this).select();
  });
}

/**
* Copy the inner text of a html element by a button click.
* @param a_SourceID string     The id of the button.
* @param a_FormInputID string  The id of the html element containg the text to copy.
* @return void
*/
function CopyTextOfElement(a_SourceID, a_ElementID)
{
  $("#" + a_SourceID).on("click", function() {
    // retrieve text
    const elem = $("#" + a_ElementID);
    if (elem && elem[0]) {
      const text = $("#" + a_ElementID)[0].textContent;
      if (text) {
        // create temporary input to copy from
        const tempInput = document.createElement("input");
        tempInput.style = "position: absolute; left: -1000px; top: -1000px; opacity: 0;";
        tempInput.value = text;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
        $(this).trigger("focus");
      }
    }
  });
}

/**
 * Convert a number to a roman numeral
 * @param a_Number number The number to convert
 * @returns string
 */
function toRomanNumeral(a_Number) {
  if (isNaN(a_Number) || a_Number < 0 || parseInt(a_Number) !== a_Number) {
    return a_Number;
  }
  const digits = String(+a_Number).split("");
  const key = [
    "","C","CC","CCC","CD","D","DC","DCC","DCCC","CM",
    "","X","XX","XXX","XL","L","LX","LXX","LXXX","XC",
    "","I","II","III","IV","V","VI","VII","VIII","IX"
  ];
  let roman = "";
  let i = 3;
  while (i--) {
    roman = (key[+digits.pop() + (i * 10)] || "") + roman;
  }
  return Array(+digits.join("") + 1).join("M") + roman;
}

/**
 * Prevents new tab from opening when used onauxclick
 */
function PreventNewTab(a_Event) {
  if (a_Event && a_Event.button === 1) {
    a_Event.preventDefault();
  }
}

function MoveCursor(a_InputElem, a_NextInputElem, a_MaxInputLength) {
  if (a_InputElem && a_NextInputElem && a_InputElem.value.length >= a_MaxInputLength) {
    a_NextInputElem.focus();
  }
}

function DownloadWindowsClient(a_Event, a_ButtonElem, a_FilePath) {
  if (a_ButtonElem.classList.contains('DisabledLink')) {
    a_Event.preventDefault();
    return;
  }
  let anchor = document.createElement('a');
  anchor.href = a_FilePath;
  anchor.type = 'application/octet-stream';
  anchor.target = '_top';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}


function PreloadImages(a_Page)
{
  var urls = [];
  switch (a_Page) {
    case "tibiatoken":
      urls = [
        JS_DIR_IMAGES + 'global/buttons/button_standard_9grid_hover.png',
        JS_DIR_IMAGES + 'global/buttons/button_standard_green_9grid_hover.png',
      ];
      break;
  }

  urls.forEach((url) => {
    const img = new Image();
    img.src = url;
  });

}