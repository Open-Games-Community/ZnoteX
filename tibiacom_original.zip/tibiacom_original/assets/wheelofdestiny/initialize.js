/**
 * -------------------------------------------------------------------
 * JavaScripts which are loaded by the OnLoad function of the body tag
 * -------------------------------------------------------------------
 */

// executes JavaScripts for the loginbox and the menu
function InitializePage()
{
  LoadLoginBox();
  LoadMenu();
}

// remove the deactivation container from the website
function ActivateWebsiteFrame()
{
  g_Deactivated = false;
  if (document.getElementById('DeactivationContainer') != null) {
    document.getElementById('DeactivationContainer').style.display = "none";
  }
  if (document.getElementById('DeactivationContainerThemebox') != null) {
    document.getElementById('DeactivationContainerThemebox').style.display = "none";
  }
}

// remove the deactivation container from the website
function DeactivateWebsiteFrame()
{
  if (document.getElementById('DeactivationContainer') != null) {
    document.getElementById('DeactivationContainer').style.display = "block";
  }
  if (document.getElementById('DeactivationContainerThemebox') != null) {
    document.getElementById('DeactivationContainerThemebox').style.display = "block";
  }
}

// functions for mouse-over and click events of Webshop-buttons
function MouseOverWebshopButton(source)
{
  source.firstChild.style.visibility = "visible";
}
function MouseOutWebshopButton(source)
{
  source.firstChild.style.visibility = "hidden";
}

// functions for mouse-over and click events of medium non-content-buttons
function MouseOverMediumButton(source)
{
  source.firstChild.style.visibility = "visible";
}
function MouseOutMediumButton(source)
{
  source.firstChild.style.visibility = "hidden";
}

// function for Forum-Management
function CheckAll(form_name, checkbox_name)
{
  var form = document.getElementById(form_name);
  if (form.ALL) {
    var c = form.ALL.checked;
  }
  for (var i = 0; i < form.elements.length; i++) {
    var e = form.elements[i];
    if (e.name != checkbox_name)
      continue;
    e.checked = c;
  }
}

/**
 * --------------------- Loginbox functionality ----------------------
 */

// initialisation of the loginbox status by the value of the variable
// 'loginStatus' which is provided to the HTML-document by PHP in the file
// 'header.inc'
function LoadLoginBox()
{
  if (loginStatus == "false") {
    document.getElementById('PlayNowContainer').childNodes[0].childNodes[1].childNodes[1].src = JS_DIR_IMAGES + "global/buttons/mediumbutton_login.png";
    document.getElementById('LoginstatusText_1').style.backgroundImage = "url('" + JS_DIR_IMAGES + "global/loginbox/loginbox-font-create-account.gif')";
    document.getElementById('LoginstatusText_2').style.backgroundImage = "url('" + JS_DIR_IMAGES + "global/loginbox/loginbox-font-create-account-over.gif')";
  } else {
    document.getElementById('PlayNowContainer').childNodes[0].childNodes[1].childNodes[1].src = JS_DIR_IMAGES + "global/buttons/mediumbutton_myaccount.png";
    document.getElementById('LoginstatusText_1').style.backgroundImage = "url('" + JS_DIR_IMAGES + "global/loginbox/loginbox-font-logout.gif')";
    document.getElementById('LoginstatusText_2').style.backgroundImage = "url('" + JS_DIR_IMAGES + "global/loginbox/loginbox-font-logout-over.gif')";
  }
}

// mouse-over and click events of the loginbox
function MouseOverLoginBoxText(source)
{
  source.lastChild.style.visibility = "visible";
  source.firstChild.style.visibility = "hidden";
}
function MouseOutLoginBoxText(source)
{
  source.firstChild.style.visibility = "visible";
  source.lastChild.style.visibility = "hidden";
}
function LoginButtonAction()
{
  if (loginStatus == "false") {
    window.location = JS_DIR_ACCOUNT + "?subtopic=accountmanagement";
  } else {
    window.location = JS_DIR_ACCOUNT + "?subtopic=accountmanagement";
  }
}
function LoginstatusTextAction(source)
{
  if (loginStatus == "false") {
    window.location = JS_DIR_ACCOUNT + "?subtopic=createaccount";
  } else {
    window.location = JS_DIR_ACCOUNT + "?subtopic=logoutaccount";
  }
}

/**
 * ------------------ Menu functionality ------------------
 */

/**
 * LOAD and SAVE the menu status by using arrays and the variable "self.name" which is a consistent JavaScript variable and allows to pass its values from the source page to the destination page
 *
 * "self.name" has the following format in this document: [menuname]=[value]&[menuname]=[value]& [...] & news=1&abouttibia=0&gameguides=0&library=0&community=0&forum=0&account=0&charactertrade=0&support=0&
 *
 * the variable 'unloadhelper' is used because IE needs the event OnBeforeUnload() and all other browsers OnUnload()
 */

var menu = new Array();
menu[0] = new Object();
var unloadhelper = false;
var menuItemName = '';

// load the menu and set the active submenu item by using the variable
// 'activeSubmenuItem' (provided to HTML-document by PHP in the file
// 'header.inc'
function LoadMenu()
{
  const submenu = document.getElementById("submenu_" + activeSubmenuItem);
  if (submenu) {
    submenu.style.color = "white";
  }
  const icon = document.getElementById("ActiveSubmenuItemIcon_" + activeSubmenuItem);
  if (icon) {
    icon.style.visibility = "visible";
  }
  if (self.name.lastIndexOf("&") == -1) {
    self.name = "news=1&abouttibia=0&gameguides=0&library=0&community=0&forum=0&account=0&charactertrade=0&support=0&";
  }
  FillMenuArray();
  // for mobile menu
  if (window.matchMedia('(max-width: 768px)').matches) {
    var submenuItem = document.getElementById(activeSubmenuItem);
    if (submenuItem) {
      var ParentID = submenuItem.closest('[class="Level1Block"]').id;
      for (menuItemName in menu[0]) {
        if (menuItemName == ParentID) {
          menu[0][menuItemName] = 1;
          $('.MobileMenuItems #' + ParentID + ' .Level1Entry').addClass('Level1ItemOpen');
        } else {
          menu[0][menuItemName] = 0;
        }
      }
    }
  }
  InitializeMenu();
  // for mobile menu
  $('#MobileMenu .Level2Block').removeClass('MobileMenuActiveItem');
  if (activeSubmenuItem) {
    $('#MobileMenu #' + activeSubmenuItem).addClass('MobileMenuActiveItem');
  }
}


function SaveMenu()
{
  if (unloadhelper == false) {
    SaveMenuArray();
    unloadhelper = true;
  }
}

// parse the values of the variable 'self.name' and store it in the array menu
// ATTENTION:
// if the user navigates from our website to another website which modifies
// self.name and returns to our page via the browsers back button
// our website receives the modified self.name value
function FillMenuArray()
{
  var MenuCount = 0;
  var mark1 = 0;
  var mark2 = 0;
  while (self.name.length > 0) {
    MenuCount++;
    mark1 = self.name.indexOf("=");
    mark2 = self.name.indexOf("&");
    // abort parsing of self.name when:
    // - a maximum 15 main menu points are parsed (our website uses currently
    // (16.06.2010) 10 main menu points)
    // - no more "=" or "&" characters are found in the string
    // - the string was parsed completely
    if (MenuCount > 15 || mark1 < 0 || mark2 < 0) {
      break;
    }
    menuItemName = self.name.substr(0, mark1);
    menu[0][menuItemName] = self.name.substring(mark1 + 1, mark2);
    self.name = self.name.substr(mark2 + 1, self.name.length);
  }
}

// hide or show the corresponding submenus
function InitializeMenu()
{
  for (menuItemName in menu[0]) {
    if (menu[0][menuItemName] == "0") {
      document.getElementById(menuItemName + "_Submenu").style.visibility = "hidden";
      document.getElementById(menuItemName + "_Submenu").style.display = "none";
      document.getElementById(menuItemName + "_Lights").style.visibility = "visible";
      document.getElementById(menuItemName + "_Extend").style.backgroundImage = "url(" + JS_DIR_IMAGES + "global/general/plus.gif)";
      $('#MobileMenu #' + menuItemName + ' .Level2Block').hide();
    } else {
      document.getElementById(menuItemName + "_Submenu").style.visibility = "visible";
      document.getElementById(menuItemName + "_Submenu").style.display = "block";
      document.getElementById(menuItemName + "_Lights").style.visibility = "hidden";
      document.getElementById(menuItemName + "_Extend").style.backgroundImage = "url(" + JS_DIR_IMAGES + "global/general/minus.gif)";
      $('#MobileMenu #' + menuItemName + ' .Level2Block').show();
    }
  }
}

// reconstruct the variable "self.name" out of the array menu
function SaveMenuArray()
{
  var stringSlices = "";
  var temp = "";
  for (menuItemName in menu[0]) {
    stringSlices = menuItemName + "=" + menu[0][menuItemName] + "&";
    temp = temp + stringSlices;
  }
  self.name = temp;
}

// onClick open or close submenus
function MenuItemAction(sourceId)
{
  if (menu[0][sourceId] == 1) {
    CloseMenuItem(sourceId);
    $('.MobileMenuItems #' + sourceId + ' .Level1Entry').removeClass('Level1ItemOpen');
  } else {
    OpenMenuItem(sourceId);
    $('.MobileMenuItems #' + sourceId + ' .Level1Entry').addClass('Level1ItemOpen');
  }
}
function OpenMenuItem(sourceId)
{
  if (window.matchMedia('(max-width: 768px)').matches) {
    for (menuItemName in menu[0]) {
      CloseMenuItem(menuItemName);
    }
  }
  menu[0][sourceId] = 1;
  document.getElementById(sourceId + "_Submenu").style.visibility = "visible";
  document.getElementById(sourceId + "_Submenu").style.display = "block";
  document.getElementById(sourceId + "_Lights").style.visibility = "hidden";
  document.getElementById(sourceId + "_Extend").style.backgroundImage = "url(" + JS_DIR_IMAGES + "global/general/minus.gif)";
  $('#MobileMenu #' + sourceId + ' .Level2Block').show();
}
function CloseMenuItem(sourceId)
{
  menu[0][sourceId] = 0;
  document.getElementById(sourceId + "_Submenu").style.visibility = "hidden";
  document.getElementById(sourceId + "_Submenu").style.display = "none";
  document.getElementById(sourceId + "_Lights").style.visibility = "visible";
  document.getElementById(sourceId + "_Extend").style.backgroundImage = "url(" + JS_DIR_IMAGES + "global/general/plus.gif)";
  $('#MobileMenu #' + sourceId + ' .Level2Block').hide();
}

// mouse-over effects of menubuttons and submenuitems
function MouseOverMenuItem(source)
{
  source.firstChild.style.visibility = "visible";
}
function MouseOutMenuItem(source)
{
  source.firstChild.style.visibility = "hidden";
}
function MouseOverSubmenuItem(source)
{
  source.style.backgroundColor = "#14433F";
}
function MouseOutSubmenuItem(source)
{
  source.style.backgroundColor = "#0D2E2B";
}

// display payment standby message
function PaymentStandBy(a_Source, a_Case)
{
  var m_Agree = false;
  if (a_Source == "setup" && a_Case != 1) {
    if (document.getElementById("CheckBoxAgreePayment").checked == true) {
      m_Agree = true;
    }
  }
  if (a_Source == "setup" && a_Case == 1) {
    if (document.getElementById("CheckBoxAgreePayment").checked == true && document.getElementById("CheckBoxAgreeSubscription").checked == true) {
      m_Agree = true;
    }
  }
  if (a_Source == "cancel") {
    m_Agree = true;
  }
  if (m_Agree == true) {
    document.getElementById("Step4MinorErrorBox").style.visibility = "hidden";
    document.getElementById("Step4MinorErrorBox").style.display = "none";
    document.getElementById("DisplayText").style.visibility = "hidden";
    document.getElementById("DisplayText").style.display = "none";
    document.getElementById("StandByMessage").style.visibility = "visible";
    document.getElementById("StandByMessage").style.display = "block";
    document.getElementById("DisplaySubmitButton").style.visibility = "hidden";
    document.getElementById("DisplaySubmitButton").style.display = "none";
    document.getElementById("DisplayBackButton").style.visibility = "hidden";
    document.getElementById("DisplayBackButton").style.display = "none";
  }
}

/**
 * ------------------ Exit Point Analysis -------------------
 */

// identify windows or linux client download
function NoteDownload(a_Event, a_LinkElement, a_ClientType, a_Source)
{
  if (a_LinkElement.classList.contains('DisabledLink')) {
    a_Event.preventDefault();
    return;
  }
  a_LinkElement.classList.add('DisabledLink');
  if (typeof a_Source === 'undefined') {
    a_Source = ''; // if source is not set, set a default value
  }
  parent.confirmclient.location = JS_DIR_ACCOUNT + 'downloadaction.php?clienttype=' + a_ClientType + '&source=' + a_Source;
  setTimeout(function() {
    if (a_LinkElement && a_LinkElement.classList && a_LinkElement.classList.contains('DisabledLink')) {
      a_LinkElement.classList.remove('DisabledLink');
    }
  }, 3000);
}

/**
 * ------------------------- functions related to forms --------------------------
 */

// set cursor focus in form (g_FormName) to field (g_FieldName)
function SetFormFocus()
{
  if (g_FormName.length > 0 && g_FieldName.length > 0) {
    var l_SetFocus = true;
    if (g_FormName == 'AccountLogin') {
      if (document.getElementsByName('loginemail')[0].value.length > 0) {
        l_SetFocus = false;
      }
    }
    if (l_SetFocus == true) {
      document.forms[g_FormName].elements[g_FieldName].focus();
    }
  }
}

// set cursor focus in form (a_FormName) to field (a_FieldName)
function SetFormFocusToArguments(a_FormName, a_FieldName)
{
  if (a_FormName.length > 0 && a_FieldName.length > 0) {
    document.forms[a_FormName].elements[a_FieldName].focus();
    document.forms[a_FormName].elements[a_FieldName].focus();
    document.forms[a_FormName].elements[a_FieldName].focus();
    document.forms[a_FormName].elements[a_FieldName].blur();
    document.forms[a_FormName].elements[a_FieldName].blur();
    document.forms[a_FormName].elements[a_FieldName].blur();
  }
}

// toggle masked texts with readable texts
function ToggleMaskedText(a_TextFieldID)
{
  m_DisplayedText = document.getElementById('Display' + a_TextFieldID).innerHTML;
  m_MaskedText = document.getElementById('Masked' + a_TextFieldID).innerHTML;
  m_ReadableText = document.getElementById('Readable' + a_TextFieldID).innerHTML;
  if (m_DisplayedText == m_MaskedText) {
    document.getElementById('Display' + a_TextFieldID).innerHTML = document.getElementById('Readable' + a_TextFieldID).innerHTML;
    document.getElementById('Button' + a_TextFieldID).src = JS_DIR_IMAGES + 'global/general/hide.gif';
  } else {
    document.getElementById('Display' + a_TextFieldID).innerHTML = document.getElementById('Masked' + a_TextFieldID).innerHTML;
    document.getElementById('Button' + a_TextFieldID).src = JS_DIR_IMAGES + 'global/general/show.gif';
  }
}

function FormatDate(a_DateTimeStamp, a_Format)
{
  l_Format = 'full';
  l_Date = new Date(a_DateTimeStamp);
  l_Output = l_Date.toString().substring(4);
  return l_Output;
}

function RedirectGET(a_Target)
{
  window.location = a_Target;
}

// PostParameters["KEY"] = "VALUE";
var PostParameters = new Object();

function RedirectPOST(a_Target, a_ParameterArray)
{
  const form = $('<form/>', {
    method: 'post',
    id: 'RedirectForm',
    action: a_Target
  }).hide();

  try { new URL(a_Target, window.location.href); } catch(e) { return; }

  $.each(a_ParameterArray, function(key, value) {
    $('<input/>', {
      type: 'hidden',
      name: String(key),
      value: String(value)
    }).appendTo(form);
  });
  
  form.appendTo('body');
  form.trigger('submit');
}

// -----------------------------
// functionality for screenshots
// -----------------------------

// define variables
var g_CurrentScreenshot = 0;
var g_NumberOfScreenshots = 0;
var g_Screenshots = new Array();
var g_ScreenshotTexts = new Array();

// set a certain screenshot
function SetScreenshot(a_Number)
{
  g_CurrentScreenshot = a_Number;
  // fade out the old screen shot
  $("#ScreenshotContainer").fadeTo("fast", 0, function()
  {
    // when animation is complete set the new screenshot to display
    $('#ScreenshotImage').attr('src', g_Screenshots[g_CurrentScreenshot].src);
    $('.ScreenshotTextRow').text(g_ScreenshotTexts[g_CurrentScreenshot]);
    // fade in the new screenshot
    $("#ScreenshotContainer").fadeTo("fast", 1, function()
    {
      // fade in animation is complete
    });
  });
}

// show the next screenshot
function ShowNextScreenshot()
{
  g_CurrentScreenshot = (g_CurrentScreenshot + 1);
  if (g_CurrentScreenshot > g_NumberOfScreenshots) {
    g_CurrentScreenshot = 1;
  }
  SetScreenshot(g_CurrentScreenshot);
}

// show the previous screenshot
function ShowPreviousScreenshot()
{
  g_CurrentScreenshot = (g_CurrentScreenshot - 1);
  if (g_CurrentScreenshot < 1) {
    g_CurrentScreenshot = g_NumberOfScreenshots;
  }
  SetScreenshot(g_CurrentScreenshot);
}

// show the light box with containing control elements and the screenshot
function ShowScreenshot(a_Number, a_NumberOfScreenshots)
{
  g_NumberOfScreenshots = a_NumberOfScreenshots;
  g_CurrentScreenshot = a_Number;
  // show light box
  $("#LightBox").fadeTo("fast", 1, function()
  {
    // animation complete.
  });
  $("#LightBoxBackground").fadeTo("fast", 0.75, function()
  {
    // animation complete.
  });
  // set the screenshot
  SetScreenshot(a_Number);
}

// preload all screenshots
function PreloadScreenshots(a_NumberOfScreenshots)
{
  for (i = 1; i <= a_NumberOfScreenshots; i++) {
    g_Screenshots[i] = new Image();
    g_Screenshots[i].src = JS_DIR_IMAGES + 'abouttibia/tibia_screenshot_' + i + '.png'
  }
}

// Use YouTupe API to control the video.

// Define global variable for the youtube player api otherwise safari will not play the video automatically.
var player = null;
//Load the youtube iFrame player API asynchronously.
var ConsentCookie = GetCookieValue('CookieConsentPreferences'); // only load the youtube api, when consent was given
if (ConsentCookie) {
  var ConsentObject = JSON.parse(decodeURIComponent(ConsentCookie));
  var SocialMediaConsent = ConsentObject.socialmedia;

  if (SocialMediaConsent) {
    var l_ElementTag = document.createElement('script');
    l_ElementTag.src = "https://www.youtube.com/iframe_api";
    var l_FirstScriptTag = document.getElementsByTagName('script')[0];
    l_FirstScriptTag.parentNode.insertBefore(l_ElementTag, l_FirstScriptTag);
  }
}

function onYouTubeIframeAPIReady() {
  player = new YT.Player('YouTubeVideo');
}

function StopVideoIfExists() {
  if (typeof player !== 'undefined' && !!player && typeof player.stopVideo === 'function') {
    player.stopVideo();
  }
}

function ImageInNewWindow(a_ImageSource) {
  DeactivateWebsiteFrame();
  $('#DeactivationContainer').css('z-index', '1001');

  const modal = document.createElement('div');
  modal.id = 'ImageModal';
  modal.classList.add('LightBoxContentToHide');
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-label', 'Selected image displayed in large format');

  const contentWrapper = document.createElement('div');
  contentWrapper.id = 'ImageModalContentWrapper';

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "X";
  closeBtn.id = 'ImageModalCloseButton';
  closeBtn.setAttribute('aria-label', 'Close popup with large image');
  closeBtn.onclick = function() {
    ActivateWebsiteFrame();
    DestroyImageModal();
  };
  contentWrapper.appendChild(closeBtn);
  
  const img = new Image();
  img.id = 'ImageModalImgElement';
  img.src = a_ImageSource;
  contentWrapper.appendChild(img);

  modal.appendChild(contentWrapper);
  document.body.appendChild(modal);
  document.body.classList.add('ModalOpen');
}

function DestroyImageModal() {
  const modal = document.getElementById('ImageModal');
  if (modal) {
    document.body.removeChild(modal);
  }
  document.body.classList.remove('ModalOpen');
}
