function runWodPlanner(t, e) {
    let d = ""
      , c = ""
      , H = ""
      , O = 0
      , o = null
      , g = null
      , h = null
      , v = []
      , y = null
      , b = ""
      , G = ""
      , M = ""
      , n = ""
      , r = ""
      , a = ""
      , oe = ""
      , l = ""
      , ue = ""
      , f = ""
      , w = ""
      , I = ""
      , Q = ""
      , _ = ""
      , N = ""
      , se = ""
      , de = ""
      , R = ""
      , T = ""
      , L = ""
      , x = ""
      , B = ""
      , ce = ""
      , S = ""
      , q = ""
      , U = ""
      , F = ""
      , fe = ""
      , ge = ""
      , he = ""
      , ve = ""
      , me = ""
      , pe = ""
      , ke = ""
      , Ae = null
      , we = null
      , $e = null
      , Ie = null
      , be = null
      , Ge = null
      , Me = null
      , Qe = null
      , _e = null
      , Re = null
      , Te = null
      , Le = null
      , xe = null
      , Be = null
      , Se = null
      , qe = null
      , ye = null
      , Pe = null
      , De = null
      , We = null
      , Ce = null
      , Ee = null
      , Ue = null
      , Fe = null
      , He = null
      , Oe = !1
      , Ne = !1
      , J = null;
    const u = new Map
      , V = new Map;
    let Je = []
      , Ve = []
      , ze = []
      , Ze = []
      , Ke = []
      , je = []
      , Xe = []
      , Ye = 0
      , en = 0
      , nn = 0;
    const P = {
        Knight: "knight",
        Druid: "druid",
        Sorcerer: "sorcerer",
        Paladin: "paladin",
        Monk: "monk",
        t: "TopLeft",
        l: "TopRight",
        i: "BottomLeft",
        o: "BottomRight",
        QTL0: "QTL0",
        QTL1: "QTL1",
        QTL2: "QTL2",
        QTL3: "QTL3",
        QTL4: "QTL4",
        QTL5: "QTL5",
        QTL6: "QTL6",
        QTL7: "QTL7",
        QTL8: "QTL8",
        QTR0: "QTR0",
        QTR1: "QTR1",
        QTR2: "QTR2",
        QTR3: "QTR3",
        QTR4: "QTR4",
        QTR5: "QTR5",
        QTR6: "QTR6",
        QTR7: "QTR7",
        QTR8: "QTR8",
        QBL0: "QBL0",
        QBL1: "QBL1",
        QBL2: "QBL2",
        QBL3: "QBL3",
        QBL4: "QBL4",
        QBL5: "QBL5",
        QBL6: "QBL6",
        QBL7: "QBL7",
        QBL8: "QBL8",
        QBR0: "QBR0",
        QBR1: "QBR1",
        QBR2: "QBR2",
        QBR3: "QBR3",
        QBR4: "QBR4",
        QBR5: "QBR5",
        QBR6: "QBR6",
        QBR7: "QBR7",
        QBR8: "QBR8",
        u: "Unique",
        g: "SkillBonus",
        h: "Leech",
        v: "Augmentation",
        m: "VesselResonance",
        p: "Other",
        k: "ModEffect",
        A: "ModAugCd",
        $: "ModAugCrit",
        I: "ModAugDmg",
        G: "ModAugHeal",
        M: "ModAugOther",
        _: "ModRevelation"
    }
      , m = {
        R: "#46b21c31",
        T: "#94c4126b",
        L: "#ae143431",
        B: "#ef1a386b",
        S: "#198d4031",
        q: "#18cd8f6b",
        P: "#841d9e31",
        D: "#e618da6b",
        W: "#80808067",
        C: 2,
        U: Math.PI / 180,
        F: 180 / Math.PI
    };
    let z = P.Knight
      , Z = []
      , K = []
      , j = null
      , X = null
      , Y = null
      , ee = null
      , ne = null
      , te = null;
    const p = 261
      , tn = 50
      , k = [{
        id: P.QTL0,
        radiusIndex: 0,
        startAngleGrad: 180,
        endAngleGrad: 270,
        quarter: P.t
    }, {
        id: P.QTL1,
        radiusIndex: 1,
        startAngleGrad: 180,
        endAngleGrad: 225,
        quarter: P.t
    }, {
        id: P.QTL3,
        radiusIndex: 1,
        startAngleGrad: 225,
        endAngleGrad: 270,
        quarter: P.t
    }, {
        id: P.QTL2,
        radiusIndex: 2,
        startAngleGrad: 180,
        endAngleGrad: 210,
        quarter: P.t
    }, {
        id: P.QTL4,
        radiusIndex: 2,
        startAngleGrad: 210,
        endAngleGrad: 240,
        quarter: P.t
    }, {
        id: P.QTL6,
        radiusIndex: 2,
        startAngleGrad: 240,
        endAngleGrad: 270,
        quarter: P.t
    }, {
        id: P.QTL5,
        radiusIndex: 3,
        startAngleGrad: 195,
        endAngleGrad: 225,
        quarter: P.t
    }, {
        id: P.QTL7,
        radiusIndex: 3,
        startAngleGrad: 225,
        endAngleGrad: 255,
        quarter: P.t
    }, {
        id: P.QTL8,
        radiusIndex: 4,
        startAngleGrad: 195,
        endAngleGrad: 255,
        quarter: P.t
    }, {
        id: P.QTR0,
        radiusIndex: 0,
        startAngleGrad: 270,
        endAngleGrad: 360,
        quarter: P.l
    }, {
        id: P.QTR3,
        radiusIndex: 1,
        startAngleGrad: 270,
        endAngleGrad: 315,
        quarter: P.l
    }, {
        id: P.QTR1,
        radiusIndex: 1,
        startAngleGrad: 315,
        endAngleGrad: 360,
        quarter: P.l
    }, {
        id: P.QTR6,
        radiusIndex: 2,
        startAngleGrad: 270,
        endAngleGrad: 300,
        quarter: P.l
    }, {
        id: P.QTR4,
        radiusIndex: 2,
        startAngleGrad: 300,
        endAngleGrad: 330,
        quarter: P.l
    }, {
        id: P.QTR2,
        radiusIndex: 2,
        startAngleGrad: 330,
        endAngleGrad: 360,
        quarter: P.l
    }, {
        id: P.QTR7,
        radiusIndex: 3,
        startAngleGrad: 285,
        endAngleGrad: 315,
        quarter: P.l
    }, {
        id: P.QTR5,
        radiusIndex: 3,
        startAngleGrad: 315,
        endAngleGrad: 345,
        quarter: P.l
    }, {
        id: P.QTR8,
        radiusIndex: 4,
        startAngleGrad: 285,
        endAngleGrad: 345,
        quarter: P.l
    }, {
        id: P.QBL0,
        radiusIndex: 0,
        startAngleGrad: 90,
        endAngleGrad: 180,
        quarter: P.i
    }, {
        id: P.QBL3,
        radiusIndex: 1,
        startAngleGrad: 90,
        endAngleGrad: 135,
        quarter: P.i
    }, {
        id: P.QBL1,
        radiusIndex: 1,
        startAngleGrad: 135,
        endAngleGrad: 180,
        quarter: P.i
    }, {
        id: P.QBL6,
        radiusIndex: 2,
        startAngleGrad: 90,
        endAngleGrad: 120,
        quarter: P.i
    }, {
        id: P.QBL4,
        radiusIndex: 2,
        startAngleGrad: 120,
        endAngleGrad: 150,
        quarter: P.i
    }, {
        id: P.QBL2,
        radiusIndex: 2,
        startAngleGrad: 150,
        endAngleGrad: 180,
        quarter: P.i
    }, {
        id: P.QBL7,
        radiusIndex: 3,
        startAngleGrad: 105,
        endAngleGrad: 135,
        quarter: P.i
    }, {
        id: P.QBL5,
        radiusIndex: 3,
        startAngleGrad: 135,
        endAngleGrad: 165,
        quarter: P.i
    }, {
        id: P.QBL8,
        radiusIndex: 4,
        startAngleGrad: 105,
        endAngleGrad: 165,
        quarter: P.i
    }, {
        id: P.QBR0,
        radiusIndex: 0,
        startAngleGrad: 0,
        endAngleGrad: 90,
        quarter: P.o
    }, {
        id: P.QBR1,
        radiusIndex: 1,
        startAngleGrad: 0,
        endAngleGrad: 45,
        quarter: P.o
    }, {
        id: P.QBR3,
        radiusIndex: 1,
        startAngleGrad: 45,
        endAngleGrad: 90,
        quarter: P.o
    }, {
        id: P.QBR2,
        radiusIndex: 2,
        startAngleGrad: 0,
        endAngleGrad: 30,
        quarter: P.o
    }, {
        id: P.QBR4,
        radiusIndex: 2,
        startAngleGrad: 30,
        endAngleGrad: 60,
        quarter: P.o
    }, {
        id: P.QBR6,
        radiusIndex: 2,
        startAngleGrad: 60,
        endAngleGrad: 90,
        quarter: P.o
    }, {
        id: P.QBR5,
        radiusIndex: 3,
        startAngleGrad: 15,
        endAngleGrad: 45,
        quarter: P.o
    }, {
        id: P.QBR7,
        radiusIndex: 3,
        startAngleGrad: 45,
        endAngleGrad: 75,
        quarter: P.o
    }, {
        id: P.QBR8,
        radiusIndex: 4,
        startAngleGrad: 15,
        endAngleGrad: 75,
        quarter: P.o
    }]
      , rn = [{
        quarter: P.t
    }, {
        quarter: P.l
    }, {
        quarter: P.i
    }, {
        quarter: P.o
    }];
    function an(e) {
        switch (e) {
        case P.t:
            return m.R;
        case P.l:
            return m.L;
        case P.i:
            return m.S;
        case P.o:
            return m.P;
        default:
            return m.R
        }
    }
    function ln(e) {
        switch (e) {
        case P.t:
            return m.T;
        case P.l:
            return m.B;
        case P.i:
            return m.q;
        case P.o:
            return m.D;
        default:
            return m.T
        }
    }
    function on(e) {
        return e * (tn + m.C) + 1
    }
    function un(e) {
        return on(e) + tn
    }
    function sn(e) {
        var n = e.x - p
          , t = e.y - p
          , r = Math.sqrt(n * n + t * t);
        let a = Math.atan(t / n) * m.F
          , l = (n < 0 ? a += 180 : 0 < n && t < 0 && (a += 360),
        null);
        for (const u of k) {
            var i = on(u.radiusIndex) - m.C / 2
              , o = un(u.radiusIndex) + m.C / 2;
            if (i <= r && r <= o && u.startAngleGrad <= a && a < u.endAngleGrad) {
                l = u.id;
                break
            }
        }
        return l
    }
    function dn(e) {
        for (let t = 0; t < v.length; t++) {
            var n = v[t];
            if (n.H(e))
                return n.quarter
        }
        return null
    }
    function cn(e) {
        for (let t = 0; t < v.length; t++) {
            var n = v[t];
            if (n.O(e))
                return n.quarter
        }
        return null
    }
    function fn(e, n, t, r) {
        h.beginPath(),
        0 == e ? h.moveTo(p, p) : h.arc(p, p, e, t, r, !1),
        h.arc(p, p, n, r, t, !0),
        h.closePath()
    }
    function gn(e, n) {
        h.beginPath(),
        1 != e && h.moveTo(n.N, n.J),
        h.arc(n.N, n.J, n.V, -90 * m.U, (360 * e - 90) * m.U, !1),
        h.closePath()
    }
    function hn() {
        h.save();
        for (const g of k) {
            let e = 0
              , n = !1;
            var t = Z.find(e => e.id === g.id);
            t && (e = t.fillPercent,
            n = t.unlocked),
            r = g.radiusIndex,
            a = g.startAngleGrad,
            l = g.endAngleGrad,
            i = g.quarter,
            o = e,
            u = n,
            f = c = d = s = t = void 0,
            t = a * m.U,
            s = l * m.U,
            d = on(r),
            c = un(r),
            f = d + o * (c - d),
            f = o < .5 ? Math.ceil(f) : Math.floor(f),
            0 < o && (fn(d, f, t, s),
            A(ln(i))),
            u && (fn(d, c, t, s),
            A(an(i)))
        }
        var r, a, l, i, o, u, s, d, c, f;
        h.restore()
    }
    function vn() {
        var e, n, t, r;
        h.save(),
        null != j && (e = k.find(e => e.id === j)) && (n = e.radiusIndex,
        t = e.startAngleGrad,
        r = e.endAngleGrad,
        fn(on(n), un(n), t * m.U, r * m.U),
        A(m.W)),
        h.restore()
    }
    function mn() {
        var e, n, t, r;
        h.save(),
        null != X && (e = k.find(e => e.id === X)) && (n = e.radiusIndex,
        t = e.startAngleGrad,
        r = e.endAngleGrad,
        fn(on(n) - m.C / 2, un(n) + m.C / 2, t * m.U, r * m.U),
        h.lineWidth = m.C,
        h.strokeStyle = "white",
        h.stroke()),
        h.restore()
    }
    function pn() {
        var e = $("#" + ge);
        if (e && e[0]) {
            g = e[0],
            h = g.getContext("2d");
            {
                e = $("#" + ge);
                let t = null
                  , r = null;
                function a() {
                    t = null,
                    r = null
                }
                e.on("contextmenu", function(e) {
                    return bn(e),
                    a(),
                    $n(e),
                    null != X && Nn(Gn(e)),
                    !1
                }),
                e.on("click", function(e) {
                    bn(e),
                    $n(e)
                }),
                e.on("mousemove", function(e) {
                    var n, t, r, a;
                    e = e,
                    n = j,
                    t = Y,
                    r = ne,
                    a = In(e),
                    j = sn(a),
                    Y = dn(a),
                    ne = cn(a),
                    n === j && t === Y && r === ne || (kn(),
                    Rn(fe, j, Y, ne, !1))
                }),
                e.on("mouseout", function(e) {
                    j = null,
                    Y = null,
                    ne = null,
                    kn()
                }),
                e.on("touchstart", function(e) {
                    e = e.originalEvent || e,
                    DeactivateHelperDiv(),
                    e.touches && 1 == e.touches.length && (t = new Date,
                    r = e.touches[0])
                }),
                e.on("touchmove touchcancel", function() {
                    a()
                }),
                e.on("touchend", function(e) {
                    var n;
                    bn(e),
                    r && t && ($n(r),
                    n = (new Date).getTime() - t.getTime(),
                    null != X) && 500 < n && Nn(),
                    a()
                })
            }
            re()
        }
    }
    function re() {
        if (Ae && we && $e && Ie && be && Ge && Me && Qe && _e && Re && Te && Le && xe && Be && Se && qe && ye && Pe && De && We && Ce && Ee && Ue && Fe && 0 < Z.length && 0 < K.length && Oe && g && h) {
            h.save(),
            h.drawImage(Ae, 0, 0),
            h.restore(),
            hn(),
            j && vn();
            {
                h.save();
                let e = be;
                switch (z) {
                case P.Knight:
                    e = be;
                    break;
                case P.Sorcerer:
                    e = Me;
                    break;
                case P.Paladin:
                    e = Qe;
                    break;
                case P.Druid:
                    e = Ge;
                    break;
                case P.Monk:
                    e = _e
                }
                h.drawImage(e, 0, 0),
                h.restore()
            }
            var e = Ce.height
              , t = Ee.height
              , l = {};
            l[P.t] = 0,
            l[P.l] = 0,
            l[P.i] = 0,
            l[P.o] = 0,
            h.save();
            for (let n = 0; n < k.length; n++) {
                var i = function(e) {
                    return (e.startAngleGrad + e.endAngleGrad) / 2 * m.U
                }(k[n])
                  , o = function(e) {
                    var n = (on(e.radiusIndex) + un(e.radiusIndex)) / 2;
                    return n + (n < un(0) ? 2 : 0)
                }(k[n])
                  , u = Math.round(Math.cos(i) * o + p - e / 2)
                  , i = Math.round(Math.sin(i) * o + p - e / 2)
                  , o = Z.find(e => e.id === k[n].id)
                  , r = o.mediumPerkId
                  , s = o.smallPerkId;
                let a = !1;
                if (o.mediumPerkCategory === P.m && 1 === o.fillPercent) {
                    const f = k[n].quarter;
                    var d = K.find(e => e.id === f);
                    if (d && d.hasGem && d.gemQuality >= l[f]) {
                        a = !0,
                        l[f]++;
                        let e = 0
                          , n = De
                          , t = Ue
                          , r = 0;
                        switch (l[f]) {
                        case 1:
                            e = d.keyBasicMod1;
                            break;
                        case 2:
                            e = d.keyBasicMod2;
                            break;
                        case 3:
                            e = d.keySupremeMod,
                            n = We,
                            t = Fe,
                            r = -5
                        }
                        var o = n.height
                          , c = t.height;
                        h.drawImage(t, 0, 0, c, c, u - 1, i - 1, c, c),
                        h.drawImage(n, e * o, 0, o, o, u, i + r, o, o)
                    }
                }
                a || h.drawImage(Ce, r * e, 0, e, e, u, i, e, e),
                h.drawImage(Ee, s * t, 0, t, t, u - 3, i + 17, t, t)
            }
            if (h.restore(),
            v.length !== rn.length) {
                v = [];
                let a = 0;
                rn.forEach(n => {
                    var e = K.find(e => e.id === n.quarter)
                      , t = an(n.quarter)
                      , r = ln(n.quarter);
                    switch (n.quarter) {
                    case P.t:
                        a = 180;
                        break;
                    case P.l:
                        a = 270;
                        break;
                    case P.i:
                        a = 90;
                        break;
                    default:
                        P.o;
                        a = 0
                    }
                    e = new Vn(e,t,r,a);
                    v.push(e)
                }
                )
            } else
                v.forEach(n => {
                    var e = K.find(e => e.id === n.quarter);
                    e && (n.largePerkId = e.largePerkId,
                    n.level = e.level,
                    n.fillPercent = e.fillPercent,
                    n.vesselLevel = e.vesselLevel,
                    n.hasGem = e.hasGem,
                    n.gemQuality = e.gemQuality,
                    n.socketBezelImgId = e.socketBezelImgId,
                    n.gemImgId = e.gemImgId)
                }
                );
            v.forEach(e => {
                let n = Re;
                switch (e.level) {
                case 0:
                    n = Re;
                    break;
                case 1:
                    n = Te;
                    break;
                case 2:
                    n = Le;
                    break;
                default:
                    n = xe
                }
                let t = we
                  , r = (0 < e.vesselLevel && (t = $e),
                0);
                switch (e.quarter) {
                case P.t:
                    r = 0;
                    break;
                case P.l:
                    r = 90;
                    break;
                case P.o:
                    r = 180;
                    break;
                case P.i:
                    r = 270;
                    break;
                default:
                    r = 0
                }
                var a, l, i;
                h.save(),
                r && An(r),
                e.quarter != P.l && e.quarter != P.i || wn(t),
                h.drawImage(t, 0, 0),
                h.restore(),
                h.save(),
                gn((o = e).fillPercent, o),
                A(o.Z),
                gn(1, o),
                A(o.K),
                h.restore(),
                h.save(),
                a = ((o = e).j + 40) * m.U,
                l = (o.j + 50) * m.U,
                h.beginPath(),
                h.arc(p, p, o.X, a, l, !1),
                h.arc(p, p, o.Y, l, a, !0),
                h.closePath(),
                A(o.Z),
                A(o.Z),
                A(o.Z),
                h.restore(),
                (o = e).quarter === Y && (h.save(),
                gn(1, o),
                A(m.W),
                h.restore()),
                (o = e).quarter === ne && (h.save(),
                h.beginPath(),
                h.arc(o.ee, o.ne, o.te, 0 * m.U, 360 * m.U, !1),
                h.closePath(),
                A(m.W),
                h.restore());
                h.save(),
                r && An(r),
                h.globalAlpha = .4,
                h.drawImage(Ie, 0, 0),
                h.restore(),
                h.save(),
                r && An(r),
                e.quarter != P.l && e.quarter != P.i || wn(n),
                h.drawImage(n, 0, 0),
                h.restore(),
                o = e,
                l = Be.height,
                a = l / 2,
                i = o.N - a,
                a = o.J - a,
                h.save(),
                h.drawImage(Be, o.largePerkId * l, 0, l, l, i, a, l, l),
                h.restore();
                var o = e
                  , o = (o.quarter === ee && (h.save(),
                i = Math.round(o.N - o.V + 1),
                a = Math.round(o.J - o.V + 1),
                h.drawImage(Se, i, a),
                h.restore()),
                e)
                  , o = (o.hasGem && (l = qe.height,
                a = o.ee - (i = l / 2),
                i = o.ne - i,
                h.save(),
                h.drawImage(qe, o.gemImgId * l, 0, l, l, a, i, l, l),
                h.restore()),
                o = e,
                a = ye.height,
                i = a / 2,
                l = o.ee - i,
                i = o.ne - i,
                h.save(),
                h.drawImage(ye, o.socketBezelImgId * a, 0, a, a, l, i, a, a),
                h.restore(),
                e);
                o.quarter === te && (h.save(),
                l = Math.round(o.ee - o.te - 1),
                i = o.quarter === P.t || o.quarter === P.l ? -2 : 0,
                i = Math.round(o.ne - o.te + i),
                h.drawImage(Pe, l, i),
                h.restore())
            }
            ),
            X && mn()
        }
    }
    function kn() {
        g && h && (h.clearRect(0, 0, g.width, g.height),
        re())
    }
    function A(e) {
        h.fillStyle = e,
        h.globalCompositeOperation = "lighter",
        h.mozFillRule = "evenodd",
        h.fill("evenodd")
    }
    function An(e) {
        h.translate(p, p),
        h.rotate(e * m.U),
        h.translate(-p, -p)
    }
    function wn(e) {
        h.translate(e.height / 2, e.width / 2),
        h.rotate(-90 * m.U),
        h.scale(-1, 1),
        h.translate(-e.width / 2, -e.height / 2)
    }
    function $n(e) {
        var n = X
          , t = ee
          , r = te
          , a = In(e);
        X = sn(a),
        ee = dn(a),
        te = cn(a),
        n === X && t === ee && r === te || (j === X && Y === ee && ne === te || (j = X,
        Y = ee,
        ne = te,
        Rn(fe, j, Y, ne, !1)),
        kn(),
        Rn(N, X, ee, te, !0))
    }
    function In(e) {
        var n = g.getBoundingClientRect();
        return {
            x: e.clientX - n.left,
            y: e.clientY - n.top
        }
    }
    function bn(e) {
        e.cancelable && e.preventDefault(),
        e.stopPropagation()
    }
    function Gn(n) {
        if (n.altKey || n.shiftKey || n.ctrlKey) {
            let e = 1;
            return n.shiftKey && (e *= 10),
            n.ctrlKey && (e *= 100),
            e
        }
        return 0
    }
    function Mn(e) {
        return /^$|^[-_.~a-zA-Z0-9]{3,90}$/.test(e)
    }
    function Qn(n) {
        var e = $("#" + a + "_" + n);
        e && e[0] && (n === z && (e[0].setAttribute("checked", "checked"),
        e.prop("checked", !0)),
        e[0].addEventListener("click", function() {
            var e;
            (e = n) !== z && s(!1, null, "setVocation", u.get(e))
        }))
    }
    function _n(n) {
        if (n && n[0]) {
            let e = n.val().trim();
            var t = e.match(/code=([-_.~a-zA-Z0-9]+)/);
            Mn(e = t ? t[1] : e) ? (n.val(e),
            Fn(e)) : (ae(se),
            ae(ce))
        }
    }
    function ae(e) {
        var n = $("#" + e);
        n && n[0] && n[0].classList.remove("hide")
    }
    function le(e) {
        var n = $("#" + e);
        return n && n[0] && (n[0].classList.add("hide"),
        1)
    }
    function D(e) {
        var n = $("#" + e);
        n && n[0] && n[0].classList.remove("Locked")
    }
    function W(e) {
        var n = $("#" + e);
        n && n[0] && n[0].classList.add("Locked")
    }
    function ie(e, n, t, r, a) {
        var l = $("#" + e);
        l && l[0] && (t ? l.html(n) : l.text(n),
        r) && Wn(l[0], a, r)
    }
    function Rn(e, n, t, r, a) {
        if (y) {
            var l = e + "-empty"
              , i = e + "-large"
              , o = e + "-medium"
              , u = e + "-dedication"
              , s = e + "-conviction"
              , d = e + "-revelation"
              , c = e + "-buttons"
              , f = e + "-socket"
              , g = e + "-gem"
              , h = e + "-vessel";
            if (null != n) {
                le(l),
                le(i),
                le(f);
                var v = Z.find(e => e.id === n);
                if (v) {
                    Tn(e, v);
                    var m = u
                      , p = s
                      , k = v
                      , A = a;
                    if (k) {
                        var w, I, b, G, u = m + "-value", s = y.SmallPerkInfos[k.smallPerkId];
                        let e = ""
                          , n = "";
                        k.smallPerkHasSecondaryEffect ? (R = y.SmallPerkInfos[0],
                        w = y.SmallPerkInfos[1],
                        b = E(R.Name),
                        M = E(w.Name),
                        I = C(R.FormatType, k.smallPerkPrimaryEffectValue),
                        G = C(w.FormatType, k.smallPerkSecondaryEffectValue),
                        I = "" + I + b,
                        G = "" + G + M,
                        e = I + "<br>" + G,
                        A && (I = C(R.FormatType, k.smallPerkPrimaryEffectIncrease),
                        G = C(w.FormatType, k.smallPerkSecondaryEffectIncrease),
                        R = "" + I + b,
                        w = "" + G + M,
                        n = R + "<br>" + w)) : (I = E(s.Name),
                        b = C(s.FormatType, k.smallPerkPrimaryEffectValue),
                        e = "" + b + I,
                        A && (G = C(s.FormatType, k.smallPerkPrimaryEffectIncrease),
                        n = "" + G + I)),
                        A && (n = y.SmallPerkInfos.PerSmallPerkCaption + "<br>" + n,
                        s.LongInfo) && (n = s.LongInfo + "<br><br>" + n),
                        ie(u, e, !0),
                        (0 === k.currentSkillPoints ? W : D)(u),
                        xn(m, y.SmallPerkInfos, "", n);
                        var M = p + "-value"
                          , Q = y.MediumPerkInfos[k.mediumPerkId];
                        let t = ""
                          , r = "";
                        switch (k.mediumPerkCategory) {
                        case P.v:
                            t = E(Q.Name) + "<br>",
                            t += En(k.mediumPerkValue, Q, !0),
                            A && (r = y.MediumPerkInfos.AugGeneralInfo);
                            break;
                        case P.h:
                            var _ = C(Q.FormatType, k.mediumPerkValue);
                            t = "" + _ + E(Q.Name),
                            A && (r = y.MediumPerkInfos.GeneralInfo);
                            break;
                        case P.g:
                            t = C(Q.FormatType, k.mediumPerkValue),
                            t = (t += E(Q.Name) + "<br>") + Q.LongInfo,
                            A && (r = y.MediumPerkInfos.GeneralInfo);
                            break;
                        case P.u:
                            _ = Un(Q.LongInfo);
                            t = E(Q.Name) + "<br>",
                            t = (t += `<span title="${_}">`) + _ + "</span>",
                            A && (r = y.MediumPerkInfos.GeneralInfo);
                            break;
                        case P.m:
                            t = E(Q.Name) + "<br>",
                            t += Q.LongInfo,
                            A && (r = y.MediumPerkInfos.GeneralInfo);
                            break;
                        default:
                            P.p;
                            t = E(Q.Name) + "<br>",
                            t += Un(Q.LongInfo),
                            A && (r = y.MediumPerkInfos.GeneralInfo)
                        }
                        ie(M, t, !0),
                        (!(k.mediumPerkCategory === P.v && 1 <= k.mediumPerkValue) && k.fillPercent < 1 ? W : D)(M),
                        xn(p, y.MediumPerkInfos, "", r)
                    }
                    ae(o),
                    (v.unlocked && v.editable ? ae : le)(c)
                }
            } else if (null != t) {
                le(l),
                le(o),
                le(f);
                var R = K.find(e => e.id === t);
                R && (Tn(e, R),
                m = d,
                p = a,
                (L = R) && (w = m + "-name",
                s = m + "-description",
                u = `(${y.LargePerkLevelNames[L.level]})`,
                v = y.LargePerkInfos,
                c = v[L.largePerkId],
                d = E(c.Name),
                S = p ? v.GeneralInfo : "",
                Bn(m, Be, L.largePerkId, ["LargePerkIcon"]),
                T = p ? c.LongInfoPerLevel[L.level] : "",
                ie(w, d, !1, T, d),
                ie(s, c.ShortInfo),
                (0 === L.level ? (W(w),
                W(s),
                W) : (D(w),
                D(s),
                D))(m + "-icon"),
                xn(m, v, u, S)),
                ae(i))
            } else if (null != r) {
                Tn(e, null),
                le(l),
                le(o),
                le(i);
                var T = K.find(e => e.id === r);
                if (T) {
                    var L = g
                      , x = h
                      , B = T;
                    if (B) {
                        d = y.BasicModEffectInfos,
                        c = y.SupremeModInfos,
                        s = y.VesselInfos;
                        if (d && c && s) {
                            var u = L + "-name"
                              , S = L + "-modgrades"
                              , g = L + "-mod1"
                              , h = L + "-mod2"
                              , q = L + "-mod3";
                            let e = 0
                              , n = s.NoGemInVesselInfo
                              , t = (B.hasGem && (e = B.gemQuality + 1,
                            n = s.GemNames[B.gemQuality][z]),
                            "");
                            a && (t = s.GemInfo + "<br><br>All mods shown in the Wheel of Destiny Planner have their grade set to a maximum of IV."),
                            ie(u, n, !1, t, n),
                            !function(e, n) {
                                for (let r = 0; r < 3; r++) {
                                    var t = $(`#${e}-` + (r + 1));
                                    t && t[0] && (r < n ? t[0].classList.remove("hide") : t[0].classList.add("hide"))
                                }
                            }(S, e),
                            yn(g, B.keyBasicMod1, B.valueBasicMod1, d),
                            yn(h, B.keyBasicMod2, B.valueBasicMod2, d),
                            !function(n, t, e) {
                                if (t < 0)
                                    ie(n, "");
                                else {
                                    var r = e[t];
                                    if (r) {
                                        let e = r.EffectInfo[3];
                                        r.Name && (e = E(r.Name, !0) + "<br>" + e),
                                        -1 === Xe.indexOf(t) && (e = `<div class="InvalidMod ColorRed">${e}</div>`),
                                        ie(n, e, !0)
                                    } else
                                        ie(n, "")
                                }
                            }(q, B.keySupremeMod, c),
                            Bn(g, De, B.keyBasicMod1, ["ModIcon"]),
                            Bn(h, De, B.keyBasicMod2, ["ModIcon"]),
                            Bn(q, We, B.keySupremeMod, ["ModIcon", "SupremeMod"]),
                            (0 < B.vesselLevel ? (D(g),
                            D) : (W(g),
                            W))(g + "-icon"),
                            (1 < B.vesselLevel ? (D(h),
                            D) : (W(h),
                            W))(h + "-icon"),
                            (2 < B.vesselLevel ? (D(q),
                            D) : (W(q),
                            W))(q + "-icon"),
                            Sn(g + "-dropdown", 1, e, B.keyBasicMod1, [B.keyBasicMod2]),
                            Sn(h + "-dropdown", 2, e, B.keyBasicMod2, [B.keyBasicMod1]),
                            Sn(q + "-dropdown", 3, e, B.keySupremeMod);
                            u = x + "-header",
                            S = x + "-value",
                            d = s.VesselActivation[B.vesselLevel],
                            c = a ? s.VesselInfo : "";
                            ie(u, d, !1, c, d),
                            s.ExtraDamageHealingDisplayName ? (g = `+${B.vesselDamageHealingBonus} ` + s.ExtraDamageHealingDisplayName,
                            ie(S, g)) : ie(S, ""),
                            (B.hasGem && B.vesselLevel === e ? D : W)(S)
                        }
                    }
                    ae(f)
                }
            } else
                Tn(e, null),
                le(o),
                le(i),
                le(f),
                ae(l)
        }
    }
    function Tn(e, n) {
        var t, r, a, l, i, o = e + "-bar";
        (n ? (l = o + "-filling",
        t = o + "-text",
        r = n.maxSkillPoints || 0,
        a = Math.min(n.currentSkillPoints || 0, r),
        (l = $("#" + l)) && l[0] && (i = 0 === r ? 0 : Math.round(a / r * 1e3) / 10,
        l[0].style.width = i + "%"),
        ie(t, a + "/" + r),
        ae) : le)(o)
    }
    function Ln(e, n) {
        var t = $("#" + a + "_" + e);
        t && t[0] && (t[0].checked = n)
    }
    function xn(e, n, t, r) {
        var a = $("#" + e + "-header");
        if (a && a[0] && n && n.DisplayName) {
            a.empty();
            let e = n.DisplayName;
            t && (e = e + " " + t),
            a.text(e),
            r && Wn(a[0], n.DisplayName, r)
        }
    }
    function Bn(e, n, t, r=[]) {
        var a = $("#" + e + "-icon");
        if (a && a[0] && (a.empty(),
        n)) {
            var l, i = n.height;
            a[0].style = `min-width: ${i}px; max-width: ${i}px; height: ${i}px;`;
            for (let e = 0; e < r.length; e++)
                a[0].classList.add(r[e]);
            -1 < t && ((l = document.createElement("img")).setAttribute("src", n.getAttribute("src")),
            l.style = `margin-left: -${t * i}px;`,
            a[0].appendChild(l))
        }
    }
    function Sn(e, r, n, l, i=[]) {
        const o = $(`select[name="${e}"]`);
        if (o && o[0]) {
            o.empty();
            const d = y.BasicModEffectInfos
              , c = y.SupremeModInfos;
            let t = null;
            if (n <= r && ((t = document.createElement("option")).setAttribute("value", -1),
            t.textContent = "(no Mod)",
            o[0].appendChild(t)),
            n + 1 < r)
                o[0].setAttribute("disabled", !0);
            else {
                o[0].removeAttribute("disabled");
                let a = !1;
                if (3 === r) {
                    if (Xe.sort( (e, n) => {
                        var t = c[e]
                          , r = c[n];
                        return t.SummaryPriority !== r.SummaryPriority ? t.SummaryPriority - r.SummaryPriority : t.NameSummary > r.NameSummary ? 1 : -1
                    }
                    ),
                    Xe.forEach(n => {
                        var t = c[n];
                        if (t && (!i.includes(n) || n === l)) {
                            var r = document.createElement("option");
                            r.setAttribute("value", n);
                            let e = t.EffectInfo[3];
                            t.Name && (e = `${E(t.Name, !0)} (${e})`),
                            r.textContent = e,
                            a || n !== l || (a = !0,
                            r.setAttribute("selected", !0)),
                            o[0].appendChild(r)
                        }
                    }
                    ),
                    !a)
                        if (-1 < l) {
                            var u = c[l];
                            if (u) {
                                var s = document.createElement("option");
                                s.setAttribute("value", l);
                                let e = u.EffectInfo[3];
                                u.Name && (e = `${E(u.Name, !0)} (${e})`),
                                s.textContent = e,
                                s.setAttribute("selected", !0),
                                o[0].appendChild(s)
                            }
                        } else
                            t && t.setAttribute("selected", !0)
                } else {
                    let e = []
                      , n = [];
                    1 === r ? (e = Ke,
                    n = je) : 2 === r && (e = je,
                    n = Ke),
                    (e = -1 < l && !e.find(e => e.id === l) && (u = n.find(e => e.id === l)) ? e.concat(u) : e).forEach(e => {
                        var n, t;
                        i.includes(e.id) && e.id !== l || (n = qn(e.effects, d)).length && ((t = document.createElement("option")).setAttribute("value", e.id),
                        t.textContent = n.join(" / "),
                        a || e.id !== l || (a = !0,
                        t.setAttribute("selected", !0)),
                        o[0].appendChild(t))
                    }
                    ),
                    !a && t && t.setAttribute("selected", !0)
                }
            }
        }
    }
    function qn(e, n) {
        if (!e || !e.length || !n)
            return [];
        var t = [];
        for (let i = 0; i < e.length; i++) {
            var r, a = e[i].id, l = e[i].value, a = n[a];
            a && (r = (r = "") + Cn(a.FormatType, l) + E(a.Name),
            t.push(r))
        }
        return t
    }
    function yn(e, n, t, r) {
        var a;
        !(n < 0) && (a = qn(t, r)).length ? ie(e, a.join("<br>"), !0) : ie(e, "")
    }
    function Pn() {
        if (y) {
            let e = [];
            const A = y.SmallPerkInfos
              , w = (A && (e = Je.map(e => {
                var n = A[e.id]
                  , t = {};
                return t.name = E(n.Name),
                t.value = C(n.FormatType, e.value),
                t.re = t.name,
                t.ae = n.LongInfo,
                t
            }
            )),
            []);
            var t, r, a, l, i = y.MediumPerkInfos;
            if (i) {
                for (let e = 0; e < Ve.length; e++) {
                    var o, u, s = Ve[e];
                    0 !== s.value && (o = i[s.id]) && (u = s.category === P.v ? En(s.value, o) : o.LongInfo,
                    t = s,
                    a = E((r = o).Name),
                    l = u,
                    (s = {}).name = a,
                    s.value = C(r.FormatType, t.value),
                    s.re = a,
                    s.ae = l,
                    s.priority = r.SummaryPriority,
                    w.push(s))
                }
                w.sort( (e, n) => e.priority !== n.priority ? e.priority - n.priority : e.name > n.name ? 1 : -1)
            }
            let n = [];
            const $ = y.LargePerkInfos
              , I = ($ && ((n = K.map(e => {
                var n = $[e.largePerkId]
                  , t = {};
                return t.name = E(n.Name),
                t.value = y.LargePerkLevelNames[e.level],
                t.re = t.name,
                t.ae = n.LongInfoPerLevel[e.level],
                t
            }
            )).sort( (e, n) => e.name > n.name ? 1 : -1),
            (g = {}).name = $.ExtraDamageHealingDisplayName,
            g.value = "+" + Ye,
            g.re = g.name,
            g.ae = $.ExtraDamageHealingInfo,
            n.unshift(g)),
            []);
            var d, c = y.BasicModEffectInfos, f = y.SupremeModInfos, g = y.VesselInfos;
            if (c && f && g) {
                function h(e, n, t, r, a) {
                    var l = {};
                    l.name = t,
                    l.value = Cn(n.FormatType, e),
                    l.re = t,
                    l.ae = r || "",
                    l.priority = n.SummaryPriority,
                    a && (l.icon = a),
                    I.push(l)
                }
                for (let e = 0; e < ze.length; e++) {
                    var v, m = ze[e];
                    0 !== m.value && (v = c[m.id]) && h(m.value, v, E(v.Name), v.LongInfo)
                }
                for (let n = 0; n < Ze.length; n++) {
                    var p = Ze[n];
                    if (0 !== p.value) {
                        var k = f[p.id];
                        if (k) {
                            let e = "";
                            switch (p.category) {
                            case P.A:
                                e = b;
                                break;
                            case P.$:
                                e = G;
                                break;
                            case P.I:
                            case P.G:
                                e = M
                            }
                            h(p.value, k, E(k.NameSummary), function(e, n, t) {
                                if (!e)
                                    return "";
                                let r = n;
                                0 <= t.indexOf("FromInt") && (r = 100 * n);
                                return e.replaceAll("<ReplaceMe>", r)
                            }(k.EffectInfoSummary, p.value, k.FormatType), e)
                        }
                    }
                }
                0 < nn && ((d = {}).name = g.MomentumName,
                d.value = Cn(g.MomentumFormat, nn),
                d.re = d.name,
                d.ae = g.MomentumTooltip,
                d.priority = g.MomentumSummaryPriority,
                I.push(d)),
                I.sort( (e, n) => e.priority !== n.priority ? e.priority - n.priority : e.name > n.name ? 1 : -1),
                0 < en && ((d = {}).name = g.ExtraDamageHealingDisplayName,
                d.value = "+" + en,
                d.re = d.name,
                d.ae = g.VesselInfo,
                I.unshift(d))
            }
            Dn(he, e),
            Dn(ve, w),
            Dn(me, n),
            Dn(pe, I)
        }
    }
    function Dn(e, n) {
        var t, r, a = $("#" + e);
        if (a && a[0])
            if (a.empty(),
            0 === n.length)
                (t = document.createElement("tr")).classList.add("Even"),
                (r = document.createElement("td")).setAttribute("colspan", 2),
                r.textContent = "none",
                t.appendChild(r),
                a[0].appendChild(t);
            else
                for (i = 0; i < n.length; i++) {
                    var l = n[i]
                      , o = document.createElement("tr")
                      , u = (o.classList.add(i % 2 ? "Odd" : "Even"),
                    document.createElement("td"))
                      , s = document.createElement("span");
                    let e = l.name;
                    l.icon && ((d = document.createElement("img")).className = "ModAugIcon",
                    d.src = l.icon,
                    s.appendChild(d),
                    e = (e = e.replace("Aug. ", "")).replace("Augmented ", ""));
                    var d = document.createTextNode(e)
                      , c = (s.appendChild(d),
                    document.createElement("td"))
                      , f = document.createElement("span");
                    f.textContent = l.value,
                    f.classList.add("PerksSummaryValue"),
                    u.appendChild(s),
                    c.appendChild(f),
                    Wn(c, l.re, l.ae),
                    o.appendChild(u),
                    o.appendChild(c),
                    a[0].appendChild(o)
                }
    }
    function Wn(e, n, t) {
        if (e && t) {
            e.style.position = "relative";
            const i = `<p>${function(e) {
                let n = "";
                return n = (n = e.replace(/<font color='#ffffff'>(.*?)<\/font>/gi, '<span class="Highlight">$1</span>')).replace(/<\/?font[^>]*>/gi, "")
            }(t)}</p>`;
            var r = document.createElement("div")
              , a = (r.classList.add("PerkTooltipContainer"),
            document.createElement("span"))
              , l = (a.classList.add("HelperDivIndicator"),
            a.addEventListener("mouseover", function() {
                var e = $("#HelperDivText");
                e && e[0] && e[0].classList.add("LeftAlign"),
                ActivateHelperDiv($(this), n, i, "")
            }),
            a.addEventListener("mouseout", function() {
                var e = $("#HelperDivText");
                e && e[0] && e[0].classList.remove("LeftAlign"),
                DeactivateHelperDiv()
            }),
            document.createElement("img"));
            l.src = d,
            l.setAttribute("alt", "tooltip icon"),
            a.appendChild(l),
            r.appendChild(a),
            e.appendChild(r)
        }
    }
    function C(e, n) {
        switch (e) {
        case "NoEffectDisplay":
            return "";
        case "PlusInteger":
            return `+${n.toLocaleString("en-US")} `;
        case "PlusFullPercent":
            return `+${n.toLocaleString("en-US")}% `;
        case "PlusPercentWithTwoFloatingpoints":
            return 0 === n ? "+0% " : n < 0 ? (n / 100).toFixed(2).toLocaleString("en-US") + "% " : `+${(n / 100).toFixed(2).toLocaleString("en-US")}% `;
        case "PercentWithTwoFloatingpoints":
            return 0 === n ? "0% " : (n / 100).toFixed(2).toLocaleString("en-US") + "% ";
        case "RomanNumerals":
            return toRomanNumeral(n) + " "
        }
        return n + " "
    }
    function Cn(e, n) {
        switch (e) {
        case "PlusInteger":
            return `+${n.toLocaleString("en-US")} `;
        case "PercentWithTwoFloatingpoints":
            return 0 === n ? "0% " : (Math.round(100 * n) / 100).toLocaleString("en-US") + "% ";
        case "PlusPercentWithUpToTwoFloatingpoints":
            return 0 === n ? "+0% " : n < 0 ? (Math.round(100 * n) / 100).toLocaleString("en-US") + "% " : `+${(Math.round(100 * n) / 100).toLocaleString("en-US")}% `;
        case "PlusPercentWithUpToTwoFloatingpointsFromInt":
            return 0 === n ? "+0% " : n < 0 ? (100 * n).toLocaleString("en-US") + "% " : `+${(100 * n).toLocaleString("en-US")}% `;
        case "RomanNumerals":
            return toRomanNumeral(n) + " ";
        case "Seconds":
            return n + "s"
        }
        return n + " "
    }
    function E(e, n) {
        var t;
        return "string" != typeof e ? "" : (t = e.split("|"),
        n && 1 < t.length ? t[1] : t[0])
    }
    function En(e, n, t) {
        var r = 1 <= e
          , a = 2 <= e
          , l = `<img src="${c}1-${r ? "active" : "inactive"}.png">`
          , i = `<img src="${c}2-${a ? "active" : "inactive"}.png">`
          , o = t ? ` title="${n.Aug1Info}"` : ""
          , u = t ? ` title="${n.Aug2Info}"` : "";
        return `<table><tr>${`<td class="AugIcon">${l}:</td>`}${`<td class="AugText${t ? " Abbr" : ""}">${`<span ${`class="${r ? "Unlocked" : "Locked"}"`}${o}>${n.Aug1Info}</span>`}</td>`}</tr><tr>${`<td class="AugIcon">${i}:</td>`}${`<td class="AugText${t ? " Abbr" : ""}">${`<span ${`class="${a ? "Unlocked" : "Locked"}"`}${u}>${n.Aug2Info}</span>`}</td>`}</tr></table>`
    }
    function Un(e) {
        return e.replaceAll("/", " / ")
    }
    function s(d, e, c, ...f) {
        if (d || Oe) {
            Ne = !0;
            let s = e;
            var n;
            J || (n = u.get(z),
            J = new He.SkillwheelPlanner(n),
            s = s || H);
            try {
                "string" == typeof s && (Mn(s = s.trim()) && J.updateByCode(s) || d ? (le(se),
                le) : (ae(se),
                ae))(ce),
                c && "function" == typeof J[c] && J[c](...f),
                Z = [];
                var g = J.getSkillParameters();
                for (let e = 0; e < g.size(); e++) {
                    var h = g.get(e);
                    h.id = V.get(h.id),
                    h.mediumPerkCategory = V.get(h.mediumPerkCategory),
                    Z.push(h)
                }
                K = [];
                var v = J.getCornerParameters();
                for (let n = 0; n < v.size(); n++) {
                    var m = v.get(n);
                    if (m.id = V.get(m.id),
                    m.valueBasicMod1) {
                        var p = [];
                        for (let e = 0; e < m.valueBasicMod1.size(); e++) {
                            var k = m.valueBasicMod1.get(e);
                            p.push(k)
                        }
                        m.valueBasicMod1 = p
                    } else
                        m.valueBasicMod1 = [];
                    if (m.valueBasicMod2) {
                        var A = [];
                        for (let e = 0; e < m.valueBasicMod2.size(); e++) {
                            var w = m.valueBasicMod2.get(e);
                            A.push(w)
                        }
                        m.valueBasicMod2 = A
                    } else
                        m.valueBasicMod2 = [];
                    K.push(m)
                }
                Ye = J.getGridDamageAndHealingBonus(),
                en = J.getVesselsDamageAndHealingBonus(),
                nn = J.getVesselsMomentumBonus(),
                Je = [];
                var $ = J.getSmallPerksSummary();
                for (let t = 0; t < $.size(); t++) {
                    var I = $.get(t);
                    Je.push(I)
                }
                Ve = [];
                var b = J.getMediumPerksSummary();
                for (let r = 0; r < b.size(); r++) {
                    var G = b.get(r);
                    G.category = V.get(G.category),
                    Ve.push(G)
                }
                ze = [];
                var M = J.getGemsBasicModEffectSummary();
                for (let a = 0; a < M.size(); a++) {
                    var Q = M.get(a);
                    ze.push(Q)
                }
                Ze = [];
                var _ = J.getGemsSupremeModSummary();
                for (let l = 0; l < _.size(); l++) {
                    var R = _.get(l);
                    R.category = V.get(R.category),
                    Ze.push(R)
                }
                var T = J.getVocation()
                  , L = V.get(T)
                  , x = (L !== z && (Ln(z, !1),
                Ln(L, !0),
                z = L),
                Ke = [],
                J.getAvailableBasicModsPos1());
                for (let i = 0; i < x.size(); i++) {
                    var B = x.get(i);
                    if (B.effects) {
                        var S = [];
                        for (let e = 0; e < B.effects.size(); e++) {
                            var q = B.effects.get(e);
                            S.push(q)
                        }
                        B.effects = S
                    } else
                        B.effects = [];
                    Ke.push(B)
                }
                je = [];
                var y = J.getAvailableBasicModsPos2();
                for (let o = 0; o < y.size(); o++) {
                    var P = y.get(o);
                    if (P.effects) {
                        var D = [];
                        for (let e = 0; e < P.effects.size(); e++) {
                            var W = P.effects.get(e);
                            D.push(W)
                        }
                        P.effects = D
                    } else
                        P.effects = [];
                    je.push(P)
                }
                Xe = [];
                var C = J.getAvailableSupremeMods();
                for (let u = 0; u < C.size(); u++) {
                    var E = C.get(u);
                    Xe.push(E)
                }
                var U = J.getCode()
                  , F = (U !== H && Mn(U) && (H = U,
                ie(ue, H),
                ie(de, H),
                history.replaceState(null, null, "?p=wheelofdestinyplanner&code=" + H),
                Rn(N, X, ee, te, !0),
                Rn(fe, j, Y, ne, !1),
                Pn()),
                J.getSpentSkillPoints());
                F !== O && (O = F,
                ie(oe, O)),
                (d ? (Oe = !0,
                re) : kn)(),
                Ne = !1
            } catch (t) {
                J["delete"](),
                J = null,
                Ne = !1
            }
        }
    }
    function Fn(e) {
        e === H ? (le(se),
        le(ce)) : s(!1, e)
    }
    function Hn(n) {
        var t = Z.find(e => e.id === X);
        if (t && 1 != t.fillPercent && t.unlocked) {
            t = u.get(X);
            let e = n || 1;
            0 < (e = null != o ? Math.min(e, o - O) : e) && s(!1, null, "addToSkill", t, e)
        }
    }
    function On(e) {
        var n = Z.find(e => e.id === X);
        n && 0 != n.fillPercent && n.editable && s(!1, null, "removeFromSkill", u.get(X), e || 1)
    }
    function Nn(n) {
        var t = Z.find(e => e.id === X);
        if (t) {
            let e = n || 0;
            s(!1, null, "onGridTileRightClicked", u.get(X), e = null != o ? O >= o ? -1 : 0 < e ? Math.min(e, o - O) : (t = t.maxSkillPoints - t.currentSkillPoints,
            Math.min(t, o - O)) : e)
        }
    }
    function Jn(e, n) {
        var t;
        Ne || (t = u.get(te)) && s(!1, null, "onModChange", e, n, t)
    }
    class Vn {
        constructor(e, n, t, r) {
            this.quarter = e.id,
            this.largePerkId = e.largePerkId,
            this.level = e.level,
            this.fillPercent = e.fillPercent,
            this.vesselLevel = e.vesselLevel,
            this.hasGem = e.hasGem,
            this.gemQuality = e.gemQuality,
            this.socketBezelImgId = e.socketBezelImgId,
            this.gemImgId = e.gemImgId,
            this.K = n,
            this.Z = t,
            this.j = r,
            this.X = 270,
            this.Y = 285,
            this.le = 311,
            this.V = 25,
            this.ie = 287,
            this.te = 17,
            this.oe = this.quarter == P.l || this.quarter == P.i ? 34 : 56,
            this.N = Math.round(Math.cos((this.j + 45) * m.U) * this.le) + p,
            this.J = Math.round(Math.sin((this.j + 45) * m.U) * this.le) + p,
            this.ee = Math.round(Math.cos((this.j + this.oe) * m.U) * this.ie) + p,
            this.ne = Math.round(Math.sin((this.j + this.oe) * m.U) * this.ie) + p
        }
        H(e) {
            var n = this.N - e.x
              , t = this.J - e.y;
            return Math.sqrt(n * n + t * t) <= this.V
        }
        O(e) {
            var n = this.ee - e.x
              , t = this.ne - e.y;
            return Math.sqrt(n * n + t * t) <= this.te
        }
    }
    if ((e = e) && (n = e.warning,
    r = e.wrapper,
    a = e.vocationRadio,
    oe = e.reqPoints,
    l = e.limitPoints,
    ue = e.code,
    f = e.codeCopy,
    w = e.codeUrl,
    I = e.codeImport,
    Q = e.codeReset,
    _ = e.codeInput,
    se = e.codeInvalid,
    de = e.codeMobile,
    R = e.codeCopyMobile,
    T = e.codeUrlMobile,
    L = e.codeImportMobile,
    x = e.codeResetMobile,
    B = e.codeInputMobile,
    ce = e.codeInvalidMobile,
    N = e.selectionBox,
    S = e.maxMinus,
    q = e.minus,
    U = e.maxPlus,
    F = e.plus,
    fe = e.infoBox,
    ge = e.canvas,
    he = e.dedicationPerks,
    ve = e.convictionPerks,
    me = e.revelationPerks,
    pe = e.gemPerks,
    ke = e.summaryNote,
    n) && r && a && oe && l && ue && f && w && I && Q && _ && se && de && R && T && L && x && B && ce && N && S && q && U && F && fe && ge && he && ve && me && pe && ke && le(n)) {
        var zn = window.navigator.userAgent;
        if (!zn || 0 < zn.indexOf("MSIE ") || 0 < zn.indexOf("Trident/"))
            ie(n, "If you are using Internet Explorer, you won't be able to use the Wheel of Destiny Planner. Please use a different browser!"),
            ae(n);
        else {
            var zn = new URLSearchParams(window.location.search).get("code")
              , zn = Mn(zn) ? zn : null
              , Zn = 1 < (Zn = t.split("version=")).length ? "?version=" + Zn[1] : ""
              , Kn = (d = JS_DIR_IMAGES + "global/content/info.gif",
            c = JS_DIR_IMAGES + "community/wheelofdestiny/icon-augmentation",
            M = JS_DIR_IMAGES + "community/wheelofdestiny/icon_spelldamage.png",
            b = JS_DIR_IMAGES + "community/wheelofdestiny/icon_cooldown_reduction.png",
            G = JS_DIR_IMAGES + "community/wheelofdestiny/icon_crit.png",
            zn);
            try {
                createModule().then(e => {
                    ae(r),
                    He = e,
                    e = He,
                    u.set(P.Knight, e.EActiveVocation.Knight),
                    u.set(P.Druid, e.EActiveVocation.Druid),
                    u.set(P.Sorcerer, e.EActiveVocation.Sorcerer),
                    u.set(P.Paladin, e.EActiveVocation.Paladin),
                    u.set(P.Monk, e.EActiveVocation.Monk),
                    V.set(e.EActiveVocation.Knight, P.Knight),
                    V.set(e.EActiveVocation.Druid, P.Druid),
                    V.set(e.EActiveVocation.Sorcerer, P.Sorcerer),
                    V.set(e.EActiveVocation.Paladin, P.Paladin),
                    V.set(e.EActiveVocation.Monk, P.Monk),
                    u.set(P.t, e.EQuarter.TL),
                    u.set(P.l, e.EQuarter.TR),
                    u.set(P.i, e.EQuarter.BL),
                    u.set(P.o, e.EQuarter.BR),
                    V.set(e.EQuarter.TL, P.t),
                    V.set(e.EQuarter.TR, P.l),
                    V.set(e.EQuarter.BL, P.i),
                    V.set(e.EQuarter.BR, P.o),
                    u.set(P.QTL0, e.EGridTile.QTL0),
                    u.set(P.QTL1, e.EGridTile.QTL1),
                    u.set(P.QTL2, e.EGridTile.QTL2),
                    u.set(P.QTL3, e.EGridTile.QTL3),
                    u.set(P.QTL4, e.EGridTile.QTL4),
                    u.set(P.QTL5, e.EGridTile.QTL5),
                    u.set(P.QTL6, e.EGridTile.QTL6),
                    u.set(P.QTL7, e.EGridTile.QTL7),
                    u.set(P.QTL8, e.EGridTile.QTL8),
                    u.set(P.QTR0, e.EGridTile.QTR0),
                    u.set(P.QTR1, e.EGridTile.QTR1),
                    u.set(P.QTR2, e.EGridTile.QTR2),
                    u.set(P.QTR3, e.EGridTile.QTR3),
                    u.set(P.QTR4, e.EGridTile.QTR4),
                    u.set(P.QTR5, e.EGridTile.QTR5),
                    u.set(P.QTR6, e.EGridTile.QTR6),
                    u.set(P.QTR7, e.EGridTile.QTR7),
                    u.set(P.QTR8, e.EGridTile.QTR8),
                    u.set(P.QBL0, e.EGridTile.QBL0),
                    u.set(P.QBL1, e.EGridTile.QBL1),
                    u.set(P.QBL2, e.EGridTile.QBL2),
                    u.set(P.QBL3, e.EGridTile.QBL3),
                    u.set(P.QBL4, e.EGridTile.QBL4),
                    u.set(P.QBL5, e.EGridTile.QBL5),
                    u.set(P.QBL6, e.EGridTile.QBL6),
                    u.set(P.QBL7, e.EGridTile.QBL7),
                    u.set(P.QBL8, e.EGridTile.QBL8),
                    u.set(P.QBR0, e.EGridTile.QBR0),
                    u.set(P.QBR1, e.EGridTile.QBR1),
                    u.set(P.QBR2, e.EGridTile.QBR2),
                    u.set(P.QBR3, e.EGridTile.QBR3),
                    u.set(P.QBR4, e.EGridTile.QBR4),
                    u.set(P.QBR5, e.EGridTile.QBR5),
                    u.set(P.QBR6, e.EGridTile.QBR6),
                    u.set(P.QBR7, e.EGridTile.QBR7),
                    u.set(P.QBR8, e.EGridTile.QBR8),
                    V.set(e.EGridTile.QTL0, P.QTL0),
                    V.set(e.EGridTile.QTL1, P.QTL1),
                    V.set(e.EGridTile.QTL2, P.QTL2),
                    V.set(e.EGridTile.QTL3, P.QTL3),
                    V.set(e.EGridTile.QTL4, P.QTL4),
                    V.set(e.EGridTile.QTL5, P.QTL5),
                    V.set(e.EGridTile.QTL6, P.QTL6),
                    V.set(e.EGridTile.QTL7, P.QTL7),
                    V.set(e.EGridTile.QTL8, P.QTL8),
                    V.set(e.EGridTile.QTR0, P.QTR0),
                    V.set(e.EGridTile.QTR1, P.QTR1),
                    V.set(e.EGridTile.QTR2, P.QTR2),
                    V.set(e.EGridTile.QTR3, P.QTR3),
                    V.set(e.EGridTile.QTR4, P.QTR4),
                    V.set(e.EGridTile.QTR5, P.QTR5),
                    V.set(e.EGridTile.QTR6, P.QTR6),
                    V.set(e.EGridTile.QTR7, P.QTR7),
                    V.set(e.EGridTile.QTR8, P.QTR8),
                    V.set(e.EGridTile.QBL0, P.QBL0),
                    V.set(e.EGridTile.QBL1, P.QBL1),
                    V.set(e.EGridTile.QBL2, P.QBL2),
                    V.set(e.EGridTile.QBL3, P.QBL3),
                    V.set(e.EGridTile.QBL4, P.QBL4),
                    V.set(e.EGridTile.QBL5, P.QBL5),
                    V.set(e.EGridTile.QBL6, P.QBL6),
                    V.set(e.EGridTile.QBL7, P.QBL7),
                    V.set(e.EGridTile.QBL8, P.QBL8),
                    V.set(e.EGridTile.QBR0, P.QBR0),
                    V.set(e.EGridTile.QBR1, P.QBR1),
                    V.set(e.EGridTile.QBR2, P.QBR2),
                    V.set(e.EGridTile.QBR3, P.QBR3),
                    V.set(e.EGridTile.QBR4, P.QBR4),
                    V.set(e.EGridTile.QBR5, P.QBR5),
                    V.set(e.EGridTile.QBR6, P.QBR6),
                    V.set(e.EGridTile.QBR7, P.QBR7),
                    V.set(e.EGridTile.QBR8, P.QBR8),
                    u.set(P.u, e.EMediumPerkCategory.Unique),
                    u.set(P.g, e.EMediumPerkCategory.SkillBonus),
                    u.set(P.h, e.EMediumPerkCategory.Leech),
                    u.set(P.v, e.EMediumPerkCategory.Augmentation),
                    u.set(P.m, e.EMediumPerkCategory.VesselResonance),
                    u.set(P.p, e.EMediumPerkCategory.Other),
                    V.set(e.EMediumPerkCategory.Unique, P.u),
                    V.set(e.EMediumPerkCategory.SkillBonus, P.g),
                    V.set(e.EMediumPerkCategory.Leech, P.h),
                    V.set(e.EMediumPerkCategory.Augmentation, P.v),
                    V.set(e.EMediumPerkCategory.VesselResonance, P.m),
                    V.set(e.EMediumPerkCategory.Other, P.p),
                    u.set(P.k, e.ESupremeModCategory.ModEffect),
                    u.set(P.A, e.ESupremeModCategory.ModAugCd),
                    u.set(P.$, e.ESupremeModCategory.ModAugCrit),
                    u.set(P.I, e.ESupremeModCategory.ModAugDmg),
                    u.set(P.G, e.ESupremeModCategory.ModAugHeal),
                    u.set(P.M, e.ESupremeModCategory.ModAugOther),
                    u.set(P._, e.ESupremeModCategory.ModRevelation),
                    V.set(e.ESupremeModCategory.ModEffect, P.k),
                    V.set(e.ESupremeModCategory.ModAugCd, P.A),
                    V.set(e.ESupremeModCategory.ModAugCrit, P.$),
                    V.set(e.ESupremeModCategory.ModAugDmg, P.I),
                    V.set(e.ESupremeModCategory.ModAugHeal, P.G),
                    V.set(e.ESupremeModCategory.ModAugOther, P.M),
                    V.set(e.ESupremeModCategory.ModRevelation, P._),
                    s(!0, Kn)
                }
                )["catch"](e => {
                    ie(n, "It appears that your browser version is too old to use the Wheel of Destiny Planner. Please use a different browser!"),
                    ae(n)
                }
                )
            } catch (lt) {
                ie(n, "Loading the Wheel of Destiny Planner failed. Please check if your browser or plugins are blocking the loading process!"),
                ae(n)
            }
            {
                e = JS_DIR_IMAGES + "community/wheelofdestiny";
                var jn = JS_DIR_IMAGES + "global/common/skillwheel";
                var Xn = Zn;
                const it = new Image
                  , ot = (it.src = e + "/backdrop_skillwheel.png",
                it.onload = function() {
                    Ae = it,
                    re()
                }
                ,
                new Image)
                  , ut = (ot.src = e + "/backdrop_skillwheel_largebonus_socketdisabled.png",
                ot.onload = function() {
                    we = ot,
                    re()
                }
                ,
                new Image)
                  , st = (ut.src = e + "/backdrop_skillwheel_largebonus_socketenabled.png",
                ut.onload = function() {
                    $e = ut,
                    re()
                }
                ,
                new Image)
                  , dt = (st.src = e + "/backdrop_skillwheel_largebonus_light.png",
                st.onload = function() {
                    Ie = st,
                    re()
                }
                ,
                new Image)
                  , ct = (dt.src = e + "/backdrop_skillwheel_front_knight.png",
                dt.onload = function() {
                    be = dt,
                    re()
                }
                ,
                new Image)
                  , ft = (ct.src = e + "/backdrop_skillwheel_front_druid.png",
                ct.onload = function() {
                    Ge = ct,
                    re()
                }
                ,
                new Image)
                  , gt = (ft.src = e + "/backdrop_skillwheel_front_sorc.png",
                ft.onload = function() {
                    Me = ft,
                    re()
                }
                ,
                new Image)
                  , ht = (gt.src = e + "/backdrop_skillwheel_front_paladin.png",
                gt.onload = function() {
                    Qe = gt,
                    re()
                }
                ,
                new Image)
                  , vt = (ht.src = e + "/backdrop_skillwheel_front_monk.png",
                ht.onload = function() {
                    _e = ht,
                    re()
                }
                ,
                new Image)
                  , mt = (vt.src = e + "/backdrop_skillwheel_largebonus_front0.png",
                vt.onload = function() {
                    Re = vt,
                    re()
                }
                ,
                new Image)
                  , pt = (mt.src = e + "/backdrop_skillwheel_largebonus_front1.png",
                mt.onload = function() {
                    Te = mt,
                    re()
                }
                ,
                new Image)
                  , kt = (pt.src = e + "/backdrop_skillwheel_largebonus_front2.png",
                pt.onload = function() {
                    Le = pt,
                    re()
                }
                ,
                new Image)
                  , At = (kt.src = e + "/backdrop_skillwheel_largebonus_front3.png",
                kt.onload = function() {
                    xe = kt,
                    re()
                }
                ,
                new Image)
                  , wt = (At.src = e + "/icons-skillwheel-largeperks.png" + Xn,
                At.onload = function() {
                    Be = At,
                    re()
                }
                ,
                new Image)
                  , $t = (wt.src = e + "/marker_largeperk.png",
                wt.onload = function() {
                    Se = wt,
                    re()
                }
                ,
                new Image)
                  , It = ($t.src = jn + "/icons-gematelier-gemvariants.png",
                $t.onload = function() {
                    qe = $t,
                    re()
                }
                ,
                new Image)
                  , bt = (It.src = e + "/icons-skillwheel-sockets.png",
                It.onload = function() {
                    ye = It,
                    re()
                }
                ,
                new Image)
                  , Gt = (bt.src = jn + "/icons-skillwheel-basicmods.png" + Xn,
                bt.onload = function() {
                    De = bt,
                    re()
                }
                ,
                new Image)
                  , Mt = (Gt.src = jn + "/icons-skillwheel-suprememods.png" + Xn,
                Gt.onload = function() {
                    We = Gt,
                    re()
                }
                ,
                new Image)
                  , Qt = (Mt.src = e + "/marker-skillwheelsocket.png",
                Mt.onload = function() {
                    Pe = Mt,
                    re()
                }
                ,
                new Image)
                  , _t = (Qt.src = e + "/icons-skillwheel-mediumperks.png" + Xn,
                Qt.onload = function() {
                    Ce = Qt,
                    re()
                }
                ,
                new Image)
                  , Rt = (_t.src = e + "/icons-skillwheel-smallperks.png" + Xn,
                _t.onload = function() {
                    Ee = _t,
                    re()
                }
                ,
                new Image)
                  , Tt = (Rt.src = e + "/icon_skillwheel_vesselresonance_basic.png",
                Rt.onload = function() {
                    Ue = Rt,
                    re()
                }
                ,
                new Image);
                Tt.src = e + "/icon_skillwheel_vesselresonance_supreme.png",
                Tt.onload = function() {
                    Fe = Tt,
                    re()
                }
            }
            pn(),
            CopyTextOfElement(f, ue),
            CopyTextOfElement(R, de),
            $("#" + w).on("click", function() {
                rt($(this))
            }),
            $("#" + T).on("click", function() {
                rt($(this))
            }),
            $("#" + I).on("click", function() {
                _n($("#" + _))
            }),
            $("#" + L).on("click", function() {
                _n($("#" + B))
            }),
            $("#" + Q).on("click", function() {
                Fn("")
            }),
            $("#" + x).on("click", function() {
                Fn("")
            }),
            $("#" + B).on("keyup", function(e) {
                var n = $("#" + B);
                $("#" + _).val(n.val()),
                at(e, $(this))
            }),
            $("#" + _).on("keyup", function(e) {
                var n = $("#" + _);
                $("#" + B).val(n.val()),
                at(e, $(this))
            }),
            Qn(P.Knight),
            Qn(P.Druid),
            Qn(P.Sorcerer),
            Qn(P.Paladin),
            Qn(P.Monk);
            {
                const Lt = $("#" + l);
                Lt.on("input blur", function(e) {
                    var n = Lt.val().trim().replace(/[^0-9]/g, "").slice(0, 4);
                    if (Lt.val(n),
                    /^[0-9]+$/.test(n)) {
                        n = parseInt(n);
                        if (!isNaN(n) && Number.isInteger(n) && 0 < n)
                            return void (o = n)
                    }
                    o = null
                })
            }
            {
                const xt = $("#" + S)
                  , Bt = $("#" + U)
                  , St = $("#" + q)
                  , qt = $("#" + F);
                let r = undefined
                  , a = !1
                  , l = null;
                function Yn(e, n, t) {
                    if (("mousedown" != e.type || 1 == e.which) && (bn(e),
                    l = X,
                    n(t),
                    !a & !t)) {
                        a = !0;
                        let e = 0;
                        r = setInterval( () => {
                            l !== X ? et() : e < 15 ? e++ : n(t)
                        }
                        , 30)
                    }
                }
                function et() {
                    clearInterval(r),
                    a = !1,
                    l = null
                }
                function nt(e, n, t, r, a) {
                    switch (e.code) {
                    case "Space":
                    case "Enter":
                        r && (bn(e),
                        r(a));
                        break;
                    case "ArrowLeft":
                        bn(e),
                        n && n.focus();
                        break;
                    case "ArrowRight":
                        bn(e),
                        t && t.focus()
                    }
                }
                function tt(e) {
                    return e = e.originalEvent || e,
                    DeactivateHelperDiv(),
                    e.touches && 1 < e.touches.length
                }
                St.on("keydown", function(e) {
                    nt(e, xt, qt, On, Gn(e))
                }),
                St.on("mousedown touchstart", function(e) {
                    tt(e) || Yn(e, On, Gn(e))
                }),
                St.on("mouseup mouseout touchend touchcancel", function() {
                    et()
                }),
                qt.on("keydown", function(e) {
                    nt(e, St, Bt, Hn, Gn(e))
                }),
                qt.on("mousedown touchstart", function(e) {
                    tt(e) || Yn(e, Hn, Gn(e))
                }),
                qt.on("mouseup mouseout touchend touchcancel", function() {
                    et()
                }),
                xt.on("keydown", function(e) {
                    nt(e, null, St)
                }),
                xt.on("click", function() {
                    var e;
                    et(),
                    (e = Z.find(e => e.id === X)) && 0 != e.fillPercent && e.editable && s(!1, null, "clearSkill", u.get(X))
                }),
                Bt.on("keydown", function(e) {
                    nt(e, qt, null)
                }),
                Bt.on("click", function() {
                    var e, n;
                    et(),
                    (e = Z.find(e => e.id === X)) && 1 != e.fillPercent && e.unlocked && (n = u.get(X),
                    null != o ? O < o && (e = e.maxSkillPoints - e.currentSkillPoints,
                    e = Math.min(e, o - O),
                    s(!1, null, "addToSkill", n, e)) : s(!1, null, "fillSkill", n))
                }),
                $(window).on("scroll", function(e) {
                    et()
                })
            }
            {
                const yt = N + "-gem-mod1-dropdown"
                  , Pt = N + "-gem-mod2-dropdown"
                  , Dt = N + "-gem-mod3-dropdown"
                  , Wt = $(`select[name="${yt}"]`)
                  , Ct = $(`select[name="${Pt}"]`)
                  , Et = $(`select[name="${Dt}"]`);
                Wt.on("change", function(e) {
                    Jn(1, $(this).val()),
                    Wt.focus()
                }),
                Ct.on("change", function(e) {
                    Jn(2, $(this).val()),
                    Ct.focus()
                }),
                Et.on("change", function(e) {
                    Jn(3, $(this).val()),
                    Et.focus()
                })
            }
            $.getJSON(t).done(e => {
                y = e,
                Pn(),
                y.SliceRightClickInfo && ie(fe + "-fillinfo", y.SliceRightClickInfo),
                y.SmallPerkInfos.DisplayName && ie(he + "-header", y.SmallPerkInfos.DisplayName + "s"),
                y.MediumPerkInfos.DisplayName && ie(ve + "-header", y.MediumPerkInfos.DisplayName + "s"),
                y.LargePerkInfos.DisplayName && ie(me + "-header", y.LargePerkInfos.DisplayName + "s"),
                y.VesselInfos.DisplayName && ie(pe + "-header", y.VesselInfos.DisplayName + "s"),
                y.CooldownLimitInfo && ie(ke, y.CooldownLimitInfo)
            }
            )
        }
    }
    function rt(e) {
        var n, t = window.location.href;
        t && ((n = document.createElement("input")).style = "position: absolute; left: -1000px; top: -1000px; opacity: 0;",
        n.value = t,
        document.body.appendChild(n),
        n.select(),
        document.execCommand("copy"),
        document.body.removeChild(n),
        e.focus())
    }
    function at(e, n) {
        "Enter" === e.code && n.val().trim() && _n(n)
    }
}
