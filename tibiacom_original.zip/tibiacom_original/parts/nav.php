<?php

/**
 * Adapt the menu managed in Admin Panel > Menus to Tibia.com's artwork.
 * Menu entries deliberately do not live in this theme.
 */
function tco_nav_items(): array {
	$managed = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
	$groups = array();

	foreach ($managed as $entry) {
		$label = function_exists('theme_menu_label')
			? theme_menu_label((string)$entry['label'])
			: (string)$entry['label'];
		// The picture-label artwork (label_account.png, etc.) is matched by the
		// menu entry's original English text, not the translated $label - a
		// Spanish/German/etc. site must still get the same picture.
		$presentation = tco_nav_presentation((string)$entry['label'], (string)($entry['icon'] ?? ''));
		$items = array();

		$url = trim((string)($entry['url'] ?? ''));
		if ($url !== '' && $url !== '#') {
			$items[] = tco_nav_item($entry, $label);
		}

		foreach ($entry['children'] ?? array() as $child) {
			$childLabel = function_exists('theme_menu_label')
				? theme_menu_label((string)$child['label'])
				: (string)$child['label'];
			$items[] = tco_nav_item($child, $childLabel);
		}

		$groups['menu_' . (int)$entry['id']] = array(
			'label' => $label,
			'icon' => $presentation['icon'],
			'label_img' => $presentation['label_img'],
			'items' => $items,
		);
	}

	return $groups;
}

function tco_nav_item(array $entry, string $label): array {
	return array(
		'id' => 'menu_' . (int)$entry['id'],
		'label' => $label,
		'url' => (string)($entry['url'] ?? '#'),
		'target' => (string)($entry['target'] ?? ''),
	);
}

/**
 * Known categories retain their original artwork. Custom categories use a
 * text label, so administrators can add or rename sections without PHP edits.
 */
function tco_nav_presentation(string $label, string $managedIcon = ''): array {
	$key = strtolower(trim($label));
	$byLabel = array(
		'home' => array('icon_news.gif', 'label_news.png'),
		'news' => array('icon_news.gif', 'label_news.png'),
		'about' => array('icon_abouttibia.gif', 'label_abouttibia.png'),
		'about tibia' => array('icon_abouttibia.gif', 'label_abouttibia.png'),
		'game guides' => array('icon_gamesguide.gif', 'label_gamesguide.png'),
		'library' => array('icon_library.gif', 'label_library.png'),
		'community' => array('icon_community.gif', 'label_community.png'),
		'forum' => array('icon_forum.gif', 'label_forum.png'),
		'account' => array('icon_account.gif', 'label_account.png'),
		'character bazaar' => array('icon_charactertrade.gif', 'label_charactertrade.png'),
		'char bazaar' => array('icon_charactertrade.gif', 'label_charactertrade.png'),
		'support' => array('icon_support.gif', 'label_support.png'),
		'shop' => array('icon_account.gif', 'label-shops.gif'),
		'webshop' => array('icon_account.gif', 'label-shops.gif'),
	);

	if (isset($byLabel[$key])) {
		return array('icon' => $byLabel[$key][0], 'label_img' => $byLabel[$key][1]);
	}

	$byIcon = array(
		'fa-home' => 'icon_news.gif',
		'fa-user' => 'icon_account.gif',
		'fa-user-circle' => 'icon_account.gif',
		'fa-users' => 'icon_community.gif',
		'fa-book' => 'icon_library.gif',
		'fa-info-circle' => 'icon_support.gif',
		'fa-shopping-cart' => 'icon_account.gif',
	);

	return array(
		'icon' => $byIcon[strtolower(trim($managedIcon))] ?? 'icon_news.gif',
		'label_img' => '',
	);
}

function tco_current_page(): string {
	global $page_filename;
	return (string)($page_filename ?? '');
}

function tco_nav_is_active(array $item): bool {
	$page = tco_current_page();
	return $page !== '' && strpos((string)$item['url'], $page . '.php') === 0;
}
