<?php
$tcoLoggedIn = function_exists('user_logged_in') && user_logged_in() === true;
$tcoArtworkHeaderLogo = trim(theme_option('logo_artwork_header_logo'));
$tcoArtworkBottomLogo = trim(theme_option('logo_artwork_bottom_logo'));
$tcoHasCustomArtworkLogo = $tcoArtworkHeaderLogo !== '' || $tcoArtworkBottomLogo !== '';
?>
<div id="LeftArtwork"<?= $tcoHasCustomArtworkLogo ? ' class="HasCustomArtworkLogo"' : '' ?>>
	<a href="index.php" class="TibiaLogoArtworkLink" aria-label="<?= h(theme_title()) ?>">
		<img id="TibiaLogoArtworkTop" src="<?= theme_asset($tcoHasCustomArtworkLogo ? 'tibia-logo-artwork-top2.png' : 'tibia-logo-artwork-top.gif') ?>" alt="">
		<?php if ($tcoArtworkHeaderLogo !== ''): ?>
			<span class="TibiaLogoArtworkSlot TibiaLogoArtworkHeader"><img src="<?= theme_image('logo_artwork_header_logo') ?>" alt="<?= h(theme_title()) ?>"></span>
		<?php endif; ?>
		<?php if ($tcoArtworkBottomLogo !== ''): ?>
			<span class="TibiaLogoArtworkSlot TibiaLogoArtworkBottom"><img src="<?= theme_image('logo_artwork_bottom_logo') ?>" alt=""></span>
		<?php endif; ?>
	</a>
</div>
<div class="SmallMenuBorder BorderTop" style="background-image:url(<?= theme_asset('box_top.gif') ?>);"></div>

<div class="SmallMenuBox">
	<div class="SmallBoxTop" style="background-image:url(<?= theme_asset('box_top.gif') ?>)"></div>
	<div class="SmallBoxBorder" style="background-image:url(<?= theme_asset('chain.gif') ?>)"></div>
	<div class="SmallBoxButtonContainer" style="background-image:url(<?= theme_asset('loginbox_textfield.gif') ?>)">
		<div id="PlayNowContainer">
			<form class="MediumButtonForm" action="<?= $tcoLoggedIn ? 'myaccount.php' : 'login.php' ?>" method="get" style="padding:0;margin:0;">
				<div class="MediumButtonBackground" style="background-image:url(<?= theme_asset('mediumbutton.gif') ?>)" onmouseover="this.firstElementChild.style.visibility='visible';" onmouseout="this.firstElementChild.style.visibility='hidden';">
					<div class="MediumButtonOver" style="background-image:url(<?= theme_asset('mediumbutton-over.gif') ?>);visibility:hidden;"></div>
					<input class="MediumButtonText" type="image"
						src="<?= theme_asset($tcoLoggedIn ? 'mediumbutton_myaccount.png' : 'mediumbutton_login.png') ?>"
						alt="<?= $tcoLoggedIn ? h(t_default('tco.myaccount', 'My Account')) : h(t('nav.login')) ?>">
				</div>
			</form>
		</div>
	</div>
	<div class="Loginstatus" style="background-image:url(<?= theme_asset('loginbox_textfield.gif') ?>)">
		<?php if ($tcoLoggedIn): ?>
			<a href="logout.php"><img class="LoginstatusText" src="<?= theme_asset('loginbox-font-logout.gif') ?>" data-over="<?= theme_asset('loginbox-font-logout-over.gif') ?>" data-out="<?= theme_asset('loginbox-font-logout.gif') ?>" alt="<?= h(t('nav.logout')) ?>"></a>
		<?php else: ?>
			<a href="register.php"><img class="LoginstatusText" src="<?= theme_asset('loginbox-font-create-account.gif') ?>" data-over="<?= theme_asset('loginbox-font-create-account-over.gif') ?>" data-out="<?= theme_asset('loginbox-font-create-account.gif') ?>" alt="<?= h(t('nav.register')) ?>"></a>
		<?php endif; ?>
	</div>
	<div class="SmallBoxBorder BorderRight" style="background-image:url(<?= theme_asset('chain.gif') ?>)"></div>
	<div class="Loginstatus SmallBoxBottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>)"></div>
</div>

<div class="SmallMenuBox" id="DownloadBox">
	<div class="SmallBoxTop" style="background-image:url(<?= theme_asset('box_top.gif') ?>)"></div>
	<div class="SmallBoxBorder" style="background-image:url(<?= theme_asset('chain.gif') ?>);"></div>
	<div class="SmallBoxButtonContainer" style="background-image:url(<?= theme_asset('loginbox_textfield.gif') ?>)">
		<div id="PlayNowContainer">
			<form class="MediumButtonForm" action="downloads.php" method="get" style="padding:0;margin:0;">
				<div class="MediumButtonBackground" style="background-image:url(<?= theme_asset('mediumbutton.gif') ?>)" onmouseover="this.firstElementChild.style.visibility='visible';" onmouseout="this.firstElementChild.style.visibility='hidden';">
					<div class="MediumButtonOver" style="background-image:url(<?= theme_asset('mediumbutton-over.gif') ?>);visibility:hidden;"></div>
					<input class="MediumButtonText" type="image" src="<?= theme_asset('mediumbutton_download.png') ?>" alt="<?= h(t_default('tco.download', 'Download')) ?>">
				</div>
			</form>
		</div>
	</div>
	<div class="SmallBoxBorder BorderRight" style="background-image:url(<?= theme_asset('chain.gif') ?>);"></div>
	<div class="Loginstatus SmallBoxBottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
</div>

<div class="SmallMenuBorder BorderBottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
