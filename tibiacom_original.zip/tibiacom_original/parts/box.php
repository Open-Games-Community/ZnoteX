<?php

function tco_headline_path(string $key): string {
	return theme_file_exists('assets/headline-' . $key . '.gif') ? $key : '';
}

function theme_file_exists(string $relative): bool {
	return function_exists('theme_file') && theme_file($relative) !== null;
}

function tco_default_view(string $viewName): void {
	$file = dirname(__DIR__, 2) . '/default/views/' . $viewName . '.php';
	if (is_file($file)) {
		extract($GLOBALS, EXTR_SKIP);
		include $file;
	}
}

function tco_wrap_default_view(string $viewName, string $headlineKey, string $title = ''): void {
	tco_box_open($title, $headlineKey);
	tco_default_view($viewName);
	tco_box_close();
}

function tco_box_open(string $title = '', string $headlineKey = '', string $id = ''): void {
	$headlineKey = $headlineKey !== '' ? tco_headline_path($headlineKey) : '';
	?>
	<div class="Box"<?= $id !== '' ? ' id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '"' : '' ?>>
		<div class="Corner-tl" style="background-image:url(<?= theme_asset('corner-tl.gif') ?>);"></div>
		<div class="Corner-tr" style="background-image:url(<?= theme_asset('corner-tr.gif') ?>);"></div>
		<div class="Border_1" style="background-image:url(<?= theme_asset('box-frame-horizontal.gif') ?>);"></div>
		<?php if ($headlineKey !== ''): ?>
			<div class="BorderTitleText" style="background-image:url(<?= theme_asset('title_background_green.gif') ?>);"></div>
			<img class="Title" src="<?= theme_asset('headline-' . $headlineKey . '.gif') ?>" alt="<?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?>">
		<?php endif; ?>
		<div class="Border_2">
			<div class="Border_3">
				<div class="BoxContent" style="background-image:url(<?= theme_asset('scroll.gif') ?>);">
					<?php if ($title !== '' && $headlineKey === ''): ?>
						<h1><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
					<?php endif; ?>
	<?php
}

function tco_box_close(): void {
	?>
				</div>
			</div>
		</div>
		<div class="Border_1" style="background-image:url(<?= theme_asset('box-frame-horizontal.gif') ?>);"></div>
		<div class="CornerWrapper-b"><div class="Corner-bl" style="background-image:url(<?= theme_asset('corner-bl.gif') ?>);"></div></div>
		<div class="CornerWrapper-b"><div class="Corner-br" style="background-image:url(<?= theme_asset('corner-br.gif') ?>);"></div></div>
	</div>
	<?php
}

function tco_panel_open(string $title, string $tableClass = 'Table3'): void {
	?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<span class="CaptionEdgeLeftTop" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionEdgeRightTop" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionBorderTop" style="background-image:url(<?= theme_asset('table-headline-border.gif') ?>);"></span>
				<span class="CaptionVerticalLeft" style="background-image:url(<?= theme_asset('box-frame-vertical.gif') ?>);"></span>
				<div class="Text"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></div>
				<span class="CaptionVerticalRight" style="background-image:url(<?= theme_asset('box-frame-vertical.gif') ?>);"></span>
				<span class="CaptionBorderBottom" style="background-image:url(<?= theme_asset('table-headline-border.gif') ?>);"></span>
				<span class="CaptionEdgeLeftBottom" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionEdgeRightBottom" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
			</div>
		</div>
		<table class="<?= htmlspecialchars($tableClass, ENT_QUOTES, 'UTF-8') ?>" cellpadding="0" cellspacing="0">
			<tbody><tr><td>
				<div class="InnerTableContainer">
					<table style="width:100%;"><tbody><tr><td>
						<div class="TableContentContainer">
							<table class="TableContent" width="100%"><tbody>
	<?php
}

function tco_panel_close(): void {
	?>
							</tbody></table>
						</div>
					</td></tr></tbody></table>
				</div>
			</td></tr></tbody>
		</table>
	</div>
	<?php
}

function tco_row(string $label, string $html, string $bg = ''): void {
	?>
	<tr<?= $bg !== '' ? ' style="background-color:' . htmlspecialchars($bg, ENT_QUOTES, 'UTF-8') . ';"' : '' ?>>
		<td class="LabelV"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></td>
		<td><?= $html ?></td>
	</tr>
	<?php
}

function tco_alt_bg(int $i): string {
	return $i % 2 === 0 ? '#F1E0C6' : '#D4C0A1';
}

function tco_changelog_split(string $raw): array {
	if (preg_match('/^\s*\[(community|development|technical)\]\s*/i', $raw, $m)) {
		return array(strtolower($m[1]), (string)substr($raw, strlen($m[0])));
	}
	return array('community', $raw);
}

function tco_changelog_icon(string $category): string {
	$map = array(
		'community' => 'newsicon_community_small.png',
		'development' => 'newsicon_development_small.png',
		'technical' => 'newsicon_technical_small.png',
	);
	return $map[$category] ?? $map['community'];
}

function tco_changelog_plain(string $bbcode, int $limit = 90): string {
	$plain = trim(preg_replace('/\s+/', ' ', strip_tags(znote_bbcode_raw($bbcode))) ?? '');
	return mb_strlen($plain) > $limit ? mb_substr($plain, 0, $limit) . '...' : $plain;
}

function tco_news_icon(string $category): string {
	$map = array(
		'community' => 'newsicon_community_small.png',
		'development' => 'newsicon_development_small.png',
		'technical' => 'newsicon_technical_small.png',
	);
	$big = str_replace('_small', '_big', $map[$category] ?? $map['community']);
	return theme_file_exists('assets/' . $big) ? $big : ($map[$category] ?? $map['community']);
}

function tco_news_entry(array $item, string $permalink = ''): void {
	list($tcoCat, $tcoText) = tco_changelog_split((string)($item['text'] ?? ''));
	$title = znote_bbcode_raw((string)($item['title'] ?? ''));
	?>
	<div class="NewsHeadline">
		<div class="NewsHeadlineBackground" style="background-image:url(<?= theme_asset('newsheadline_background.gif') ?>)">
			<div>
				<img src="<?= theme_asset(tco_news_icon($tcoCat)) ?>" class="NewsHeadlineIcon" alt="<?= htmlspecialchars($tcoCat, ENT_QUOTES, 'UTF-8') ?>">
				<div class="NewsHeadlineDate"><?= htmlspecialchars(date('M d Y', (int)($item['date'] ?? 0)), ENT_QUOTES, 'UTF-8') ?> - </div>
			</div>
			<div class="NewsHeadlineText"><p><?= $permalink !== '' ? '<a href="' . htmlspecialchars($permalink, ENT_QUOTES, 'UTF-8') . '">' . $title . '</a>' : $title ?></p></div>
		</div>
	</div>
	<table class="NewsTable" cellpadding="0" cellspacing="0"><tbody><tr>
		<td class="NewsTableContainer"><p><?= tco_dropcap_render($tcoText) ?></p></td>
	</tr></tbody></table>
	<?php
}

function tco_news_pagination(int $page, int $pageAmount): void {
	if ($pageAmount < 2) {
		return;
	}
	?>
	<div class="PageNavigation">
		<div class="BlockPageNavigationRow tco-pagination">
			<?php if ($page > 0): ?>
				<a class="CipAjaxLink" href="index.php?page=<?= $page - 1 ?>">&#171; <?= t_default('tco.page_prev', 'Previous') ?></a>
			<?php endif; ?>
			<?php for ($i = 0; $i < $pageAmount; $i++): ?>
				<?php if ($i === $page): ?>
					<span class="CurrentPageLink"><?= $i + 1 ?></span>
				<?php else: ?>
					<a class="CipAjaxLink" href="index.php?page=<?= $i ?>"><?= $i + 1 ?></a>
				<?php endif; ?>
			<?php endfor; ?>
			<?php if ($page < $pageAmount - 1): ?>
				<a class="CipAjaxLink" href="index.php?page=<?= $page + 1 ?>"><?= t_default('tco.page_next', 'Next') ?> &#187;</a>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

function tco_dropcap_render(string $raw): string {
	$trimmed = ltrim($raw);
	if ($trimmed === '' || $trimmed[0] === '[' || !ctype_alpha($trimmed[0])) {
		return znote_bbcode_raw($raw);
	}
	$letter = strtoupper($trimmed[0]);
	if (!theme_file_exists('assets/letters/letter_martel_' . $letter . '.gif')) {
		return znote_bbcode_raw($raw);
	}
	$rest = substr($trimmed, 1);
	$img = '<img class="tco-dropcap" src="' . theme_asset('letters/letter_martel_' . $letter . '.gif') . '" border="0" align="bottom" alt="' . htmlspecialchars($letter, ENT_QUOTES, 'UTF-8') . '">';
	return $img . znote_bbcode_raw($rest);
}

function tco_button(string $label, string $color = 'green', string $formId = '', string $name = '', string $value = '', bool $wide = false): string {
	$colors = array('green', 'blue', 'red');
	if (!in_array($color, $colors, true)) {
		$color = 'green';
	}
	$formAttr = $formId !== '' ? ' form="' . htmlspecialchars($formId, ENT_QUOTES, 'UTF-8') . '"' : '';
	$nameAttr = $name !== '' ? ' name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '"' : '';
	$valueAttr = $value !== '' ? htmlspecialchars($value, ENT_QUOTES, 'UTF-8') : htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
	$wideClass = $wide ? ' tco-btn-wide' : '';
	return '<div class="BigButton' . $wideClass . '" style="background-image:url(' . theme_asset('button_' . $color . '.gif') . ')">'
		. '<div><div class="BigButtonOver" style="background-image:url(' . theme_asset('button_' . $color . '_over.gif') . ');"></div>'
		. '<input class="BigButtonText" type="submit"' . $formAttr . $nameAttr . ' value="' . $valueAttr . '"></div></div>';
}

function tco_medium_button_link(string $href, string $image = 'mediumbutton_download.png', string $alt = 'Download'): string {
	return '<a href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">'
		. '<div class="MediumButtonBackground" style="background-image:url(' . theme_asset('mediumbutton.gif') . ');margin:0 auto;" onmouseover="this.firstElementChild.style.visibility=\'visible\';" onmouseout="this.firstElementChild.style.visibility=\'hidden\';">'
		. '<div class="MediumButtonOver" style="background-image:url(' . theme_asset('mediumbutton-over.gif') . ');visibility:hidden;"></div>'
		. '<input class="MediumButtonText" type="image" src="' . theme_asset($image) . '" alt="' . htmlspecialchars($alt, ENT_QUOTES, 'UTF-8') . '">'
		. '</div></a>';
}
