<?php
$tcoWebshopActiveTab = in_array($tcoWebshopActiveTab ?? '', array('offers', 'services', 'points'), true)
	? $tcoWebshopActiveTab
	: 'offers';
$tcoShopConfig = (array)($config['shop'] ?? array());
$tcoLoggedIn = function_exists('user_logged_in') && user_logged_in();

if (!isset($shop_list) || !is_array($shop_list)) {
	if (function_exists('shop_load_db_offers')) {
		$shop_list = shop_load_db_offers();
	} else {
		$columns = array();
		foreach ((array)db()->fetchAll('SHOW COLUMNS FROM `znote_shop_offers`;') as $column) {
			if (!empty($column['Field'])) $columns[(string)$column['Field']] = true;
		}
		$where = isset($columns['active']) ? 'WHERE `active` = 1' : '';
		$order = isset($columns['sort_order']) ? 'ORDER BY `sort_order`, `id`' : 'ORDER BY `id`';
		$shop_list = array();
		foreach ((array)db()->fetchAll("SELECT `id`, `type`, `itemid`, `count`, `description`, `points` FROM `znote_shop_offers` {$where} {$order};") as $row) {
			$itemId = (int)$row['itemid'];
			if ((int)$row['type'] === 5 && $itemId > 0) {
				$itemId = array((int)floor($itemId / 10000), $itemId % 10000);
			}
			$shop_list[(int)$row['id']] = array(
				'type' => (int)$row['type'],
				'itemid' => $itemId,
				'count' => (int)$row['count'],
				'description' => (string)$row['description'],
				'points' => (int)$row['points'],
			);
		}
	}
}

$tcoOfferGroups = array(
	'items' => array(),
	'outfits' => array(),
	'mounts' => array(),
	'services' => array(),
);
foreach ($shop_list as $offerId => $offer) {
	$type = (int)($offer['type'] ?? 0);
	if ($type === 1) $tcoOfferGroups['items'][$offerId] = $offer;
	elseif ($type === 5) $tcoOfferGroups['outfits'][$offerId] = $offer;
	elseif ($type === 6) $tcoOfferGroups['mounts'][$offerId] = $offer;
	else $tcoOfferGroups['services'][$offerId] = $offer;
}

$tcoShopSession = '';
if ($tcoLoggedIn) {
	$tcoShopSession = bin2hex(random_bytes(32));
	$_SESSION['shop_session'] = $tcoShopSession;
}

$tcoPrices = (array)($config['paypal_prices'] ?? array());
$tcoProviders = array(
	'paypal' => array(
		'label' => 'PayPal',
		'enabled' => !empty($config['paypal']['enabled']),
		'image' => theme_asset('paymentmethodcategory34.gif'),
		'currency' => (string)($config['paypal']['currency'] ?? 'EUR'),
		'time' => 'very fast',
	),
	'stripe' => array(
		'label' => 'Stripe',
		'enabled' => !empty($config['stripe']['enabled']),
		'image' => theme_asset('stripe.png'),
		'currency' => (string)($config['stripe']['currency'] ?? 'EUR'),
		'time' => 'very fast',
	),
	'mercadopago' => array(
		'label' => 'Mercado Pago',
		'enabled' => !empty($config['mercadopago']['enabled']),
		'image' => theme_asset('mercadopago.png'),
		'currency' => (string)($config['mercadopago']['currency'] ?? 'BRL'),
		'time' => 'very fast',
	),
	'pagseguro' => array(
		'label' => 'PagSeguro',
		'enabled' => !empty($config['pagseguro']['enabled']),
		'image' => theme_asset('pagseguro.png'),
		'currency' => (string)($config['pagseguro']['currency'] ?? 'BRL'),
		'time' => 'very fast',
		'unit_price' => ((float)($config['pagseguro']['price'] ?? 0)) / 100,
	),
	'paygol' => array(
		'label' => 'PayGol',
		'enabled' => !empty($config['paygol']['enabled']),
		'image' => theme_asset('paygol.png'),
		'currency' => (string)($config['paygol']['currency'] ?? 'EUR'),
		'time' => 'fast',
		'fixed_price' => (string)($config['paygol']['price'] ?? ''),
		'fixed_points' => (int)($config['paygol']['points'] ?? 0),
	),
);
$tcoDefaultCurrency = 'EUR';
foreach ($tcoProviders as $providerKey => $provider) {
	if ($provider['enabled'] && $providerKey !== 'paygol') {
		$tcoDefaultCurrency = $provider['currency'];
		break;
	}
}

$tcoEmail = (string)($user_data['email'] ?? 'your account');
$tcoMaskedEmail = $tcoEmail;
if (str_contains($tcoEmail, '@')) {
	list($mailName, $mailDomain) = explode('@', $tcoEmail, 2);
	$tcoMaskedEmail = substr($mailName, 0, 1) . str_repeat('*', max(4, strlen($mailName) - 1)) . '@' . $mailDomain;
}

if (!function_exists('tco_webshop_panel_open')) {
	function tco_webshop_panel_open(string $title): void {
		?>
		<div class="TableContainer tco-webshop-panel">
			<div class="CaptionContainer"><div class="CaptionInnerContainer">
				<span class="CaptionEdgeLeftTop" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionEdgeRightTop" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionBorderTop" style="background-image:url(<?= theme_asset('table-headline-border.gif') ?>);"></span>
				<span class="CaptionVerticalLeft" style="background-image:url(<?= theme_asset('box-frame-vertical.gif') ?>);"></span>
				<div class="Text"><?= h($title) ?></div>
				<span class="CaptionVerticalRight" style="background-image:url(<?= theme_asset('box-frame-vertical.gif') ?>);"></span>
				<span class="CaptionBorderBottom" style="background-image:url(<?= theme_asset('table-headline-border.gif') ?>);"></span>
				<span class="CaptionEdgeLeftBottom" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
				<span class="CaptionEdgeRightBottom" style="background-image:url(<?= theme_asset('box-frame-edge.gif') ?>);"></span>
			</div></div>
			<table class="Table5" cellpadding="0" cellspacing="0"><tbody><tr><td>
				<div class="InnerTableContainer"><div class="tco-webshop-panel-content">
		<?php
	}

	function tco_webshop_panel_close(): void {
		?></div></div></td></tr></tbody></table></div><?php
	}
}

if (!function_exists('tco_webshop_offer_image')) {
function tco_webshop_offer_image(array $offer): string {
	global $config;
	$type = (int)($offer['type'] ?? 0);
	$itemId = $offer['itemid'] ?? 0;
	if ($type === 1) {
		return '<img class="tco-offer-image" src="' . h(znote_item_image_url((int)$itemId)) . '" alt="">';
	}
	if ($type === 5) {
		$ids = is_array($itemId) ? array_slice($itemId, 0, 2) : array($itemId);
		$html = '';
		foreach ($ids as $id) {
			$url = (string)($config['show_outfits']['imageServer'] ?? '') . '?id=' . (int)$id
				. '&addons=' . (int)($offer['count'] ?? 0) . '&head=78&body=68&legs=58&feet=76';
			$html .= '<img class="tco-offer-image tco-outfit-image" src="' . h($url) . '" alt="">';
		}
		return $html;
	}
	if ($type === 6) {
		$url = (string)($config['show_outfits']['imageServer'] ?? '')
			. '?id=128&addons=3&head=78&body=68&legs=58&feet=76&mount=' . (int)$itemId . '&direction=2';
		return '<img class="tco-offer-image" src="' . h($url) . '" alt="">';
	}
	$serviceImages = array(
		2 => 'PremiumIcon-Trainingstatues.png',
		3 => 'changesex.png',
		4 => 'changename.png',
	);
	return '<img class="tco-offer-image" src="' . theme_asset($serviceImages[$type] ?? 'icon-tibiacoin.png') . '" alt="">';
}
}
?>
<link rel="stylesheet" href="<?= theme_asset('webshop-overlay.css') ?>">
<div class="tco-webshop-backdrop"></div>
<?php tco_box_open('Webshop', 'webshop', 'webshop'); ?>

<div class="tco-progress" id="tcoWebshopProgress" data-step="1">
	<div class="tco-progress-line"></div>
	<?php foreach (array('Select product', 'Enter payment data', 'Confirm your order', 'Summary') as $index => $label): ?>
		<div class="tco-progress-step" data-step="<?= $index + 1 ?>">
			<img
				src="<?= theme_asset('progress-bar-icon-' . ($index + 1) . (($index === 0) ? '-green.gif' : '-blue.gif')) ?>"
				data-blue="<?= theme_asset('progress-bar-icon-' . ($index + 1) . '-blue.gif') ?>"
				data-green="<?= theme_asset('progress-bar-icon-' . ($index + 1) . '-green.gif') ?>"
				alt=""
			>
			<span><?= h($label) ?></span>
		</div>
	<?php endforeach; ?>
</div>

<?php if ($tcoLoggedIn): ?>
	<div class="CustomerIdentification">Order for: <span><?= h($tcoMaskedEmail) ?></span></div>
<?php endif; ?>

<nav id="shop" class="tco-webshop-tabs" aria-label="Webshop categories">
	<a href="shop.php" class="<?= $tcoWebshopActiveTab === 'offers' ? 'is-active' : '' ?>">Outfits &amp; Items</a>
	<a href="shop.php?shop_tab=services" class="<?= $tcoWebshopActiveTab === 'services' ? 'is-active' : '' ?>">Services</a>
	<a href="buypoints.php" class="<?= $tcoWebshopActiveTab === 'points' ? 'is-active' : '' ?>">Buy Points</a>
</nav>

<section class="tco-webshop-tab <?= $tcoWebshopActiveTab === 'offers' ? 'is-active' : '' ?>" data-tab="offers">
	<?php tco_webshop_panel_open('Outfits & Items'); ?>
	<div class="tco-shop-filters" role="tablist">
		<button type="button" class="is-active" data-filter="all">All</button>
		<?php foreach (array('items' => 'Items', 'outfits' => 'Outfits', 'mounts' => 'Mounts') as $group => $label): ?>
			<?php if ($tcoOfferGroups[$group]): ?><button type="button" data-filter="<?= h($group) ?>"><?= h($label) ?></button><?php endif; ?>
		<?php endforeach; ?>
	</div>
	<div class="tco-offer-grid">
		<?php foreach (array('items', 'outfits', 'mounts') as $group): foreach ($tcoOfferGroups[$group] as $offerId => $offer): ?>
			<form action="shop.php" method="post" class="tco-offer-card" data-offer-group="<?= h($group) ?>">
				<?= znote_csrf_field() ?>
				<input type="hidden" name="buy" value="<?= (int)$offerId ?>">
				<input type="hidden" name="session" value="<?= h($tcoShopSession) ?>">
				<div class="tco-offer-visual" style="background-image:url(<?= theme_asset('serviceid_icon_normal.png') ?>);">
					<div class="tco-offer-name"><?= h((string)$offer['description']) ?></div>
					<div class="tco-offer-picture"><?= tco_webshop_offer_image($offer) ?></div>
					<div class="tco-offer-price"><?= (int)$offer['points'] ?> Points</div>
				</div>
				<?php if ($tcoLoggedIn): ?>
					<button type="submit" class="tco-purchase-button needconfirmation" data-item-name="<?= h((string)$offer['description']) ?>" data-item-cost="<?= (int)$offer['points'] ?>">Purchase</button>
				<?php else: ?><a class="tco-purchase-button" href="login.php">Login to purchase</a><?php endif; ?>
			</form>
		<?php endforeach; endforeach; ?>
		<?php if (!$tcoOfferGroups['items'] && !$tcoOfferGroups['outfits'] && !$tcoOfferGroups['mounts']): ?>
			<p>No item or outfit offers are currently available.</p>
		<?php endif; ?>
	</div>
	<div class="tco-stage-actions"><a class="tco-big-button is-cancel" href="index.php">Close</a></div>
	<?php tco_webshop_panel_close(); ?>
</section>

<section class="tco-webshop-tab <?= $tcoWebshopActiveTab === 'services' ? 'is-active' : '' ?>" data-tab="services">
	<?php tco_webshop_panel_open('Services'); ?>
	<div class="tco-offer-grid">
		<?php foreach ($tcoOfferGroups['services'] as $offerId => $offer): ?>
			<form action="shop.php?shop_tab=services" method="post" class="tco-offer-card">
				<?= znote_csrf_field() ?>
				<input type="hidden" name="buy" value="<?= (int)$offerId ?>">
				<input type="hidden" name="session" value="<?= h($tcoShopSession) ?>">
				<div class="tco-offer-visual" style="background-image:url(<?= theme_asset('serviceid_icon_normal.png') ?>);">
					<div class="tco-offer-name"><?= h((string)$offer['description']) ?></div>
					<div class="tco-offer-picture"><?= tco_webshop_offer_image($offer) ?></div>
					<div class="tco-offer-price"><?= (int)$offer['points'] ?> Points</div>
				</div>
				<?php if ($tcoLoggedIn): ?>
					<button type="submit" class="tco-purchase-button needconfirmation" data-item-name="<?= h((string)$offer['description']) ?>" data-item-cost="<?= (int)$offer['points'] ?>">Purchase</button>
				<?php else: ?><a class="tco-purchase-button" href="login.php">Login to purchase</a><?php endif; ?>
			</form>
		<?php endforeach; ?>
		<?php if (!$tcoOfferGroups['services']): ?><p>No service offers are currently available.</p><?php endif; ?>
	</div>
	<div class="tco-stage-actions"><a class="tco-big-button is-cancel" href="index.php">Close</a></div>
	<?php tco_webshop_panel_close(); ?>
</section>

<section class="tco-webshop-tab <?= $tcoWebshopActiveTab === 'points' ? 'is-active' : '' ?>" data-tab="points">
	<div class="tco-payment-stage is-active" data-payment-stage="1">
		<?php tco_webshop_panel_open('Select product'); ?>
		<div class="tco-country-row"><strong>Country:</strong><select id="tcoWebshopCountry"><option>France</option><option>Belgium</option><option>Brazil</option><option>Germany</option><option>Poland</option><option>Portugal</option><option>Spain</option><option>United States</option></select></div>
		<h3>Buy Points</h3>
		<div class="tco-product-grid" id="tcoPointPackages">
			<?php $packageIndex = 0; foreach ($tcoPrices as $price => $points): $packageIndex++; $imageId = 132 + min($packageIndex, 6); ?>
				<label class="tco-point-package">
					<input type="radio" name="tco-point-package" value="<?= h((string)$price) ?>" data-points="<?= (int)$points ?>" data-providers="paypal,stripe,mercadopago,pagseguro">
					<span class="tco-service-icon" style="background-image:url(<?= theme_asset('serviceid_icon_normal.png') ?>);">
						<span class="tco-service-label"><?= (int)$points ?> Points</span>
						<img src="<?= theme_asset('serviceid_' . $imageId . '.png') ?>" alt="">
						<span class="tco-service-price" data-base-price="<?= h((string)$price) ?>" data-points="<?= (int)$points ?>"><?= h((string)$price) ?> <?= h($tcoDefaultCurrency) ?></span>
					</span>
					<form style="display:none" aria-hidden="true"><input type="hidden" name="amount" value="<?= h((string)$price) ?>"></form>
				</label>
			<?php endforeach; ?>
			<?php if ($tcoProviders['paygol']['enabled'] && $tcoProviders['paygol']['fixed_points'] > 0): ?>
				<label class="tco-point-package">
					<input type="radio" name="tco-point-package" value="<?= h($tcoProviders['paygol']['fixed_price']) ?>" data-points="<?= (int)$tcoProviders['paygol']['fixed_points'] ?>" data-providers="paygol">
					<span class="tco-service-icon" style="background-image:url(<?= theme_asset('serviceid_icon_normal.png') ?>);">
						<span class="tco-service-label"><?= (int)$tcoProviders['paygol']['fixed_points'] ?> Points</span>
						<img src="<?= theme_asset('serviceid_133.png') ?>" alt="">
						<span class="tco-service-price" data-base-price="<?= h($tcoProviders['paygol']['fixed_price']) ?>" data-points="<?= (int)$tcoProviders['paygol']['fixed_points'] ?>"><?= h($tcoProviders['paygol']['fixed_price']) ?> <?= h($tcoProviders['paygol']['currency']) ?></span>
					</span>
				</label>
			<?php endif; ?>
		</div>
		<div id="buypointsTable"></div>
		<h3>Payment method</h3>
		<div class="tco-payment-grid" id="tcoPaymentMethods">
			<?php foreach ($tcoProviders as $providerKey => $provider): ?>
				<label class="tco-payment-method <?= $provider['enabled'] ? '' : 'is-disabled' ?>">
					<input type="radio" name="tco-payment-provider" value="<?= h($providerKey) ?>" data-currency="<?= h($provider['currency']) ?>" data-enabled="<?= $provider['enabled'] ? '1' : '0' ?>"<?= isset($provider['unit_price']) ? ' data-unit-price="' . h((string)$provider['unit_price']) . '"' : '' ?> <?= $provider['enabled'] ? '' : 'disabled' ?>>
					<span class="tco-payment-icon" style="background-image:url(<?= theme_asset('pmcid_icon_normal.png') ?>);">
						<?php if ($provider['image'] !== ''): ?><img src="<?= h($provider['image']) ?>" alt="<?= h($provider['label']) ?>"><?php else: ?><span class="tco-payment-brand tco-payment-brand-pagseguro">PagSeguro</span><?php endif; ?>
						<span class="tco-payment-label"><?= h($provider['label']) ?></span>
						<span class="tco-payment-time"><span><?= $provider['enabled'] ? 'Usual Process Time:<br>' . h($provider['time']) : 'Currently unavailable' ?></span></span>
					</span>
				</label>
			<?php endforeach; ?>
		</div>
		<div class="tco-stage-error" id="tcoPaymentSelectionError" role="alert"></div>
		<div class="tco-stage-actions"><button type="button" class="tco-big-button" data-payment-next="2">Next</button><a class="tco-big-button is-cancel" href="index.php">Cancel</a></div>
		<?php tco_webshop_panel_close(); ?>
	</div>

	<div class="tco-payment-stage" data-payment-stage="2">
		<?php tco_webshop_panel_open('Enter payment data'); ?>
		<div class="tco-order-summary"></div>
		<p>You will enter your secure payment details on the selected provider's checkout page.</p>
		<div class="tco-stage-actions"><span class="tco-stage-action-group"><button type="button" class="tco-big-button" data-payment-back="1">Back</button><button type="button" class="tco-big-button" data-payment-next="3">Next</button></span><a class="tco-big-button is-cancel" href="index.php">Cancel</a></div>
		<?php tco_webshop_panel_close(); ?>
	</div>

	<div class="tco-payment-stage" data-payment-stage="3">
		<?php tco_webshop_panel_open('Confirm your order'); ?>
		<div class="tco-order-summary"></div>
		<p>Please verify your order. Clicking &ldquo;Confirm order&rdquo; opens the secure checkout of your selected payment provider.</p>
		<div class="tco-checkout-forms">
			<?php foreach ($tcoProviders as $providerKey => $provider): if (!$provider['enabled']) continue; foreach ($tcoPrices as $price => $points): ?>
				<?php if ($providerKey === 'paypal'): ?>
					<form class="tco-checkout-form" data-provider="paypal" data-price="<?= h((string)$price) ?>" action="https://www.paypal.com/cgi-bin/webscr" method="post">
						<input type="hidden" name="cmd" value="_xclick"><input type="hidden" name="business" value="<?= hhb_tohtml($config['paypal']['email']) ?>">
						<input type="hidden" name="item_name" value="<?= h(t('buypoints.shop_points_on', array('points' => $points, 'site' => $config['site_title']))) ?>">
						<input type="hidden" name="item_number" value="1"><input type="hidden" name="amount" value="<?= h((string)$price) ?>">
						<input type="hidden" name="no_shipping" value="1"><input type="hidden" name="no_note" value="1"><input type="hidden" name="currency_code" value="<?= h($provider['currency']) ?>">
						<input type="hidden" name="return" value="<?= hhb_tohtml($config['paypal']['success']) ?>"><input type="hidden" name="cancel_return" value="<?= hhb_tohtml($config['paypal']['failed']) ?>">
						<input type="hidden" name="notify_url" value="<?= hhb_tohtml($config['paypal']['ipn']) ?>"><input type="hidden" name="custom" value="<?= (int)$session_user_id ?>">
						<button type="submit" class="tco-big-button">Confirm order</button>
					</form>
				<?php elseif ($providerKey === 'stripe' || $providerKey === 'mercadopago'): ?>
					<form class="tco-checkout-form" data-provider="<?= h($providerKey) ?>" data-price="<?= h((string)$price) ?>" action="payment.php" method="post">
						<?php Token::create(); ?><input type="hidden" name="provider" value="<?= h($providerKey) ?>"><input type="hidden" name="price" value="<?= h((string)$price) ?>">
						<button type="submit" class="tco-big-button">Confirm order</button>
					</form>
				<?php elseif ($providerKey === 'pagseguro'): $pagSeguroTotal = number_format((int)$points * (float)$provider['unit_price'], 2, '.', ''); ?>
					<form class="tco-checkout-form" data-provider="pagseguro" data-price="<?= h($pagSeguroTotal) ?>" target="pagseguro" action="https://<?= h((string)($config['pagseguro']['urls']['www'] ?? 'pagseguro.uol.com.br')) ?>/checkout/checkout.jhtml" method="post">
						<input type="hidden" name="email_cobranca" value="<?= hhb_tohtml($config['pagseguro']['email'] ?? '') ?>"><input type="hidden" name="tipo" value="CP"><input type="hidden" name="moeda" value="<?= h($provider['currency']) ?>">
						<input type="hidden" name="ref_transacao" value="<?= (int)$session_user_id ?>"><input type="hidden" name="item_id_1" value="1"><input type="hidden" name="item_descr_1" value="<?= hhb_tohtml($config['pagseguro']['product_name'] ?? '') ?>">
						<input type="hidden" name="item_quant_1" value="<?= (int)$points ?>"><input type="hidden" name="item_peso_1" value="0"><input type="hidden" name="item_valor_1" value="<?= h((string)($config['pagseguro']['price'] ?? 0)) ?>">
						<button type="submit" class="tco-big-button">Confirm order</button>
					</form>
				<?php endif; ?>
			<?php endforeach; endforeach; ?>
			<?php if ($tcoProviders['paygol']['enabled']): ?>
				<form class="tco-checkout-form" data-provider="paygol" data-price="<?= h($tcoProviders['paygol']['fixed_price']) ?>" action="http://www.paygol.com/micropayment/paynow" method="post">
					<input type="hidden" name="pg_serviceid" value="<?= hhb_tohtml($config['paygol']['serviceID'] ?? '') ?>"><input type="hidden" name="pg_currency" value="<?= h($tcoProviders['paygol']['currency']) ?>"><input type="hidden" name="pg_name" value="<?= hhb_tohtml($config['paygol']['name'] ?? '') ?>">
					<input type="hidden" name="pg_custom" value="<?= (int)$session_user_id ?>"><input type="hidden" name="pg_price" value="<?= h($tcoProviders['paygol']['fixed_price']) ?>"><input type="hidden" name="pg_return_url" value="<?= hhb_tohtml($config['paygol']['returnURL'] ?? '') ?>"><input type="hidden" name="pg_cancel_url" value="<?= hhb_tohtml($config['paygol']['cancelURL'] ?? '') ?>">
					<button type="submit" class="tco-big-button">Confirm order</button>
				</form>
			<?php endif; ?>
		</div>
		<div class="tco-stage-actions"><button type="button" class="tco-big-button" data-payment-back="2">Back</button><a class="tco-big-button is-cancel" href="index.php">Cancel</a></div>
		<?php tco_webshop_panel_close(); ?>
	</div>
</section>

<?php tco_box_close(); ?>
<script src="<?= theme_asset('webshop-overlay.js') ?>"></script>
