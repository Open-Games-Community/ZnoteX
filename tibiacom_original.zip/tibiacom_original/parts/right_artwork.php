<?php
$tcoBoostedVisuals = array();
if (function_exists('boosted_creatures_enabled')
	&& boosted_creatures_enabled()
	&& function_exists('boosted_creatures_data')
	&& function_exists('boosted_creatures_outfit_url')) {
	$tcoBoostedData = boosted_creatures_data();
	foreach (array('creature', 'boss') as $tcoBoostedType) {
		if (!isset($tcoBoostedData[$tcoBoostedType])) continue;
		$tcoBoostedRow = $tcoBoostedData[$tcoBoostedType];
		$tcoBoostedImage = boosted_creatures_outfit_url($tcoBoostedRow);
		if ($tcoBoostedImage === '') continue;
		$tcoBoostedVisuals[$tcoBoostedType] = array(
			'image' => $tcoBoostedImage,
			'name' => (string)($tcoBoostedRow['name'] ?? ''),
			'url' => function_exists('boosted_creatures_link_url') ? boosted_creatures_link_url($tcoBoostedRow) : '',
		);
	}
}
?>
<?php if ($tcoBoostedVisuals): ?>
	<div id="RightArtwork" aria-label="Today's boosted creatures">
		<img id="Pedestal" src="<?= theme_asset('pedestal_boosted.gif') ?>" alt="">
		<?php foreach (array('creature' => 'Monster', 'boss' => 'Boss') as $tcoBoostedType => $tcoBoostedId): ?>
			<?php if (isset($tcoBoostedVisuals[$tcoBoostedType])):
				$tcoBoosted = $tcoBoostedVisuals[$tcoBoostedType];
				$tcoBoostedTitle = ($tcoBoostedType === 'boss' ? 'Today\'s boosted boss: ' : 'Today\'s boosted creature: ') . $tcoBoosted['name'];
			?>
				<?php if ($tcoBoosted['url'] !== ''): ?><a href="<?= h($tcoBoosted['url']) ?>" title="<?= h($tcoBoostedTitle) ?>"><?php endif; ?>
					<img id="<?= $tcoBoostedId ?>" src="<?= h($tcoBoosted['image']) ?>" alt="<?= h($tcoBoostedTitle) ?>">
				<?php if ($tcoBoosted['url'] !== ''): ?></a><?php endif; ?>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
