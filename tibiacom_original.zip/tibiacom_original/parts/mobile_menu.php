<?php $tcoLoggedInMobile = function_exists('user_logged_in') && user_logged_in() === true; ?>
<header id="MobileMenu">
	<nav>
		<div class="MobileTibiaLogo"><a href="index.php" aria-label="<?= h(theme_title()) ?>"> </a></div>

		<input type="checkbox" id="MobileShortMenuIcon">
		<label for="MobileShortMenuIcon" id="MyAccount" class="MobileShortMenuIconContainer MobileNavigationMainElement"></label>
		<div class="MobileMenuItems MobileShortMenuItems">
			<ul class="MobileShortMenuItemsList">
				<?php if ($tcoLoggedInMobile): ?>
					<li class="MobileNavigationLinkContainer">
						<form action="myaccount.php" method="get" style="padding:0;margin:0;">
							<div class="BigButton" style="background-image:url(<?= theme_asset('button_green.gif') ?>)">
								<div>
									<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_green_over.gif') ?>);"></div>
									<input class="BigButtonText" type="submit" value="<?= h(t_default('tco.myaccount', 'My Account')) ?>">
								</div>
							</div>
						</form>
					</li>
					<li class="MobileNavigationLinkContainer">
						<form action="logout.php" method="get" style="padding:0;margin:0;">
							<div class="BigButton" style="background-image:url(<?= theme_asset('button_red.gif') ?>)">
								<div>
									<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_red_over.gif') ?>);"></div>
									<input class="BigButtonText" type="submit" value="<?= h(t('nav.logout')) ?>">
								</div>
							</div>
						</form>
					</li>
				<?php else: ?>
					<li class="MobileNavigationLinkContainer">
						<form action="login.php" method="get" style="padding:0;margin:0;">
							<div class="BigButton" style="background-image:url(<?= theme_asset('button_green.gif') ?>)">
								<div>
									<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_green_over.gif') ?>);"></div>
									<input class="BigButtonText" type="submit" value="<?= h(t('nav.login')) ?>">
								</div>
							</div>
						</form>
					</li>
					<li class="MobileNavigationLinkContainer">
						<form action="register.php" method="get" style="padding:0;margin:0;">
							<div class="BigButton" style="background-image:url(<?= theme_asset('button_blue.gif') ?>)">
								<div>
									<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_blue_over.gif') ?>);"></div>
									<input class="BigButtonText" type="submit" value="<?= h(t('nav.register')) ?>">
								</div>
							</div>
						</form>
					</li>
				<?php endif; ?>
				<li class="MobileNavigationLinkContainer">
					<form action="support.php" method="get" style="padding:0;margin:0;">
						<div class="BigButton" style="background-image:url(<?= theme_asset('button_blue.gif') ?>)">
							<div>
								<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_blue_over.gif') ?>);"></div>
								<input class="BigButtonText" type="submit" value="<?= h(t_default('tco.nav.support', 'Support')) ?>">
							</div>
						</div>
					</form>
				</li>
			</ul>
		</div>

		<input type="checkbox" id="MobileMenuIcon">
		<label for="MobileMenuIcon" class="MobileMenuIconContainer MobileNavigationMainElement"></label>
		<ul class="MobileMenuItems">
			<?php foreach (tco_nav_items() as $key => $group): ?>
				<li class="Level1Block" id="mobile_<?= h($key) ?>">
					<div class="Level1Entry" data-tco-toggle="mobile_<?= h($key) ?>"><?= h($group['label']) ?></div>
					<ul>
						<?php foreach ($group['items'] as $item): ?>
							<li class="Level2Block MobileNavigationLinkContainer">
								<a class="Level2Entry" href="<?= h($item['url']) ?>"<?= $item['target'] !== '' ? ' target="' . h($item['target']) . '" rel="noopener"' : '' ?>><?= h($item['label']) ?></a>
							</li>
						<?php endforeach; ?>
					</ul>
				</li>
			<?php endforeach; ?>
		</ul>
	</nav>
</header>
