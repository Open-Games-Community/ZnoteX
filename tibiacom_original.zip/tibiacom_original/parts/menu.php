<?php
$tcoActive = tco_current_page();
?>
<div id="Menu">
	<div id="MenuTop" style="background-image:url(<?= theme_asset('box_top.gif') ?>);"></div>
	<?php foreach (tco_nav_items() as $key => $group):
		$hasActive = false;
		foreach ($group['items'] as $item) {
			if (tco_nav_is_active($item)) {
				$hasActive = true;
			}
		}
	?>
		<div id="<?= h($key) ?>" class="menuitem<?= $hasActive ? ' MenuItemOpen' : '' ?>">
			<span class="tco-menu-toggle" data-target="<?= h($key) ?>">
				<div class="MenuButton" style="background-image:url(<?= theme_asset('button_background.gif') ?>);">
					<div><div class="Button" style="background-image:url(<?= theme_asset('button_background_over.gif') ?>);"></div>
						<div id="<?= h($key) ?>_Icon" class="Icon" style="background-image:url(<?= theme_asset($group['icon']) ?>);"></div>
					<div id="<?= h($key) ?>_Label" class="Label<?= $group['label_img'] === '' ? ' tco-menu-label-text' : '' ?>"<?= $group['label_img'] !== '' ? ' style="background-image:url(' . h(theme_asset($group['label_img'])) . ');"' : '' ?>>
						<?= $group['label_img'] === '' ? h($group['label']) : '' ?>
					</div>
						<div id="<?= h($key) ?>_Extend" class="Extend" data-plus="<?= theme_asset('plus.gif') ?>" data-minus="<?= theme_asset('minus.gif') ?>"
						style="background-image:url(<?= theme_asset($hasActive ? 'minus.gif' : 'plus.gif') ?>);"></div>
					</div>
				</div>
			</span>
			<div id="<?= h($key) ?>_Submenu" class="Submenu" style="<?= $hasActive ? 'display:block;' : 'display:none;' ?>">
				<?php foreach ($group['items'] as $item):
					$active = tco_nav_is_active($item);
				?>
					<a href="<?= h($item['url']) ?>"<?= $item['target'] !== '' ? ' target="' . h($item['target']) . '" rel="noopener"' : '' ?>>
						<div id="submenu_<?= h($item['id']) ?>" class="Submenuitem<?= $active ? ' ActiveSubmenuItem' : '' ?>">
							<div class="LeftChain" style="background-image:url(<?= theme_asset('chain.gif') ?>);"></div>
							<div id="ActiveSubmenuItemIcon_<?= h($item['id']) ?>" class="ActiveSubmenuItemIcon" style="background-image:url(<?= theme_asset('icon_active_submenu.gif') ?>);<?= $active ? 'visibility:visible;' : '' ?>"></div>
							<div id="ActiveSubmenuItemLabel_<?= h($item['id']) ?>" class="SubmenuitemLabel"><?= h($item['label']) ?></div>
							<div class="RightChain" style="background-image:url(<?= theme_asset('chain.gif') ?>);"></div>
						</div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endforeach; ?>
	<div id="MenuBottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
</div>
