<?php
$tcoOnline = function_exists('znote_server_adapter') ? znote_server_adapter()->onlineCount() : 0;
$tcoDiscord = theme_option('discord_url');
$tcoTwitch = theme_option('twitch_url');
$tcoYoutube = theme_option('youtube_url');
$tcoWhatsapp = theme_option('whatsapp_url');
?>
<div class="Box" id="tco-infobar">
	<div class="Corner-tl" style="background-image:url(<?= theme_asset('corner-tl.gif') ?>);"></div>
	<div class="Corner-tr" style="background-image:url(<?= theme_asset('corner-tr.gif') ?>);"></div>
	<div class="Border_1" style="background-image:url(<?= theme_asset('border-1.gif') ?>);"></div>
	<div class="BorderTitleText" style="background-image:url(<?= theme_asset('cacheinfo_background.gif') ?>); height: 28px;">
		<div class="InfoBar"><?php if ($tcoTwitch !== ''): ?><a class="InfoBarBlock" href="<?= h($tcoTwitch) ?>" target="_blank" rel="noopener noreferrer"><img class="InfoBarBigLogo NotOnMobile" src="<?= theme_asset('icon-twitch.png') ?>" alt="Twitch"><img class="InfoBarSmallLogo" src="<?= theme_asset('icon_mobile_twitch.png') ?>" alt="Twitch"></a><?php endif; ?><?php if ($tcoYoutube !== ''): ?><a class="InfoBarBlock" href="<?= h($tcoYoutube) ?>" target="_blank" rel="noopener noreferrer"><img class="InfoBarBigLogo NotOnMobile" src="<?= theme_asset('icon-youtube.png') ?>" alt="YouTube"><img class="InfoBarSmallLogo" src="<?= theme_asset('icon_mobile_youtube.png') ?>" alt="YouTube"></a><?php endif; ?><?php if ($tcoDiscord !== ''): ?><a class="InfoBarBlock" href="<?= h($tcoDiscord) ?>" target="_blank" rel="noopener noreferrer"><img class="InfoBarBigLogo" src="<?= theme_asset('icon-discord.png') ?>" alt="Discord"><span class="InfoBarNumbers NotOnMobile"><span class="InfoBarSmallElement"><?= h(t_default('tco.discord', 'Discord')) ?></span></span></a><?php endif; ?><?php if ($tcoWhatsapp !== ''): ?><a class="InfoBarBlock" href="<?= h($tcoWhatsapp) ?>" target="_blank" rel="noopener noreferrer"><img class="InfoBarBigLogo" src="<?= theme_asset('icon-whatsapp.png') ?>" alt="WhatsApp"><span class="InfoBarNumbers NotOnMobile"><span class="InfoBarSmallElement"><?= h(t_default('tco.whatsapp', 'WhatsApp')) ?></span></span></a><?php endif; ?><a style="float:right;" href="onlinelist.php"><img class="InfoBarBigLogo" src="<?= theme_asset('icon-players-online.png') ?>" alt=""><span class="InfoBarNumbers"><span class="InfoBarSmallElement"><?= number_format((int)$tcoOnline) ?><span class="NotOnMobile"> <?= h(t_default('tco.players_online', 'Players Online')) ?></span></span></span></a></div>
	</div>
	<div class="Border_1" style="background-image:url(<?= theme_asset('border-1.gif') ?>);"></div>
	<div class="CornerWrapper-b"><div class="Corner-bl" style="background-image:url(<?= theme_asset('corner-bl.gif') ?>);"></div></div>
	<div class="CornerWrapper-b"><div class="Corner-br" style="background-image:url(<?= theme_asset('corner-br.gif') ?>);"></div></div>
</div>
