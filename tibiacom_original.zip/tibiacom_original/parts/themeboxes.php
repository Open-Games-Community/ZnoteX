<?php
$tcoFacebookUrl = trim(theme_option('facebook_url'));
$tcoYoutubeUrl = trim(theme_option('youtube_url'));
$tcoFriendUrl = function_exists('user_logged_in') && user_logged_in() ? 'myaccount.php' : 'register.php';

if (!function_exists('tco_highscores_top5')) {
	function tco_highscores_top5(): array {
		try {
			$columns = array();
			foreach ((array)db()->fetchAll('SHOW COLUMNS FROM `players`;') as $column) {
				if (!empty($column['Field'])) $columns[(string)$column['Field']] = true;
			}
			$select = array('`name`', '`level`');
			foreach (array('looktype', 'lookaddons', 'lookhead', 'lookbody', 'looklegs', 'lookfeet', 'lookmount') as $field) {
				if (isset($columns[$field])) $select[] = '`' . $field . '`';
			}
			$where = array();
			if (isset($columns['deleted'])) $where[] = '`deleted` = 0';
			if (isset($columns['group_id'])) $where[] = '`group_id` < 2';
			$sql = 'SELECT ' . implode(', ', $select) . ' FROM `players`'
				. ($where ? ' WHERE ' . implode(' AND ', $where) : '')
				. ' ORDER BY `experience` DESC, `level` DESC LIMIT 5;';
			return (array)db()->fetchAll($sql);
		} catch (Throwable $e) {
			return array();
		}
	}
}
$tcoHighscores = tco_highscores_top5();
?>

<div id="TcoWebshopBox" class="Themebox">
	<a class="tco-themebox-cover" href="shop.php" aria-label="Webshop"></a>
	<div class="tco-webshop-tagline">Get Supplies Anywhere!</div>
	<img class="tco-webshop-art" src="<?= theme_asset('coins_trade.png') ?>" alt="">
	<div class="ThemeboxButton">
		<div class="BigButton" style="background-image:url(<?= theme_asset('button_blue.gif') ?>)">
			<div class="BigButtonOver" style="background-image:url(<?= theme_asset('button_blue_over.gif') ?>);"></div>
			<a class="BigButtonText" href="buypoints.php">Get Tibia Coins</a>
		</div>
	</div>
</div>

<div id="TcoHighscoresBox" class="Themebox">
	<a class="tco-themebox-headlink" href="highscores.php" aria-label="Highscores">
		<img class="tco-highscores-headline" src="<?= theme_asset('highscores.png') ?>" alt="Highscores">
	</a>
	<div class="Top tco-highscores-top" style="background-image:url(<?= theme_asset('box_top.gif') ?>);"></div>
	<div class="tco-highscores-body" style="background-image:url(<?= theme_asset('bg_top.png') ?>);">
		<?php if ($tcoHighscores): ?>
			<ol class="tco-highscores-list">
				<?php foreach ($tcoHighscores as $rank => $player): ?>
					<?php
						$name = (string)($player['name'] ?? '');
						$outfitUrl = '';
						if (!empty($player['looktype']) && !empty($config['show_outfits']['imageServer'])) {
							$outfitUrl = (string)$config['show_outfits']['imageServer']
								. '?id=' . (int)$player['looktype']
								. '&addons=' . (int)($player['lookaddons'] ?? 0)
								. '&head=' . (int)($player['lookhead'] ?? 78)
								. '&body=' . (int)($player['lookbody'] ?? 68)
								. '&legs=' . (int)($player['looklegs'] ?? 58)
								. '&feet=' . (int)($player['lookfeet'] ?? 76);
							if (!empty($player['lookmount'])) $outfitUrl .= '&mount=' . (int)$player['lookmount'];
						}
					?>
										<li class="tco-highscores-entry">
						<?php if ($outfitUrl !== ''): ?>
							<img class="tco-highscores-outfit" style="position:absolute;margin-top:-42px;margin-left:-72px;" src="<?= h($outfitUrl) ?>" alt="player outfit">
						<?php endif; ?>
						<a class="tco-highscores-player" href="characterprofile.php?name=<?= urlencode($name) ?>" title="<?= h($name) ?> - Level <?= (int)($player['level'] ?? 0) ?>">
							<span class="tco-highscores-name"><?= h($name) ?></span>
							<span class="tco-highscores-level">Level: (<?= (int)($player['level'] ?? 0) ?>)</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ol>
		<?php else: ?>
			<a class="tco-highscores-empty" href="highscores.php">View Highscores</a>
		<?php endif; ?>
	</div>
	<div class="Bottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
</div>

<div id="TcoTellFriendBox" class="Themebox">
	<a class="tco-themebox-cover" href="<?= $tcoFriendUrl ?>" aria-label="Tell a Friend"></a>
	<div class="Bottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
</div>

<div id="TcoNetworksBox" class="Themebox">
	<div class="tco-network-buttons">
		<?php if ($tcoFacebookUrl !== ''): ?>
			<a class="tco-network-button" href="<?= h($tcoFacebookUrl) ?>" target="_blank" rel="noopener" aria-label="Facebook">
		<?php else: ?>
			<span class="tco-network-button is-disabled" aria-label="Facebook URL is not configured" title="Configure the Facebook URL in the layout options">
		<?php endif; ?>
			<img class="idle" src="<?= theme_asset('button_facebook.png') ?>" alt="">
			<img class="hover" src="<?= theme_asset('button_facebook_over.png') ?>" alt="">
		<?= $tcoFacebookUrl !== '' ? '</a>' : '</span>' ?>

		<?php if ($tcoYoutubeUrl !== ''): ?>
			<a class="tco-network-button" href="<?= h($tcoYoutubeUrl) ?>" target="_blank" rel="noopener" aria-label="YouTube">
		<?php else: ?>
			<span class="tco-network-button is-disabled" aria-label="YouTube URL is not configured" title="Configure the YouTube URL in the layout options">
		<?php endif; ?>
			<img class="idle" src="<?= theme_asset('button_youtube.png') ?>" alt="">
			<img class="hover" src="<?= theme_asset('button_youtube_over.png') ?>" alt="">
		<?= $tcoYoutubeUrl !== '' ? '</a>' : '</span>' ?>
	</div>
	<div class="Bottom" style="background-image:url(<?= theme_asset('box_bottom.gif') ?>);"></div>
</div>