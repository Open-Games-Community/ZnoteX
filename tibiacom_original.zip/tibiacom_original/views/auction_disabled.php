<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades');
echo '<p>' . t('auc.disabled2') . '</p>';
tco_box_close();
