<?php
tco_box_open(t_default('tco.guild_x', 'Guild: ') . $guild['name'], 'guilds');
?>
<div class="tco-guild-overview">
	<?= $guildOverviewHtml ?>
</div>
<?php
tco_box_close();
