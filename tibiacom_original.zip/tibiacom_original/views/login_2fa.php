<?php
tco_box_open(t('twofa.title'), 'accountmanagement', 'accountmanagement');
tco_panel_open(t('twofa.title'));
?>
<tr>
	<td>
		<?php if (empty($errors) === false): ?>
			<font color="red"><b><?= output_errors($errors) ?></b></font>
		<?php endif; ?>
		<p>
			<?php if ($pendingStatus['totp_enabled']): ?>
				<?= t_default('twofa2.enter_app_code', 'Enter the code from your authenticator app, or a recovery code.') ?>
			<?php else: ?>
				<?= t_default('twofa2.enter_email_code', 'We emailed you a verification code. Enter it below, or use a recovery code.') ?>
			<?php endif; ?>
		</p>
		<form class="loginForm tco-login-form" method="post" action="login.php">
			<div class="tco-login-row">
				<label><?= t('widget.login.token') ?></label>
				<input class="tco-mini-input" type="text" name="tfa2_code" autocomplete="one-time-code" autofocus>
			</div>
			<?php if ((int)znote2fa_v2_config()['trusted_device_days'] > 0): ?>
				<div class="tco-login-row">
					<label><input type="checkbox" name="tfa2_trust" value="1"> <?= t_default('twofa2.trust_device', 'Remember this device') ?></label>
				</div>
			<?php endif; ?>
			<input type="hidden" name="tfa2_email_sent" value="1">
			<?php Token::create(); ?>
			<div class="tco-login-buttons">
				<?= tco_button(t('widget.login.submit'), 'blue') ?>
			</div>
		</form>
	</td>
</tr>
<?php
tco_panel_close();
tco_box_close();
