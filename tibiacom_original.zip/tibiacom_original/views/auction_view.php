<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades', 'currentcharactertrades');
?>
<p><a href="/auctionChar.php?action=list"><?= t('auc.go_back_list') ?></a></p>

<?php tco_panel_open(t_default('tco.auc_basic_info', 'Basic Information')); ?>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;">
		<td class="LabelV"><?= t('common.level') ?></td>
		<td><?= (int)$character['level'] ?></td>
	</tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;">
		<td class="LabelV"><?= t('common.vocation') ?></td>
		<td><?= h(vocation_id_to_name($character['vocation'])) ?></td>
	</tr>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;">
		<td class="LabelV"><?= t('common.sex') ?></td>
		<td><?= ((int)$character['sex'] === 1) ? t('common.male') : t('common.female') ?></td>
	</tr>
	<?php if ($loadOutfits): ?>
		<tr style="background-color:<?= tco_alt_bg(1) ?>;">
			<td class="LabelV"><?= t('common.image') ?></td>
			<td><img src="<?= h($config['show_outfits']['imageServer']) ?>?id=<?= (int)$character['type'] ?>&addons=<?= (int)$character['addons'] ?>&head=<?= (int)$character['head'] ?>&body=<?= (int)$character['body'] ?>&legs=<?= (int)$character['legs'] ?>&feet=<?= (int)$character['feet'] ?>" alt=""></td>
		</tr>
	<?php endif; ?>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;">
		<td class="LabelV"><?= t('auc.bank') ?></td>
		<td><?= (int)$character['balance'] ?></td>
	</tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;">
		<td class="LabelV"><?= t('auc.price') ?></td>
		<td><?= (int)$character['price'] ?> <img src="<?= theme_asset('icon-tibiacoin.png') ?>" alt="" style="width:12px;height:12px;vertical-align:middle;"></td>
	</tr>
	<?php if ($bidding_period): ?>
		<tr style="background-color:<?= tco_alt_bg(0) ?>;">
			<td class="LabelV"><?= t('auc.remaining') ?></td>
			<td><span data-auc2-countdown="<?= (int)$character['time_end'] ?>" data-auc2-ended-text="<?= h(t('auc.instant')) ?>"><?= h(toDuration((int)$character['time_end'] - time())) ?></span></td>
		</tr>
	<?php endif; ?>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t_default('tco.auc_action', 'Auction')); ?>
	<tr>
		<td>
			<?php if ($character['own'] == 0): ?>
				<?php if (is_array($account) && !empty($account)): ?>
					<p><?= t('common.you_have') ?> <strong><?= (int)$account['points'] ?></strong> <?= t('auc.points_remaining') ?></p>
					<?php if ((int)$character['bidder_account_id'] === $this_account_id): ?>
						<p><strong><?= t('auc.so_far_good') ?></strong> <?= t('auc.highest_bid') ?> <?= (int)$character['price'] - $step ?></p>
						<p><?= t('auc.yours_in') ?> <?= h(toDuration((int)$character['time_end'] - time())) ?></p>
					<?php endif; ?>
					<form action="/auctionChar.php" method="POST">
						<input type="hidden" name="action" value="bid">
						<input type="hidden" name="zaid" value="<?= (int)$character['zaid'] ?>">
						<input type="number" name="price" min="<?= (int)$character['price'] ?>" max="<?= (int)$account['points'] ?>" step="5" value="<?= (int)$character['price'] ?>" <?= !$bidding_period ? 'disabled' : '' ?>>
						<?php if (!$bidding_period): ?>
							<input type="hidden" name="price" value="<?= (int)$character['price'] ?>">
						<?php endif; ?>
						<div style="display:inline-block;vertical-align:middle;margin-left:5px;">
							<?= tco_button($bidding_period ? t('auc.bid_btn') : t('auc.buy_btn'), 'blue') ?>
						</div>
					</form>
				<?php else: ?>
					<?php if ((int)$character['bidder_account_id'] === $this_account_id): ?>
						<p><strong><?= t('auc.so_far_good') ?></strong> <?= t('auc.highest_bid') ?> <?= (int)$character['price'] - $step ?></p>
						<p><?= t('auc.yours_in') ?> <?= h(toDuration((int)$character['time_end'] - time())) ?></p>
					<?php else: ?>
						<p><?= t('auc.cannot_afford') ?></p>
					<?php endif; ?>
				<?php endif; ?>
			<?php else: ?>
				<p><strong><?= t('auc.is_seller') ?></strong><br>
					<?= t('common.name_label') ?> <a href="/characterprofile.php?name=<?= h($character['name']) ?>"><?= h($character['name']) ?></a><br>
					<?= t('auc.price') ?>: <?= (int)$character['price'] ?><br>
					<?= t('common.bid_label') ?> <?= (int)$character['bid'] ?><br>
					<?= t('auc.deposit') ?> <?= (int)$character['deposit'] ?>
				</p>
				<?php if (!$bidding_period): ?>
					<form action="/auctionChar.php" method="POST">
						<input type="hidden" name="action" value="refund">
						<input type="hidden" name="zaid" value="<?= (int)$character['zaid'] ?>">
						<div style="display:inline-block;vertical-align:middle;">
							<?= tco_button(t('auc.reclaim_btn'), 'blue') ?>
						</div>
					</form>
				<?php else: ?>
					<p><?= t('auc.bid_period') ?> <?= h(toDuration($character['time_end'] - time())) ?>. <?= t('auc.reclaim_after_period') ?></p>
				<?php endif; ?>
			<?php endif; ?>
		</td>
	</tr>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t('auc.skills')); ?>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;"><td class="LabelV"><?= t('char.magic_level') ?></td><td><?= (int)$character['magic'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;"><td class="LabelV"><?= t('skill.fist') ?></td><td><?= (int)$character['fist'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;"><td class="LabelV"><?= t('skill.club') ?></td><td><?= (int)$character['club'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;"><td class="LabelV"><?= t('skill.sword') ?></td><td><?= (int)$character['sword'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;"><td class="LabelV"><?= t('skill.axe') ?></td><td><?= (int)$character['axe'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;"><td class="LabelV"><?= t('skill.distance') ?></td><td><?= (int)$character['dist'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;"><td class="LabelV"><?= t('skill.shielding') ?></td><td><?= (int)$character['shielding'] ?></td></tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;"><td class="LabelV"><?= t('skill.fishing') ?></td><td><?= (int)$character['fishing'] ?></td></tr>
<?php tco_panel_close(); ?>

<?php
$tcoAucItemGroups = array(
	t('auc.player_items') => (is_array($player_items) ? $player_items : array()),
	t('auc.depot_items') => (is_array($depot_items) ? $depot_items : array()),
);
$tcoAucHasItems = false;
foreach ($tcoAucItemGroups as $tcoAucGroupItems) {
	if (!empty($tcoAucGroupItems)) { $tcoAucHasItems = true; break; }
}
?>

<?php if ($tcoAucHasItems): ?>
	<p><input type="text" id="tcoAucItemSearch" class="tco-auc-item-search" placeholder="<?= h(t('auc.item_search_placeholder')) ?>"></p>
<?php endif; ?>

<?php foreach ($tcoAucItemGroups as $tcoAucGroupTitle => $tcoAucGroupItems): ?>
	<?php if (!empty($tcoAucGroupItems)): ?>
		<?php tco_panel_open($tcoAucGroupTitle); ?>
			<tr>
				<td colspan="3">
					<div class="tco-auc-item-grid">
						<?php foreach ($tcoAucGroupItems as $item): ?>
							<?php $tcoAucItemName = (string)($items[$item['itemtype']] ?? $item['itemtype']); ?>
							<a class="tco-auc-item-tile" href="items.php?item=<?= (int)$item['itemtype'] ?>" title="<?= h($tcoAucItemName) ?>" data-auc-item-name="<?= h(strtolower($tcoAucItemName)) ?>">
								<img src="<?= h(znote_item_image_url((int)$item['itemtype'])) ?>" alt="<?= h($tcoAucItemName) ?>">
								<?php if ((int)$item['count'] > 1): ?><span class="tco-auc-item-count"><?= (int)$item['count'] ?></span><?php endif; ?>
							</a>
						<?php endforeach; ?>
					</div>
				</td>
			</tr>
		<?php tco_panel_close(); ?>
	<?php endif; ?>
<?php endforeach; ?><?php
tco_box_close();
?>
<script>
document.addEventListener('DOMContentLoaded', function () {
	document.querySelectorAll('[data-auc2-countdown]').forEach(function (el) {
		var end = parseInt(el.getAttribute('data-auc2-countdown'), 10);
		function tick() {
			var remaining = end - Math.floor(Date.now() / 1000);
			if (remaining <= 0) {
				el.textContent = el.getAttribute('data-auc2-ended-text') || '';
				return;
			}
			var d = Math.floor(remaining / 86400);
			var h = Math.floor((remaining % 86400) / 3600);
			var m = Math.floor((remaining % 3600) / 60);
			var s = remaining % 60;
			var parts = [];
			if (d > 0) parts.push(d + (d === 1 ? ' day' : ' days'));
			if (h > 0) parts.push(h + (h === 1 ? ' hour' : ' hours'));
			if (m > 0) parts.push(m + (m === 1 ? ' minute' : ' minutes'));
			if (s > 0) parts.push(s + (s === 1 ? ' second' : ' seconds'));
			el.textContent = parts.join(', ');
			setTimeout(tick, 1000);
		}
		tick();
	});

	var search = document.getElementById('tcoAucItemSearch');
	if (search) {
		search.addEventListener('keyup', function () {
			var needle = search.value.trim().toLowerCase();
			document.querySelectorAll('.tco-auc-item-tile').forEach(function (tile) {
				var name = tile.getAttribute('data-auc-item-name') || '';
				tile.hidden = (needle !== '' && name.indexOf(needle) === -1);
			});
		});
	}
});
</script>
