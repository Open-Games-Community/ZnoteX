<?php
tco_box_open(t_default('tco.feedback_form', 'Feedback Form'), 'feedbackform');

if ($tickets !== false && !empty($tickets)) {
	tco_panel_open(t('helpdesk.latest'));
	$i = 0;
	foreach ($tickets as $ticket) {
		$i++;
		?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td class="LabelV"><?= (int)$ticket['id'] ?></td>
			<td><a href="helpdesk.php?view=<?= (int)$ticket['id'] ?>"><?= h($ticket['subject']) ?></a></td>
			<td><?= h(getClock($ticket['creation'], true)) ?></td>
			<td><?= h($ticket['status']) ?></td>
		</tr>
		<?php
	}
	tco_panel_close();
	?>
	<br>
	<?php
}

tco_panel_open(t('helpdesk.title'));
if ($helpdeskCreated) {
	?>
	<tr><td><?= t('helpdesk.created') ?></td></tr>
	<?php
} else {
	?>
	<tr>
		<td>
			<?php if (empty($errors) === false): ?>
				<font color="red"><b><?= output_errors($errors) ?></b></font>
			<?php endif; ?>
			<form action="" method="post">
				<ul>
					<li>
						<?= t_default('tco.account_name', 'Account Name:') ?><br>
						<input class="tco-mini-input" type="text" name="username" size="40" value="<?= h($account['name']) ?>" disabled>
					</li>
					<li>
						<?= t_default('tco.email', 'Email') ?>:<br>
						<input class="tco-mini-input" type="text" name="email" size="40" value="<?= h($account['email']) ?>" disabled>
					</li>
					<li>
						<?= t('helpdesk.subject') ?><br>
						<input class="tco-mini-input" type="text" name="subject" size="40">
					</li>
					<li>
						<?= t_default('tco.message', 'Message:') ?><br>
						<textarea class="tco-mini-input" name="message" rows="7" cols="30"></textarea>
					</li>
					<?php if ($config['use_captcha']): ?>
						<li>
							<div class="g-recaptcha" data-sitekey="<?= h($config['captcha_site_key']) ?>"></div>
						</li>
					<?php endif; ?>
					<?php Token::create(); ?>
					<li>
						<input type="hidden" name="username" value="<?= h($account['name']) ?>">
						<?= tco_button(t('helpdesk.submit'), 'blue') ?>
					</li>
				</ul>
			</form>
		</td>
	</tr>
	<?php
}
tco_panel_close();
tco_box_close();
