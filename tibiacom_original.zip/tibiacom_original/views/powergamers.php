<?php
tco_wrap_default_view('powergamers', 'leaderboards');
