<?php
tco_box_open(t_default('tco.feedback_form', 'Feedback Form'), 'feedbackform');
?>
<p class="tco-plain-heading" style="text-align:left;font-size:13pt;">
	<?= t_default('tco.view_ticket', 'View Ticket #') ?><?= (int)$ticketData['id'] ?>
	<?php if ($ticketData['status'] === 'CLOSED'): ?>
		<span style="color:red;">[<?= t_default('tco.closed', 'CLOSED') ?>]</span>
	<?php endif; ?>
</p>
<?php
tco_panel_open(h(getClock($ticketData['creation'], true)) . ' - ' . t_default('tco.created_by', 'Created by:') . ' ' . h($ticketData['username']));
?>
<tr>
	<td><p><?= nl2br(h($ticketData['message'])) ?></p></td>
</tr>
<?php
tco_panel_close();

if ($replies !== false) {
	foreach ($replies as $reply) {
		?>
		<br>
		<?php
		tco_panel_open(h(getClock($reply['created'], true)) . ' - ' . t_default('tco.posted_by', 'Posted by:') . ' ' . h($reply['username']));
		?>
		<tr>
			<td><p><?= nl2br(h($reply['message'])) ?></p></td>
		</tr>
		<?php
		tco_panel_close();
	}
}

if ($ticketData['status'] !== 'CLOSED') {
	?>
	<br>
	<form action="" method="post">
		<input type="hidden" name="username" value="<?= h($ticketData['username']) ?>">
		<textarea class="tco-mini-input" name="reply_text" style="width:100%;height:150px;"></textarea><br><br>
		<?= tco_button(t('helpdesk.reply'), 'blue') ?>
	</form>
	<?php
}
tco_box_close();
