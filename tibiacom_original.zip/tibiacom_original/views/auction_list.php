<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades');
?>
<style>
.tco-auc-filters { display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end; margin-bottom: 15px; }
.tco-auc-filters .tco-auc-field { display: flex; flex-direction: column; gap: 3px; font-size: 12px; }
.tco-auc-pagination { margin: 10px 0; }
.tco-auc-pagination a, .tco-auc-pagination strong { margin-right: 6px; }
.tco-auc-card { border: 1px solid #8a6b2f; background: #d0b98f; margin-bottom: 12px; padding: 8px 10px; }
.tco-auc-card-header { margin-bottom: 6px; }
.tco-auc-card-header .tco-auc-name { font-weight: bold; color: #5a2800; }
.tco-auc-card-row { display: flex; gap: 14px; align-items: flex-start; flex-wrap: wrap; }
.tco-auc-col-outfit { width: 64px; flex: 0 0 auto; text-align: center; }
.tco-auc-col-items { flex: 0 0 auto; display: grid; grid-template-columns: repeat(2, 34px); grid-template-rows: repeat(2, 34px); gap: 4px; }
.tco-auc-item-tile { position: relative; width: 34px; height: 34px; border: 1px solid #8a6b2f; background: #ead7b8; display: flex; align-items: center; justify-content: center; }
.tco-auc-item-tile img { max-width: 28px; max-height: 28px; }
.tco-auc-item-count { position: absolute; bottom: 0; right: 1px; font-size: 9px; background: rgba(0,0,0,.6); color: #fff; padding: 0 2px; }
.tco-auc-col-data { flex: 1 1 220px; font-size: 12px; line-height: 1.5; color: #3a2200; }
.tco-auc-col-data .tco-auc-label { color: #5f4d41; }
.tco-auc-coin { width: 14px; height: 14px; vertical-align: middle; margin-left: 2px; }
.tco-auc-amount { white-space: nowrap; }
.tco-auc-col-bid { flex: 0 0 180px; border-left: 1px solid #8a6b2f; padding-left: 12px; }
.tco-auc-col-bid form { display: flex; flex-direction: column; gap: 4px; }
.tco-auc-col-bid input[type="number"] { width: 100%; box-sizing: border-box; }
</style>

<?php if ($pending !== false && $pending): ?>
	<?php tco_panel_open(t('common.congrats')); ?>
	<tr>
		<td>
			<p><?= t('common.you_have') ?> <?= count($pending) > 1 ? 'characters' : 'a character' ?> ready to claim!</p>
			<?php foreach ($pending as $character): ?>
				<p>
					<?= t('common.level') ?> <?= (int)$character['level'] ?> <?= h(vocation_id_to_name($character['vocation'])) ?> -
					<?= (int)$character['price'] ?> <img src="<?= theme_asset('icon-tibiacoin.png') ?>" alt="" style="width:12px;height:12px;vertical-align:middle;"> -
					<a href="/auctionChar.php?action=view&zaid=<?= (int)$character['zaid'] ?>"><?= t('auc.details') ?></a>
				</p>
				<form action="/auctionChar.php" method="POST">
					<input type="hidden" name="action" value="claim">
					<input type="hidden" name="zaid" value="<?= (int)$character['zaid'] ?>">
					<?= t('auc.claim_name') ?>
					<input type="text" name="name">
					<div style="display:inline-block;vertical-align:middle;margin-left:5px;">
						<?= tco_button(t('auc.claim_btn'), 'blue') ?>
					</div>
				</form>
			<?php endforeach; ?>
		</td>
	</tr>
	<?php tco_panel_close(); ?>
<?php endif; ?>

<?php if ($is_admin): ?>
	<p>Admin: <a href="/admin/index.php?p=auction"><?= t('auc.history') ?></a></p>
<?php endif; ?>

<?php
if (!function_exists('tco_auc_url')) {
	function tco_auc_url(array $overrides = array()) {
		global $filterVoc, $filterLevelMin, $filterLevelMax, $search, $sort, $page;
		$params = array_merge(array(
			'voc' => $filterVoc ?: '',
			'level_min' => $filterLevelMin ?: '',
			'level_max' => $filterLevelMax ?: '',
			'q' => $search,
			'sort' => $sort,
			'page' => $page,
		), $overrides);
		$params = array_filter($params, static fn($v) => $v !== '' && $v !== 0 && $v !== null);
		return 'auctionChar.php?' . http_build_query($params);
	}
}
?>

<form action="auctionChar.php" method="get" class="tco-auc-filters">
	<div class="tco-auc-field">
		<label for="tco_auc_voc"><?= t('common.vocation') ?></label>
		<select id="tco_auc_voc" name="voc">
			<option value="0"><?= t('vocation.any') ?></option>
			<?php foreach ($config['vocations'] as $id => $vocation): if ((int)$id === 0) continue; ?>
				<option value="<?= (int)$id ?>" <?= $filterVoc === (int)$id ? 'selected' : '' ?>><?= h($vocation['name']) ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div class="tco-auc-field">
		<label for="tco_auc_level_min"><?= t('auc.min_level') ?></label>
		<input type="number" id="tco_auc_level_min" name="level_min" min="0" value="<?= $filterLevelMin ?: '' ?>" style="width:80px;">
	</div>
	<div class="tco-auc-field">
		<label for="tco_auc_level_max">&mdash;</label>
		<input type="number" id="tco_auc_level_max" name="level_max" min="0" value="<?= $filterLevelMax ?: '' ?>" style="width:80px;">
	</div>
	<div class="tco-auc-field">
		<label for="tco_auc_sort"><?= t('auc.sort_by') ?></label>
		<select id="tco_auc_sort" name="sort">
			<option value="level_desc" <?= $sort === 'level_desc' ? 'selected' : '' ?>><?= t('auc.sort_level_desc') ?></option>
			<option value="level_asc" <?= $sort === 'level_asc' ? 'selected' : '' ?>><?= t('auc.sort_level_asc') ?></option>
			<option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>><?= t('auc.sort_price_desc') ?></option>
			<option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>><?= t('auc.sort_price_asc') ?></option>
			<option value="ending_soon" <?= $sort === 'ending_soon' ? 'selected' : '' ?>><?= t('auc.sort_ending_soon') ?></option>
		</select>
	</div>
	<div class="tco-auc-field" style="flex:1 1 200px;">
		<label for="tco_auc_q"><?= t('common.search') ?></label>
		<input type="text" id="tco_auc_q" name="q" value="<?= h($search) ?>" placeholder="<?= h(t('auc.search_placeholder')) ?>">
	</div>
	<div class="tco-auc-field">
		<?= tco_button(t('common.search'), 'blue') ?>
	</div>
</form>

<?php if ($pageCount > 1): ?>
	<div class="tco-auc-pagination">
		<?php for ($p = 1; $p <= $pageCount; $p++): ?>
			<?php if ($p === $page): ?><strong>[<?= $p ?>]</strong><?php else: ?><a href="<?= h(tco_auc_url(['page' => $p])) ?>">[<?= $p ?>]</a><?php endif; ?>
		<?php endfor; ?>
	</div>
<?php endif; ?>

<?php if (is_array($characters) && !empty($characters)): ?>
	<?php foreach ($characters as $character): ?>
		<article class="tco-auc-card">
			<div class="tco-auc-card-header">
				<div class="tco-auc-name"><a href="/auctionChar.php?action=view&zaid=<?= (int)$character['zaid'] ?>"><?= t('common.level') ?> <?= (int)$character['level'] ?> <?= h(vocation_id_to_name($character['vocation'])) ?></a></div>
				<div>
					<?= t('common.level') ?>: <?= (int)$character['level'] ?>
					| <?= t('common.vocation') ?>: <?= h(vocation_id_to_name($character['vocation'])) ?>
					| <?= ((int)$character['sex'] === 1) ? t('common.male') : t('common.female') ?>
					| <a href="/auctionChar.php?action=view&zaid=<?= (int)$character['zaid'] ?>"><?= t('auc.details') ?></a>
				</div>
			</div>
			<div class="tco-auc-card-row">
				<div class="tco-auc-col-outfit">
					<?php if ($loadOutfits): ?>
						<img src="<?php echo $config['show_outfits']['imageServer']; ?>?id=<?php echo $character['type']; ?>&addons=<?php echo $character['addons']; ?>&head=<?php echo $character['head']; ?>&body=<?php echo $character['body']; ?>&legs=<?php echo $character['legs']; ?>&feet=<?php echo $character['feet']; ?>" alt="">
					<?php endif; ?>
				</div>
				<div class="tco-auc-col-items">
					<?php $highlights = $highlightItems[(int)$character['player_id']] ?? array(); ?>
					<?php foreach ($highlights as $hi): ?>
						<div class="tco-auc-item-tile" title="<?= h($items[$hi['itemtype']] ?? ('#' . $hi['itemtype'])) ?>">
							<img src="<?= h(znote_item_image_url((int)$hi['itemtype'])) ?>" alt="">
							<?php if ($hi['count'] > 1): ?><span class="tco-auc-item-count"><?= (int)$hi['count'] ?></span><?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="tco-auc-col-data">
					<div><span class="tco-auc-label"><?= t('auc.start') ?></span> <?= h(getClock($character['time_begin'], true)) ?></div>
					<div><span class="tco-auc-label"><?= t('auc.end') ?></span> <?= h(getClock($character['time_end'], true)) ?></div>
					<div>
						<?php $ended = (time() > $character['time_end']); ?>
						<span class="tco-auc-label"><?= t('auc.type_label') ?></span>
						<?php if ($ended): ?>
							<?= t('auc.instant') ?>
						<?php else: ?>
							<?= t('auc.bidding') ?> (<span data-auc2-countdown="<?= (int)$character['time_end'] ?>" data-auc2-ended-text="<?= h(t('auc.instant')) ?>"><?= h(toDuration($character['time_end'] - time())) ?></span>)
						<?php endif; ?>
					</div>
					<div><span class="tco-auc-label"><?= t('auc.min_bid') ?></span> <span class="tco-auc-amount"><?= (int)$character['price'] ?><img class="tco-auc-coin" src="<?= theme_asset('icon-tibiacoin.png') ?>" alt=""></span></div>
				</div>
				<div class="tco-auc-col-bid">
					<form action="/auctionChar.php" method="POST">
						<input type="hidden" name="action" value="bid">
						<input type="hidden" name="zaid" value="<?= (int)$character['zaid'] ?>">
						<label><?= t('auc.my_bid_limit') ?></label>
						<input type="number" name="price" min="<?= (int)$character['price'] ?>" step="1" value="<?= (int)$character['price'] ?>">
						<?= tco_button(t('auc.bid_btn'), 'blue') ?>
					</form>
				</div>
			</div>
		</article>
	<?php endforeach; ?>

	<?php if ($pageCount > 1): ?>
		<div class="tco-auc-pagination">
			<?php for ($p = 1; $p <= $pageCount; $p++): ?>
				<?php if ($p === $page): ?><strong>[<?= $p ?>]</strong><?php else: ?><a href="<?= h(tco_auc_url(['page' => $p])) ?>">[<?= $p ?>]</a><?php endif; ?>
			<?php endfor; ?>
		</div>
	<?php endif; ?>
<?php else: ?>
	<p><?= t('auc.no_auctions') ?></p>
<?php endif; ?>

<p><a href="/auctionChar.php?action=create"><?= t('auc.add') ?></a>.</p>
<?php
tco_box_close();
?>
<script>
document.addEventListener('DOMContentLoaded', function () {
	document.querySelectorAll('[data-auc2-countdown]').forEach(function (el) {
		var end = parseInt(el.getAttribute('data-auc2-countdown'), 10);
		function tick() {
			var remaining = end - Math.floor(Date.now() / 1000);
			if (remaining <= 0) {
				el.textContent = el.getAttribute('data-auc2-ended-text') || '';
				return;
			}
			var d = Math.floor(remaining / 86400);
			var h = Math.floor((remaining % 86400) / 3600);
			var m = Math.floor((remaining % 3600) / 60);
			var s = remaining % 60;
			var parts = [];
			if (d > 0) parts.push(d + (d === 1 ? ' day' : ' days'));
			if (h > 0) parts.push(h + (h === 1 ? ' hour' : ' hours'));
			if (m > 0) parts.push(m + (m === 1 ? ' minute' : ' minutes'));
			if (s > 0) parts.push(s + (s === 1 ? ' second' : ' seconds'));
			el.textContent = parts.join(', ');
			setTimeout(tick, 1000);
		}
		tick();
	});
});
</script>
