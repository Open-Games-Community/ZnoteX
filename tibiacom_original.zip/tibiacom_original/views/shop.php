<?php
$tcoWebshopActiveTab = (($_GET['shop_tab'] ?? '') === 'services') ? 'services' : 'offers';
require dirname(__DIR__) . '/parts/webshop.php';
