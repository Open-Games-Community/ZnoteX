<?php
tco_panel_open(t('auc.claim_issues'));
foreach ($errors as $i => $error): ?>
	<tr style="background-color:<?= tco_alt_bg($i) ?>;">
		<td class="LabelV"><?= $i + 1 ?></td>
		<td><?= $error ?></td>
	</tr>
<?php endforeach;
tco_panel_close();
