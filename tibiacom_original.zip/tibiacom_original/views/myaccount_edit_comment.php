<?php
tco_box_open(t('acc.change_comment_on'), 'accountmanagement');
?>
<form action="" method="post">
	<?php tco_panel_open(t('acc.comment')); ?>
		<tr>
			<td>
				<input name="action" type="hidden" value="update_comment">
				<input name="selected_character" type="text" value="<?= h($char_name) ?>" readonly>
				<textarea name="comment" cols="70" rows="10" style="width:100%;box-sizing:border-box;"><?= h($comment_data['comment']) ?></textarea>
			</td>
		</tr>
	<?php tco_panel_close(); ?>
	<?php Token::create(); ?>
	<p><input type="submit" value="<?= h(t('acc.update_comment')) ?>"></p>
</form>
<?php
tco_box_close();
