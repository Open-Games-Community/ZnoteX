<?php
tco_box_open(t('login.title'), 'accountmanagement', 'accountmanagement');
tco_panel_open(t_default('tco.account_login', 'Account Login'), 'Table4');
?>
<tr class="LoginTable">
	<td>
		<?php if (empty($errors) === false): ?>
			<font color="red"><b><?= output_errors($errors) ?></b></font>
		<?php endif; ?>
		<form action="login.php" method="post" id="tcoLoginForm">
			<div class="LoginBox">
				<div class="Cell LabelV120"><span><?= t('widget.login.username') ?></span></div>
				<div class="Cell InputField"><input type="text" name="username" id="login_username" style="width:100%;"></div>
				<div class="Break"></div>
				<div class="Cell LabelV120"><span><?= t('widget.login.password') ?></span></div>
				<div class="Cell InputField"><input type="password" name="password" id="login_password" style="width:100%;"></div>
				<?php if ($config['twoFactorAuthenticator']): ?>
					<div class="Break"></div>
					<div class="Cell LabelV120"><span><?= t('widget.login.token') ?></span></div>
					<div class="Cell InputField"><input type="password" name="authcode" style="width:100%;"></div>
				<?php endif; ?>
			</div>
			<?php Token::create(); ?>
		</form>
	</td>
	<td class="LoginButtons">
		<div class="Cell ButtonField"><?= tco_button(t('widget.login.submit'), 'blue', 'tcoLoginForm') ?></div>
		<div class="Cell ButtonField"><a href="recovery.php"><?= tco_button(t_default('tco.account_lost', 'Account Lost?'), 'red') ?></a></div>
	</td>
</tr>
<?php
tco_panel_close();
?>
<br>
<center><p class="tco-plain-heading"><?= t_default('tco.new_to_tibia', 'New to Tibia?') ?></p></center>
<?php
tco_panel_open(t_default('tco.new_player', 'New Player'), 'Table3');
?>
<tr>
	<td>
		<div style="float:right;margin-top:20px;">
			<form class="MediumButtonForm" action="register.php" method="get" style="padding:0;margin:0;">
				<div class="MediumButtonBackground" style="background-image:url(<?= theme_asset('mediumbutton.gif') ?>)" onmouseover="this.firstElementChild.style.visibility='visible';" onmouseout="this.firstElementChild.style.visibility='hidden';">
					<div class="MediumButtonOver" style="background-image:url(<?= theme_asset('mediumbutton-over.gif') ?>);visibility:hidden;"></div>
					<input class="MediumButtonText" type="image" src="<?= theme_asset('mediumbutton_createaccount.png') ?>" alt="<?= h(t('nav.register')) ?>">
				</div>
			</form>
		</div>
		<div id="LoginCreateAccountBox">
			<p><b><?= h(theme_title()) ?>...</b></p>
			<div style="margin-left:10px;">
				<p><?= t_default('tco.new_player_line1', '... where hardcore gaming meets fantasy.') ?></p>
				<p><?= t_default('tco.new_player_line2', '... where friendships last a lifetime.') ?></p>
				<p><?= t_default('tco.new_player_line3', '... unites adventurers, old and new!') ?></p>
			</div>
		</div>
	</td>
</tr>
<?php
tco_panel_close();
tco_box_close();
