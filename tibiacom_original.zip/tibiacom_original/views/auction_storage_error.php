<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades');
echo '<p>' . t_default('tco.auction_storage_error', 'The storage account cannot use the character auction.') . '</p>';
tco_box_close();
