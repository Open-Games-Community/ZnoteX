<?php
tco_box_open(t('settings.title'), 'accountmanagement');

if ($formState === 'success') {
	echo '<p style="color:#1a7a1a;font-weight:bold;">' . t('settings.success') . '</p><br>';
} elseif ($formState === 'errors') {
	echo '<p style="color:#a02020;font-weight:bold;">' . output_errors($errors) . '</p><br>';
}

// 1. Account Creation
$accountCreated = !empty($user_data['creation']) ? (int)$user_data['creation'] : (!empty($user_znote_data['created']) ? (int)$user_znote_data['created'] : 0);
$createdText = ($accountCreated > 0) ? date('M d Y, H:i:s T', $accountCreated) : 'Never';

// 2. Last Login Game
$gameLoginQuery = db()->fetchOne("SELECT MAX(`lastlogin`) AS `lastlogin` FROM `players` WHERE `account_id` = ?;", [$session_user_id]);
$lastGameLogin = (int)($gameLoginQuery['lastlogin'] ?? 0);
$gameLoginText = ($lastGameLogin > 0) ? date('M d Y, H:i:s T', $lastGameLogin) : 'Never';

// 3. Last Login Website
$lastWebLogin = 0;
if (function_exists('znote_table_exists') && znote_table_exists('znote_account_security_events')) {
	$webLoginQuery = db()->fetchOne("SELECT `created_at` FROM `znote_account_security_events` WHERE `account_id` = ? AND `event` = 'session_started' ORDER BY `id` DESC LIMIT 1;", [$session_user_id]);
	$lastWebLogin = (int)($webLoginQuery['created_at'] ?? 0);
}
if ($lastWebLogin === 0 && function_exists('znote_table_exists') && znote_table_exists('znote_account_security_sessions')) {
	$sessQuery = db()->fetchOne("SELECT MAX(`last_seen`) AS `m` FROM `znote_account_security_sessions` WHERE `account_id` = ?;", [$session_user_id]);
	$lastWebLogin = (int)($sessQuery['m'] ?? 0);
}
$webLoginText = ($lastWebLogin > 0) ? date('M d Y, H:i:s T', $lastWebLogin) : 'Never';

// 4. Account Status & Premium
$premLeft = (int)($user_data['premium_ends_at'] ?? 0) - time();
$premDays = ($premLeft > 0) ? floor($premLeft / 86400) : (int)($user_data['premdays'] ?? 0);
$isPrem = ($premDays > 0);
$premEndsAt = (int)($user_data['premium_ends_at'] ?? 0);

// 5. Tibia Coins (Points)
$tibiaCoins = (int)($user_znote_data['points'] ?? 0);

// 6. Loyalty Points & Title
$loyaltyRow = null;
if (function_exists('loyalty_shop_row')) {
	$loyaltyRow = loyalty_shop_row($session_user_id);
} elseif (function_exists('znote_table_exists') && znote_table_exists('znote_loyalty_accounts')) {
	$loyaltyRow = db()->fetchOne("SELECT * FROM `znote_loyalty_accounts` WHERE `account_id` = ? LIMIT 1;", [$session_user_id]);
}
$loyaltyPoints = is_array($loyaltyRow) ? (int)($loyaltyRow['spent_points'] ?? 0) : 0;
$loyaltyTier = function_exists('loyalty_shop_tier_for') ? loyalty_shop_tier_for($loyaltyPoints) : ['name' => 'Warden of Tibia'];
$nextTier = function_exists('loyalty_shop_next_tier') ? loyalty_shop_next_tier($loyaltyPoints) : null;

// 7. Email masking
$email = (string)($user_data['email'] ?? '');
$maskedEmail = str_repeat('*', min(30, max(16, strlen($email))));

$rowIdx = 0;
tco_panel_open(t_default('tco.general_info', 'General Information'));
?>
	<!-- Email Address -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.email_address', 'Email Address:') ?></td>
		<td>
			<span id="DisplayEmail" onmousedown="ToggleMaskedText('Email');" style="cursor:pointer;font-family:monospace;letter-spacing:1px;"><?= $maskedEmail ?></span>
			<span id="MaskedEmail" style="display:none;"><?= $maskedEmail ?></span>
			<span id="ReadableEmail" style="display:none;"><?= h($email) ?></span>
			<img id="ButtonEmail" onmousedown="ToggleMaskedText('Email');" src="<?= theme_asset('show.gif') ?>" alt="Show" style="cursor:pointer;vertical-align:middle;margin-left:6px;">
		</td>
	</tr>

	<!-- Created -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.created', 'Created:') ?></td>
		<td><?= h($createdText) ?></td>
	</tr>

	<!-- Last Login (Game) -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.last_login_game', 'Last Login (Game):') ?></td>
		<td><?= h($gameLoginText) ?></td>
	</tr>

	<!-- Last Login (Website) -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.last_login_web', 'Last Login (Website):') ?></td>
		<td><?= h($webLoginText) ?></td>
	</tr>

	<!-- Account Status -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.account_status', 'Account Status:') ?></td>
		<td>
			<?php if ($isPrem): ?>
				<span style="color:#1a7a1a;font-weight:bold;"><?= t_default('tco.premium_account', 'Premium Account') ?></span>
				<br><small>(<?= t('acc.premium_days', ['days' => $premDays]) ?><?= $premEndsAt > 0 ? ', ' . t_default('tco.expires_at', 'expires at') . ' ' . date('M d Y, H:i:s T', $premEndsAt) : '' ?>)</small>
			<?php else: ?>
				<span style="color:#a02020;font-weight:bold;"><?= t_default('tco.free_account_title', 'Free Account') ?></span>
				<?php if ($premEndsAt > 0): ?>
					<br><small>(<?= t_default('tco.premium_expired_at', 'Premium Time expired at') ?> <?= date('M d Y, H:i:s T', $premEndsAt) ?>, balance: 0 days)</small>
				<?php else: ?>
					<br><small>(balance: 0 days)</small>
				<?php endif; ?>
			<?php endif; ?>
		</td>
	</tr>

	<!-- Tibia Coins -->
	<tr style="background-color:<?= tco_alt_bg($rowIdx++) ?>;">
		<td class="LabelV"><?= t_default('tco.tibia_coins', 'Tibia Coins:') ?></td>
		<td>
			<?= number_format($tibiaCoins) ?>
			<img src="<?= theme_asset('icon-tibiacoin.png') ?>" class="VSCCoinImages" alt="Tibia Coin" style="vertical-align:-1px;margin-left:2px;">
		</td>
	</tr>


	<!-- Action Buttons Row -->
	<tr>
		<td colspan="2" style="padding:6px 0 2px;">
			<table class="InnerTableButtonRow AccountShowButtons" cellpadding="0" cellspacing="0" style="width:100%;">
				<tbody>
					<tr>
						<td style="padding:2px 4px;">
						<a href="changepassword.php"><?= tco_button(t_default('tco.change_password', 'Change Password'), 'blue') ?></a>
					</td>
					<td style="padding:2px 4px;">
						<div onclick="toggleManageEmail();" style="cursor:pointer;"><?= tco_button(t_default('tco.manage_emails', 'Manage Emails'), 'blue') ?></div>
					</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
<?php
tco_panel_close();
?>

<!-- Collapsible Manage Emails Panel -->
<div id="ManageEmailContainer" style="display:<?= ($formState === 'errors' && !empty($_POST['is_email_form'])) ? 'block' : 'none' ?>;margin-top:15px;">
	<?php tco_panel_open(t_default('tco.manage_emails', 'Manage Emails')); ?>
		<form action="" method="post">
			<tr style="background-color:<?= tco_alt_bg(0) ?>;">
				<td class="LabelV"><?= t_default('tco.current_email', 'Current Email:') ?></td>
				<td><?= h($user_data['email']) ?></td>
			</tr>
			<tr style="background-color:<?= tco_alt_bg(1) ?>;">
				<td class="LabelV"><?= t_default('tco.new_email', 'New Email:') ?></td>
				<td><input type="email" name="new_email" value="<?= h($user_data['email']) ?>" style="width:260px;" required></td>
			</tr>
			<input type="hidden" name="new_flag" value="<?= h($user_znote_data['flag'] ?? 'us') ?>">
			<input type="hidden" name="is_email_form" value="1">
			<?php Token::create(); ?>
			<tr>
				<td colspan="2" style="padding:8px;text-align:right;">
					<div style="display:flex;gap:10px;justify-content:flex-end;">
						<?= tco_button(t_default('tco.update_email', 'Update Email'), 'green') ?>
						<div onclick="toggleManageEmail();" style="cursor:pointer;"><?= tco_button(t_default('tco.cancel', 'Cancel'), 'red') ?></div>
					</div>
				</td>
			</tr>
		</form>
	<?php tco_panel_close(); ?>
</div>

<script>
function ToggleMaskedText(id) {
	var display = document.getElementById('Display' + id);
	var masked = document.getElementById('Masked' + id);
	var readable = document.getElementById('Readable' + id);
	var button = document.getElementById('Button' + id);
	if (!display || !masked || !readable || !button) return;
	if (display.textContent === masked.textContent) {
		display.textContent = readable.textContent;
		button.src = '<?= theme_asset("hide.gif") ?>';
	} else {
		display.textContent = masked.textContent;
		button.src = '<?= theme_asset("show.gif") ?>';
	}
}

function toggleManageEmail() {
	var el = document.getElementById('ManageEmailContainer');
	if (!el) return;
	if (el.style.display === 'none' || el.style.display === '') {
		el.style.display = 'block';
		el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
	} else {
		el.style.display = 'none';
	}
}
</script>

<?php
tco_box_close();
