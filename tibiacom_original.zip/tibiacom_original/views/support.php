<?php
tco_wrap_default_view('support', 'gethelp', t('support.title'));
