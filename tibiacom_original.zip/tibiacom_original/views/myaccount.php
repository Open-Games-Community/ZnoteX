<?php
$tcoIsAdmin = function_exists('has_admin_panel_access') && has_admin_panel_access($user_data);
tco_box_open(t('acc.page_title'), 'accountmanagement');
?>
<center><table><tr>
	<td><img src="<?= theme_asset('headline-bracer-left.gif') ?>" alt=""></td>
	<td class="tco-account-welcome"><?= h(t('acc.welcome')) ?> <b><?= h($user_data['name']) ?></b>!</td>
	<td><img src="<?= theme_asset('headline-bracer-right.gif') ?>" alt=""></td>
</tr></table></center><br>
<?php
tco_panel_open(t_default('tco.account_status', 'Account Status'));
$tcoIsPremium = $user_data['premdays'] != 0;
?>
	<tr>
		<td width="100%">
			<div style="display:flex;align-items:center;gap:8px;">
				<img src="<?= theme_asset($tcoIsPremium ? 'account-status_green.gif' : 'account-status_red.gif') ?>" alt="<?= $tcoIsPremium ? h(t_default('tco.premium_account', 'Premium Account')) : h(t('acc.free_account')) ?>" width="52" height="52" style="display:block;flex:0 0 auto;">
				<div>
					<span class="tco-account-status-label" style="color:<?= $tcoIsPremium ? '#1a7a1a' : '#a02020' ?>;"><?= $tcoIsPremium ? h(t_default('tco.premium_account', 'Premium Account')) : h(t_default('tco.free_account_title', 'Free Account')) ?></span>
					<br><small><?= $tcoIsPremium ? h(t('acc.premium_days', ['days' => $user_data['premdays']])) : h(t('acc.free_account')) ?></small>
				</div>
			</div>
		</td>
		<td>
			<a href="settings.php"><?= tco_button(t_default('tco.manage_account', 'Manage Account'), 'blue') ?></a>
			<div style="height:4px;"></div>
			<a href="buypoints.php"><?= tco_button(t_default('tco.get_premium', 'Get Premium'), 'green') ?></a>
			<div style="height:4px;"></div>
			<?php if ($tcoIsAdmin): ?>
				<a href="admin/index.php"><?= tco_button(t_default('tco.admin_panel', 'Admin Panel'), 'red') ?></a>
				<div style="height:4px;"></div>
			<?php endif; ?>
			<a href="logout.php"><?= tco_button(t('nav.logout'), 'red') ?></a>
		</td>
	</tr>
	<?php if ($config['mailserver']['myaccount_verify_email']): ?>
		<tr style="background-color:<?= tco_alt_bg(0) ?>;">
			<td class="LabelV"><?= t_default('tco.email', 'Email') ?></td>
			<td colspan="2">
				<?= h($user_data['email']) ?>
				<?php if ($user_znote_data['active_email'] == 1): ?>
					(<?= t_default('tco.verified', 'Verified') ?>)
				<?php else: ?>
					<br><strong><?= t('acc.email_not_verified') ?> <a href="?authenticate"><?= t('acc.please_verify') ?></a>.</strong>
				<?php endif; ?>
			</td>
		</tr>
	<?php endif; ?>
	<?php if ($twofa2_status !== null): ?>
		<tr style="background-color:<?= tco_alt_bg(1) ?>;">
			<td class="LabelV"><?= t_default('tco.website_2fa', 'Website 2FA') ?></td>
			<td colspan="2"><a href="twofa.php"><?= tco_button(!empty($twofa2_status['any_enabled']) ? t_default('tco.enabled', 'Enabled') : t_default('tco.disabled', 'Disabled'), !empty($twofa2_status['any_enabled']) ? 'blue' : 'red') ?></a></td>
		</tr>
	<?php endif; ?>
	<?php if ($legacy_twofa_status !== null): ?>
		<tr style="background-color:<?= tco_alt_bg(2) ?>;">
			<td class="LabelV"><?= t_default('tco.legacy_2fa', 'Legacy Game 2FA') ?></td>
			<td colspan="2"><a href="twofa.php"><?= tco_button($legacy_twofa_status ? t_default('tco.enabled', 'Enabled') : t_default('tco.disabled', 'Disabled'), $legacy_twofa_status ? 'blue' : 'red') ?></a></td>
		</tr>
	<?php endif; ?>
<?php
tco_panel_close();
?>
<br><br>
<?php
tco_panel_open(t_default('tco.download_client', 'Download Client'));
?>
	<tr>
		<td style="width:56px;">
			<img src="<?= theme_asset('download_windows.gif') ?>" alt="<?= h(t_default('tco.download', 'Download')) ?>" style="width:45px;height:45px;">
		</td>
		<td width="100%" valign="middle">
			<?= t_default('tco.download_client_text', 'Click') ?> <a href="downloads.php"><?= t_default('tco.here', 'here') ?></a> <?= t_default('tco.download_client_text2', 'to download the latest client!') ?>
		</td>
	</tr>
<?php
tco_panel_close();
?>
<br>
<?php
tco_panel_open(t_default('tco.character_list', 'Character List'));
?>
	<tr style="background-color:#5f4d41;">
		<td class="LabelV" style="color:#fff;width:24px;"></td>
		<td style="color:#fff;"><?= t_default('common.name', 'Name') ?></td>
		<td style="color:#fff;"><?= t_default('common.status', 'Status') ?></td>
		<td style="color:#fff;width:60px;"></td>
	</tr>
	<?php if ($char_array): $i = 0; foreach ($char_array as $value): $i++; ?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td style="text-align:center;"><?= $i ?>.</td>
			<td>
				<a href="characterprofile.php?name=<?= h($value['name']) ?>" class="tco-char-name"><?= h($value['name']) ?></a>
				<br><small><?= h(vocation_id_to_name((int)$value['vocation'])) ?> - <?= t_default('tco.level_n', 'Level') ?> <?= (int)$value['level'] ?> - <?= t_default('tco.on_town', 'On') ?> <?= h(town_id_to_name((int)$value['town_id'])) ?></small>
			</td>
			<td><?= online_id_to_name($value['online']) ?> / <?= h(hide_char_to_name($value['hide_char'])) ?></td>
			<td style="text-align:center;">
				[<a href="page.php?p=editcharacter&character=<?= urlencode($value['name']) ?>"><?= t_default('tco.edit', 'Edit') ?></a>]
			</td>
		</tr>
	<?php endforeach; else: ?>
		<tr><td colspan="4"><?= t_default('tco.no_characters', "You don't have any characters yet.") ?> <a href="createcharacter.php"><?= t_default('tco.create_one', 'Create one') ?></a>.</td></tr>
	<?php endif; ?>
	<?php if ($char_array): ?>
		<tr>
			<td colspan="4">
				<table class="InnerTableButtonRow" cellpadding="0" cellspacing="0"><tr><td>
					<div class="DivWithButton">
						<a href="createcharacter.php"><?= tco_button(t('widget.account.create_character'), 'blue') ?></a>
					</div>
				</td></tr></table>
			</td>
		</tr>
	<?php endif; ?>
<?php
tco_panel_close();
tco_box_close();
