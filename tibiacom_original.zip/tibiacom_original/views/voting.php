<?php
/**
 * Vote for us, boxed for this theme.
 *
 * Prepared by voting.php: $votingMessage.
 */
tco_box_open(t_default('tco.vote', 'Vote for this server'), '');
?>
<p><?= $votingMessage ?></p>
<?php
tco_box_close();
