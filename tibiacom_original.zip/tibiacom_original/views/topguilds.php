<?php
tco_wrap_default_view('topguilds', 'leaderboards');
