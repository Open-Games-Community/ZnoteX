<?php
tco_box_open(t('changepw.title'), 'accountmanagement');

if ($formState === 'success') {
	echo '<p>' . t('changepw.success') . '<br>' . t('changepw.relogin') . '</p>';
} else {
	if ($formState === 'errors') {
		echo '<font color="red"><b>' . output_errors($errors) . '</b></font>';
	}
	?>
	<form action="" method="post">
		<?php tco_panel_open(t('changepw.title')); ?>
			<tr style="background-color:<?= tco_alt_bg(0) ?>;">
				<td class="LabelV"><?= t('changepw.current') ?></td>
				<td><input type="password" name="current_password"></td>
			</tr>
			<tr style="background-color:<?= tco_alt_bg(1) ?>;">
				<td class="LabelV"><?= t('changepw.new') ?></td>
				<td><input type="password" name="new_password"></td>
			</tr>
			<tr style="background-color:<?= tco_alt_bg(0) ?>;">
				<td class="LabelV"><?= t('changepw.new_again') ?></td>
				<td><input type="password" name="new_password_again"></td>
			</tr>
		<?php tco_panel_close(); ?>
		<?php Token::create(); ?>
		<p><input type="submit" value="<?= h(t('changepw.title')) ?>"></p>
	</form>
	<?php
}

tco_box_close();
