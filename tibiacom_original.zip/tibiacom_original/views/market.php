<?php
/**
 * Item market, boxed for this theme with the search/compare/go-back buttons
 * swapped for the tibia.com-styled tco_button().
 *
 * Prepared by market.php: $marketLoadError, $marketMode ('list' or 'compare'),
 * $items, $offers, $historyOffers, $activeSellOffers, $buylist, $itemname,
 * $compare.
 */
tco_box_open(t('market.title'), '');
?>

<?php if ($marketLoadError !== ''): ?>

	<h1><?= t('market.title') ?></h1>
	<p><?= t('market.load_failed2') ?></p>
	<p><?= t('market.tried_file') ?> <?php echo $marketLoadError; ?></p>
	<p><?= t('market.fix_path') ?></p>
	<p><?= t('market.check_permissions') ?></p>

<?php elseif ($marketMode === 'list'): ?>

	<h1><?= t('market.title') ?></h1>
	<p><?= t('market.hint') ?> <a target="_BLANK" href="http://znote.eu/images/depotmarket.jpg"><?= t('market.depot_link_text') ?></a> <br><?= t('market.sell_instructions') ?></p>
	<form action="" class="market_item_search" style="margin-bottom:15px;">
		<label for="compareSearch"><?= t('market.search') ?></label>
		<input type="text" id="compareSearch" name="compare">
		<div style="display:inline-block; vertical-align:middle; margin-left:5px;">
			<?= tco_button(t('common.search'), 'blue') ?>
		</div>
	</form>

	<?php tco_panel_open(t('market.wts')); ?>
		<tr style="background-color:#5f4d41;">
			<td style="color:#fff;"><?= t('market.item_name') ?></td>
			<td style="color:#fff;"><?= t('common.item') ?></td>
			<td style="color:#fff;"><?= t('common.count') ?></td>
			<td style="color:#fff;"><?= t('market.price_for_1') ?></td>
			<td style="color:#fff;"><?= t('common.added') ?></td>
			<td style="color:#fff;"><?= t('common.by') ?></td>
			<td style="color:#fff;"><?= t('market.compare') ?></td>
		</tr>
		<?php $i = 0; foreach (($offers['wts'] ?: array()) as $o): $i++; ?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td><?php echo (isset($items[$o['item_id']])) ? $items[$o['item_id']] : $o['item_id']; ?></td>
			<td><img src="<?php echo htmlspecialchars(znote_item_image_url((int)$o["item_id"]), ENT_QUOTES); ?>" alt="<?= t('market.item_image_alt') ?>"></td>
			<td><?php echo $o['amount']; ?></td>
			<td><?php echo number_format($o['price'], 0, "", " "); ?></td>
			<td><?php echo getClock($o['created'], true, true); ?></td>
			<td><?php echo ($o['anonymous'] == 1) ? t('market.anonymous') : "<a target='_BLANK' href='characterprofile.php?name=".$o['player_name']."'>".$o['player_name']."</a>"; ?></td>
			<td><a href="?compare=<?php echo $o['item_id']; ?>"><?= tco_button(t('market.compare'), 'blue') ?></a></td>
		</tr>
		<?php endforeach; ?>
	<?php tco_panel_close(); ?>

	<?php tco_panel_open(t('market.wtb')); ?>
		<tr style="background-color:#5f4d41;">
			<td style="color:#fff;"><?= t('market.item_name') ?></td>
			<td style="color:#fff;"><?= t('common.item') ?></td>
			<td style="color:#fff;"><?= t('common.count') ?></td>
			<td style="color:#fff;"><?= t('market.price_for_1') ?></td>
			<td style="color:#fff;"><?= t('common.added') ?></td>
			<td style="color:#fff;"><?= t('common.by') ?></td>
			<td style="color:#fff;"><?= t('market.compare') ?></td>
		</tr>
		<?php $i = 0; foreach (($offers['wtb'] ?: array()) as $o): $i++; ?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td><?php echo (isset($items[$o['item_id']])) ? $items[$o['item_id']] : $o['item_id']; ?></td>
			<td><img src="<?php echo htmlspecialchars(znote_item_image_url((int)$o["item_id"]), ENT_QUOTES); ?>" alt="<?= t('market.item_image_alt') ?>"></td>
			<td><?php echo $o['amount']; ?></td>
			<td><?php echo number_format($o['price'], 0, "", " "); ?></td>
			<td><?php echo getClock($o['created'], true, true); ?></td>
			<td><?php echo ($o['anonymous'] == 1) ? t('market.anonymous') : "<a target='_BLANK' href='characterprofile.php?name=".$o['player_name']."'>".$o['player_name']."</a>"; ?></td>
			<td><a href="?compare=<?php echo $o['item_id']; ?>"><?= tco_button(t('market.compare'), 'blue') ?></a></td>
		</tr>
		<?php endforeach; ?>
	<?php tco_panel_close(); ?>

<?php else: ?>

	<?php if (!is_string($compare)): ?>
		<h1><?= t('market.comparing_item', ['name' => $itemname]) ?></h1>
	<?php else: ?>
		<h1><?= t('market.search_result', ['query' => stripslashes($compare)]) ?></h1>
	<?php endif; ?>
	<div style="margin-bottom:15px;"><a href="market.php"><?= tco_button(t('market.go_back'), 'red') ?></a></div>

	<?php tco_panel_open(t('market.active')); ?>
		<tr style="background-color:#5f4d41;">
			<td style="color:#fff;"><?= t('market.item_name') ?></td>
			<td style="color:#fff;"><?= t('common.item') ?></td>
			<td style="color:#fff;"><?= t('common.count') ?></td>
			<td style="color:#fff;"><?= t('market.price_for_1') ?></td>
			<td style="color:#fff;"><?= t('common.added') ?></td>
			<td style="color:#fff;"><?= t('common.by') ?></td>
		</tr>
		<?php $i = 0; foreach ($activeSellOffers as $o): $i++; ?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td><?php echo (isset($items[$o['item_id']])) ? $items[$o['item_id']] : $o['item_id']; ?></td>
			<td><img src="<?php echo htmlspecialchars(znote_item_image_url((int)$o["item_id"]), ENT_QUOTES); ?>" alt="<?= t('market.item_image_alt') ?>"></td>
			<td><?php echo $o['amount']; ?></td>
			<td><?php echo number_format($o['price'], 0, "", " "); ?></td>
			<td><?php echo getClock($o['created'], true, true); ?></td>
			<td><?php echo ($o['anonymous'] == 1) ? t('market.anonymous') : "<a target='_BLANK' href='characterprofile.php?name=".$o['player_name']."'>".$o['player_name']."</a>"; ?></td>
		</tr>
		<?php endforeach; ?>
	<?php tco_panel_close(); ?>

	<?php if ($buylist !== false): ?>
		<?php tco_panel_open(t('market.want_to_buy')); ?>
			<tr style="background-color:#5f4d41;">
				<td style="color:#fff;"><?= t('market.item_name') ?></td>
				<td style="color:#fff;"><?= t('common.item') ?></td>
				<td style="color:#fff;"><?= t('common.count') ?></td>
				<td style="color:#fff;"><?= t('market.price_for_1') ?></td>
				<td style="color:#fff;"><?= t('common.added') ?></td>
				<td style="color:#fff;"><?= t('common.by') ?></td>
			</tr>
			<?php $i = 0; foreach ($buylist as $o): $i++; ?>
			<tr style="background-color:<?= tco_alt_bg($i) ?>;">
				<td><?php echo (isset($items[$o['item_id']])) ? $items[$o['item_id']] : $o['item_id']; ?></td>
				<td><img src="<?php echo htmlspecialchars(znote_item_image_url((int)$o["item_id"]), ENT_QUOTES); ?>" alt="<?= t('market.item_image_alt') ?>"></td>
				<td><?php echo $o['amount']; ?></td>
				<td><?php echo number_format($o['price'], 0, "", " "); ?></td>
				<td><?php echo getClock($o['created'], true, true); ?></td>
				<td><?php echo ($o['anonymous'] == 1) ? t('market.anonymous') : "<a target='_BLANK' href='characterprofile.php?name=".$o['player_name']."'>".$o['player_name']."</a>"; ?></td>
			</tr>
			<?php endforeach; ?>
		<?php tco_panel_close(); ?>
	<?php endif; ?>

	<?php tco_panel_open(t('market.old')); ?>
		<tr style="background-color:#5f4d41;">
			<td style="color:#fff;"><?= t('market.item_name') ?></td>
			<td style="color:#fff;"><?= t('common.item') ?></td>
			<td style="color:#fff;"><?= t('common.count') ?></td>
			<td style="color:#fff;"><?= t('market.price_for_1') ?></td>
			<td style="color:#fff;"><?= t('market.sold') ?></td>
		</tr>
		<?php $i = 0; foreach (($historyOffers ?: array()) as $o): $i++; ?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td><?php echo (isset($items[$o['item_id']])) ? $items[$o['item_id']] : $o['item_id']; ?></td>
			<td><img src="<?php echo htmlspecialchars(znote_item_image_url((int)$o["item_id"]), ENT_QUOTES); ?>" alt="<?= t('market.item_image_alt') ?>"></td>
			<td><?php echo $o['amount']; ?></td>
			<td><?php echo number_format($o['price'], 0, "", " "); ?></td>
			<td><?php echo getClock($o['inserted'], true, true); ?></td>
		</tr>
		<?php endforeach; ?>
	<?php tco_panel_close(); ?>

<?php endif; ?>

<?php
tco_box_close();
?>
