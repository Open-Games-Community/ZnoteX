<?php
tco_box_open(t('reg.heading'), 'createaccount');
?>
<form action="" method="post">
	<?php tco_panel_open(t_default('tco.account_data', 'Account Data')); ?>
		<tr style="background-color:<?= tco_alt_bg(0) ?>;">
			<td class="LabelV"><?= t('reg.label_name') ?></td>
			<td><input type="text" name="username"></td>
		</tr>
		<tr style="background-color:<?= tco_alt_bg(1) ?>;">
			<td class="LabelV"><?= t('reg.label_pw') ?></td>
			<td><input type="password" name="password"></td>
		</tr>
		<tr style="background-color:<?= tco_alt_bg(0) ?>;">
			<td class="LabelV"><?= t('reg.label_pw2') ?></td>
			<td><input type="password" name="password_again"></td>
		</tr>
		<tr style="background-color:<?= tco_alt_bg(1) ?>;">
			<td class="LabelV"><?= t_default('tco.email', 'Email') ?></td>
			<td><input type="text" name="email"></td>
		</tr>
		<tr style="background-color:<?= tco_alt_bg(0) ?>;">
			<td class="LabelV"><?= t('reg.label_country') ?></td>
			<td>
				<select name="flag">
					<option value="">(Please choose)</option>
					<?php
					foreach (array('pl', 'se', 'br', 'us', 'gb') as $c) {
						echo '<option value="' . h($c) . '">' . h($config['countries'][$c]) . '</option>';
					}
					echo '<option value="">----------</option>';
					foreach ($config['countries'] as $code => $c) {
						echo '<option value="' . h($code) . '">' . h($c) . '</option>';
					}
					?>
				</select>
			</td>
		</tr>
		<?php if ($config['use_captcha']): ?>
			<tr style="background-color:<?= tco_alt_bg(1) ?>;">
				<td class="LabelV"></td>
				<td><div class="g-recaptcha" data-sitekey="<?= h($config['captcha_site_key']) ?>"></div></td>
			</tr>
		<?php endif; ?>
	<?php tco_panel_close(); ?>

	<?php tco_panel_open(t('reg.rules_title')); ?>
		<tr>
			<td>
				<p><?= t('reg.rule_golden') ?></p>
				<p><?= t('reg.rule_pwned') ?></p>
				<p>No <a href="https://en.wikipedia.org/wiki/Cheating_in_video_games" target="_blank">cheating</a> allowed.</p>
				<p>No <a href="https://en.wikipedia.org/wiki/Video_game_bot" target="_blank">botting</a> allowed.</p>
				<p>The staff can delete, ban, do whatever they want with your account and your submitted information. (Including exposing and logging your IP).</p>
				<p><?= t('reg.rules_agree') ?>
					<select name="selected">
						<option value="0">Umh...</option>
						<option value="1">Yes.</option>
						<option value="2">No.</option>
					</select>
				</p>
			</td>
		</tr>
	<?php tco_panel_close(); ?>

	<?php Token::create(); ?>
	<p><input type="submit" value="<?= h(t('reg.submit')) ?>"></p>
</form>
<?php
tco_box_close();
