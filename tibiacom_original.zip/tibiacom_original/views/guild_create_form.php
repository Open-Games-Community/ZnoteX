<?php
tco_box_open(t_default('tco.create_guild', 'Create Guild'), '');
?>
<div class="tco-guild-overview">
	<?= $guildCreateFormHtml ?>
</div>
<?php
tco_box_close();
