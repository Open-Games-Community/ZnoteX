<?php
tco_wrap_default_view('killers', 'killstatistics');
