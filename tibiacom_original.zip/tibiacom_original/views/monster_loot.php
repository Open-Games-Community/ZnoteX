<?php
tco_wrap_default_view('monster_loot', '');
