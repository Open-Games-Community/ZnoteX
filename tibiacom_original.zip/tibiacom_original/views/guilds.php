<?php
tco_box_open(t_default('tco.nav.guilds', 'Guilds'), 'guilds');
tco_panel_open(t('guild.data'));
$i = 0;
foreach ($guilds as $guild) {
	if ($guild['total'] >= 1) {
		$i++;
		$url = url('guilds.php?name=' . $guild['name']);
		?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;cursor:pointer;" onclick="window.location.href='<?= h($url) ?>';">
			<td style="width:70px;">
				<img style="max-width:60px;max-height:60px;display:block;" src="<?php logo_exists($guild['name']); ?>" alt="">
			</td>
			<td>
				<a href="<?= h($url) ?>" style="font-weight:bold;font-size:11pt;"><?= h($guild['name']) ?></a>
				<?php if (strlen($guild['motd']) > 0): ?>
					<br><small><?= h($guild['motd']) ?></small>
				<?php endif; ?>
			</td>
			<td>
				<?= t_default('tco.total_members', 'Total members:') ?> <?= (int)$guild['level']['players'] ?>
				<br><?= t_default('tco.average_level', 'Average level:') ?> <?= (int)$guild['level']['avg'] ?>
				<br><?= t_default('tco.guild_level', 'Guild level:') ?> <?= (int)$guild['level']['total'] ?>
			</td>
		</tr>
		<?php
	}
}
if ($i === 0) {
	?>
	<tr><td><?= t('guild.empty_list') ?></td></tr>
	<?php
}
tco_panel_close();
tco_box_close();
