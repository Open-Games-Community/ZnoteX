<?php
tco_box_open(t('reg.heading'), 'createaccount');
if ($ok) {
	echo '<h1>' . t('common.congrats') . '</h1><p>' . t('reg.created') . '</p>';
} else {
	echo '<h1>' . t('acc.auth_failed') . '</h1><p>' . t('acc.auth_failed_text') . '</p>';
}
tco_box_close();
