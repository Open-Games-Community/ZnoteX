<?php
tco_box_open(t('downloads.title'), 'downloadclient');
$downloadSections = znote_download_entries_by_section();
$sectionTitles = array(
	'official' => t_default('tco.official_client', 'Official Tibia Client'),
	'unsupported' => t_default('tco.unsupported_clients', 'Unsupported Tibia Clients'),
	'tools' => t_default('tco.download_tools', 'Tools'),
	'custom' => t_default('tco.download_custom', 'Other Downloads'),
);
$sectionOrder = array('official', 'unsupported', 'tools', 'custom');
?>
<p><?= t('downloads.intro') ?></p>

<?php foreach ($sectionOrder as $section): ?>
	<?php if (empty($downloadSections[$section])) continue; ?>
	<?php tco_panel_open($sectionTitles[$section] ?? ucwords(str_replace('_', ' ', $section))); ?>
		<?php foreach ($downloadSections[$section] as $entry): ?>
			<tr>
				<td style="text-align:center;padding:<?= $section === 'official' ? '20px' : '16px' ?>;">
					<?php if ($entry['image'] !== ''): ?>
						<img src="<?= h($entry['image']) ?>" style="max-width:120px;max-height:120px;" alt="">
					<?php elseif ($entry['key'] === 'windows_client' && theme_file_exists('assets/download_windows.gif')): ?>
						<img src="<?= theme_asset('download_windows.gif') ?>" style="width:90px;height:90px;" alt="">
					<?php endif; ?>
					<p style="<?= $section === 'official' ? 'font-size:12pt;' : '' ?>font-weight:bold;"><?= h($entry['label']) ?></p>
					<?php if ($entry['description'] !== ''): ?>
						<p><?= h($entry['description']) ?></p>
					<?php endif; ?>
					<p><?= tco_medium_button_link($entry['url'], 'mediumbutton_download.png', t('downloads.download')) ?></p>
				</td>
			</tr>
		<?php endforeach; ?>
	<?php tco_panel_close(); ?>
	<br>
<?php endforeach; ?>

<?php tco_panel_open(t_default('tco.ip_changer', 'IP Changer'), 'Table1'); ?>
	<tr>
		<td><?= t('downloads.ipchanger') ?> <a href="https://github.com/jo3bingham/tibia-ip-changer/releases/latest"><?= t('downloads.here') ?></a>.</td>
	</tr>
<?php tco_panel_close(); ?>

<h2><?= t('downloads.howto') ?></h2>
<ol>
	<li><a href="<?= h($config['client_download']) ?>"><?= t('downloads.download') ?></a> <?= t('downloads.step1') ?></li>
	<li><a href="https://github.com/jo3bingham/tibia-ip-changer/releases/latest"><?= t('downloads.download') ?></a> <?= t('downloads.step2') ?></li>
	<li><?= t('downloads.step3') ?></li>
	<li><?= t('downloads.step4') ?> <?= h($_SERVER['SERVER_NAME']) ?></li>
	<li><?= t('downloads.step5') ?> <strong>Apply</strong>.<br><?= t('downloads.step5b') ?> <a href="register.php"><?= t('downloads.here') ?></a>.</li>
</ol>
<?php
tco_box_close();
