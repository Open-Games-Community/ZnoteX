<?php
/**
 * Creature library.
 *
 * Prepared by creatures.php: $creatures, $creatureRaces, $creatureSearch,
 * $creatureRace, $creatureError. Nothing is read from disk here.
 */
tco_box_open(t('creatures.title'), 'creatures');
?>

<?php if ($creatureError !== ''): ?>

	<p><?= htmlspecialchars($creatureError, ENT_QUOTES, 'UTF-8') ?></p>

<?php else: ?>

	<div style="margin-bottom: 15px;">
		<form action="" method="get" style="display:inline-block; margin:0; padding:0;">
			<input type="text" name="search" placeholder="<?= t('creatures.placeholder') ?>"
				   value="<?= htmlspecialchars($creatureSearch, ENT_QUOTES, 'UTF-8') ?>">
			<select name="race">
				<option value=""><?= t('creatures.all_races') ?></option>
				<?php foreach ($creatureRaces as $race): ?>
					<option value="<?= htmlspecialchars($race, ENT_QUOTES, 'UTF-8') ?>"
						<?= $race === $creatureRace ? 'selected' : '' ?>>
						<?= htmlspecialchars(ucfirst($race), ENT_QUOTES, 'UTF-8') ?>
					</option>
				<?php endforeach; ?>
			</select>
			
			<div style="display:inline-block; vertical-align:middle; margin-left:5px;">
				<?= tco_button(t('common.search'), 'blue') ?>
			</div>
		</form>
		
		<?php if ($creatureSearch !== '' || $creatureRace !== ''): ?>
			<div style="display:inline-block; vertical-align:middle; margin-left:5px;">
				<a href="creatures.php"><?= tco_button(t('common.clear'), 'red') ?></a>
			</div>
		<?php endif; ?>
	</div>

	<p class="txt"><?= count($creatures) ?> creature<?= count($creatures) === 1 ? '' : 's' ?>.</p>

	<?php if ($creatures): ?>
		<?php tco_panel_open('Creatures'); ?>
			<tr style="background-color:#5f4d41;">
				<td style="color:#fff;">Name</td>
				<td style="color:#fff;">Race</td>
				<td style="color:#fff;">Health</td>
				<td style="color:#fff;"><?= t('creatures.experience') ?></td>
				<td style="color:#fff;">Speed</td>
			</tr>
			<?php $i = 0; foreach ($creatures as $creature): $i++; ?>
				<tr style="background-color:<?= tco_alt_bg($i) ?>;">
					<td><?= htmlspecialchars($creature['name'], ENT_QUOTES, 'UTF-8') ?></td>
					<td><?= htmlspecialchars(ucfirst($creature['race']), ENT_QUOTES, 'UTF-8') ?></td>
					<td><?= number_format($creature['health']) ?></td>
					<td><?= number_format($creature['experience']) ?></td>
					<td><?= number_format($creature['speed']) ?></td>
				</tr>
			<?php endforeach; ?>
		<?php tco_panel_close(); ?>
	<?php else: ?>
		<p><?= t('creatures.no_match') ?></p>
	<?php endif; ?>

<?php endif; ?>

<?php
tco_box_close();
?>
