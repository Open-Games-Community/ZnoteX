<?php
$tcoWebshopActiveTab = 'points';
require dirname(__DIR__) . '/parts/webshop.php';
