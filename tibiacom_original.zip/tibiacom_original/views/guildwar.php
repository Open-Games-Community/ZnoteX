<?php
tco_wrap_default_view('guildwar', 'guilds');
