<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades');
?>
<p><a href="/auctionChar.php?action=list"><?= t('auc.go_back_list') ?></a></p>

<?php if (is_array($own_characters) && !empty($own_characters)): ?>
	<?php tco_panel_open(t_default('tco.sell_character', 'Sell a Character')); ?>
		<tr>
			<td>
				<form action="/auctionChar.php" method="POST">
					<input type="hidden" name="action" value="add">
					<p><?= t('auc.char_offline') ?></p>
					<select name="pid">
						<?php foreach ($own_characters as $char): ?>
							<option value="<?= (int)$char['id'] ?>">
								<?= t_default('common.level', 'Level') ?>: <?= (int)$char['level'] ?> <?= h(vocation_id_to_name($char['vocation'])) ?>: <?= h($char['name']) ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p><strong><?= t('auc.shop_points') ?></strong><br>
						<?= t('auc.your_points') ?> <?= (int)$own_characters[0]['points'] ?><br>
						<?= t('auc.minimum') ?> <?= (int)$auction['lowestPrice'] ?><br>
						deposit: <?= (int)$auction['deposit'] ?>%<br>
						<?= t('auc.your_max') ?> <?= (int)$max ?>
					</p>
					<p><strong><?= t('auc.deposit_info') ?></strong></p>
					<p><?= t('auc.sell_price') ?></p>
					<input type="number" name="cost" min="<?= (int)$auction['lowestPrice'] ?>" max="<?= (int)$max ?>" step="5" placeholder="<?= (int)$auction['lowestPrice'] ?> - <?= (int)$max ?>">
					<p><?= t('auc.verify_pw') ?></p>
					<input type="password" name="password">
					<p><input type="submit" value="<?= h(t('auc.sell_btn')) ?>"></p>
				</form>
			</td>
		</tr>
	<?php tco_panel_close(); ?>
<?php else: ?>
	<?php tco_panel_open(t_default('tco.sell_character', 'Sell a Character')); ?>
		<tr>
			<td>
				<p><?= t_default('tco.auc_not_eligible', 'Your account does not follow the required rules to sell characters.') ?></p>
				<p>
					1. <?= t_default('tco.min_level', 'Minimum level') ?>: <?= (int)$auction['lowestLevel'] ?><br>
					2. <?= t_default('tco.min_points', 'Minimum already earned shop points') ?>: <?= (int)$minToCreate ?><br>
					3. <?= t_default('tco.must_be_offline', 'Eligible characters must be offline.') ?>
				</p>
			</td>
		</tr>
	<?php tco_panel_close(); ?>
<?php endif; ?>
<?php
tco_box_close();
