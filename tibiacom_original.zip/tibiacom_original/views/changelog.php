<?php
tco_box_open(t('changelog.title'), 'newsarchive');

if ($changelogs) {
	tco_panel_open(t('changelog.header'));
	$i = 0;
	foreach ($changelogs as $changelog) {
		$i++;
		list($tcoCat, $tcoText) = tco_changelog_split((string)($changelog['text'] ?? ''));
		?>
		<tr style="background-color:<?= tco_alt_bg($i) ?>;">
			<td style="width:24px;"><img src="<?= theme_asset(tco_changelog_icon($tcoCat)) ?>" alt="<?= h($tcoCat) ?>"></td>
			<td>
				<b><?= h(getClock((int)($changelog['time'] ?? 0), true, true)) ?></b><br>
				<?= znote_bbcode_raw($tcoText) ?>
			</td>
		</tr>
		<?php
	}
	tco_panel_close();
} else {
	echo '<h2>' . t('changelog.none') . '</h2>';
}

tco_box_close();
