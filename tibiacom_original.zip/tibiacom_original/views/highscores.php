<?php
tco_box_open('', 'highscores', 'highscores');
tco_default_view('highscores');
tco_box_close();