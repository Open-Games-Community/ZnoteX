<?php
/**
 * A simple title + text message for payment.php's error paths, boxed for
 * this theme.
 *
 * Prepared by payment.php: $paymentMessage = ['title' => ..., 'text' => ...].
 */
tco_box_open($paymentMessage['title'], '');
?>
<p><?= $paymentMessage['text'] ?></p>
<?php
tco_box_close();
