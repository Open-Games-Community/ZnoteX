<?php
tco_box_open(t('auc.page_title'), 'currentcharactertrades');
echo '<p>' . t_default('tco.auction_wrong_engine', 'Character shop auction system is currently only available for ServerEngine TFS_10.') . '</p>';
tco_box_close();
