<?php
tco_box_open(t_default('twofa2.title', 'Two-Factor Authentication'), 'accountmanagement');

if (empty($errors) === false) {
	echo '<font color="red"><b>' . output_errors($errors) . '</b></font>';
}

if (!empty($successes)) {
	foreach ($successes as $message) {
		echo '<div class="tco-success"><b>' . h($message) . '</b></div>';
	}
}

tco_panel_open(t_default('twofa2.app_title', 'Two-Factor Authenticator App (recommended)'));
?>
	<tr>
		<td>
			<?php if ($status['totp_enabled']): ?>
				<p><?= t_default('twofa2.app_enabled', 'Enabled.') ?></p>
				<form method="post" data-confirm="Disable the authenticator app?">
					<?php Token::create(); ?>
					<?= tco_button(t_default('twofa2.disable', 'Disable'), 'blue', '', 'tfa2_totp_disable') ?>
				</form>
			<?php else:
				$pendingRow = znote2fa_row($accountId);
				if (empty($pendingRow['totp_secret'])) {
					?>
					<form method="post">
						<?php Token::create(); ?>
						<?= tco_button(t_default('twofa2.app_start', 'Set up an authenticator app'), 'blue', '', 'tfa2_totp_start', '', true) ?>
					</form>
					<?php
				} else {
					?>
					<p style="text-align:center;">
						<img
							src="<?php echo TokenAuth6238::getBarCodeUrl($user_data['name'], $_SERVER["HTTP_HOST"], $pendingRow['totp_secret'], preg_replace('/\s+/', '', $config['site_title'])); ?>"
							alt="Two-factor authentication QR code image for this account."
						/>
					</p>
					<form method="post">
						<?php Token::create(); ?>
						<input type="text" name="tfa2_totp_code" placeholder="000000" autocomplete="one-time-code">
						<?= tco_button(t_default('twofa2.app_confirm', 'Confirm'), 'blue', '', 'tfa2_totp_confirm') ?>
					</form>
					<?php
				}
			endif; ?>
		</td>
	</tr>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t_default('twofa2.email_title', 'E-mail Codes')); ?>
	<tr>
		<td>
			<?php if (znote2fa_v2_config()['email_otp_enabled']): ?>
				<p><?= t_default('twofa2.email_help', 'Receive a one-time code by e-mail whenever you log in and have no authenticator app configured.') ?></p>
				<form method="post">
					<?php Token::create(); ?>
					<label>
						<input type="checkbox" name="tfa2_email_enabled" value="1" <?= $status['email_otp_enabled'] ? 'checked' : '' ?>>
						<?= t_default('twofa2.email_enable', 'Enable e-mail codes') ?>
					</label>
					<?= tco_button(t_default('twofa2.save', 'Save'), 'blue', '', 'tfa2_email_toggle') ?>
				</form>
			<?php else: ?>
				<p><?= t_default('twofa2.email_disabled_by_admin', 'E-mail codes have been disabled by the administrator.') ?></p>
			<?php endif; ?>
		</td>
	</tr>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t_default('twofa2.recovery_title', 'Recovery Key')); ?>
	<tr>
		<td>
			<?php if ($revealedRecoveryCodes): ?>
				<p><strong><?= t_default('twofa2.recovery_reveal', 'Save these somewhere safe. Each one works once and this is the only time they are shown.') ?></strong></p>
				<ul>
					<?php foreach ($revealedRecoveryCodes as $code): ?>
						<li><code><?= h($code) ?></code></li>
					<?php endforeach; ?>
				</ul>
			<?php else: ?>
				<p><?= t_default('twofa2.recovery_remaining', '{n} unused recovery codes.', ['n' => $status['recovery_remaining']]) ?></p>
			<?php endif; ?>
			<form method="post" <?= $status['recovery_remaining'] > 0 ? 'data-confirm="Generating new codes invalidates the old ones. Continue?"' : '' ?>>
				<?php Token::create(); ?>
				<?= tco_button(t_default('twofa2.recovery_generate', 'Generate new recovery codes'), 'blue', '', 'tfa2_recovery_generate', '', true) ?>
			</form>
		</td>
	</tr>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t_default('twofa2.devices_title', 'Trusted Devices')); ?>
	<tr>
		<td>
			<?php if ($devices): ?>
				<table class="TableContent" width="100%">
					<?php $i = 0; foreach ($devices as $device): $i++; ?>
						<tr style="background-color:<?= tco_alt_bg($i) ?>;">
							<td><?= h($device['label']) ?> - <?= h($device['ip']) ?><br>
								<?= t_default('twofa2.last_used', 'last used {when}', ['when' => getClock((int)$device['last_used_at'], true)]) ?>
							</td>
							<td style="text-align:right;">
								<form method="post">
									<?php Token::create(); ?>
									<input type="hidden" name="tfa2_device_revoke" value="<?= (int)$device['id'] ?>">
									<?= tco_button(t_default('twofa2.revoke', 'Revoke'), 'red') ?>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php else: ?>
				<p><?= t_default('twofa2.no_devices', 'There are no trusted devices.') ?></p>
			<?php endif; ?>
		</td>
	</tr>
<?php tco_panel_close(); ?>

<?php tco_panel_open(t_default('twofa2.logout_all_title', 'Log Out Everywhere')); ?>
	<tr>
		<td>
			<p><?= t_default('twofa2.logout_all_help', 'Forgets every trusted device and requires the two-factor code again on every session, including this one\'s next login.') ?></p>
			<form method="post" data-confirm="Log out all devices and forget trusted devices?">
				<?php Token::create(); ?>
				<?= tco_button(t_default('twofa2.logout_all', 'Log out all devices'), 'red', '', 'tfa2_logout_all', '', true) ?>
			</form>
		</td>
	</tr>
<?php
tco_panel_close();
tco_box_close();
