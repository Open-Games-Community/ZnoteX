<?php
tco_box_open(t('char.search_title'), 'characters');
tco_panel_open(t('char.search_title'));
?>
<tr>
	<td class="LabelV"><?= t('char.search_name') ?></td>
	<td>
		<form action="characterprofile.php" method="get" style="display:flex;gap:8px;align-items:center;">
			<input class="tco-mini-input" type="text" name="name" autofocus style="width:220px;">
			<input type="submit" value="<?= t('char.search_submit') ?>">
		</form>
	</td>
</tr>
<?php
tco_panel_close();
tco_box_close();
