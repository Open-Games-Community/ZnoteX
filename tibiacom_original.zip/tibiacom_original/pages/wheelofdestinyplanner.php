<?php
$wodAssetRoot = str_replace('\\', '/', dirname(theme_asset('wheelofdestiny/jquery_min.js'))) . '/';
$wodImageRoot = $wodAssetRoot . 'images/';
$wodDataUrl = $wodAssetRoot . 'SkillwheelStringsJsonLibrary.js';
$wodFragmentPath = __DIR__ . '/wheelofdestinyplanner.fragment.html';

tco_box_open(t_default('tco.wheel_title', 'Wheel of Destiny Planner'), 'wheelofdestinyplanner', 'wheelofdestinyplanner');

if (!is_file($wodFragmentPath)) {
	echo '<p class="ColorRed">' . t_default('tco.wheel_incomplete', 'The Wheel of Destiny Planner resources are incomplete.') . '</p>';
	tco_box_close();
	return;
}
?>
<style>
#wheelofdestinyplanner .WheelOfDestinyWrapper .Table5 > tbody > tr > td,
#wheelofdestinyplanner .WheelOfDestinyWrapper .Table5 > tbody > tr > th {
	border: 0 !important;
}
#wheelofdestinyplanner .WheelOfDestinyWrapper .Table3 .TableContent td {
	border: 1px solid #faf0d7;
}
</style>
<script src="<?= h($wodAssetRoot . 'jquery_min.js') ?>"></script>
<script src="<?= h($wodAssetRoot . 'ajaxcip_tibia_v1.js') ?>"></script>
<script>
var loginStatus = 'false';
var activeSubmenuItem = 'wheelofdestinyplanner';
const JS_DIR_IMAGES = <?= json_encode($wodImageRoot, JSON_UNESCAPED_SLASHES) ?>;
const JS_DIR_ACCOUNT = 'account.php';
const JS_DIR_COMMUNITY = '';
const JS_DIR_SUPPORT = 'support.php';
const JS_DIR_WEBSITESERVICES = '';
const JS_COOKIE_DOMAIN = window.location.hostname;
var g_FormName = '';
var g_FormField = '';
var g_Deactivated = false;
</script>
<script src="<?= h($wodAssetRoot . 'global.js') ?>"></script>
<script src="<?= h($wodAssetRoot . 'generic.js') ?>"></script>
<script src="<?= h($wodAssetRoot . 'initialize.js') ?>"></script>
<script id="wod-grid-script" src="<?= h($wodAssetRoot . 'skillgrid.js') ?>"></script>
<script id="wod-planner-script" src="<?= h($wodAssetRoot . 'wheelofdestiny.js') ?>"></script>
<?php
$wodMarkup = file_get_contents($wodFragmentPath);
$wodMarkup = str_replace('https://static.tibia.com/images/', $wodImageRoot, $wodMarkup);
$wodMarkup = preg_replace(
	'~https://static\.tibia\.com/javascripts/wheelofdestiny/SkillwheelStringsJsonLibrary\.json(?:\?version=[a-f0-9]+)?~',
	$wodDataUrl,
	$wodMarkup
);
echo $wodMarkup;

tco_box_close();
?>
<div id="HelperDivContainer" style="background-image:url(<?= h($wodImageRoot . 'global/content/scroll.gif') ?>);display:none;">
	<div class="HelperDivArrow" style="background-image:url(<?= h($wodImageRoot . 'global/content/helper-div-arrow.png') ?>);"></div>
	<div id="HelperDivHeadline"></div>
	<div id="HelperDivText"></div>
	<div class="TextCenter"><img class="Ornament" src="<?= h($wodImageRoot . 'global/content/ornament.gif') ?>" alt=""></div>
	<br>
</div>
<script>
document.body.appendChild(document.getElementById('HelperDivContainer'));
</script>
