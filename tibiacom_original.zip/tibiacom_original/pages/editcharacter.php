<?php
protect_page();

$charName = getValue($_GET['character'] ?? null);
$charId = $charName !== false ? user_character_id($charName) : false;
$isOwner = $charId !== false && (int)user_character_account_id($charName) === (int)$session_user_id;

if (!$isOwner) {
	tco_box_open(t_default('tco.edit_character', 'Edit Character'), 'accountmanagement');
	echo '<p>' . t_default('tco.character_not_found', 'Character not found.') . '</p>';
	tco_box_close();
	return;
}

$charData = user_character_data($charId, 'name', 'level', 'vocation', 'town_id', 'sex');
$hideChar = user_character_hide($charName);
$commentData = user_znote_character_data($charId, 'comment');

tco_box_open(t_default('tco.edit_character', 'Edit Character') . ': ' . $charName, 'accountmanagement');
?>
<p><a href="myaccount.php">&laquo; <?= t_default('tco.back_to_account', 'Back to My Account') ?></a></p>

<?php tco_panel_open(t_default('tco.character_info', 'Character Info')); ?>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;">
		<td class="LabelV"><?= t_default('common.vocation', 'Vocation') ?></td>
		<td><?= h(vocation_id_to_name((int)$charData['vocation'])) ?></td>
	</tr>
	<tr style="background-color:<?= tco_alt_bg(1) ?>;">
		<td class="LabelV"><?= t_default('common.level', 'Level') ?></td>
		<td><?= (int)$charData['level'] ?></td>
	</tr>
	<tr style="background-color:<?= tco_alt_bg(0) ?>;">
		<td class="LabelV"><?= t_default('tco.town', 'Town') ?></td>
		<td><?= h(town_id_to_name((int)$charData['town_id'])) ?></td>
	</tr>
<?php tco_panel_close(); ?>
<br>

<?php tco_panel_open(t('acc.change_name')); ?>
	<tr>
		<td>
			<form action="myaccount.php" method="post">
				<input type="hidden" name="selected_character" value="<?= h($charName) ?>">
				<input type="hidden" name="action" value="change_name">
				<input class="tco-mini-input" type="text" name="newName" value="<?= h($charName) ?>" style="width:220px;display:inline-block;">
				<?php Token::create(); ?>
				<?= tco_button(t('common.submit'), 'blue') ?>
			</form>
		</td>
	</tr>
<?php tco_panel_close(); ?>
<br>

<?php tco_panel_open(t('acc.change_gender')); ?>
	<tr>
		<td>
			<?= t_default('tco.current_gender', 'Current gender:') ?>
			<b><?= (int)$charData['sex'] === 1 ? t_default('tco.male', 'Male') : t_default('tco.female', 'Female') ?></b>
			<form action="myaccount.php" method="post" style="display:inline;">
				<input type="hidden" name="selected_character" value="<?= h($charName) ?>">
				<input type="hidden" name="action" value="change_gender">
				<?php Token::create(); ?>
				<?= tco_button(t('acc.change_gender'), 'blue') ?>
			</form>
		</td>
	</tr>
<?php tco_panel_close(); ?>
<br>

<?php tco_panel_open(t_default('tco.visibility', 'Visibility')); ?>
	<tr>
		<td>
			<?= t_default('tco.current_status', 'Current status:') ?> <b><?= h(hide_char_to_name($hideChar)) ?></b>
			<form action="myaccount.php" method="post" style="display:inline;">
				<input type="hidden" name="selected_character" value="<?= h($charName) ?>">
				<input type="hidden" name="action" value="toggle_hide">
				<?php Token::create(); ?>
				<?= tco_button(t('acc.toggle_hide'), 'blue') ?>
			</form>
		</td>
	</tr>
<?php tco_panel_close(); ?>
<br>

<?php tco_panel_open(t('acc.comment')); ?>
	<tr>
		<td>
			<form action="myaccount.php" method="post">
				<input type="hidden" name="selected_character" value="<?= h($charName) ?>">
				<input type="hidden" name="action" value="update_comment">
				<textarea class="tco-mini-input" name="comment" rows="6" style="width:100%;box-sizing:border-box;"><?= h($commentData['comment'] ?? '') ?></textarea>
				<br><br>
				<?php Token::create(); ?>
				<?= tco_button(t('acc.update_comment'), 'blue') ?>
			</form>
		</td>
	</tr>
<?php tco_panel_close(); ?>
<br>

<?php tco_panel_open(t_default('tco.delete_character', 'Delete Character')); ?>
	<tr>
		<td>
			<form action="myaccount.php" method="post" data-confirm="<?= h(t_default('tco.confirm_delete_char', 'Do you really want to DELETE character: ') . $charName . '?') ?>">
				<input type="hidden" name="selected_character" value="<?= h($charName) ?>">
				<input type="hidden" name="action" value="delete_character">
				<?php Token::create(); ?>
				<?= tco_button(t('acc.delete_char'), 'red') ?>
			</form>
		</td>
	</tr>
<?php
tco_panel_close();
tco_box_close();
