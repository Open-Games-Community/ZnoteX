<?php
$page_filename = 'houses';

theme_open();

if ($config['log_ip']) {
	znote_visitor_insert_detailed_data(3);
}

$towns = $config['towns'] ?? array();
$defaultTown = (int)($config['houseConfig']['HouseListDefaultTown'] ?? array_key_first($towns));
$townid = isset($_GET['id']) ? (int)$_GET['id'] : $defaultTown;
if (!isset($towns[$townid]) && !empty($towns)) {
	$townid = (int)array_key_first($towns);
}

$status = (string)($_GET['status'] ?? 'all');
$category = (string)($_GET['category'] ?? 'houses');
$order = (string)($_GET['order'] ?? 'name');

$statusAllowed = array('all', 'auctioned', 'rented');
$categoryAllowed = array('houses', 'guildhalls');
$orderAllowed = array(
	'name' => 'name',
	'size' => 'size',
	'rent' => 'rent',
	'bid' => 'bid',
	'auction_end' => 'bid_end',
);

if (!in_array($status, $statusAllowed, true)) {
	$status = 'all';
}
if (!in_array($category, $categoryAllowed, true)) {
	$category = 'houses';
}
if (!array_key_exists($order, $orderAllowed)) {
	$order = 'name';
}

$guildhallColumn = null;
foreach (array('guildhall', 'is_guildhall') as $candidate) {
	if (function_exists('znote_column_exists') && znote_column_exists('houses', $candidate)) {
		$guildhallColumn = $candidate;
		break;
	}
}

$selectGuildhall = $guildhallColumn !== null ? ', `' . $guildhallColumn . '` AS `guildhall`' : ', 0 AS `guildhall`';
$orderColumn = $orderAllowed[$order];
$cache = new Cache('engine/cache/houses/tco-houses-' . $orderColumn);
$houses = array();

if ($cache->hasExpired()) {
	$houses = db()->fetchAll("
		SELECT
			`id`, `owner`, `paid`, `warnings`, `name`, `rent`, `town_id`,
			`size`, `beds`, " . houseSelect(array('bid','bid_end','last_bid','highest_bidder')) . $selectGuildhall . "
		FROM `houses`
		ORDER BY {$orderColumn} ASC;
	");

	if ($houses !== false) {
		$playerlist = array();
		foreach ($houses as $h) {
			if ((int)$h['owner'] > 0) {
				$playerlist[] = (int)$h['owner'];
			}
		}

		if (!empty($playerlist)) {
			$playerlist = array_values(array_unique($playerlist));
			$placeholders = implode(',', array_fill(0, count($playerlist), '?'));
			$tmpPlayers = db()->fetchAll("SELECT `id`, `name` FROM players WHERE `id` IN ($placeholders);", $playerlist);
			$tmpById = array();
			foreach ($tmpPlayers as $p) {
				$tmpById[(int)$p['id']] = (string)$p['name'];
			}
			for ($i = 0; $i < count($houses); $i++) {
				if ((int)$houses[$i]['owner'] > 0 && isset($tmpById[(int)$houses[$i]['owner']])) {
					$houses[$i]['ownername'] = $tmpById[(int)$houses[$i]['owner']];
				}
			}
		}

		$cache->setContent($houses);
		$cache->save();
	}
} else {
	$houses = $cache->load();
}

$filteredHouses = array();
if (is_array($houses)) {
	foreach ($houses as $house) {
		if ((int)$house['town_id'] !== $townid) {
			continue;
		}
		if ($status === 'auctioned' && (int)$house['owner'] !== 0) {
			continue;
		}
		if ($status === 'rented' && (int)$house['owner'] === 0) {
			continue;
		}
		if ($guildhallColumn !== null) {
			$isGuildhall = !empty($house['guildhall']);
			if ($category === 'guildhalls' && !$isGuildhall) {
				continue;
			}
			if ($category === 'houses' && $isGuildhall) {
				continue;
			}
		}
		$filteredHouses[] = $house;
	}
}

$radio = function (string $name, string $value, string $label, string $selected) {
	return '<label><input type="radio" name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"' . ($value === $selected ? ' checked' : '') . '> ' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</label>';
};

tco_box_open('Houses', 'houses', 'houses');
?>
<p class="tco-houses-intro">
	Here you can see the list of all available houses, flats or guildhalls. Please select the game world of your choice. Click on any view button to get more information about a house or adjust the search criteria and start a new search.
</p>

<form action="houses.php" method="get" id="tco-house-search">
	<?php tco_panel_open('House Search'); ?>
	<tr class="tco-house-world-row">
		<td colspan="3">
			<label for="tco-house-world">World</label>
			<select id="tco-house-world" name="world">
				<option value="main" selected><?= htmlspecialchars((string)($config['server_name'] ?? $config['site_title'] ?? 'World'), ENT_QUOTES, 'UTF-8') ?></option>
			</select>
		</td>
	</tr>
	<tr class="tco-house-filter-row">
		<td class="tco-house-town-cell">
			<div class="tco-house-filter-title">Town</div>
			<?php foreach ($towns as $id => $name): ?>
				<?= $radio('id', (string)$id, (string)$name, (string)$townid) ?>
			<?php endforeach; ?>
		</td>
		<td class="tco-house-status-cell">
			<div class="tco-house-filter-title">Status</div>
			<?= $radio('status', 'all', 'all states', $status) ?>
			<?= $radio('status', 'auctioned', 'auctioned', $status) ?>
			<?= $radio('status', 'rented', 'rented', $status) ?>
			<div class="tco-house-filter-separator"></div>
			<?= $radio('category', 'houses', 'houses and flats', $category) ?>
			<?= $radio('category', 'guildhalls', 'guildhalls', $category) ?>
		</td>
		<td class="tco-house-order-cell">
			<div class="tco-house-filter-title">Order</div>
			<?= $radio('order', 'name', 'by name', $order) ?>
			<?= $radio('order', 'size', 'by size', $order) ?>
			<?= $radio('order', 'rent', 'by rent', $order) ?>
			<?= $radio('order', 'bid', 'by bid', $order) ?>
			<?= $radio('order', 'auction_end', 'by auction end', $order) ?>
		</td>
	</tr>
	<?php tco_panel_close(); ?>

	<div class="tco-house-submit">
		<?= tco_button('Submit', 'blue', 'tco-house-search') ?>
	</div>
</form>

<?php if ($houses === false): ?>
	<h1><?= t('houses.fetch_failed') ?></h1>
	<p><?= t('houses.empty') ?></p>
<?php elseif (!empty($filteredHouses)): ?>
	<?php tco_panel_open('House List'); ?>
	<tr class="tco-house-list-head">
		<td>Name</td>
		<td>Size</td>
		<td>Beds</td>
		<td>Rent</td>
		<td>Owner</td>
		<td>Town</td>
	</tr>
	<?php foreach ($filteredHouses as $index => $house): ?>
		<tr style="background-color:<?= tco_alt_bg($index) ?>;">
			<td><a href="house.php?id=<?= (int)$house['id'] ?>"><?= htmlspecialchars((string)$house['name'], ENT_QUOTES, 'UTF-8') ?></a></td>
			<td><?= (int)$house['size'] ?></td>
			<td><?= (int)$house['beds'] ?></td>
			<td><?= (int)$house['rent'] ?></td>
			<td>
				<?php if ((int)$house['owner'] !== 0 && isset($house['ownername'])): ?>
					<a href="characterprofile.php?name=<?= urlencode((string)$house['ownername']) ?>" target="_BLANK"><?= htmlspecialchars((string)$house['ownername'], ENT_QUOTES, 'UTF-8') ?></a>
				<?php elseif ((int)$house['highest_bidder'] === 0): ?>
					None
				<?php else: ?>
					<b>Selling</b>
				<?php endif; ?>
			</td>
			<td><?= htmlspecialchars((string)($towns[(int)$house['town_id']] ?? ('Town ' . (int)$house['town_id'])), ENT_QUOTES, 'UTF-8') ?></td>
		</tr>
	<?php endforeach; ?>
	<?php tco_panel_close(); ?>
<?php else: ?>
	<p class="tco-houses-empty">No houses match the selected search criteria.</p>
<?php endif; ?>
<?php
tco_box_close();
theme_close();
