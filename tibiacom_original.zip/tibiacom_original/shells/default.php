<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, viewport-fit=cover">
	<title><?= theme_title() ?></title>

	<link rel="stylesheet" href="<?= theme_asset('basic_part1.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('basic_part2.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('basic_part3.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('global_part_1.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('global_part_2.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('accountmanagement.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('news.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('tco.css') ?>?v=<?= (int)@filemtime(theme_path() . '/assets/tco.css') ?>">

	<script src="<?= theme_asset('tco.js') ?>?v=<?= (int)@filemtime(theme_path() . '/assets/tco.js') ?>"></script>
</head>
<body>

	<div class="main-site-container">

		<div class="main-header">
			<?php require __DIR__ . '/../parts/mobile_menu.php'; ?>
		</div>

		<div class="main-menu">
			<?php theme_sidebar(); ?>
		</div>

		<div class="main-content Content feedContainer">
			<?php require __DIR__ . '/../parts/infobar.php'; ?>
			<?php require __DIR__ . '/../parts/right_artwork.php'; ?>
			<?php theme_content(); ?>
		</div>

		<div class="main-themboxes Themeboxes">
			<?php require __DIR__ . '/../parts/themeboxes.php'; ?>
		</div>

		<div class="main-footer">
			<div id="Footer">
				<?php $footerText = theme_option('footer_html'); ?>
				<?php if ($footerText !== ''): ?>
					<p><?= $footerText ?></p>
				<?php endif; ?>
				<p>
					&copy; <?= theme_title() ?>.
					<?= h(t('footer.generated_in', ['time' => elapsedTime()])) ?>
					<?= h(t('footer.engine')) ?> <a href="credits.php">ZnoteX</a>.
					<?= h(t('footer.server_clock', ['clock' => getClock(false, true)])) ?>
				</p>
			</div>
		</div>

	</div>

</body>
</html>
