<?php
require_once __DIR__ . '/parts/box.php';
require_once __DIR__ . '/parts/nav.php';

// This theme renders the boosted plugin's data on Tibia's pedestal. Claiming
// the embedded renderer prevents the plugin from also injecting its floating box.
if (function_exists('boosted_creatures_claim_embedded_renderer')) {
	boosted_creatures_claim_embedded_renderer();
}

function tco_recovery_open(): void {
	tco_box_open(t_default('recovery.lost_account_title', 'Lost Account'), 'lostaccount', 'lostaccount');
}

function tco_recovery_close(): void {
	tco_box_close();
}

function tco_characterprofile_open(): void {
	tco_box_open('Character Profile', 'characters', 'characterprofile');
}

function tco_characterprofile_close(): void {
	tco_box_close();
}