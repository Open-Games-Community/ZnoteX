<?php
/**
 * Title: Bounty Board
 * Icon: fa-crosshairs
 * Group: Installed Plugins
 * Order: 36
 * Description: Rules, detector tables, whitelisted monsters, moderation and the kill-counter script.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'bounty_board__board';
if (function_exists('bounty_board_ensure_schema')) bounty_board_ensure_schema();

function bounty_board_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function bounty_board_admin_ident($v): string {
	$v = trim((string) $v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? '');

	if ($do === 'monster_add') {
		$name = strtolower(trim((string) ($_POST['name'] ?? '')));
		$name = preg_replace('/[^a-z0-9 _\'-]/', '', $name);
		if ($name !== '') {
			mysql_insert("INSERT INTO `znote_bounty_monsters` (`name`,`label`,`added_at`) VALUES ('" . esc($name) . "','" . esc(trim((string) ($_POST['label'] ?? ''))) . "'," . time() . ") ON DUPLICATE KEY UPDATE `label` = VALUES(`label`);");
			acp_flash_success('Monster added.');
		}
		acp_redirect($module);
	}
	if ($do === 'monster_del') {
		$name = strtolower(trim((string) ($_POST['name'] ?? '')));
		mysql_delete("DELETE FROM `znote_bounty_monsters` WHERE `name` = '" . esc($name) . "' LIMIT 1;");
		acp_flash_success('Monster removed.');
		acp_redirect($module);
	}
	if ($do === 'force_cancel') {
		$id = intv($_POST['id'] ?? 0);
		$b = bounty_board_get($id);
		if ($b && $b['status'] === 'open') {
			$res = bounty_board_cancel($id, (int) $b['poster_account_id']); // refunds the un-paid remainder to the poster
			bounty_board_log($id, 'admin', 0, 'force cancel');
			acp_flash_success($res['ok'] ? 'Bounty cancelled and refunded.' : $res['message']);
		}
		acp_redirect($module);
	}
	if ($do === 'delete') {
		$id = intv($_POST['id'] ?? 0);
		mysql_delete("DELETE FROM `znote_bounties` WHERE `id` = {$id} LIMIT 1;");
		mysql_delete("DELETE FROM `znote_bounty_log` WHERE `bounty_id` = {$id};");
		bounty_board_clear_cache();
		acp_flash_success('Bounty deleted.');
		acp_redirect($module);
	}

	// config
	setting_set('bounty_board:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('bounty_board:pages', trim((string) ($_POST['pages'] ?? 'index.php')));
	setting_set('bounty_board:side', ($_POST['side'] ?? 'right') === 'left' ? 'left' : 'right');
	setting_set('bounty_board:offset_top', (string) max(0, min(800, intv($_POST['offset_top'] ?? 120))));
	setting_set('bounty_board:box_count', (string) max(1, min(10, intv($_POST['box_count'] ?? 4))));
	setting_set('bounty_board:cache_ttl', (string) max(15, min(3600, intv($_POST['cache_ttl'] ?? 60))));
	setting_set('bounty_board:poll_seconds', (string) max(0, min(600, intv($_POST['poll_seconds'] ?? 30))));
	setting_set('bounty_board:max_winners', (string) max(1, min(20, intv($_POST['max_winners'] ?? 5))));
	setting_set('bounty_board:panel_title', trim((string) ($_POST['panel_title'] ?? '')));

	setting_set('bounty_board:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
	setting_set('bounty_board:menu_v', '');
	if (function_exists('bounty_board_sync_menu')) bounty_board_sync_menu();

	foreach (array_keys(bounty_board_types()) as $t)
		setting_set('bounty_board:type_' . $t, !empty($_POST['type_' . $t]) ? '1' : '0');

	setting_set('bounty_board:min_stake', (string) max(0, intv($_POST['min_stake'] ?? 50)));
	setting_set('bounty_board:max_stake', (string) max(1, intv($_POST['max_stake'] ?? 100000)));
	setting_set('bounty_board:max_days', (string) max(1, intv($_POST['max_days'] ?? 30)));
	setting_set('bounty_board:max_active', (string) max(1, intv($_POST['max_active'] ?? 3)));
	setting_set('bounty_board:cooldown', (string) max(0, intv($_POST['cooldown'] ?? 0)));
	setting_set('bounty_board:listing_fee', (string) max(0, intv($_POST['listing_fee'] ?? 0)));
	setting_set('bounty_board:allow_self', !empty($_POST['allow_self']) ? '1' : '0');
	setting_set('bounty_board:unjustified_only', !empty($_POST['unjustified_only']) ? '1' : '0');

	foreach (array('deaths_table', 'deaths_time_col', 'deaths_killedby_col', 'deaths_isplayer_col', 'deaths_unjust_col', 'players_table', 'players_name_col', 'players_level_col', 'players_balance_col', 'players_lastlogin_col', 'players_voc_col', 'guild_membership_table', 'guild_membership_guild_col', 'guilds_table', 'guilds_owner_col', 'guilds_name_col') as $k)
		setting_set('bounty_board:' . $k, bounty_board_admin_ident($_POST[$k] ?? ''));

	foreach (array('box_bg', 'border', 'text', 'accent', 'button_bg', 'button_text', 'title_bg', 'title_text') as $k)
		setting_set('bounty_board:style_' . $k, bounty_board_admin_color($_POST['style_' . $k] ?? ''));
	setting_set('bounty_board:style_radius', (string) max(0, min(40, intv($_POST['style_radius'] ?? 14))));
	setting_set('bounty_board:style_shadow', !empty($_POST['style_shadow']) ? '1' : '0');

	bounty_board_clear_cache();
	if (function_exists('acp_log')) acp_log('bounty_board.config', '');
	acp_flash_success('Bounty Board saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('bounty_board:' . $k, $d);
$monsters = bounty_board_monsters();
$allBounties = bounty_board_list('open', 40);
foreach (array('claimed', 'expired', 'cancelled') as $st) $allBounties = array_merge($allBounties, bounty_board_list($st, 15));
?>
<?php acp_card_open('Bounty Board', 'Players stake shop points; the first to meet the condition is paid automatically. Detector tables are autodetected - override only if your fork differs. "Monster kills" needs the Lua counter below and at least one whitelisted monster.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Add a "Bounty Board" link to the main menu</label></div>
		<div class="acp-field"><label class="acp-label">Side box on pages (comma, blank = all)</label><input class="acp-input" name="pages" value="<?= h($get('pages', 'index.php')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Side</label><select class="acp-select" name="side"><option value="right" <?= $get('side', 'right') !== 'left' ? 'selected' : '' ?>>Right</option><option value="left" <?= $get('side', 'right') === 'left' ? 'selected' : '' ?>>Left</option></select></div>
		<div class="acp-field"><label class="acp-label">Top offset (px)</label><input class="acp-input" type="number" name="offset_top" value="<?= (int) $get('offset_top', '120') ?>"></div>
		<div class="acp-field"><label class="acp-label">Bounties shown in the box</label><input class="acp-input" type="number" min="1" max="10" name="box_count" value="<?= (int) $get('box_count', '4') ?>"></div>
		<div class="acp-field"><label class="acp-label">Cache / detection interval (seconds)</label><input class="acp-input" type="number" min="15" name="cache_ttl" value="<?= (int) $get('cache_ttl', '60') ?>"></div>
		<div class="acp-field"><label class="acp-label">Live refresh on the page &amp; box (seconds, 0 = off)</label><input class="acp-input" type="number" min="0" name="poll_seconds" value="<?= (int) $get('poll_seconds', '30') ?>"></div>
		<div class="acp-field"><label class="acp-label">Max winners per bounty (1 = classic, first-to-claim)</label><input class="acp-input" type="number" min="1" max="20" name="max_winners" value="<?= (int) $get('max_winners', '5') ?>"></div>
		<div class="acp-field"><label class="acp-label">Panel title</label><input class="acp-input" name="panel_title" value="<?= h($get('panel_title')) ?>" placeholder="Bounty Board"></div>
	</div>

	<h3>Bounty types</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (bounty_board_types() as $t => $v): ?>
			<div class="acp-field"><label class="acp-label"><input type="checkbox" name="type_<?= h($t) ?>" value="1" <?= $get('type_' . $t, $t === 'monster_kills' ? '0' : '1') === '1' ? 'checked' : '' ?>> <?= h($v['label']) ?><?= $v['script'] ? ' <span class="acp-muted">(needs the script)</span>' : '' ?></label></div>
		<?php endforeach; ?>
	</div>

	<h3>Rules</h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Min stake (points)</label><input class="acp-input" type="number" min="0" name="min_stake" value="<?= (int) $get('min_stake', '50') ?>"></div>
		<div class="acp-field"><label class="acp-label">Max stake (points)</label><input class="acp-input" type="number" min="1" name="max_stake" value="<?= (int) $get('max_stake', '100000') ?>"></div>
		<div class="acp-field"><label class="acp-label">Max duration (days)</label><input class="acp-input" type="number" min="1" name="max_days" value="<?= (int) $get('max_days', '30') ?>"></div>
		<div class="acp-field"><label class="acp-label">Max open bounties per account</label><input class="acp-input" type="number" min="1" name="max_active" value="<?= (int) $get('max_active', '3') ?>"></div>
		<div class="acp-field"><label class="acp-label">Cooldown between posts (seconds)</label><input class="acp-input" type="number" min="0" name="cooldown" value="<?= (int) $get('cooldown', '0') ?>"></div>
		<div class="acp-field"><label class="acp-label">Listing fee (points, non-refundable sink)</label><input class="acp-input" type="number" min="0" name="listing_fee" value="<?= (int) $get('listing_fee', '0') ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="allow_self" value="1" <?= $get('allow_self', '0') === '1' ? 'checked' : '' ?>> Allow claiming / targeting your own account</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="unjustified_only" value="1" <?= $get('unjustified_only', '0') === '1' ? 'checked' : '' ?>> PvP: only count unjustified kills</label></div>
	</div>

	<h3>Detector tables <span class="acp-muted">(blank = autodetect)</span></h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array(
			'deaths_table' => 'player_deaths table', 'deaths_time_col' => 'deaths: time column', 'deaths_killedby_col' => 'deaths: killer-name column', 'deaths_isplayer_col' => 'deaths: is-player column', 'deaths_unjust_col' => 'deaths: unjustified column',
			'players_table' => 'players table', 'players_name_col' => 'players: name column', 'players_level_col' => 'players: level column', 'players_balance_col' => 'players: bank column', 'players_lastlogin_col' => 'players: last-login column', 'players_voc_col' => 'players: vocation column',
			'guild_membership_table' => 'guild_membership table', 'guild_membership_guild_col' => 'membership: guild-id column', 'guilds_table' => 'guilds table', 'guilds_owner_col' => 'guilds: owner column', 'guilds_name_col' => 'guilds: name column',
		) as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="<?= h($k) ?>" value="<?= h($get($k)) ?>" placeholder="auto"></div>
		<?php endforeach; ?>
	</div>

	<h3>Colours</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent', 'button_bg' => 'Button background', 'button_text' => 'Button text', 'title_bg' => 'Title bar background', 'title_text' => 'Title bar text') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>" placeholder="#1a1d24 or rgba(...)"></div>
		<?php endforeach; ?>
		<div class="acp-field"><label class="acp-label">Corner radius (px)</label><input class="acp-input" type="number" min="0" max="40" name="style_radius" value="<?= (int) $get('style_radius', '14') ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="style_shadow" value="1" <?= $get('style_shadow', '1') === '1' ? 'checked' : '' ?>> Drop shadow</label></div>
	</div>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Whitelisted monsters', 'For "First to N monster kills" bounties. The Lua counter reads this list from the database (no script editing when you add one). Use the exact spawn name, lowercase.'); ?>
<form method="post" class="acp-inline-form"><?= acp_csrf_field() ?><input type="hidden" name="do" value="monster_add">
	<input class="acp-input" name="name" placeholder="demon" style="max-width:200px">
	<input class="acp-input" name="label" placeholder="Demon (label)" style="max-width:200px">
	<button class="acp-btn" type="submit"><i class="fa fa-plus"></i> Add</button>
</form>
<?php if ($monsters): ?>
<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Name (key)</th><th>Label</th><th></th></tr></thead><tbody>
	<?php foreach ($monsters as $m): ?>
		<tr><td><code><?= h($m['name']) ?></code></td><td><?= h($m['label']) ?></td>
		<td><form class="acp-inline-form" method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="monster_del"><input type="hidden" name="name" value="<?= h($m['name']) ?>"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button></form></td></tr>
	<?php endforeach; ?>
</tbody></table></div>
<?php else: ?><p class="acp-muted">No monsters whitelisted.</p><?php endif; ?>
<?php acp_card_close(); ?>

<?php acp_card_open('Kill counter script', 'Only for "monster kills" bounties. Buffered in memory, flushed every 30 s (one query per monster per flush). The script auto-reads the whitelist above.'); ?>
<div class="acp-field"><label class="acp-label">Server</label>
	<select class="acp-select" id="bbDistro">
		<?php foreach (bounty_board_distros() as $k => $lbl): ?><option value="<?= h($k) ?>"><?= h($lbl) ?></option><?php endforeach; ?>
	</select>
</div>
<div class="acp-actions"><a class="acp-btn acp-btn--green" id="bbDownload" href="../index.php?bounty_board_dl=tfs_revscript"><i class="fa fa-download"></i> Download script bundle</a></div>
<script>(function(){var s=document.getElementById('bbDistro'),a=document.getElementById('bbDownload');if(s&&a)s.addEventListener('change',function(){a.href='../index.php?bounty_board_dl='+encodeURIComponent(s.value);});}());</script>
<?php acp_card_close(); ?>

<?php acp_card_open('Moderation', 'Recent bounties. Force-cancel refunds the poster.'); ?>
<?php if (!$allBounties): ?><p class="acp-muted">No bounties yet.</p><?php else: ?>
<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>#</th><th>Bounty</th><th>Poster</th><th>Stake</th><th>Status</th><th>Winner</th><th></th></tr></thead><tbody>
	<?php foreach ($allBounties as $b): $rid = (int) $b['id']; ?>
		<tr>
			<td><?= $rid ?></td>
			<td><?= h(bounty_board_title($b)) ?></td>
			<td><?= h($b['poster_name']) ?></td>
			<td><?= number_format((int) $b['stake']) ?></td>
			<td><?= h($b['status']) ?></td>
			<td><?= h($b['claimed_by_name']) ?></td>
			<td style="white-space:nowrap">
				<?php if ($b['status'] === 'open'): ?>
					<form class="acp-inline-form" method="post" data-confirm="Cancel &amp; refund?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="force_cancel"><input type="hidden" name="id" value="<?= $rid ?>"><button class="acp-btn acp-btn--sm" type="submit"><i class="fa fa-ban"></i></button></form>
				<?php endif; ?>
				<form class="acp-inline-form" method="post" data-confirm="Delete permanently?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $rid ?>"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button></form>
			</td>
		</tr>
	<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
<?php acp_card_close(); ?>
