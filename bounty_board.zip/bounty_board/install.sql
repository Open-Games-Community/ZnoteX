CREATE TABLE IF NOT EXISTS `znote_bounties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `poster_account_id` int NOT NULL,
  `poster_name` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(24) NOT NULL DEFAULT 'pvp_kill',
  `title` varchar(180) NOT NULL DEFAULT '',
  `target_name` varchar(64) NOT NULL DEFAULT '',
  `target_value` bigint NOT NULL DEFAULT '0',
  `vocation_filter` int NOT NULL DEFAULT '0',
  `stake` int NOT NULL DEFAULT '0',
  `winners` int NOT NULL DEFAULT '1',
  `status` varchar(16) NOT NULL DEFAULT 'open',
  `claimed_by_account` int NOT NULL DEFAULT '0',
  `claimed_by_name` varchar(64) NOT NULL DEFAULT '',
  `claimed_at` int NOT NULL DEFAULT '0',
  `guard` varchar(32) NOT NULL DEFAULT '',
  `note` varchar(500) NOT NULL DEFAULT '',
  `posted_at` int NOT NULL DEFAULT '0',
  `expires_at` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status_stake` (`status`, `stake`),
  KEY `poster` (`poster_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_bounty_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bounty_id` int NOT NULL,
  `event` varchar(20) NOT NULL DEFAULT '',
  `account_id` int NOT NULL DEFAULT '0',
  `detail` varchar(200) NOT NULL DEFAULT '',
  `created_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bounty` (`bounty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_bounty_monsters` (
  `name` varchar(64) NOT NULL,
  `label` varchar(64) NOT NULL DEFAULT '',
  `added_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_bounty_claims` (
  `bounty_id` int NOT NULL,
  `account_id` int NOT NULL,
  `character_name` varchar(64) NOT NULL DEFAULT '',
  `amount` int NOT NULL DEFAULT '0',
  `paid` tinyint NOT NULL DEFAULT '0',
  `claimed_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`bounty_id`, `account_id`),
  KEY `bounty` (`bounty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_bounty_kill_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` int NOT NULL,
  `monster_key` varchar(64) NOT NULL,
  `kills` int NOT NULL DEFAULT '0',
  `logged_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `monster_time` (`monster_key`, `logged_at`),
  KEY `player_monster` (`player_id`, `monster_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
