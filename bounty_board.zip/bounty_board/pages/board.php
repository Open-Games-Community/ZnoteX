<?php
/**
 * Public page: page.php?plugin=bounty_board&p=board
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'bounty_board_h';
$accountId = 0;
if (!empty($GLOBALS['session_user_id'])) $accountId = (int) $GLOBALS['session_user_id'];
elseif (function_exists('user_logged_in') && user_logged_in() === true) $accountId = (int) getSession('user_id');

$posterName = '';
if ($accountId > 0 && function_exists('user_character_list')) {
	foreach ((array) user_character_list($accountId) as $c) { $posterName = (string) ($c['name'] ?? ''); break; }
}
if ($posterName === '' && isset($GLOBALS['user_data']['name'])) $posterName = (string) $GLOBALS['user_data']['name'];

$flash = null;
if ($accountId > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
	$okToken = !class_exists('Token') || Token::isValid($_POST['token'] ?? null);
	if (!$okToken) {
		$flash = array('ok' => false, 'message' => bounty_board_t('bounty_board.err_session', 'Session expired, reload and try again.'));
	} elseif (($_POST['do'] ?? '') === 'cancel') {
		$flash = bounty_board_cancel((int) ($_POST['id'] ?? 0), $accountId);
	} elseif (($_POST['do'] ?? '') === 'post') {
		$flash = bounty_board_post($accountId, $posterName, array(
			'type'        => (string) ($_POST['type'] ?? ''),
			'stake'       => (int) ($_POST['stake'] ?? 0),
			'winners'     => (int) ($_POST['winners'] ?? 1),
			'days'        => (int) ($_POST['days'] ?? 7),
			'target_name' => (string) ($_POST['target_name'] ?? ''),
			'value'       => (int) ($_POST['value'] ?? 0),
			'vocation'    => (int) ($_POST['vocation'] ?? 0),
			'skill'       => (string) ($_POST['skill'] ?? ''),
			'monster'     => (string) ($_POST['monster'] ?? ''),
			'note'        => (string) ($_POST['note'] ?? ''),
		));
	}
}

$data    = bounty_board_data(true);
$points  = $accountId > 0 ? bounty_board_points($accountId) : 0;
$mine    = $accountId > 0 ? bounty_board_by_poster($accountId) : array();
$monsters = bounty_board_monsters();
$types   = array();
foreach (bounty_board_types() as $k => $v) if (bounty_board_type_enabled($k)) $types[$k] = $v;
$minStake = bounty_board_int('min_stake', 50);
$maxStake = bounty_board_int('max_stake', 100000);
$maxDays  = bounty_board_int('max_days', 30);
$fee      = max(0, bounty_board_int('listing_fee', 0));

$style = bounty_board_style_attr();
?>
<style>
.bb-page{--bb-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--bb-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bb-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--bb-accent:var(--accent,var(--link,#f4c542));--bb-btn-bg:var(--bb-accent);--bb-btn-text:#151515;--bb-radius:12px;color:var(--bb-text)}
.bb-page *{box-sizing:border-box}
.bb-page h1{font-size:26px;margin:0 0 4px}
.bb-page .bb-lead{opacity:.8;margin:0 0 20px;max-width:640px}
.bb-grid{display:grid;grid-template-columns:1fr;gap:22px}
@media(min-width:900px){.bb-grid{grid-template-columns:320px 1fr}}
.bb-card{border:1px solid var(--bb-border);border-radius:var(--bb-radius);background:var(--bb-surface);padding:16px}
.bb-card h2{font-size:15px;margin:0 0 12px;text-transform:uppercase;letter-spacing:.05em;opacity:.8}
.bb-form label{display:block;font-size:12px;opacity:.8;margin:9px 0 3px}
.bb-form input,.bb-form select,.bb-form textarea{width:100%;padding:8px 10px;border:1px solid var(--bb-border);border-radius:8px;background:rgba(0,0,0,.16);color:inherit;font:inherit}
.bb-form select{background:#f4f5f8;color:#1c1e24}
.bb-form select option{background:#fff;color:#1c1e24}
.bb-form .bb-when{display:none}
.bb-btn{display:inline-block;margin-top:12px;padding:11px 16px;border:0;border-radius:9px;background:var(--bb-btn-bg);color:var(--bb-btn-text);font-weight:800;cursor:pointer;text-transform:uppercase;letter-spacing:.03em}
.bb-btn--ghost{background:transparent;color:inherit;border:1px solid var(--bb-border);font-weight:600}
.bb-msg{margin:0 0 16px;padding:10px 13px;border-radius:9px;border:1px solid var(--bb-border);font-size:14px}
.bb-msg.is-bad{border-color:#9a3d3d;background:rgba(154,61,61,.14)}
.bb-msg.is-ok{border-color:#3f7d43;background:rgba(63,125,67,.14)}
.bb-list{display:grid;gap:12px}
.bb-b{border:1px solid var(--bb-border);border-radius:var(--bb-radius);background:var(--bb-surface);padding:14px}
.bb-b__top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
.bb-b__title{font-weight:800;font-size:16px}
.bb-b__stake{flex:0 0 auto;font-weight:900;color:var(--bb-accent);font-size:17px;font-variant-numeric:tabular-nums}
.bb-b__how{font-size:13px;opacity:.78;margin:6px 0}
.bb-b__meta{font-size:12px;opacity:.6}
.bb-b__note{font-size:13px;margin-top:6px;padding:8px 10px;border-left:2px solid var(--bb-accent);background:rgba(255,255,255,.03)}
.bb-bar{height:8px;border-radius:99px;background:rgba(255,255,255,.09);overflow:hidden;margin-top:8px;border:1px solid var(--bb-border)}
.bb-bar i{display:block;height:100%;background:var(--bb-accent)}
.bb-recent{list-style:none;padding:0;margin:8px 0 0;display:grid;gap:6px;font-size:13px}
.bb-recent li{padding:7px 10px;border-radius:7px;background:rgba(255,255,255,.04)}
.bb-recent b{color:var(--bb-accent)}
.bb-empty{opacity:.6;font-size:14px}
</style>

<div class="bb-page" <?= $style ?>>
	<h1><?= $h(bounty_board_t('bounty_board.title', 'Bounty Board')) ?></h1>
	<p class="bb-lead"><?= $h(bounty_board_t('bounty_board.lead', 'Stake shop points on a challenge. The first player to meet the condition is paid automatically.')) ?></p>

	<?php if ($flash !== null): ?>
		<p class="bb-msg <?= !empty($flash['ok']) ? 'is-ok' : 'is-bad' ?>"><?= $h($flash['message']) ?></p>
	<?php endif; ?>

	<div class="bb-grid">
		<div>
			<div class="bb-card">
				<h2><?= $h(bounty_board_t('bounty_board.post_h', 'Post a bounty')) ?></h2>
				<?php if ($accountId === 0): ?>
					<p class="bb-empty"><?= bounty_board_t('bounty_board.login_html', 'You need to <a href="login.php">log in</a> to post a bounty.') ?></p>
				<?php elseif (!$types): ?>
					<p class="bb-empty"><?= $h(bounty_board_t('bounty_board.no_types', 'No bounty types are enabled yet.')) ?></p>
				<?php else: ?>
					<form method="post" class="bb-form" id="bbForm">
						<?php if (class_exists('Token')) Token::create(); ?>
						<input type="hidden" name="do" value="post">
						<label><?= $h(bounty_board_t('bounty_board.f_type', 'Type')) ?></label>
						<select name="type" id="bbType">
							<?php foreach ($types as $k => $v): ?>
								<option value="<?= $h($k) ?>"><?= $h(bounty_board_t('bounty_board.type_' . $k, $v['label'])) ?></option>
							<?php endforeach; ?>
						</select>

						<div class="bb-when" data-type="pvp_kill">
							<label><?= $h(bounty_board_t('bounty_board.f_target', 'Target character')) ?></label>
							<input type="text" name="target_name" maxlength="64" autocomplete="off" placeholder="Xandros">
						</div>
						<div class="bb-when" data-type="reach_level">
							<label><?= $h(bounty_board_t('bounty_board.f_level', 'Level to reach')) ?></label>
							<input type="number" name="value" min="2" value="200">
							<label><?= $h(bounty_board_t('bounty_board.f_voc', 'Vocation (optional)')) ?></label>
							<select name="vocation"><option value="0"><?= $h(bounty_board_t('bounty_board.any_voc', 'Any')) ?></option><option value="1">Sorcerer</option><option value="2">Druid</option><option value="3">Paladin</option><option value="4">Knight</option></select>
						</div>
						<div class="bb-when" data-type="reach_skill">
							<label><?= $h(bounty_board_t('bounty_board.f_skill', 'Skill')) ?></label>
							<select name="skill"><?php foreach (array_keys(bounty_board_skills()) as $sk): ?><option value="<?= $h($sk) ?>"><?= $h(ucfirst($sk)) ?></option><?php endforeach; ?></select>
							<label><?= $h(bounty_board_t('bounty_board.f_skillval', 'Skill level to reach')) ?></label>
							<input type="number" name="value" min="1" value="120">
						</div>
						<div class="bb-when" data-type="bank_wealth">
							<label><?= $h(bounty_board_t('bounty_board.f_gold', 'Gold in the bank')) ?></label>
							<input type="number" name="value" min="1" value="10000000">
						</div>
						<div class="bb-when" data-type="guild_size">
							<label><?= $h(bounty_board_t('bounty_board.f_members', 'Guild members to reach')) ?></label>
							<input type="number" name="value" min="2" value="50">
						</div>
						<div class="bb-when" data-type="monster_kills">
							<label><?= $h(bounty_board_t('bounty_board.f_monster', 'Monster')) ?></label>
							<?php if ($monsters): ?>
								<select name="monster"><?php foreach ($monsters as $m): ?><option value="<?= $h($m['name']) ?>"><?= $h($m['label'] !== '' ? $m['label'] : ucwords((string) $m['name'])) ?></option><?php endforeach; ?></select>
							<?php else: ?>
								<p class="bb-empty"><?= $h(bounty_board_t('bounty_board.no_monsters', 'No monsters are whitelisted yet.')) ?></p>
							<?php endif; ?>
							<label><?= $h(bounty_board_t('bounty_board.f_kills', 'Kills to reach')) ?></label>
							<input type="number" name="value" min="1" value="500">
						</div>

						<label><?= $h(bounty_board_t('bounty_board.f_stake', 'Stake (shop points)')) ?> — <?= $h(bounty_board_t('bounty_board.you_have', 'you have {n}', array('n' => number_format($points)))) ?></label>
						<input type="number" name="stake" min="<?= (int) $minStake ?>" max="<?= (int) $maxStake ?>" value="<?= (int) $minStake ?>">
						<?php if ($fee > 0): ?><p class="bb-b__meta"><?= $h(bounty_board_t('bounty_board.fee_note', 'Listing fee: {n} points (non-refundable)', array('n' => $fee))) ?></p><?php endif; ?>

						<?php $maxWinners = bounty_board_int('max_winners', 5); if ($maxWinners > 1): ?>
							<label><?= $h(bounty_board_t('bounty_board.f_winners', 'Winners (stake is split equally)')) ?></label>
							<input type="number" name="winners" min="1" max="<?= (int) $maxWinners ?>" value="1">
						<?php endif; ?>

						<label><?= $h(bounty_board_t('bounty_board.f_days', 'Runs for (days)')) ?></label>
						<input type="number" name="days" min="1" max="<?= (int) $maxDays ?>" value="7">

						<label><?= $h(bounty_board_t('bounty_board.f_note', 'Note (optional)')) ?></label>
						<textarea name="note" rows="2" maxlength="500"></textarea>

						<button class="bb-btn" type="submit"><?= $h(bounty_board_t('bounty_board.post_btn', 'Post bounty')) ?></button>
					</form>
					<script>
					(function(){var t=document.getElementById('bbType'),f=document.getElementById('bbForm');
					function sync(){var v=t.value;f.querySelectorAll('.bb-when').forEach(function(d){d.style.display=d.getAttribute('data-type')===v?'block':'none';});}
					t.addEventListener('change',sync);sync();}());
					</script>
				<?php endif; ?>
			</div>

			<?php if ($mine): ?>
				<div class="bb-card" style="margin-top:16px">
					<h2><?= $h(bounty_board_t('bounty_board.mine_h', 'My bounties')) ?></h2>
					<div class="bb-list">
						<?php foreach ($mine as $b): ?>
							<div class="bb-b">
								<div class="bb-b__top"><span class="bb-b__title"><?= $h(bounty_board_title($b)) ?></span><span class="bb-b__stake"><?= number_format((int) $b['stake']) ?></span></div>
								<div class="bb-b__meta">
									<?= $h(bounty_board_t('bounty_board.status_' . $b['status'], ucfirst((string) $b['status']))) ?>
									<?php if ($b['status'] === 'claimed' && $b['claimed_by_name'] !== ''): ?> — <?= $h($b['claimed_by_name']) ?><?php endif; ?>
								</div>
								<?php if ($b['status'] === 'open'): ?>
									<form method="post" onsubmit="return confirm('<?= $h(bounty_board_t('bounty_board.cancel_confirm', 'Cancel this bounty and refund the stake?')) ?>')">
										<?php if (class_exists('Token')) Token::create(); ?>
										<input type="hidden" name="do" value="cancel"><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
										<button class="bb-btn bb-btn--ghost" type="submit" style="margin-top:8px;padding:7px 12px"><?= $h(bounty_board_t('bounty_board.cancel_btn', 'Cancel & refund')) ?></button>
									</form>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if (!empty($data['recent'])): ?>
				<div class="bb-card" style="margin-top:16px">
					<h2><?= $h(bounty_board_t('bounty_board.recent_h', 'Recently claimed')) ?></h2>
					<ul class="bb-recent">
						<?php foreach ($data['recent'] as $r): ?>
							<li><b><?= $h($r['winner']) ?></b> — <?= $h($r['title']) ?> <span style="opacity:.6">(<?= number_format((int) $r['stake']) ?>)</span></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		</div>

		<div>
			<div class="bb-card">
				<h2><?= $h(bounty_board_t('bounty_board.open_h', 'Open bounties')) ?></h2>
				<div class="bb-list" id="bbOpenList"<?= empty($data['open']) ? ' hidden' : '' ?>>
					<?php foreach ($data['open'] as $g):
						$left = $g['expires'] > 0 ? max(0, $g['expires'] - time()) : 0; ?>
						<div class="bb-b" data-id="<?= (int) $g['id'] ?>">
							<div class="bb-b__top">
								<span class="bb-b__title"><?= $h($g['title']) ?></span>
								<span class="bb-b__stake"><?= number_format((int) $g['stake']) ?><?= (int) $g['winners'] > 1 ? ' <small style="opacity:.6">×' . (int) $g['winners'] . '</small>' : '' ?></span>
							</div>
							<div class="bb-b__how"><?= $h($g['howto']) ?></div>
							<div class="bb-mk"<?= ($g['type'] === 'monster_kills' && $g['target'] > 0) ? '' : ' hidden' ?>>
								<div class="bb-bar"><i style="width:<?= (int) $g['pct'] ?>%"></i></div>
								<div class="bb-b__meta bb-mk-txt"><?= number_format((int) $g['progress']) ?> / <?= number_format((int) $g['target']) ?> (<?= (int) $g['pct'] ?>%)</div>
							</div>
							<?php if (trim((string) $g['note']) !== ''): ?><div class="bb-b__note"><?= $h($g['note']) ?></div><?php endif; ?>
							<div class="bb-b__meta" style="margin-top:6px"><?= $h(bounty_board_t('bounty_board.by', 'by {name}', array('name' => $g['poster']))) ?><?php if ($left > 0): ?> · <?= $h(bounty_board_rel_time($left)) ?><?php endif; ?></div>
						</div>
					<?php endforeach; ?>
				</div>
				<p class="bb-empty" id="bbOpenEmpty"<?= empty($data['open']) ? '' : ' hidden' ?>><?= $h(bounty_board_t('bounty_board.none', 'No open bounties right now.')) ?></p>
			</div>
		</div>
	</div>
</div>

<script>
window.BB = { poll: <?= (int) max(0, bounty_board_int('poll_seconds', 30)) ?>, claimed: <?= json_encode(bounty_board_t('bounty_board.claimed_flash', 'Claimed!')) ?> };
(function () {
	if (!window.BB.poll) return;
	var list = document.getElementById('bbOpenList'), empty = document.getElementById('bbOpenEmpty');
	function nf(n){ return (n||0).toLocaleString('en-US'); }
	function tick() {
		fetch('?plugin=bounty_board&p=board&bounty_board_progress=1', { credentials: 'same-origin' })
			.then(function (r) { return r.json(); }).then(function (d) {
				var open = (d && d.open) || [], by = {};
				open.forEach(function (g) { by[g.id] = g; });
				list.querySelectorAll('.bb-b').forEach(function (card) {
					var id = card.getAttribute('data-id'), g = by[id];
					if (!g) {
						if (card.dataset.gone) return;
						card.dataset.gone = '1';
						var s = card.querySelector('.bb-b__stake'); if (s) s.textContent = window.BB.claimed;
						card.style.transition = 'opacity .6s'; card.style.opacity = '.35';
						setTimeout(function () { card.remove(); if (!list.querySelector('.bb-b')) { list.hidden = true; empty.hidden = false; } }, 4000);
						return;
					}
					var bar = card.querySelector('.bb-bar i'), txt = card.querySelector('.bb-mk-txt');
					if (bar && g.type === 'monster_kills') {
						bar.style.width = Math.max(0, Math.min(100, g.pct)) + '%';
						if (txt) txt.textContent = nf(g.progress) + ' / ' + nf(g.target) + ' (' + g.pct + '%)';
					}
				});
			}).catch(function () {});
	}
	setInterval(tick, window.BB.poll * 1000);
}());
</script>
