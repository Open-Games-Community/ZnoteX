--[[  ZnoteX - Bounty Board : monster kill counter
      TFS 1.1+ and Nekiro 1.5 downgrades (revscriptsys).

      INSTALL
        1. Copy to  data/scripts/bounty_kill_counter.lua
        2. /reload scripts   (or restart)

      The tracked monster list is the ACP whitelist (table znote_bounty_monsters),
      re-read every RELOAD_MINUTES - you never edit this file to add a monster.
      Kills are buffered in memory and flushed once every FLUSH_SECONDS.
      Table znote_bounty_kill_log was created by the plugin on install.
]]--

local FLUSH_SECONDS  = 30
local RELOAD_MINUTES = 5

local tracked = {}
local buffer  = {}   -- buffer[playerGuid][monsterName] = count

local function reloadList()
	local t = {}
	local rid = db.storeQuery("SELECT `name` FROM `znote_bounty_monsters`")
	if rid ~= false then
		repeat
			t[result.getString(rid, "name"):lower()] = true
		until not result.next(rid)
		result.free(rid)
	end
	tracked = t
end

local function flush()
	local now = os.time()
	for guid, mobs in pairs(buffer) do
		for mob, n in pairs(mobs) do
			if n > 0 then
				db.asyncQuery("INSERT INTO `znote_bounty_kill_log` (`player_id`, `monster_key`, `kills`, `logged_at`) VALUES (" ..
					guid .. ", " .. db.escapeString(mob) .. ", " .. n .. ", " .. now .. ")")
			end
		end
	end
	buffer = {}
end

reloadList()

local kill = CreatureEvent("ZnoteBountyKill")
function kill.onKill(creature, target)
	if not target or not target:isMonster() or not creature:isPlayer() then
		return true
	end
	local mob = target:getName():lower()
	if not tracked[mob] then
		return true
	end
	local guid = creature:getGuid()
	if guid <= 0 then
		return true
	end
	buffer[guid] = buffer[guid] or {}
	buffer[guid][mob] = (buffer[guid][mob] or 0) + 1
	return true
end
kill:register()

local login = CreatureEvent("ZnoteBountyLogin")
function login.onLogin(player)
	player:registerEvent("ZnoteBountyKill")
	return true
end
login:register()

local flushEv = GlobalEvent("ZnoteBountyFlush")
function flushEv.onThink(interval)
	flush()
	return true
end
flushEv:interval(FLUSH_SECONDS * 1000)
flushEv:register()

local reloadEv = GlobalEvent("ZnoteBountyReload")
function reloadEv.onThink(interval)
	reloadList()
	return true
end
reloadEv:interval(RELOAD_MINUTES * 60 * 1000)
reloadEv:register()

local shutdownEv = GlobalEvent("ZnoteBountyShutdown")
function shutdownEv.onShutdown()
	flush()
	return true
end
shutdownEv:register()
