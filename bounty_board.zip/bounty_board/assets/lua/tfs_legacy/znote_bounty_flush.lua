--[[  ZnoteX - Bounty Board : buffer flush (globalevent)
      data/globalevents/scripts/znote_bounty_flush.lua  -  runs every 30 s.
]]--

function onThink(interval, lastExecution)
	if _ZNOTE_BOUNTY == nil then
		return true
	end
	local now = os.time()
	for guid, mobs in pairs(_ZNOTE_BOUNTY.buffer) do
		for mob, n in pairs(mobs) do
			if n > 0 then
				local q = "INSERT INTO `znote_bounty_kill_log` (`player_id`, `monster_key`, `kills`, `logged_at`) VALUES (" ..
					guid .. ", " .. db.escapeString(mob) .. ", " .. n .. ", " .. now .. ")"
				if db.executeQuery then
					db.executeQuery(q)
				else
					db.query(q)
				end
			end
		end
	end
	_ZNOTE_BOUNTY.buffer = {}
	return true
end
