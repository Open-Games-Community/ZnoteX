--[[  ZnoteX - Bounty Board : monster kill counter (creaturescript)
      TFS 0.3.6 / 0.4 / 1.0 and other XML-script forks.

      INSTALL
        1. Copy to  data/creaturescripts/scripts/znote_bounty.lua
        2. Copy znote_bounty_flush.lua to  data/globalevents/scripts/
        3. Add the lines from XML_lines.txt
        4. Restart

      The whitelist (ACP table znote_bounty_monsters) is re-read at most every
      5 minutes. Kills buffer in a shared table; the globalevent flushes every 30 s.
]]--

if _ZNOTE_BOUNTY == nil then
	_ZNOTE_BOUNTY = { tracked = {}, buffer = {}, loaded = 0 }
end

local function reloadList()
	local t = {}
	local res = db.getResult("SELECT `name` FROM `znote_bounty_monsters`")
	if res:getID() ~= -1 then
		repeat
			t[string.lower(res:getDataString("name"))] = true
		until not res:next()
		res:free()
	end
	_ZNOTE_BOUNTY.tracked = t
	_ZNOTE_BOUNTY.loaded = os.time()
end

function onKill(cid, target)
	if not isPlayer(cid) or not isMonster(target) then
		return true
	end
	if _ZNOTE_BOUNTY.loaded == 0 or (os.time() - _ZNOTE_BOUNTY.loaded) > 300 then
		reloadList()
	end
	local mob = string.lower(getCreatureName(target))
	if not _ZNOTE_BOUNTY.tracked[mob] then
		return true
	end
	local guid = getPlayerGUID(cid)
	if guid <= 0 then
		return true
	end
	local b = _ZNOTE_BOUNTY.buffer
	b[guid] = b[guid] or {}
	b[guid][mob] = (b[guid][mob] or 0) + 1
	return true
end

function onLogin(cid)
	registerCreatureEvent(cid, "ZnoteBountyKill")
	return true
end
