<?php
/**
 * Bounty Board - player bounties staked with shop points, paid automatically to
 * the first player who meets the condition. No proof, no manual approval.
 *
 * Types: pvp_kill, reach_level, reach_skill, bank_wealth, guild_size (all read
 * the game DB directly) and monster_kills (needs the downloadable buffered Lua
 * counter). Detector tables/columns are configurable with autodetection.
 * Escrow, refunds and the atomic claim use the `guard` column.
 */
if (!function_exists('bounty_board_setting')) {

function bounty_board_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('bounty_board:' . $key, $default) : $default;
}
function bounty_board_enabled(): bool { return bounty_board_setting('enabled', '1') === '1'; }
function bounty_board_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function bounty_board_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string) $v, $text);
	return $text;
}
function bounty_board_ident(string $v): string { $v = trim($v); return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : ''; }
function bounty_board_css_value(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function bounty_board_color(string $key): string { return bounty_board_css_value(bounty_board_setting('style_' . $key, '')); }
function bounty_board_int(string $key, int $default): int { $v = bounty_board_setting($key, ''); return $v === '' ? $default : (int) $v; }
function bounty_board_style_attr(): string {
	$map = array('box_bg' => '--bb-surface', 'border' => '--bb-border', 'text' => '--bb-text', 'accent' => '--bb-accent', 'button_bg' => '--bb-btn-bg', 'button_text' => '--bb-btn-text', 'title_bg' => '--bb-title-bg', 'title_text' => '--bb-title-text');
	$css = '';
	foreach ($map as $k => $var) { $v = bounty_board_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	$r = bounty_board_int('style_radius', 14);
	if ($r >= 0 && $r <= 40) $css .= '--bb-radius:' . $r . 'px;';
	return $css !== '' ? ' style="' . bounty_board_h($css) . '"' : '';
}
function bounty_board_asset_image(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$p = __DIR__ . '/assets/img/' . $file;
	return is_file($p) ? znote_plugin_asset('bounty_board', 'img/' . $file) : '';
}
function bounty_board_tables_ok(): bool {
	return function_exists('znote_table_exists') && znote_table_exists('znote_bounties');
}

// --- type metadata --------------------------------------------------
function bounty_board_types(): array {
	return array(
		'pvp_kill'      => array('label' => 'Kill a player',            'script' => false),
		'reach_level'   => array('label' => 'First to reach a level',   'script' => false),
		'reach_skill'   => array('label' => 'First to reach a skill',   'script' => false),
		'bank_wealth'   => array('label' => 'First to a bank balance',  'script' => false),
		'guild_size'    => array('label' => 'First guild to N members', 'script' => false),
		'monster_kills' => array('label' => 'First to N monster kills', 'script' => true),
	);
}
function bounty_board_type_enabled(string $t): bool {
	if (!isset(bounty_board_types()[$t])) return false;
	return bounty_board_setting('type_' . $t, $t === 'monster_kills' ? '0' : '1') === '1';
}
function bounty_board_distros(): array {
	return array(
		'tfs_revscript' => 'TFS 1.1+ / Nekiro 1.5 (revscriptsys)',
		'canary'        => 'Canary / otservbr-global',
		'tfs_legacy'    => 'TFS 0.3.6 / 0.4 / 1.0 (XML scripts)',
	);
}
function bounty_board_vocation_ids(int $f): array {
	$m = array(1 => array(1, 5, 9), 2 => array(2, 6, 10), 3 => array(3, 7, 11), 4 => array(4, 8, 12));
	return $m[$f] ?? array();
}
function bounty_board_vocation_label(int $f): string {
	$m = array(1 => 'Sorcerer', 2 => 'Druid', 3 => 'Paladin', 4 => 'Knight');
	return $m[$f] ?? '';
}
function bounty_board_skills(): array {
	return array('magic' => 'maglevel', 'fist' => 'skill_fist', 'club' => 'skill_club', 'sword' => 'skill_sword', 'axe' => 'skill_axe', 'distance' => 'skill_dist', 'shielding' => 'skill_shielding', 'fishing' => 'skill_fishing');
}
function bounty_board_skill_id(string $key): int {
	$m = array('fist' => 0, 'club' => 1, 'sword' => 2, 'axe' => 3, 'distance' => 4, 'shielding' => 5, 'fishing' => 6);
	return $m[$key] ?? -1;
}

// --- detector table / column resolution --------------------------
function bounty_board_tbl(string $key, string $default): string {
	return bounty_board_ident(bounty_board_setting($key, '')) ?: $default;
}
function bounty_board_col(string $table, string $setting, array $candidates): string {
	$o = bounty_board_ident(bounty_board_setting($setting, ''));
	if ($o !== '') return $o;
	foreach ($candidates as $c) if (function_exists('znote_column_exists') && znote_column_exists($table, $c)) return $c;
	return $candidates[0] ?? '';
}

// --- player lookups ---------------------------------------------
function bounty_board_player_by(string $by, $val): ?array {
	static $cache = array();
	$ck = $by . ':' . $val;
	if (isset($cache[$ck])) return $cache[$ck];
	$pt = bounty_board_tbl('players_table', 'players');
	if (!function_exists('znote_table_exists') || !znote_table_exists($pt)) return $cache[$ck] = null;
	$nc = bounty_board_col($pt, 'players_name_col', array('name'));
	$ic = bounty_board_col($pt, 'players_id_col', array('id'));
	$ac = bounty_board_col($pt, 'players_acc_col', array('account_id'));
	$w = $by === 'id' ? "`{$ic}` = " . (int) $val : "`{$nc}` = '" . mysql_znote_escape_string((string) $val) . "'";
	$row = mysql_select_single("SELECT `{$ic}` AS id, `{$nc}` AS name, `{$ac}` AS account_id FROM `{$pt}` WHERE {$w} LIMIT 1;");
	return $cache[$ck] = is_array($row) ? array('id' => (int) $row['id'], 'name' => (string) $row['name'], 'account_id' => (int) $row['account_id']) : null;
}
function bounty_board_account_age_ok(int $accountId, int $postedAt): bool {
	if ($accountId <= 0) return false;
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_accounts')) return true;
	$row = mysql_select_single("SELECT `created` FROM `znote_accounts` WHERE `account_id` = {$accountId} LIMIT 1;");
	if (!is_array($row) || (int) $row['created'] <= 0) return true;
	return (int) $row['created'] < $postedAt;
}
function bounty_board_validate_winner(array $b, array $w): bool {
	$acc = (int) ($w['account_id'] ?? 0);
	if ($acc <= 0) return false;
	if ($acc === (int) $b['poster_account_id'] && bounty_board_setting('allow_self', '0') !== '1') return false;
	if (isset($w['target_account']) && $acc === (int) $w['target_account']) return false;
	if (!bounty_board_account_age_ok($acc, (int) $b['posted_at'])) return false;
	return true;
}

// --- goals / bounties read ------------------------------------
function bounty_board_get(int $id): ?array {
	if ($id <= 0 || !bounty_board_tables_ok()) return null;
	$row = mysql_select_single("SELECT * FROM `znote_bounties` WHERE `id` = {$id} LIMIT 1;");
	return is_array($row) ? $row : null;
}
function bounty_board_list(string $status = 'open', int $limit = 60): array {
	if (!bounty_board_tables_ok()) return array();
	$limit = max(1, min(200, $limit));
	$s = mysql_znote_escape_string($status);
	$rows = mysql_select_multi("SELECT * FROM `znote_bounties` WHERE `status` = '{$s}' ORDER BY `stake` DESC, `id` DESC LIMIT {$limit};");
	return is_array($rows) ? $rows : array();
}
function bounty_board_by_poster(int $accountId): array {
	if ($accountId <= 0 || !bounty_board_tables_ok()) return array();
	$rows = mysql_select_multi("SELECT * FROM `znote_bounties` WHERE `poster_account_id` = {$accountId} ORDER BY `id` DESC LIMIT 40;");
	return is_array($rows) ? $rows : array();
}
function bounty_board_active_count(int $accountId): int {
	if ($accountId <= 0 || !bounty_board_tables_ok()) return 0;
	$row = mysql_select_single("SELECT COUNT(*) AS c FROM `znote_bounties` WHERE `poster_account_id` = {$accountId} AND `status` = 'open';");
	return is_array($row) ? (int) $row['c'] : 0;
}
function bounty_board_last_post(int $accountId): int {
	if ($accountId <= 0 || !bounty_board_tables_ok()) return 0;
	$row = mysql_select_single("SELECT MAX(`created_at`) AS m FROM `znote_bounties` WHERE `poster_account_id` = {$accountId};");
	return is_array($row) ? (int) $row['m'] : 0;
}
function bounty_board_log(int $bountyId, string $event, int $accountId, string $detail): void {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_bounty_log')) return;
	mysql_insert("INSERT INTO `znote_bounty_log` (`bounty_id`,`event`,`account_id`,`detail`,`created_at`) VALUES ({$bountyId},'" . mysql_znote_escape_string($event) . "',{$accountId},'" . mysql_znote_escape_string(substr($detail, 0, 200)) . "'," . time() . ");");
}
function bounty_board_monsters(): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_bounty_monsters')) return array();
	$rows = mysql_select_multi("SELECT `name`,`label` FROM `znote_bounty_monsters` ORDER BY `label` ASC, `name` ASC;");
	return is_array($rows) ? $rows : array();
}

// --- titles ---------------------------------------------------
function bounty_board_title(array $b): string {
	if (trim((string) $b['title']) !== '') return (string) $b['title'];
	$n = (int) $b['target_value'];
	switch ((string) $b['type']) {
		case 'pvp_kill':      return bounty_board_t('bounty_board.ttl_pvp', 'Kill {name}', array('name' => $b['target_name']));
		case 'reach_level':   $v = bounty_board_vocation_label((int) $b['vocation_filter']); return bounty_board_t('bounty_board.ttl_level', 'First to level {n}', array('n' => $n)) . ($v !== '' ? ' (' . $v . ')' : '');
		case 'reach_skill':   return bounty_board_t('bounty_board.ttl_skill', 'First to {skill} {n}', array('skill' => ucfirst((string) $b['target_name']), 'n' => $n));
		case 'bank_wealth':   return bounty_board_t('bounty_board.ttl_wealth', 'First to {n} gold banked', array('n' => number_format($n)));
		case 'guild_size':    return bounty_board_t('bounty_board.ttl_guild', 'First guild to {n} members', array('n' => $n));
		case 'monster_kills': return bounty_board_t('bounty_board.ttl_monster', 'First to {n} {name} kills', array('n' => number_format($n), 'name' => $b['target_name']));
	}
	return (string) $b['type'];
}
function bounty_board_howto(array $b): string {
	switch ((string) $b['type']) {
		case 'pvp_kill':      return bounty_board_t('bounty_board.how_pvp', 'Be the player who kills {name} after this bounty was posted.', array('name' => $b['target_name']));
		case 'reach_level':   return bounty_board_t('bounty_board.how_level', 'Be the first character to reach level {n} and log in.', array('n' => (int) $b['target_value']));
		case 'reach_skill':   return bounty_board_t('bounty_board.how_skill', 'Be the first character to reach {skill} level {n}.', array('skill' => (string) $b['target_name'], 'n' => (int) $b['target_value']));
		case 'bank_wealth':   return bounty_board_t('bounty_board.how_wealth', 'Be the first character with {n} gold in the bank.', array('n' => number_format((int) $b['target_value'])));
		case 'guild_size':    return bounty_board_t('bounty_board.how_guild', "Be the first guild to reach {n} members - the guild leader is paid.", array('n' => (int) $b['target_value']));
		case 'monster_kills': return bounty_board_t('bounty_board.how_monster', 'Be the first to kill {n} {name} after this bounty was posted.', array('n' => number_format((int) $b['target_value']), 'name' => $b['target_name']));
	}
	return '';
}

// --- detectors -------------------------------------------------------
// Each returns a list of validated winner arrays (deduped by account_id,
// excluding $skip account ids), earliest-qualifying first, up to $need.
function bounty_board_detect(array $b, array $skip = array(), int $need = 1): array {
	$need = max(1, $need);
	try {
		switch ((string) $b['type']) {
			case 'pvp_kill':      return bounty_board_detect_pvp($b, $skip, $need);
			case 'reach_level':   return bounty_board_detect_players($b, 'level', $skip, $need);
			case 'reach_skill':   return bounty_board_detect_skill($b, $skip, $need);
			case 'bank_wealth':   return bounty_board_detect_players($b, 'balance', $skip, $need);
			case 'guild_size':    return bounty_board_detect_guild($b, $skip, $need);
			case 'monster_kills': return bounty_board_detect_monster($b, $skip, $need);
		}
	} catch (Throwable $e) {
		error_log('[bounty_board] detector ' . ($b['type'] ?? '?') . ' failed: ' . $e->getMessage());
	}
	return array();
}
function bounty_board_collect(array $b, $rows, array $skip, int $need, array $extra = array()): array {
	$out = array(); $seen = array();
	foreach ($skip as $s) $seen[(int) $s] = true;
	foreach ((array) $rows as $r) {
		$w = array_merge($extra, is_array($r) ? $r : array());
		$acc = (int) ($w['account_id'] ?? 0);
		if ($acc <= 0 || isset($seen[$acc])) continue;
		if (!bounty_board_validate_winner($b, $w)) continue;
		$seen[$acc] = true;
		$out[] = $w;
		if (count($out) >= $need) break;
	}
	return $out;
}
function bounty_board_detect_pvp(array $b, array $skip, int $need): array {
	$dt = bounty_board_tbl('deaths_table', 'player_deaths');
	if (!function_exists('znote_table_exists') || !znote_table_exists($dt)) return array();
	$pc = bounty_board_col($dt, 'deaths_player_col', array('player_id'));
	$tc = bounty_board_col($dt, 'deaths_time_col', array('time', 'date'));
	$kc = bounty_board_col($dt, 'deaths_killedby_col', array('killed_by'));
	$ip = bounty_board_col($dt, 'deaths_isplayer_col', array('is_player'));
	$target = bounty_board_player_by('name', $b['target_name']);
	if (!$target) return array();
	$w = "`{$pc}` = " . $target['id'] . " AND `{$tc}` > " . (int) $b['posted_at'] . " AND `{$ip}` = 1";
	if (bounty_board_setting('unjustified_only', '0') === '1') {
		$uj = bounty_board_col($dt, 'deaths_unjust_col', array('unjustified'));
		if ($uj !== '') $w .= " AND `{$uj}` = 1";
	}
	$rows = mysql_select_multi("SELECT `{$kc}` AS killer, `{$tc}` AS t FROM `{$dt}` WHERE {$w} ORDER BY `{$tc}` ASC LIMIT 25;");
	$cand = array();
	foreach ((array) $rows as $r) {
		$killer = bounty_board_player_by('name', (string) $r['killer']);
		if ($killer) $cand[] = array('account_id' => $killer['account_id'], 'name' => $killer['name'], 'at' => (int) $r['t']);
	}
	return bounty_board_collect($b, $cand, $skip, $need, array('target_account' => $target['account_id']));
}
function bounty_board_detect_players(array $b, string $kind, array $skip, int $need): array {
	$pt = bounty_board_tbl('players_table', 'players');
	if (!function_exists('znote_table_exists') || !znote_table_exists($pt)) return array();
	$nc = bounty_board_col($pt, 'players_name_col', array('name'));
	$ac = bounty_board_col($pt, 'players_acc_col', array('account_id'));
	$llc = bounty_board_col($pt, 'players_lastlogin_col', array('lastlogin'));
	$col = $kind === 'balance' ? bounty_board_col($pt, 'players_balance_col', array('balance')) : bounty_board_col($pt, 'players_level_col', array('level'));
	if ($col === '') return array();
	$w = "`{$col}` >= " . (int) $b['target_value'] . " AND `{$llc}` > " . (int) $b['posted_at'];
	if ($kind === 'level' && (int) $b['vocation_filter'] > 0) {
		$vc = bounty_board_col($pt, 'players_voc_col', array('vocation'));
		$ids = bounty_board_vocation_ids((int) $b['vocation_filter']);
		if ($vc !== '' && $ids) $w .= " AND `{$vc}` IN (" . implode(',', array_map('intval', $ids)) . ")";
	}
	$rows = mysql_select_multi("SELECT `{$nc}` AS name, `{$ac}` AS account_id FROM `{$pt}` WHERE {$w} ORDER BY `{$llc}` ASC LIMIT 25;");
	foreach ((array) $rows as &$r) $r['at'] = time();
	return bounty_board_collect($b, $rows, $skip, $need);
}
function bounty_board_detect_skill(array $b, array $skip, int $need): array {
	$pt = bounty_board_tbl('players_table', 'players');
	if (!function_exists('znote_table_exists') || !znote_table_exists($pt)) return array();
	$key = (string) $b['target_name'];
	$nc = bounty_board_col($pt, 'players_name_col', array('name'));
	$ac = bounty_board_col($pt, 'players_acc_col', array('account_id'));
	$ic = bounty_board_col($pt, 'players_id_col', array('id'));
	$llc = bounty_board_col($pt, 'players_lastlogin_col', array('lastlogin'));
	$scol = bounty_board_skills()[$key] ?? '';
	if ($scol !== '' && function_exists('znote_column_exists') && znote_column_exists($pt, $scol)) {
		$rows = mysql_select_multi("SELECT `{$nc}` AS name, `{$ac}` AS account_id FROM `{$pt}` WHERE `{$scol}` >= " . (int) $b['target_value'] . " AND `{$llc}` > " . (int) $b['posted_at'] . " ORDER BY `{$llc}` ASC LIMIT 25;");
	} else {
		$st = bounty_board_tbl('player_skills_table', 'player_skills');
		$sid = bounty_board_skill_id($key);
		if ($sid < 0 || !znote_table_exists($st)) return array();
		$rows = mysql_select_multi("SELECT p.`{$nc}` AS name, p.`{$ac}` AS account_id FROM `{$st}` s JOIN `{$pt}` p ON p.`{$ic}` = s.`player_id` WHERE s.`skillid` = {$sid} AND s.`value` >= " . (int) $b['target_value'] . " AND p.`{$llc}` > " . (int) $b['posted_at'] . " ORDER BY p.`{$llc}` ASC LIMIT 25;");
	}
	foreach ((array) $rows as &$r) $r['at'] = time();
	return bounty_board_collect($b, $rows, $skip, $need);
}
function bounty_board_detect_guild(array $b, array $skip, int $need): array {
	$gm = bounty_board_tbl('guild_membership_table', 'guild_membership');
	$gt = bounty_board_tbl('guilds_table', 'guilds');
	if (!function_exists('znote_table_exists') || !znote_table_exists($gm) || !znote_table_exists($gt)) return array();
	$gc = bounty_board_col($gm, 'guild_membership_guild_col', array('guild_id'));
	$oc = bounty_board_col($gt, 'guilds_owner_col', array('ownerid'));
	$idc = bounty_board_col($gt, 'guilds_id_col', array('id'));
	$gnc = bounty_board_col($gt, 'guilds_name_col', array('name'));
	$rows = mysql_select_multi("SELECT `{$gc}` AS gid, COUNT(*) AS c FROM `{$gm}` GROUP BY `{$gc}` HAVING c >= " . (int) $b['target_value'] . " ORDER BY c DESC LIMIT 10;");
	$cand = array();
	foreach ((array) $rows as $r) {
		$g = mysql_select_single("SELECT `{$oc}` AS owner, `{$gnc}` AS gname FROM `{$gt}` WHERE `{$idc}` = " . (int) $r['gid'] . " LIMIT 1;");
		if (!is_array($g)) continue;
		$owner = bounty_board_player_by('id', (int) $g['owner']);
		if ($owner) $cand[] = array('account_id' => $owner['account_id'], 'name' => $owner['name'], 'at' => time(), 'guild' => (string) $g['gname']);
	}
	return bounty_board_collect($b, $cand, $skip, $need);
}
function bounty_board_detect_monster(array $b, array $skip, int $need): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_bounty_kill_log')) return array();
	$key = mysql_znote_escape_string((string) $b['target_name']);
	$rows = mysql_select_multi("SELECT `player_id` AS pid, SUM(`kills`) AS k, MAX(`logged_at`) AS m FROM `znote_bounty_kill_log` WHERE `monster_key` = '{$key}' AND `logged_at` > " . (int) $b['posted_at'] . " GROUP BY `player_id` HAVING k >= " . (int) $b['target_value'] . " ORDER BY m ASC LIMIT 25;");
	$cand = array();
	foreach ((array) $rows as $r) {
		$p = bounty_board_player_by('id', (int) $r['pid']);
		if ($p) $cand[] = array('account_id' => $p['account_id'], 'name' => $p['name'], 'at' => (int) $r['m']);
	}
	return bounty_board_collect($b, $cand, $skip, $need);
}
function bounty_board_progress(array $b): int {
	switch ((string) $b['type']) {
		case 'monster_kills':
			$key = mysql_znote_escape_string((string) $b['target_name']);
			$row = mysql_select_single("SELECT MAX(k) AS v FROM (SELECT SUM(`kills`) AS k FROM `znote_bounty_kill_log` WHERE `monster_key` = '{$key}' AND `logged_at` > " . (int) $b['posted_at'] . " GROUP BY `player_id`) x;");
			return is_array($row) ? max(0, (int) $row['v']) : 0;
	}
	return 0;
}

// --- money + the guarded resolve --------------------------------------
function bounty_board_pay(int $accountId, int $points): void {
	if ($accountId > 0 && $points > 0) mysql_update("UPDATE `znote_accounts` SET `points` = COALESCE(`points`,0) + {$points} WHERE `account_id` = {$accountId};");
}
function bounty_board_charge(int $accountId, int $points): bool {
	if ($accountId <= 0 || $points <= 0) return true;
	if (bounty_board_points($accountId) < $points) return false;
	mysql_update("UPDATE `znote_accounts` SET `points` = `points` - {$points} WHERE `account_id` = {$accountId} AND `points` >= {$points};");
	return true;
}
/**
 * Serialize everything that touches one bounty across requests. GET_LOCK is a
 * connection-scoped named lock; it auto-releases if the connection drops.
 * Returns true only if the lock was acquired (0 = someone else has it).
 */
function bounty_board_lock(int $id): bool {
	$row = mysql_select_single("SELECT GET_LOCK('znx_bounty_" . (int) $id . "', 2) AS l;");
	return is_array($row) && (int) $row['l'] === 1;
}
function bounty_board_unlock(int $id): void {
	mysql_select_single("SELECT RELEASE_LOCK('znx_bounty_" . (int) $id . "');");
}
function bounty_board_claims(int $id): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_bounty_claims')) return array();
	$rows = mysql_select_multi("SELECT `account_id`,`character_name`,`amount`,`paid` FROM `znote_bounty_claims` WHERE `bounty_id` = " . (int) $id . ";");
	return is_array($rows) ? $rows : array();
}
function bounty_board_claims_sum(int $id): int {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_bounty_claims')) return 0;
	$row = mysql_select_single("SELECT COALESCE(SUM(`amount`),0) AS s, COUNT(*) AS c FROM `znote_bounty_claims` WHERE `bounty_id` = " . (int) $id . ";");
	return is_array($row) ? (int) $row['s'] : 0;
}
function bounty_board_close(int $id, string $status, int $now): void {
	mysql_update("UPDATE `znote_bounties` SET `status` = '" . mysql_znote_escape_string($status) . "', `claimed_at` = {$now}, `updated_at` = {$now} WHERE `id` = {$id} AND `status` = 'open';");
}
/**
 * Find and pay any new winners for one open bounty. Money-safe:
 *  - GET_LOCK serializes concurrent resolves of the same bounty,
 *  - UNIQUE(bounty_id, account_id) means an account is inserted (and paid) at most once,
 *  - every payout is min(share, pool - already-reserved), so total payout <= stake.
 */
function bounty_board_resolve(array $b): void {
	$id = (int) $b['id'];
	if ((string) $b['status'] !== 'open') return;
	if (!bounty_board_lock($id)) return;
	try {
		$fresh = bounty_board_get($id);
		if (!$fresh || $fresh['status'] !== 'open') return;
		$b = $fresh;
		$now = time();
		$stake   = max(0, (int) $b['stake']);
		$winners = max(1, (int) ($b['winners'] ?? 1));
		$share   = $winners > 0 ? max(1, intdiv($stake, $winners)) : $stake;

		if ((int) $b['expires_at'] > 0 && (int) $b['expires_at'] < $now) {
			$paid = bounty_board_claims_sum($id);
			$refund = max(0, $stake - $paid);
			if ($refund > 0) { bounty_board_pay((int) $b['poster_account_id'], $refund); bounty_board_log($id, 'refunded', (int) $b['poster_account_id'], (string) $refund); }
			bounty_board_close($id, 'expired', $now);
			bounty_board_log($id, 'expired', 0, '');
			return;
		}

		$claimed = array(); $lastName = ''; $lastAcc = 0;
		foreach (bounty_board_claims($id) as $c) { $claimed[(int) $c['account_id']] = true; $lastName = (string) $c['character_name']; $lastAcc = (int) $c['account_id']; }
		$reserved = bounty_board_claims_sum($id);
		$slots = $winners - count($claimed);
		if ($slots <= 0 || $stake - $reserved <= 0) {
			bounty_board_close($id, 'claimed', $now);
			return;
		}

		$found = bounty_board_detect($b, array_keys($claimed), $slots);
		foreach ($found as $w) {
			$remaining = $stake - bounty_board_claims_sum($id);
			if ($remaining <= 0) break;
			$acc = (int) $w['account_id'];
			$amount = max(0, min($share, $remaining));
			// Last slot gets whatever is left, so the pool is fully spent and never over-spent.
			if (count(bounty_board_claims($id)) + 1 >= $winners) $amount = $remaining;
			if ($amount <= 0) break;
			$ins = mysql_insert("INSERT INTO `znote_bounty_claims` (`bounty_id`,`account_id`,`character_name`,`amount`,`paid`,`claimed_at`) VALUES ({$id},{$acc},'" . mysql_znote_escape_string((string) $w['name']) . "',{$amount},0,{$now});");
			if ($ins === false) continue; // UNIQUE key: this account already has a claim row
			bounty_board_pay($acc, $amount);
			mysql_update("UPDATE `znote_bounty_claims` SET `paid` = 1 WHERE `bounty_id` = {$id} AND `account_id` = {$acc};");
			bounty_board_log($id, 'claimed', $acc, $w['name'] . ' (+' . $amount . ')');
			if (function_exists('znote_hook')) znote_hook('bounty.claimed', array('bounty_id' => $id, 'type' => (string) $b['type'], 'winner' => $w['name'], 'winner_account' => $acc, 'amount' => $amount));
			$lastName = (string) $w['name']; $lastAcc = $acc;
		}

		$total = count(bounty_board_claims($id));
		if ($total > 0) {
			mysql_update("UPDATE `znote_bounties` SET `claimed_by_account` = {$lastAcc}, `claimed_by_name` = '" . mysql_znote_escape_string($lastName) . "', `updated_at` = {$now} WHERE `id` = {$id};");
		}
		if ($total >= $winners || $stake - bounty_board_claims_sum($id) <= 0) {
			bounty_board_close($id, 'claimed', $now);
		}
	} catch (Throwable $e) {
		error_log('[bounty_board] resolve #' . $id . ' failed: ' . $e->getMessage());
	} finally {
		bounty_board_unlock($id);
	}
}
function bounty_board_cancel(int $id, int $byAccount): array {
	$b = bounty_board_get($id);
	if (!$b) return array('ok' => false, 'message' => bounty_board_t('bounty_board.err_notfound', 'Bounty not found.'));
	if ((int) $b['poster_account_id'] !== $byAccount) return array('ok' => false, 'message' => bounty_board_t('bounty_board.err_notyours', 'Not your bounty.'));
	if ($b['status'] !== 'open') return array('ok' => false, 'message' => bounty_board_t('bounty_board.err_notopen', 'This bounty is no longer open.'));
	if (!bounty_board_lock($id)) return array('ok' => false, 'message' => bounty_board_t('bounty_board.err_race', 'Could not cancel, reload the page.'));
	try {
		$fresh = bounty_board_get($id);
		if (!$fresh || $fresh['status'] !== 'open') return array('ok' => false, 'message' => bounty_board_t('bounty_board.err_notopen', 'This bounty is no longer open.'));
		$now = time();
		$refund = max(0, (int) $fresh['stake'] - bounty_board_claims_sum($id));
		bounty_board_close($id, 'cancelled', $now);
		if ($refund > 0) { bounty_board_pay($byAccount, $refund); bounty_board_log($id, 'refunded', $byAccount, (string) $refund); }
		bounty_board_log($id, 'cancelled', $byAccount, '');
		bounty_board_clear_cache();
		return array('ok' => true, 'message' => bounty_board_t('bounty_board.cancelled_ok', 'Bounty cancelled, {n} points refunded.', array('n' => $refund)));
	} finally {
		bounty_board_unlock($id);
	}
}
function bounty_board_ensure_schema(): void {
	static $done = false;
	if ($done) return;
	$done = true;
	if (!function_exists('setting')) return;

	if (setting('bounty_board:schema_v', '') !== '2') {
		if (function_exists('znote_table_exists') && znote_table_exists('znote_bounties')
			&& function_exists('znote_column_exists') && !znote_column_exists('znote_bounties', 'winners')) {
			mysql_update("ALTER TABLE `znote_bounties` ADD COLUMN `winners` int NOT NULL DEFAULT 1 AFTER `stake`;");
		}
		if (function_exists('znote_table_exists') && !znote_table_exists('znote_bounty_claims')) {
			mysql_update("CREATE TABLE IF NOT EXISTS `znote_bounty_claims` (`bounty_id` int NOT NULL,`account_id` int NOT NULL,`character_name` varchar(64) NOT NULL DEFAULT '',`amount` int NOT NULL DEFAULT 0,`paid` tinyint NOT NULL DEFAULT 0,`claimed_at` int NOT NULL DEFAULT 0,PRIMARY KEY (`bounty_id`,`account_id`),KEY `bounty` (`bounty_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
		}
		if (function_exists('setting_set')) setting_set('bounty_board:schema_v', '2');
	}

	$state = 'v4:' . (bounty_board_enabled() ? '1' : '0') . (bounty_board_setting('show_in_menu', '1') === '1' ? '1' : '0');
	if (setting('bounty_board:menu_v', '') !== $state) {
		bounty_board_sync_menu();
		if (function_exists('setting_set')) setting_set('bounty_board:menu_v', $state);
	}
}

function bounty_board_sync_menu(): void {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_menu')) return;
	mysql_delete("DELETE FROM `znote_menu` WHERE `url` = 'page.php?plugin=bounty_board&p=board';");
	if (bounty_board_enabled() && bounty_board_setting('show_in_menu', '1') === '1') {
		bounty_board_insert_menu();
	}
}

function bounty_board_insert_menu(): void {
	$p = mysql_select_single("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` LIKE '%communit%' ORDER BY `id` ASC LIMIT 1;");
	$parent = is_array($p) ? (int) $p['id'] : 0;
	if ($parent > 0) {
		$mx = mysql_select_single("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = {$parent};");
		$so = is_array($mx) ? (int) $mx['s'] + 1 : 1;
	} else {
		$g = mysql_select_single("SELECT `sort_order` FROM `znote_menu` WHERE `location` = 'main' AND `url` LIKE '%guild%' ORDER BY `sort_order` ASC LIMIT 1;");
		$so = is_array($g) ? (int) $g['sort_order'] + 3 : 57;
	}
	$raw = trim(bounty_board_setting('panel_title', ''));
	if ($raw === '') $raw = 'Bounty Board';
	$label = function_exists('mysql_znote_escape_string') ? mysql_znote_escape_string($raw) : preg_replace('/[^A-Za-z0-9 _\-]/', '', $raw);
	mysql_insert("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',{$parent},'{$label}','page.php?plugin=bounty_board&p=board','fa-scroll','all',{$so},1);");
}

// --- posting -------------------------------------------------
function bounty_board_points(int $accountId): int {
	if ($accountId <= 0) return 0;
	$row = mysql_select_single("SELECT `points` FROM `znote_accounts` WHERE `account_id` = {$accountId} LIMIT 1;");
	return is_array($row) ? max(0, (int) $row['points']) : 0;
}
function bounty_board_post(int $accountId, string $posterName, array $in): array {
	$fail = static fn(string $m) => array('ok' => false, 'message' => $m);
	if (!bounty_board_enabled() || !bounty_board_tables_ok()) return $fail(bounty_board_t('bounty_board.err_disabled', 'The bounty board is disabled.'));
	if ($accountId <= 0) return $fail(bounty_board_t('bounty_board.err_login', 'Log in to post a bounty.'));

	bounty_board_ensure_schema();

	$type = (string) ($in['type'] ?? '');
	if (!bounty_board_type_enabled($type)) return $fail(bounty_board_t('bounty_board.err_type', 'That bounty type is not available.'));

	$stake = max(0, (int) ($in['stake'] ?? 0));
	$min = bounty_board_int('min_stake', 50);
	$max = bounty_board_int('max_stake', 100000);
	if ($stake < $min) return $fail(bounty_board_t('bounty_board.err_minstake', 'Minimum stake is {n} points.', array('n' => $min)));
	if ($stake > $max) return $fail(bounty_board_t('bounty_board.err_maxstake', 'Maximum stake is {n} points.', array('n' => $max)));

	$fee = max(0, bounty_board_int('listing_fee', 0));
	$total = $stake + $fee;
	if (bounty_board_points($accountId) < $total) return $fail(bounty_board_t('bounty_board.err_broke', 'You need {n} points (stake + fee).', array('n' => $total)));

	$maxActive = bounty_board_int('max_active', 3);
	if (bounty_board_active_count($accountId) >= $maxActive) return $fail(bounty_board_t('bounty_board.err_toomany', 'You already have {n} open bounties.', array('n' => $maxActive)));

	$cooldown = bounty_board_int('cooldown', 0);
	if ($cooldown > 0 && bounty_board_last_post($accountId) + $cooldown > time()) return $fail(bounty_board_t('bounty_board.err_cooldown', 'Please wait before posting another bounty.'));

	$days = max(1, min(bounty_board_int('max_days', 30), (int) ($in['days'] ?? 7)));
	$winners = max(1, min(bounty_board_int('max_winners', 5), (int) ($in['winners'] ?? 1)));
	if ($stake < $winners) return $fail(bounty_board_t('bounty_board.err_winners', 'Stake must be at least {n} (1 point per winner).', array('n' => $winners)));

	$tv = 0; $tn = ''; $voc = 0;

	if ($type === 'pvp_kill') {
		$p = bounty_board_player_by('name', trim((string) ($in['target_name'] ?? '')));
		if (!$p) return $fail(bounty_board_t('bounty_board.err_nochar', 'No character with that name.'));
		if ((int) $p['account_id'] === $accountId && bounty_board_setting('allow_self', '0') !== '1') return $fail(bounty_board_t('bounty_board.err_selftarget', 'You cannot target your own character.'));
		$tn = $p['name'];
	} elseif ($type === 'reach_level') {
		$tv = max(2, min(100000, (int) ($in['value'] ?? 0)));
		$voc = in_array((int) ($in['vocation'] ?? 0), array(0, 1, 2, 3, 4), true) ? (int) $in['vocation'] : 0;
	} elseif ($type === 'reach_skill') {
		$tn = array_key_exists((string) ($in['skill'] ?? ''), bounty_board_skills()) ? (string) $in['skill'] : '';
		$tv = max(1, min(10000, (int) ($in['value'] ?? 0)));
		if ($tn === '') return $fail(bounty_board_t('bounty_board.err_skill', 'Pick a skill.'));
	} elseif ($type === 'bank_wealth') {
		$tv = max(1, min(999999999999, (int) ($in['value'] ?? 0)));
	} elseif ($type === 'guild_size') {
		$tv = max(2, min(100000, (int) ($in['value'] ?? 0)));
	} elseif ($type === 'monster_kills') {
		$names = array();
		foreach (bounty_board_monsters() as $m) $names[strtolower((string) $m['name'])] = true;
		if (!$names) return $fail(bounty_board_t('bounty_board.err_nomonsters', 'No monsters are whitelisted yet.'));
		$tn = strtolower(trim((string) ($in['monster'] ?? '')));
		if (!isset($names[$tn])) return $fail(bounty_board_t('bounty_board.err_monster', 'Pick a monster from the list.'));
		$tv = max(1, min(100000000, (int) ($in['value'] ?? 0)));
	} else {
		return $fail(bounty_board_t('bounty_board.err_type', 'That bounty type is not available.'));
	}

	$now = time();
	if (!bounty_board_charge($accountId, $total)) return $fail(bounty_board_t('bounty_board.err_broke', 'You need {n} points (stake + fee).', array('n' => $total)));
	$expires = $now + $days * 86400;
	$note = substr(trim((string) ($in['note'] ?? '')), 0, 500);

	$ins = mysql_insert("INSERT INTO `znote_bounties` (`poster_account_id`,`poster_name`,`type`,`title`,`target_name`,`target_value`,`vocation_filter`,`stake`,`winners`,`status`,`note`,`posted_at`,`expires_at`,`created_at`,`updated_at`) VALUES ("
		. $accountId . ",'" . mysql_znote_escape_string($posterName) . "','" . mysql_znote_escape_string($type) . "','','" . mysql_znote_escape_string($tn) . "',"
		. (int) $tv . "," . (int) $voc . "," . (int) $stake . "," . (int) $winners . ",'open','" . mysql_znote_escape_string($note) . "'," . $now . "," . $expires . "," . $now . "," . $now . ");");
	if ($ins === false) {
		bounty_board_pay($accountId, $total); // refund the charge, the insert failed
		return $fail(bounty_board_t('bounty_board.err_save', 'Could not save the bounty. Try again.'));
	}

	$id = 0;
	$r = mysql_select_single("SELECT MAX(`id`) AS id FROM `znote_bounties` WHERE `poster_account_id` = {$accountId};");
	if (is_array($r)) $id = (int) $r['id'];
	bounty_board_log($id, 'posted', $accountId, $type . ' stake ' . $stake . ($fee ? ' fee ' . $fee : ''));
	if (function_exists('setting_set')) bounty_board_clear_cache();
	return array('ok' => true, 'message' => bounty_board_t('bounty_board.posted_ok', 'Bounty posted. {n} points held in escrow.', array('n' => $stake)), 'id' => $id);
}

// --- cached data + resolution ----------------------------
function bounty_board_clear_cache(): void {
	if (function_exists('setting_set')) { setting_set('bounty_board:cache', ''); setting_set('bounty_board:cache_at', '0'); }
}
function bounty_board_data(bool $refresh = false): array {
	static $mem = null;
	if ($mem !== null && !$refresh) return $mem;

	$ttl = max(15, bounty_board_int('cache_ttl', 60));
	$at = (int) bounty_board_setting('cache_at', '0');
	$raw = bounty_board_setting('cache', '');
	if (!$refresh && $at > 0 && $at + $ttl > time() && $raw !== '') {
		$d = json_decode($raw, true);
		if (is_array($d)) return $mem = $d;
	}

	bounty_board_ensure_schema();
	$now = time();

	foreach (bounty_board_list('open', 100) as $b) {
		bounty_board_resolve($b);
	}

	$view = array();
	foreach (bounty_board_list('open', 60) as $b) {
		$target = max(1, (int) $b['target_value']);
		$prog = ($b['type'] === 'monster_kills') ? bounty_board_progress($b) : 0;
		$view[] = array(
			'id'       => (int) $b['id'],
			'type'     => (string) $b['type'],
			'title'    => bounty_board_title($b),
			'howto'    => bounty_board_howto($b),
			'stake'    => (int) $b['stake'],
			'winners'  => max(1, (int) ($b['winners'] ?? 1)),
			'poster'   => (string) $b['poster_name'],
			'note'     => (string) $b['note'],
			'expires'  => (int) $b['expires_at'],
			'target'   => $target,
			'progress' => $b['type'] === 'monster_kills' ? min($prog, $target) : 0,
			'pct'      => $b['type'] === 'monster_kills' ? (int) floor(min(100, $prog / $target * 100)) : 0,
		);
	}
	$recent = array();
	foreach (bounty_board_list('claimed', 6) as $b) {
		$recent[] = array('title' => bounty_board_title($b), 'winner' => (string) $b['claimed_by_name'], 'stake' => (int) $b['stake']);
	}

	$out = array('open' => $view, 'recent' => $recent);
	if (function_exists('setting_set')) {
		setting_set('bounty_board:cache', json_encode($out));
		setting_set('bounty_board:cache_at', (string) time());
	}
	return $mem = $out;
}

// --- endpoints -----------------------------------------
function bounty_board_handle_download(): void {
	if (($_GET['bounty_board_dl'] ?? '') === '' || headers_sent()) return;
	$d = preg_replace('/[^a-z0-9_]/', '', (string) $_GET['bounty_board_dl']);
	if (!isset(bounty_board_distros()[$d])) { http_response_code(404); exit; }
	$dir = __DIR__ . '/assets/lua/' . $d;
	if (!is_dir($dir)) { http_response_code(404); exit; }
	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: text/plain; charset=utf-8');
	header('Content-Disposition: attachment; filename="bounty_board_' . $d . '.txt"');
	$files = glob($dir . '/*'); sort($files);
	foreach ($files as $f) { if (!is_file($f)) continue; echo "\n===== FILE: " . basename($f) . " =====\n\n" . file_get_contents($f) . "\n"; }
	exit;
}
function bounty_board_handle_ajax(): void {
	if (($_GET['bounty_board_progress'] ?? '') === '' || headers_sent()) return;
	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: application/json; charset=utf-8');
	header('X-Content-Type-Options: nosniff');
	$data = bounty_board_enabled() ? bounty_board_data() : array('open' => array(), 'recent' => array());
	echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	exit;
}

// --- side box ------------------------------------------
function bounty_board_footer(): string {
	if (!bounty_board_enabled()) return '';
	$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
	$pages = array_filter(array_map('trim', explode(',', bounty_board_setting('pages', 'index.php'))));
	if ($pages && !in_array($script, $pages, true)) return '';
	if ($script === 'page.php' && (string) ($_GET['plugin'] ?? '') === 'bounty_board') return '';

	$data = bounty_board_data();
	$open = array_slice($data['open'] ?? array(), 0, max(1, bounty_board_int('box_count', 4)));
	if (!$open) return '';

	$url = bounty_board_h(znote_plugin_url('bounty_board', 'board'));
	$title = bounty_board_h(trim(bounty_board_setting('panel_title', '')) !== '' ? bounty_board_setting('panel_title', '') : bounty_board_t('bounty_board.panel_title', 'Bounty Board'));
	$side = bounty_board_setting('side', 'right') === 'left' ? 'left' : 'right';
	$offset = bounty_board_int('offset_top', 120);
	if ($offset < 0 || $offset > 800) $offset = 120;
	$shadow = bounty_board_setting('style_shadow', '1') === '1';

	$poll = max(0, bounty_board_int('poll_seconds', 30));
	$rows = '';
	foreach ($open as $g) {
		$left = $g['expires'] > 0 ? max(0, $g['expires'] - time()) : 0;
		$leftTxt = $left > 0 ? ' · ' . bounty_board_h(bounty_board_rel_time($left)) : '';
		$rows .= '<a class="bb-row" data-id="' . (int) $g['id'] . '" href="' . $url . '">'
			. '<span class="bb-row__stake">' . number_format($g['stake']) . '</span>'
			. '<span class="bb-row__t">' . bounty_board_h($g['title']) . '<em>' . bounty_board_h($g['poster']) . $leftTxt . '</em></span>'
			. '</a>';
	}

	$css = '#bbPanel{--bb-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(24,27,34))))))));--bb-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bb-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--bb-accent:var(--accent,var(--link,var(--nz-accent,#f4c542)));--bb-title-bg:var(--bb-accent);--bb-title-text:#151515;--bb-radius:14px;position:fixed;top:' . $offset . 'px;' . $side . ':14px;z-index:928;width:230px;max-width:calc(100vw - 28px);color:var(--bb-text);font-size:13px;animation:bbIn .35s ease both}'
		. '@keyframes bbIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
		. '#bbPanel *{box-sizing:border-box}'
		. '#bbPanel .bb-inner{border:1px solid var(--bb-border);border-radius:var(--bb-radius);background:var(--bb-surface);overflow:hidden' . ($shadow ? ';box-shadow:0 12px 34px rgba(0,0,0,.4)' : '') . '}'
		. '#bbPanel .bb-top{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:7px 10px;background:var(--bb-title-bg);color:var(--bb-title-text);font-weight:800;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em}'
		. '#bbPanel .bb-top a{color:inherit;text-decoration:none;opacity:.85}'
		. '#bbPanel .bb-toggle{border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;opacity:.85;padding:0}'
		. '#bbPanel .bb-body[hidden]{display:none}'
		. '#bbPanel .bb-row{display:flex;gap:9px;align-items:center;padding:9px 11px;border-top:1px solid var(--bb-border);text-decoration:none;color:inherit}#bbPanel .bb-row:first-child{border-top:0}#bbPanel .bb-row:hover{background:rgba(255,255,255,.05)}'
		. '#bbPanel .bb-row__stake{flex:0 0 auto;font-weight:800;color:var(--bb-accent);font-variant-numeric:tabular-nums}'
		. '#bbPanel .bb-row__t{min-width:0;font-size:12.5px;line-height:1.25}#bbPanel .bb-row__t em{display:block;font-style:normal;font-size:11px;opacity:.6;margin-top:1px}'
		. '#bbPanel .bb-foot{padding:8px 11px;border-top:1px solid var(--bb-border);text-align:center}'
		. '#bbPanel .bb-foot a{color:var(--bb-accent);text-decoration:none;font-weight:700;font-size:12px}'
		. '@media(max-width:820px){#bbPanel{position:static;width:auto;margin:0 0 14px;animation:none}}';

	$html = '<div id="bbPanel"' . bounty_board_style_attr() . '><div class="bb-inner">'
		. '<div class="bb-top"><span>' . $title . '</span><button type="button" class="bb-toggle" aria-expanded="true">' . bounty_board_h(bounty_board_t('bounty_board.hide', 'Hide')) . '</button></div>'
		. '<div class="bb-body">' . $rows . '<div class="bb-foot"><a href="' . $url . '">' . bounty_board_h(bounty_board_t('bounty_board.see_all', 'See all &amp; post &rarr;')) . '</a></div></div>'
		. '</div></div>';

	$showTxt = json_encode(bounty_board_t('bounty_board.show', 'Show'));
	$hideTxt = json_encode(bounty_board_t('bounty_board.hide', 'Hide'));

	return '<script>(function(){if(document.getElementById("bbPanel"))return;'
		. 'var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';var p=w.firstChild;'
		. 'var host=document.querySelector("main,#content,.content,.container")||document.body;'
		. '(window.matchMedia&&window.matchMedia("(max-width:820px)").matches?host:document.body).appendChild(p);'
		. 'var b=p.querySelector(".bb-body"),t=p.querySelector(".bb-toggle");'
		. 'try{if(localStorage.getItem("bbCollapsed")==="1"){b.hidden=true;t.textContent=' . $showTxt . ';}}catch(e){}'
		. 't.addEventListener("click",function(){var h=!b.hidden;b.hidden=h;t.textContent=h?' . $showTxt . ':' . $hideTxt . ';try{localStorage.setItem("bbCollapsed",h?"1":"0");}catch(e){}});'
		. ($poll > 0 ? 'setInterval(function(){fetch("?bounty_board_progress=1",{credentials:"same-origin"}).then(function(r){return r.json();}).then(function(d){var open=(d&&d.open)||[],ids={};open.forEach(function(g){ids[g.id]=1;});p.querySelectorAll(".bb-row").forEach(function(row){var id=row.getAttribute("data-id");if(id&&!ids[id]){row.style.transition="opacity .4s";row.style.opacity="0";setTimeout(function(){row.remove();if(!p.querySelector(".bb-row"))p.remove();},420);}});}).catch(function(){});},' . ($poll * 1000) . ');' : '')
		. '}());</script>';
}
function bounty_board_rel_time(int $seconds): string {
	if ($seconds >= 86400) return bounty_board_t('bounty_board.d_left', '{n}d left', array('n' => (int) floor($seconds / 86400)));
	if ($seconds >= 3600) return bounty_board_t('bounty_board.h_left', '{n}h left', array('n' => (int) floor($seconds / 3600)));
	return bounty_board_t('bounty_board.m_left', '{n}m left', array('n' => max(1, (int) floor($seconds / 60))));
}

}

bounty_board_handle_download();
bounty_board_handle_ajax();
bounty_board_ensure_schema();
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'bounty_board_footer');
}
