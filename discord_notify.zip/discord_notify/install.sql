CREATE TABLE IF NOT EXISTS `znote_discord_watch` (
	`id` int NOT NULL AUTO_INCREMENT,
	`label` varchar(100) NOT NULL DEFAULT '',
	`storage_key` int unsigned NOT NULL,
	`target_value` int NOT NULL,
	`active` tinyint NOT NULL DEFAULT 1,
	`sort_order` int NOT NULL DEFAULT 0,
	`announced_at` int NOT NULL DEFAULT 0,
	`announced_player` varchar(50) NOT NULL DEFAULT '',
	`created_at` int NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_discord_custom_events` (
	`id` int NOT NULL AUTO_INCREMENT,
	`label` varchar(100) NOT NULL DEFAULT '',
	`message` varchar(500) NOT NULL DEFAULT '',
	`storage_key` int unsigned NOT NULL DEFAULT 0,
	`frequency` enum('daily','interval') NOT NULL DEFAULT 'daily',
	`fire_hour` tinyint unsigned NOT NULL DEFAULT 12,
	`interval_hours` int unsigned NOT NULL DEFAULT 24,
	`active` tinyint NOT NULL DEFAULT 1,
	`sort_order` int NOT NULL DEFAULT 0,
	`last_fired_at` int NOT NULL DEFAULT 0,
	`last_fired_date` varchar(10) NOT NULL DEFAULT '',
	`created_at` int NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
