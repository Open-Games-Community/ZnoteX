<?php
/**
 * Discord Notifications - posts an embed to a Discord webhook for whichever
 * site events the admin has switched on.
 *
 * Every event this plugin can announce is something ZnoteX already fires a
 * hook for (account.registered, character.created, ...) - this plugin does
 * not invent new hook points, it just listens and formats. The one exception
 * is server.online_record, added to engine/function/settings.php's
 * znote_record_update() alongside this plugin, since nothing fired that
 * moment before.
 */
if (!function_exists('discord_notify_setting')) {

/**
 * Storage matches the generic plugin-settings.json admin page's own key
 * format exactly ("plugin:<name>:setting:<key>") - that page is what writes
 * these values, this file only reads them.
 */
function discord_notify_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('plugin:discord_notify:setting:' . $key, $default) : $default;
}
function discord_notify_enabled(): bool {
	return discord_notify_setting('enabled', '0') === '1' && discord_notify_webhook_url() !== '';
}
function discord_notify_webhook_url(): string {
	$url = trim(discord_notify_setting('webhook_url', ''));
	return (preg_match('#^https://(discord\.com|discordapp\.com)/api/webhooks/#i', $url)) ? $url : '';
}
function discord_notify_event_enabled(string $event): bool {
	$chosen = array_filter(array_map('trim', explode(',', discord_notify_setting('events', ''))));
	return in_array($event, $chosen, true);
}
function discord_notify_h($v): string {
	return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8');
}

/** Every event this plugin knows about: key => [label, default color, default description]. */
function discord_notify_events(): array {
	return array(
		'account_registered' => array('New account registered', 0x2ecc71),
		'character_created'  => array('New character created', 0x3498db),
		'online_record'      => array('New online-player record', 0xe74c3c),
		'highscores_daily'   => array('Daily highscores digest', 0x1abc9c),
	);
}

/**
 * Fire-and-forget POST to the webhook. A dead/slow Discord endpoint must
 * never hold up the page that triggered it (account creation, a purchase),
 * so this uses a short timeout and swallows every failure - at most it is
 * logged, the site keeps working either way.
 */
function discord_notify_send(string $title, string $description, int $color, array $fields = array()): void {
	$url = discord_notify_webhook_url();
	if ($url === '' || !function_exists('curl_init')) {
		return;
	}

	$embed = array(
		'title'       => $title,
		'description' => $description,
		'color'       => $color,
		'timestamp'   => gmdate('c'),
	);

	if ($fields) {
		$embed['fields'] = array_map(static function (array $f): array {
			return array(
				'name'   => (string) $f['name'],
				'value'  => (string) $f['value'],
				'inline' => !empty($f['inline']),
			);
		}, $fields);
	}

	global $config;
	$siteName = trim((string) ($config['site_title'] ?? ''));
	if ($siteName !== '') {
		$embed['footer'] = array('text' => $siteName);
	}

	$payload = json_encode(array('embeds' => array($embed)), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	if ($payload === false) {
		return;
	}

	$ch = curl_init($url);
	curl_setopt_array($ch, array(
		CURLOPT_POST           => true,
		CURLOPT_POSTFIELDS     => $payload,
		CURLOPT_HTTPHEADER     => array('Content-Type: application/json'),
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_CONNECTTIMEOUT => 3,
		CURLOPT_TIMEOUT        => 4,
		CURLOPT_SSL_VERIFYPEER => true,
	));
	curl_exec($ch);
	if (curl_errno($ch)) {
		error_log('[discord_notify] webhook post failed: ' . curl_error($ch));
	}
	curl_close($ch);
}

// --- event handlers ----------------------------------------------------

function discord_notify_on_account_registered(array $data): void {
	if (!discord_notify_enabled() || !discord_notify_event_enabled('account_registered')) return;
	$events = discord_notify_events();
	discord_notify_send($events['account_registered'][0], '', $events['account_registered'][1], array(
		array('name' => 'Account', 'value' => (string) ($data['name'] ?? '-'), 'inline' => true),
	));
}

function discord_notify_on_character_created(array $data): void {
	if (!discord_notify_enabled() || !discord_notify_event_enabled('character_created')) return;
	$events = discord_notify_events();
	$vocation = function_exists('vocation_id_to_name') ? vocation_id_to_name((int) ($data['vocation'] ?? 0)) : (string) ($data['vocation'] ?? '');
	discord_notify_send($events['character_created'][0], '', $events['character_created'][1], array(
		array('name' => 'Character', 'value' => (string) ($data['name'] ?? '-'), 'inline' => true),
		array('name' => 'Vocation', 'value' => (string) $vocation, 'inline' => true),
	));
}

function discord_notify_on_online_record(array $data): void {
	if (!discord_notify_enabled() || !discord_notify_event_enabled('online_record')) return;
	$events = discord_notify_events();
	discord_notify_send($events['online_record'][0], '', $events['online_record'][1], array(
		array('name' => 'Players online', 'value' => (string) (int) ($data['players'] ?? 0), 'inline' => true),
	));
}

// --- custom storage watches ---------------------------------------------
//
// Admin-defined milestones (Admin Panel > Installed Plugins > Discord Storage
// Watch): "announce the first player whose player_storage value for key X
// reaches Y" - a Paragon level, a custom rank, anything a Lua script writes
// to a storage key. There is no cron here, so this runs off page.footer
// (fired on every page anyway) with its own cooldown, rather than querying
// the database on every single page view.
function discord_notify_check_watches(): string {
	if (!discord_notify_enabled()
		|| !function_exists('znote_table_exists')
		|| !znote_table_exists('znote_discord_watch')
		|| !znote_table_exists('player_storage')
	) {
		return '';
	}

	$cooldown = 60;
	$last = (int) discord_notify_setting('watch_checked_at', '0');
	if ($last + $cooldown > time()) {
		return '';
	}
	setting_set('plugin:discord_notify:setting:watch_checked_at', (string) time());

	$watches = db()->fetchAll("SELECT * FROM `znote_discord_watch` WHERE `active` = 1 AND `announced_at` = 0;");
	if (!is_array($watches) || !$watches) {
		return '';
	}

	foreach ($watches as $w) {
		$storageKey = (int) $w['storage_key'];
		$target = (int) $w['target_value'];
		if ($storageKey <= 0) {
			continue;
		}

		$row = db()->fetchOne("
			SELECT `ps`.`value`, `p`.`name`
			FROM `player_storage` `ps`
			INNER JOIN `players` `p` ON `p`.`id` = `ps`.`player_id`
			WHERE `ps`.`key` = ? AND `ps`.`value` >= ?
			ORDER BY `ps`.`value` DESC
			LIMIT 1;
		", [$storageKey, $target]);

		if (!is_array($row)) {
			continue;
		}

		$updated = db()->execute("
			UPDATE `znote_discord_watch`
			SET `announced_at` = ?, `announced_player` = ?
			WHERE `id` = ? AND `announced_at` = 0;
		", [time(), (string) $row['name'], (int) $w['id']]);

		// The WHERE ... announced_at = 0 above means only one request ever wins
		// this update for a given watch, even if two page loads both cleared
		// the cooldown at the same moment - so only that one sends the message.
		if ($updated) {
			discord_notify_send(
				'🏆 ' . (string) $w['label'],
				(string) $row['name'] . ' just reached it!',
				0xf1c40f,
				array(array('name' => 'Value', 'value' => (string) (int) $row['value'], 'inline' => true))
			);
		}
	}

	return '';
}

// --- daily highscores digest ---------------------------------------------
//
// Same no-cron trick as the storage watches above (this runs off page.footer,
// which fires on every page load anyway), but keyed by calendar date instead
// of a fixed cooldown: the first page view after midnight where the stored
// date no longer matches today's date is the one that posts, then every
// other request that day sees the date already updated and does nothing.
function discord_notify_check_highscores_daily(): string {
	if (!discord_notify_enabled() || !discord_notify_event_enabled('highscores_daily') || !function_exists('db')) {
		return '';
	}

	$today = gmdate('Y-m-d');
	$lastDate = discord_notify_setting('highscores_posted_date', '');
	if ($lastDate === $today) {
		return '';
	}
	setting_set('plugin:discord_notify:setting:highscores_posted_date', $today);

	$top = (int) discord_notify_setting('highscores_top_count', '3');
	if ($top !== 3 && $top !== 5) {
		$top = 3;
	}

	global $config;
	$ignoreGroupId = (int) ($config['highscore']['ignoreGroupId'] ?? 0);

	$rows = db()->fetchAll("
		SELECT `name`, `level`, `experience`, `vocation`
		FROM `players`
		WHERE `group_id` < ?
		ORDER BY `experience` DESC
		LIMIT ?;
	", [$ignoreGroupId, $top]);
	$rows = is_array($rows) ? $rows : array();
	if (!$rows) {
		return '';
	}

	$medals = array('🥇', '🥈', '🥉', '🏅', '🏅');
	$lines = array();
	foreach ($rows as $i => $row) {
		$vocation = function_exists('vocation_id_to_name') ? vocation_id_to_name((int) $row['vocation']) : (string) $row['vocation'];
		$lines[] = ($medals[$i] ?? '🏅') . ' **' . (string) $row['name'] . '** - Level ' . (int) $row['level'] . ' ' . $vocation;
	}

	$events = discord_notify_events();
	discord_notify_send($events['highscores_daily'][0], implode("\n", $lines), $events['highscores_daily'][1]);

	return '';
}

// --- recurring custom announcements --------------------------------------
//
// Admin-defined announcements (Admin Panel > Installed Plugins > Discord
// Custom Events): a label + message text, fired on their own schedule
// instead of the one-shot storage watches above - either once a day at a
// chosen UTC hour, or every N hours. A message can optionally pull in the
// current top player for a storage key via {value}/{player} placeholders,
// reusing the same query shape as discord_notify_check_watches() but
// without a target threshold - it is just something to show, not a gate.
// Same no-cron, page.footer-cooldown trick as the two checkers above.
function discord_notify_custom_event_value(int $storageKey): array {
	if ($storageKey <= 0 || !function_exists('db')) {
		return array('value' => '-', 'player' => '-');
	}

	$row = db()->fetchOne("
		SELECT `ps`.`value`, `p`.`name`
		FROM `player_storage` `ps`
		INNER JOIN `players` `p` ON `p`.`id` = `ps`.`player_id`
		WHERE `ps`.`key` = ?
		ORDER BY `ps`.`value` DESC
		LIMIT 1;
	", [$storageKey]);

	if (!is_array($row)) {
		return array('value' => '-', 'player' => '-');
	}

	return array('value' => (string) (int) $row['value'], 'player' => (string) $row['name']);
}

function discord_notify_check_custom_events(): string {
	if (!discord_notify_enabled()
		|| !function_exists('znote_table_exists')
		|| !znote_table_exists('znote_discord_custom_events')
	) {
		return '';
	}

	$cooldown = 60;
	$last = (int) discord_notify_setting('custom_checked_at', '0');
	if ($last + $cooldown > time()) {
		return '';
	}
	setting_set('plugin:discord_notify:setting:custom_checked_at', (string) time());

	$rows = db()->fetchAll("SELECT * FROM `znote_discord_custom_events` WHERE `active` = 1;");
	if (!is_array($rows) || !$rows) {
		return '';
	}

	$now = time();
	$today = gmdate('Y-m-d');
	$hourNow = (int) gmdate('G');

	foreach ($rows as $row) {
		$id = (int) $row['id'];
		$frequency = (string) $row['frequency'];
		$due = false;

		if ($frequency === 'interval') {
			$intervalHours = max(1, (int) $row['interval_hours']);
			$due = ((int) $row['last_fired_at'] + ($intervalHours * 3600)) <= $now;
		} else {
			$due = (string) $row['last_fired_date'] !== $today && $hourNow >= (int) $row['fire_hour'];
		}

		if (!$due) {
			continue;
		}

		// WHERE last_fired_at/last_fired_date match what was just read means
		// only one request ever wins this update for a given row, even if
		// two page loads both cleared the cooldown at the same moment.
		$updated = db()->execute("
			UPDATE `znote_discord_custom_events`
			SET `last_fired_at` = ?, `last_fired_date` = ?
			WHERE `id` = ? AND `last_fired_at` = ? AND `last_fired_date` = ?;
		", [$now, $today, $id, (int) $row['last_fired_at'], (string) $row['last_fired_date']]);

		if (!$updated) {
			continue;
		}

		$storageKey = (int) $row['storage_key'];
		$vars = discord_notify_custom_event_value($storageKey);
		$message = strtr((string) $row['message'], array(
			'{value}'  => $vars['value'],
			'{player}' => $vars['player'],
		));

		discord_notify_send((string) $row['label'], $message, 0x5865f2);
	}

	return '';
}

}

if (function_exists('znote_hook_register')) {
	znote_hook_register('account.registered', 'discord_notify_on_account_registered');
	znote_hook_register('character.created', 'discord_notify_on_character_created');
	znote_hook_register('server.online_record', 'discord_notify_on_online_record');
	znote_hook_register('page.footer', 'discord_notify_check_watches');
	znote_hook_register('page.footer', 'discord_notify_check_highscores_daily');
	znote_hook_register('page.footer', 'discord_notify_check_custom_events');
}
