<?php
/**
 * Title: Discord Storage Watch
 * Icon: fa-bullhorn
 * Group: Installed Plugins
 * Order: 36
 * Description: Announce a per-player storage value in Discord the first time someone reaches it - a Paragon level, a custom rank, anything with a storage key.
 */

if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

if (!function_exists('znote_table_exists') || !znote_table_exists('znote_discord_watch')) {
	acp_flash_error(t_default('acp.dwatch.not_installed', 'Install the Discord Notifications plugin first (Admin Panel > Plugins).'));
	acp_redirect('plugins');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!acp_verify_csrf()) {
		acp_flash_error(t_default('acp.csrf_failed', 'Your session expired, please try again.'));
		acp_redirect('discord_notify__discord_watch');
	}

	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_discord_watch` WHERE `id` = ? LIMIT 1;", [$id]);
		acp_log('discord_notify.watch_delete', '#' . $id);
		acp_flash_success(t_default('acp.dwatch.deleted', 'Watch removed.'));
		acp_redirect('discord_notify__discord_watch');
	}

	if ($do === 'reset' && $id > 0) {
		db()->execute("UPDATE `znote_discord_watch` SET `announced_at` = 0, `announced_player` = '' WHERE `id` = ? LIMIT 1;", [$id]);
		acp_log('discord_notify.watch_reset', '#' . $id);
		acp_flash_success(t_default('acp.dwatch.reset_done', 'Watch reset - it will announce again the next time the target is reached.'));
		acp_redirect('discord_notify__discord_watch');
	}

	if ($do === 'save') {
		$label       = substr(trim((string) ($_POST['label'] ?? '')), 0, 100);
		$storageKey  = intv($_POST['storage_key'] ?? 0);
		$targetValue = intv($_POST['target_value'] ?? 0);
		$active      = !empty($_POST['active']) ? 1 : 0;

		if ($label === '' || $storageKey <= 0) {
			acp_flash_error(t_default('acp.dwatch.missing_fields', 'Give the watch a label and a storage key.'));
			acp_redirect('discord_notify__discord_watch');
		}

		if ($id > 0) {
			db()->execute("
				UPDATE `znote_discord_watch`
				SET `label` = ?, `storage_key` = ?, `target_value` = ?, `active` = ?
				WHERE `id` = ?
				LIMIT 1;
			", [$label, $storageKey, $targetValue, $active, $id]);
			acp_log('discord_notify.watch_update', '#' . $id);
			acp_flash_success(t_default('acp.dwatch.updated', 'Watch updated.'));
		} else {
			db()->execute("
				INSERT INTO `znote_discord_watch` (`label`, `storage_key`, `target_value`, `active`, `created_at`)
				VALUES (?, ?, ?, ?, ?);
			", [$label, $storageKey, $targetValue, $active, time()]);
			acp_log('discord_notify.watch_create', $label);
			acp_flash_success(t_default('acp.dwatch.created', 'Watch added.'));
		}

		acp_redirect('discord_notify__discord_watch');
	}
}

$watches = db()->fetchAll("SELECT * FROM `znote_discord_watch` ORDER BY `sort_order` ASC, `id` ASC;");
$watches = is_array($watches) ? $watches : array();
$editId  = intv($_GET['edit'] ?? 0);
$editing = null;
if ($editId > 0) {
	foreach ($watches as $w) {
		if ((int) $w['id'] === $editId) { $editing = $w; break; }
	}
}
?>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.dwatch.form_title', 'Add a storage watch') ?></h2>
		<p><?= t_default('acp.dwatch.form_sub', 'One row = one milestone. Find the storage key with the script your server engine already uses to inspect player_storage, or ask whoever wrote the Paragon/rank system.') ?></p>
	</header>
	<div class="acp-card-body">
		<form method="post">
			<?= acp_csrf_field() ?>
			<input type="hidden" name="do" value="save">
			<input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="dw_label"><?= t_default('acp.dwatch.label_label', 'Label') ?></label>
					<input class="acp-input" id="dw_label" name="label" value="<?= h((string) ($editing['label'] ?? '')) ?>" placeholder="<?= h(t_default('acp.dwatch.label_placeholder', 'e.g. Paragon Level 200')) ?>" maxlength="100" required>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="dw_key"><?= t_default('acp.dwatch.key_label', 'Storage key') ?></label>
					<input class="acp-input" id="dw_key" name="storage_key" type="number" min="1" value="<?= (int) ($editing['storage_key'] ?? 0) ?: '' ?>" required>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="dw_target"><?= t_default('acp.dwatch.target_label', 'Target value') ?></label>
					<input class="acp-input" id="dw_target" name="target_value" type="number" value="<?= (int) ($editing['target_value'] ?? 0) ?>">
					<p class="acp-hint"><?= t_default('acp.dwatch.target_help', 'Fires the first time any player\'s value for this key reaches this number or higher.') ?></p>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="dw_active"><?= t_default('acp.dwatch.active_label', 'Active') ?></label>
					<label style="display:flex;align-items:center;gap:8px;font-weight:400;min-height:34px;">
						<input type="checkbox" id="dw_active" name="active" value="1" <?= empty($editing) || !empty($editing['active']) ? 'checked' : '' ?>>
						<span class="is-muted"><?= t('acp.settings.enabled') ?></span>
					</label>
				</div>
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? t_default('acp.dwatch.save_btn', 'Save') : t_default('acp.dwatch.add_btn', 'Add watch') ?></button>
				<?php if ($editing): ?>
					<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url('discord_notify__discord_watch')) ?>"><?= t_default('acp.dwatch.cancel_btn', 'Cancel') ?></a>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.dwatch.list_title', 'Watches') ?></h2>
	</header>
	<div class="acp-card-body is-flush">
		<?php if ($watches): ?>
			<div class="acp-table-wrap">
				<table class="acp-table" data-sortable>
					<thead>
						<tr>
							<th><?= t_default('acp.dwatch.col_label', 'Label') ?></th>
							<th class="is-num"><?= t_default('acp.dwatch.col_key', 'Key') ?></th>
							<th class="is-num"><?= t_default('acp.dwatch.col_target', 'Target') ?></th>
							<th><?= t_default('acp.dwatch.col_status', 'Status') ?></th>
							<th class="is-num"><?= t_default('acp.dwatch.col_actions', 'Actions') ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($watches as $w): ?>
							<tr>
								<td><?= h((string) $w['label']) ?></td>
								<td class="is-num"><?= (int) $w['storage_key'] ?></td>
								<td class="is-num"><?= (int) $w['target_value'] ?></td>
								<td>
									<?php if (!empty($w['active']) == false): ?>
										<span class="acp-pill acp-pill--grey"><?= t_default('acp.dwatch.status_off', 'Off') ?></span>
									<?php elseif ((int) $w['announced_at'] > 0): ?>
										<span class="acp-pill acp-pill--green"><?= t_default('acp.dwatch.status_announced', 'Reached by {player}', ['player' => h((string) $w['announced_player'])]) ?></span>
									<?php else: ?>
										<span class="acp-pill acp-pill--amber"><?= t_default('acp.dwatch.status_waiting', 'Waiting') ?></span>
									<?php endif; ?>
								</td>
								<td class="is-nowrap is-num">
									<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url('discord_notify__discord_watch', ['edit' => (int) $w['id']])) ?>"><i class="fa fa-pencil"></i></a>
									<?php if ((int) $w['announced_at'] > 0): ?>
										<form class="acp-inline-form" method="post" data-confirm="<?= h(t_default('acp.dwatch.confirm_reset', 'Reset this watch so it can announce again?')) ?>">
											<?= acp_csrf_field() ?>
											<input type="hidden" name="do" value="reset">
											<input type="hidden" name="id" value="<?= (int) $w['id'] ?>">
											<button class="acp-btn acp-btn--ghost acp-btn--sm" type="submit" title="<?= h(t_default('acp.dwatch.reset_btn', 'Reset')) ?>"><i class="fa fa-refresh"></i></button>
										</form>
									<?php endif; ?>
									<form class="acp-inline-form" method="post" data-confirm="<?= h(t_default('acp.dwatch.confirm_delete', 'Remove this watch?')) ?>">
										<?= acp_csrf_field() ?>
										<input type="hidden" name="do" value="delete">
										<input type="hidden" name="id" value="<?= (int) $w['id'] ?>">
										<button class="acp-btn acp-btn--red acp-btn--sm" type="submit" title="<?= h(t_default('acp.dwatch.delete_btn', 'Delete')) ?>"><i class="fa fa-trash"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<?php acp_empty(t_default('acp.dwatch.empty', 'No watches yet - add one above.'), 'fa-bullhorn'); ?>
		<?php endif; ?>
	</div>
</section>
