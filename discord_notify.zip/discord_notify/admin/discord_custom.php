<?php
/**
 * Title: Discord Custom Events
 * Icon: fa-calendar-check
 * Group: Installed Plugins
 * Order: 37
 * Description: Recurring Discord announcements - a message posted daily at a chosen hour, or every N hours, optionally showing a player_storage value.
 */

if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

if (!function_exists('znote_table_exists') || !znote_table_exists('znote_discord_custom_events')) {
	acp_flash_error(t_default('acp.dcustom.not_installed', 'Click "Update" on the Discord Notifications plugin first (Admin Panel > Plugins).'));
	acp_redirect('plugins');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!acp_verify_csrf()) {
		acp_flash_error(t_default('acp.csrf_failed', 'Your session expired, please try again.'));
		acp_redirect('discord_notify__discord_custom');
	}

	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_discord_custom_events` WHERE `id` = ? LIMIT 1;", [$id]);
		acp_log('discord_notify.custom_delete', '#' . $id);
		acp_flash_success(t_default('acp.dcustom.deleted', 'Event removed.'));
		acp_redirect('discord_notify__discord_custom');
	}

	if ($do === 'save') {
		$label         = substr(trim((string) ($_POST['label'] ?? '')), 0, 100);
		$message       = substr(trim((string) ($_POST['message'] ?? '')), 0, 500);
		$storageKey    = intv($_POST['storage_key'] ?? 0);
		$frequency     = ((string) ($_POST['frequency'] ?? 'daily')) === 'interval' ? 'interval' : 'daily';
		$fireHour      = max(0, min(23, intv($_POST['fire_hour'] ?? 12)));
		$intervalHours = max(1, intv($_POST['interval_hours'] ?? 24));
		$active        = !empty($_POST['active']) ? 1 : 0;

		if ($label === '' || $message === '') {
			acp_flash_error(t_default('acp.dcustom.missing_fields', 'Give the event a label and a message.'));
			acp_redirect('discord_notify__discord_custom');
		}

		if ($id > 0) {
			db()->execute("
				UPDATE `znote_discord_custom_events`
				SET `label` = ?, `message` = ?, `storage_key` = ?, `frequency` = ?, `fire_hour` = ?, `interval_hours` = ?, `active` = ?
				WHERE `id` = ?
				LIMIT 1;
			", [$label, $message, $storageKey, $frequency, $fireHour, $intervalHours, $active, $id]);
			acp_log('discord_notify.custom_update', '#' . $id);
			acp_flash_success(t_default('acp.dcustom.updated', 'Event updated.'));
		} else {
			db()->execute("
				INSERT INTO `znote_discord_custom_events`
					(`label`, `message`, `storage_key`, `frequency`, `fire_hour`, `interval_hours`, `active`, `created_at`)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?);
			", [$label, $message, $storageKey, $frequency, $fireHour, $intervalHours, $active, time()]);
			acp_log('discord_notify.custom_create', $label);
			acp_flash_success(t_default('acp.dcustom.created', 'Event added.'));
		}

		acp_redirect('discord_notify__discord_custom');
	}
}

$events = db()->fetchAll("SELECT * FROM `znote_discord_custom_events` ORDER BY `sort_order` ASC, `id` ASC;");
$events = is_array($events) ? $events : array();
$editId = intv($_GET['edit'] ?? 0);
$editing = null;
if ($editId > 0) {
	foreach ($events as $e) {
		if ((int) $e['id'] === $editId) { $editing = $e; break; }
	}
}
$editFrequency = (string) ($editing['frequency'] ?? 'daily');
?>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.dcustom.form_title', 'Add a custom announcement') ?></h2>
		<p><?= t_default('acp.dcustom.form_sub', 'Use {value} and {player} in the message to show the current top player for a storage key - leave the storage key at 0 to just post fixed text.') ?></p>
	</header>
	<div class="acp-card-body">
		<form method="post">
			<?= acp_csrf_field() ?>
			<input type="hidden" name="do" value="save">
			<input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="dc_label"><?= t_default('acp.dcustom.label_label', 'Label') ?></label>
					<input class="acp-input" id="dc_label" name="label" value="<?= h((string) ($editing['label'] ?? '')) ?>" placeholder="<?= h(t_default('acp.dcustom.label_placeholder', 'e.g. Evening reminder')) ?>" maxlength="100" required>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="dc_key"><?= t_default('acp.dcustom.key_label', 'Storage key (0 = none)') ?></label>
					<input class="acp-input" id="dc_key" name="storage_key" type="number" min="0" value="<?= (int) ($editing['storage_key'] ?? 0) ?>">
				</div>
			</div>
			<div class="acp-field">
				<label class="acp-label" for="dc_message"><?= t_default('acp.dcustom.message_label', 'Message') ?></label>
				<textarea class="acp-textarea" id="dc_message" name="message" rows="3" maxlength="500" required><?= h((string) ($editing['message'] ?? '')) ?></textarea>
			</div>
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="dc_frequency"><?= t_default('acp.dcustom.frequency_label', 'Frequency') ?></label>
					<select class="acp-input" id="dc_frequency" name="frequency">
						<option value="daily" <?= $editFrequency === 'daily' ? 'selected' : '' ?>><?= t_default('acp.dcustom.frequency_daily', 'Daily, at a chosen hour') ?></option>
						<option value="interval" <?= $editFrequency === 'interval' ? 'selected' : '' ?>><?= t_default('acp.dcustom.frequency_interval', 'Every N hours') ?></option>
					</select>
				</div>
				<div class="acp-field" id="dc_hour_field">
					<label class="acp-label" for="dc_hour"><?= t_default('acp.dcustom.hour_label', 'Hour (UTC, 0-23)') ?></label>
					<input class="acp-input" id="dc_hour" name="fire_hour" type="number" min="0" max="23" value="<?= (int) ($editing['fire_hour'] ?? 12) ?>">
				</div>
				<div class="acp-field" id="dc_interval_field">
					<label class="acp-label" for="dc_interval"><?= t_default('acp.dcustom.interval_label', 'Every (hours)') ?></label>
					<input class="acp-input" id="dc_interval" name="interval_hours" type="number" min="1" value="<?= (int) ($editing['interval_hours'] ?? 24) ?>">
				</div>
				<div class="acp-field">
					<label class="acp-label" for="dc_active"><?= t_default('acp.dcustom.active_label', 'Active') ?></label>
					<label style="display:flex;align-items:center;gap:8px;font-weight:400;min-height:34px;">
						<input type="checkbox" id="dc_active" name="active" value="1" <?= empty($editing) || !empty($editing['active']) ? 'checked' : '' ?>>
						<span class="is-muted"><?= t('acp.settings.enabled') ?></span>
					</label>
				</div>
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? t_default('acp.dcustom.save_btn', 'Save') : t_default('acp.dcustom.add_btn', 'Add event') ?></button>
				<?php if ($editing): ?>
					<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url('discord_notify__discord_custom')) ?>"><?= t_default('acp.dcustom.cancel_btn', 'Cancel') ?></a>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.dcustom.list_title', 'Custom events') ?></h2>
	</header>
	<div class="acp-card-body is-flush">
		<?php if ($events): ?>
			<div class="acp-table-wrap">
				<table class="acp-table" data-sortable>
					<thead>
						<tr>
							<th><?= t_default('acp.dcustom.col_label', 'Label') ?></th>
							<th><?= t_default('acp.dcustom.col_schedule', 'Schedule') ?></th>
							<th class="is-num"><?= t_default('acp.dcustom.col_key', 'Storage key') ?></th>
							<th><?= t_default('acp.dcustom.col_status', 'Status') ?></th>
							<th class="is-num"><?= t_default('acp.dcustom.col_actions', 'Actions') ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($events as $e): ?>
							<tr>
								<td><?= h((string) $e['label']) ?></td>
								<td class="is-muted">
									<?php if ((string) $e['frequency'] === 'interval'): ?>
										<?= h(t_default('acp.dcustom.schedule_interval', 'Every {n}h', ['n' => (int) $e['interval_hours']])) ?>
									<?php else: ?>
										<?= h(t_default('acp.dcustom.schedule_daily', 'Daily at {h}:00 UTC', ['h' => (int) $e['fire_hour']])) ?>
									<?php endif; ?>
								</td>
								<td class="is-num"><?= (int) $e['storage_key'] > 0 ? (int) $e['storage_key'] : '-' ?></td>
								<td>
									<?php if (empty($e['active'])): ?>
										<span class="acp-pill acp-pill--grey"><?= t_default('acp.dcustom.status_off', 'Off') ?></span>
									<?php elseif ((int) $e['last_fired_at'] > 0): ?>
										<span class="acp-pill acp-pill--green"><?= h(t_default('acp.dcustom.status_last_fired', 'Last: {date}', ['date' => date('Y-m-d H:i', (int) $e['last_fired_at'])])) ?></span>
									<?php else: ?>
										<span class="acp-pill acp-pill--amber"><?= t_default('acp.dcustom.status_waiting', 'Waiting') ?></span>
									<?php endif; ?>
								</td>
								<td class="is-nowrap is-num">
									<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url('discord_notify__discord_custom', ['edit' => (int) $e['id']])) ?>"><i class="fa fa-pencil"></i></a>
									<form class="acp-inline-form" method="post" data-confirm="<?= h(t_default('acp.dcustom.confirm_delete', 'Remove this event?')) ?>">
										<?= acp_csrf_field() ?>
										<input type="hidden" name="do" value="delete">
										<input type="hidden" name="id" value="<?= (int) $e['id'] ?>">
										<button class="acp-btn acp-btn--red acp-btn--sm" type="submit" title="<?= h(t_default('acp.dcustom.delete_btn', 'Delete')) ?>"><i class="fa fa-trash"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<?php acp_empty(t_default('acp.dcustom.empty', 'No custom events yet - add one above.'), 'fa-calendar-check'); ?>
		<?php endif; ?>
	</div>
</section>

<script>
(function () {
	var freq = document.getElementById('dc_frequency');
	var hourField = document.getElementById('dc_hour_field');
	var intervalField = document.getElementById('dc_interval_field');
	if (!freq || !hourField || !intervalField) return;

	function refresh() {
		var isInterval = freq.value === 'interval';
		hourField.hidden = isInterval;
		intervalField.hidden = !isInterval;
	}

	freq.addEventListener('change', refresh);
	refresh();
})();
</script>
