<?php
if (!function_exists('purchase_history_setting')) {
function purchase_history_setting(string $key, string $default = ''): string { return function_exists('setting') ? (string)setting('purchase_history:' . $key, $default) : $default; }
function purchase_history_enabled(): bool { return purchase_history_setting('enabled', '1') === '1'; }
function purchase_history_h($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function purchase_history_color(string $key): string {
	$value = trim(purchase_history_setting('style_' . $key, ''));
	return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value) ? $value : '';
}
function purchase_history_style_attr(array $map): string {
	$css = '';
	foreach ($map as $key => $var) {
		$value = purchase_history_color($key);
		if ($value !== '') $css .= $var . ':' . $value . ';';
	}
	return $css !== '' ? ' style="' . purchase_history_h($css) . '"' : '';
}
function purchase_history_table_columns(string $table): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists($table)) return array();
	$rows = db()->fetchAll("SHOW COLUMNS FROM `{$table}`;");
	$cols = array();
	if (is_array($rows)) foreach ($rows as $row) if (!empty($row['Field'])) $cols[(string)$row['Field']] = true;
	return $cols;
}
function purchase_history_time($time): string {
	$time = (int)$time;
	if ($time <= 0) return '-';
	return function_exists('getClock') ? (string)getClock($time, true) : date('Y-m-d H:i', $time);
}
function purchase_history_shop(int $accountId): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_shop_logs')) return array();
	$rows = db()->fetchAll("SELECT `type`,`itemid`,`count`,`points`,`time` FROM `znote_shop_logs` WHERE `account_id` = ? ORDER BY `time` DESC LIMIT 30;", [$accountId]);
	$out = array();
	if (is_array($rows)) foreach ($rows as $row) {
		$out[] = array(
			'date' => purchase_history_time($row['time'] ?? 0),
			'name' => 'Type ' . (int)($row['type'] ?? 0) . ' / Item ' . (int)($row['itemid'] ?? 0),
			'amount' => (int)($row['count'] ?? 0) . 'x',
			'status' => '-' . number_format((int)($row['points'] ?? 0)) . ' pts',
		);
	}
	return $out;
}
function purchase_history_payments(int $accountId): array {
	$out = array();
	if (function_exists('znote_table_exists') && znote_table_exists('znote_payment_transactions')) {
		$rows = db()->fetchAll("SELECT `provider`,`price`,`currency`,`points`,`status`,`credited`,`created_at`,`credited_at` FROM `znote_payment_transactions` WHERE `account_id` = ? ORDER BY `created_at` DESC LIMIT 30;", [$accountId]);
		if (is_array($rows)) foreach ($rows as $row) {
			$out[] = array(
				'date' => purchase_history_time((int)($row['credited_at'] ?: $row['created_at'])),
				'name' => ucfirst((string)$row['provider']),
				'amount' => number_format((float)$row['price'], 2) . ' ' . (string)$row['currency'],
				'status' => ((int)$row['credited'] === 1 ? '+' . number_format((int)$row['points']) . ' pts' : (string)$row['status']),
			);
		}
	}
	$cols = purchase_history_table_columns('znote_paypal');
	if (isset($cols['custom'], $cols['points'])) {
		$timeCol = isset($cols['created']) ? 'created' : (isset($cols['time']) ? 'time' : '');
		$timeSql = $timeCol !== '' ? "`{$timeCol}` AS `paid_at`" : "0 AS `paid_at`";
		$rows = db()->fetchAll("SELECT {$timeSql},`points` FROM `znote_paypal` WHERE `custom` = ? AND `points`>0 ORDER BY `paid_at` DESC LIMIT 20;", [$accountId]);
		if (is_array($rows)) foreach ($rows as $row) $out[] = array('date' => purchase_history_time($row['paid_at'] ?? 0), 'name' => 'PayPal', 'amount' => '', 'status' => '+' . number_format((int)$row['points']) . ' pts');
	}
	return array_slice($out, 0, 30);
}
function purchase_history_starter(int $accountId): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_starter_pack_transactions')) return array();
	$rows = db()->fetchAll("SELECT `pack_key`,`price`,`currency`,`status`,`delivered`,`created_at`,`delivered_at` FROM `znote_starter_pack_transactions` WHERE `account_id` = ? ORDER BY `created_at` DESC LIMIT 30;", [$accountId]);
	$out = array();
	if (is_array($rows)) foreach ($rows as $row) {
		$status = (string)$row['status'] . ((int)($row['delivered'] ?? 0) === 1 ? ' / delivered' : '');
		$out[] = array(
			'date' => purchase_history_time((int)($row['delivered_at'] ?: $row['created_at'])),
			'name' => (string)$row['pack_key'],
			'amount' => number_format((float)$row['price'], 2) . ' ' . (string)$row['currency'],
			'status' => $status,
		);
	}
	return $out;
}
function purchase_history_rows_html(array $rows): string {
	if (!$rows) return '<p class="ph-empty">' . purchase_history_h(t_default('purchase_history.empty', 'No purchases found.')) . '</p>';
	$html = '<div class="ph-table-wrap"><table class="ph-table"><thead><tr><th>' . purchase_history_h(t_default('purchase_history.date', 'Date')) . '</th><th>' . purchase_history_h(t_default('purchase_history.item', 'Item')) . '</th><th>' . purchase_history_h(t_default('purchase_history.amount', 'Amount')) . '</th><th>' . purchase_history_h(t_default('purchase_history.status', 'Status')) . '</th></tr></thead><tbody>';
	foreach ($rows as $row) {
		$html .= '<tr><td>' . purchase_history_h($row['date']) . '</td><td>' . purchase_history_h($row['name']) . '</td><td>' . purchase_history_h($row['amount']) . '</td><td>' . purchase_history_h($row['status']) . '</td></tr>';
	}
	return $html . '</tbody></table></div>';
}
function purchase_history_footer(): string {
	if (!purchase_history_enabled() || basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'myaccount.php' || empty($GLOBALS['session_user_id'])) return '';
	$accountId = (int)$GLOBALS['session_user_id'];
	$shop = purchase_history_rows_html(purchase_history_shop($accountId));
	$payments = purchase_history_rows_html(purchase_history_payments($accountId));
	$starter = purchase_history_rows_html(purchase_history_starter($accountId));
	$css = '.ph-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 18px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);overflow:hidden}.ph-box *{box-sizing:border-box}.ph-tabs{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}.ph-tab{display:inline-flex;align-items:center;justify-content:center;min-height:36px;border:1px solid var(--ph-tab-border,var(--znx-plugin-border));border-radius:6px;background:var(--ph-tab-bg,var(--button-bg,var(--btn-bg,var(--znx-plugin-surface))));color:var(--ph-tab-text,var(--button-text,var(--btn-text,var(--znx-plugin-text))));padding:7px 18px;font-weight:700;text-transform:uppercase;cursor:pointer;opacity:.92;transition:filter .15s ease,opacity .15s ease,transform .15s ease}.ph-tab:hover,.ph-tab:focus,.ph-tab.is-active{background:var(--ph-tab-active-bg,var(--ph-tab-bg,var(--button-hover-bg,var(--button-bg,var(--btn-bg,var(--znx-plugin-surface))))));color:var(--ph-tab-active-text,var(--ph-tab-text,var(--button-text,var(--btn-text,var(--znx-plugin-text)))));border-color:var(--ph-tab-active-border,var(--ph-tab-border,var(--znx-plugin-border)));opacity:1;filter:brightness(1.08)}.ph-tab.is-active{transform:translateY(0)}.ph-panel{display:none}.ph-panel.is-active{display:block}.ph-table-wrap{max-width:100%;overflow:auto}.ph-table{width:100%;border-collapse:collapse;background:var(--ph-table-bg,transparent);color:var(--znx-plugin-text)}.ph-table th,.ph-table td{padding:8px;border-bottom:1px solid var(--znx-plugin-border);text-align:left}.ph-table tr{background:var(--ph-row-bg,transparent)}.ph-empty{color:var(--ph-muted,var(--znx-plugin-text));opacity:.72}';
	$html = '<section id="purchaseHistoryBox" class="ph-box"' . purchase_history_style_attr(array('box_bg'=>'--znx-plugin-surface','text'=>'--znx-plugin-text','border'=>'--znx-plugin-border','tab_bg'=>'--ph-tab-bg','tab_active_bg'=>'--ph-tab-active-bg','tab_text'=>'--ph-tab-text','table_bg'=>'--ph-table-bg','row_bg'=>'--ph-row-bg','muted'=>'--ph-muted')) . '><h2>' . purchase_history_h(t_default('purchase_history.title', 'Purchase History')) . '</h2><div class="ph-tabs"><button class="ph-tab is-active" type="button" data-ph-tab="shop">' . purchase_history_h(t_default('purchase_history.shop', 'Shop')) . '</button><button class="ph-tab" type="button" data-ph-tab="payments">' . purchase_history_h(t_default('purchase_history.payments', 'Payments')) . '</button><button class="ph-tab" type="button" data-ph-tab="starter">' . purchase_history_h(t_default('purchase_history.starter', 'Starter Packs')) . '</button></div><div class="ph-panel is-active" data-ph-panel="shop">' . $shop . '</div><div class="ph-panel" data-ph-panel="payments">' . $payments . '</div><div class="ph-panel" data-ph-panel="starter">' . $starter . '</div></section>';
	$js = '(function(){if(document.getElementById("purchaseHistoryBox"))return;var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);var root=document.getElementById("myaccount")||document.querySelector("main,#content,.content");if(!root)return;var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';var box=w.firstChild;root.appendChild(box);box.addEventListener("click",function(e){var tab=e.target.closest("[data-ph-tab]");if(!tab)return;var name=tab.getAttribute("data-ph-tab");box.querySelectorAll(".ph-tab").forEach(function(t){t.classList.toggle("is-active",t===tab);});box.querySelectorAll(".ph-panel").forEach(function(p){p.classList.toggle("is-active",p.getAttribute("data-ph-panel")===name);});});}());';
	return '<script>' . $js . '</script>';
}
}
if (function_exists('znote_hook_register')) znote_hook_register('page.footer', 'purchase_history_footer');
