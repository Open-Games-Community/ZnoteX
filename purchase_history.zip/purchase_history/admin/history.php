<?php
/**
 * Title: Purchase History
 * Icon: fa-receipt
 * Group: Installed Plugins
 * Order: 80
 * Description: Configure the My Account purchase history panel.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

function purchase_history_admin_color($value): string {
	$value = trim((string)$value);
	return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value) ? $value : '';
}

$styleKeys = array(
	'box_bg' => 'Box background',
	'text' => 'Text color',
	'border' => 'Border color',
	'tab_bg' => 'Tab background',
	'tab_active_bg' => 'Active tab background',
	'tab_text' => 'Tab text',
	'table_bg' => 'Table background',
	'row_bg' => 'Row background',
	'muted' => 'Muted text',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	setting_set('purchase_history:enabled', !empty($_POST['enabled']) ? '1' : '0');
	foreach ($styleKeys as $key => $label) {
		setting_set('purchase_history:style_' . $key, purchase_history_admin_color($_POST['style_' . $key] ?? ''));
	}
	acp_flash_success('Purchase History settings saved.');
	acp_redirect('purchase_history__history');
}
?>
<?php acp_card_open('Purchase History', 'Adds a compact purchase history section inside My Account. Leave colours empty to inherit the theme, with default theme fallback.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-field"><label><input type="checkbox" name="enabled" value="1" <?= setting('purchase_history:enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
	<div class="acp-grid acp-grid--2">
		<?php foreach ($styleKeys as $key => $label): ?>
			<div class="acp-field">
				<label class="acp-label"><?= h($label) ?></label>
				<input class="acp-input" name="style_<?= h($key) ?>" value="<?= h(setting('purchase_history:style_' . $key, '')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)">
			</div>
		<?php endforeach; ?>
	</div>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit">Save</button></div>
</form>
<?php acp_card_close(); ?>
