<?php

return array(
	'purchase_history.title' => 'Historico de compras',
	'purchase_history.shop' => 'Loja',
	'purchase_history.payments' => 'Pagamentos',
	'purchase_history.starter' => 'Pacotes iniciais',
	'purchase_history.empty' => 'Nenhuma compra encontrada.',
	'purchase_history.date' => 'Data',
	'purchase_history.item' => 'Item',
	'purchase_history.amount' => 'Valor',
	'purchase_history.status' => 'Status',
);
