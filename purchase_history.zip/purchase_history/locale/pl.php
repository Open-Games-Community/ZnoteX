<?php

return array(
	'purchase_history.title' => 'Historia zakupow',
	'purchase_history.shop' => 'Sklep',
	'purchase_history.payments' => 'Platnosci',
	'purchase_history.starter' => 'Pakiety startowe',
	'purchase_history.empty' => 'Nie znaleziono zakupow.',
	'purchase_history.date' => 'Data',
	'purchase_history.item' => 'Przedmiot',
	'purchase_history.amount' => 'Kwota',
	'purchase_history.status' => 'Status',
);
