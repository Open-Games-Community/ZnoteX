<?php

return array(
	'purchase_history.title' => 'Purchase History',
	'purchase_history.shop' => 'Shop',
	'purchase_history.payments' => 'Payments',
	'purchase_history.starter' => 'Starter Packs',
	'purchase_history.empty' => 'No purchases found.',
	'purchase_history.date' => 'Date',
	'purchase_history.item' => 'Item',
	'purchase_history.amount' => 'Amount',
	'purchase_history.status' => 'Status',
);
