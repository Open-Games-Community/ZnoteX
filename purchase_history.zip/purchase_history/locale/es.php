<?php

return array(
	'purchase_history.title' => 'Historial de compras',
	'purchase_history.shop' => 'Tienda',
	'purchase_history.payments' => 'Pagos',
	'purchase_history.starter' => 'Packs iniciales',
	'purchase_history.empty' => 'No se encontraron compras.',
	'purchase_history.date' => 'Fecha',
	'purchase_history.item' => 'Articulo',
	'purchase_history.amount' => 'Importe',
	'purchase_history.status' => 'Estado',
);
