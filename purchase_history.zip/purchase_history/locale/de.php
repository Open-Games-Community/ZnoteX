<?php

return array(
	'purchase_history.title' => 'Kaufverlauf',
	'purchase_history.shop' => 'Shop',
	'purchase_history.payments' => 'Zahlungen',
	'purchase_history.starter' => 'Starter-Pakete',
	'purchase_history.empty' => 'Keine Kaufe gefunden.',
	'purchase_history.date' => 'Datum',
	'purchase_history.item' => 'Artikel',
	'purchase_history.amount' => 'Betrag',
	'purchase_history.status' => 'Status',
);
