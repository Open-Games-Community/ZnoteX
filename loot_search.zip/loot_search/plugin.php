<?php
/**
 * Loot Search - "which monster / boss drops this item", plus the reverse.
 *
 * Read-only. Builds znote_loot_index + znote_loot_monster from either the
 * ZnoteX Server-Info cache (items.xml + data/monster zip, uploaded in the ACP)
 * or a folder path it scans itself - parsing both XML (TFS / OTHire / OTX) and
 * Lua (Canary) monster files. No core change; menu entry under Library.
 */
if (!function_exists('loot_search_setting')) {

function loot_search_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('loot_search:' . $k, $d) : $d;
}
function loot_search_enabled(): bool { return loot_search_setting('enabled', '1') === '1'; }
function loot_search_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function loot_search_int(string $k, int $d): int { $v = loot_search_setting($k, ''); return $v === '' ? $d : (int) $v; }
function loot_search_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function loot_search_css(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function loot_search_color(string $k): string { return loot_search_css(loot_search_setting('style_' . $k, '')); }
function loot_search_style_attr(): string {
	$map = array('box_bg' => '--ls-surface', 'border' => '--ls-border', 'text' => '--ls-text', 'accent' => '--ls-accent',
		'row_bg' => '--ls-row', 'head_bg' => '--ls-head-bg', 'head_text' => '--ls-head-text',
		'tab_bg' => '--ls-tab', 'tab_active' => '--ls-tab-active', 'button_bg' => '--ls-btn-bg', 'button_text' => '--ls-btn-text',
		'search_bg' => '--ls-search-bg');
	$css = '';
	foreach ($map as $k => $var) { $v = loot_search_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	$r = loot_search_int('style_radius', 12);
	if ($r >= 0 && $r <= 30) $css .= '--ls-radius:' . $r . 'px;';
	return $css !== '' ? ' style="' . loot_search_h($css) . '"' : '';
}
function loot_search_tables_ok(): bool {
	return function_exists('znote_table_exists') && znote_table_exists('znote_loot_index');
}

// --- elements (the real Tibia set) -------------------------------
function loot_search_elements(): array {
	return array(
		'physical'  => array('#c9c9c9', 'Physical'),
		'fire'      => array('#ff6b3d', 'Fire'),
		'ice'       => array('#7fd7ff', 'Ice'),
		'energy'    => array('#c07bff', 'Energy'),
		'earth'     => array('#7bd66b', 'Earth'),
		'holy'      => array('#ffe27a', 'Holy'),
		'death'     => array('#9a7bd6', 'Death'),
		'healing'   => array('#67e0a3', 'Healing'),
		'drown'     => array('#5aa9ff', 'Drown'),
		'lifedrain' => array('#d64b6b', 'Life Drain'),
		'manadrain' => array('#4b7bd6', 'Mana Drain'),
	);
}
function loot_search_element_from_xml_attr(string $attr): string {
	$attr = strtolower($attr);
	$attr = str_replace('percent', '', $attr);
	if ($attr === 'poison') $attr = 'earth';
	return array_key_exists($attr, loot_search_elements()) ? $attr : '';
}
function loot_search_element_from_lua_const(string $c): string {
	$m = array('firedamage' => 'fire', 'icedamage' => 'ice', 'energydamage' => 'energy', 'earthdamage' => 'earth',
		'holydamage' => 'holy', 'deathdamage' => 'death', 'physicaldamage' => 'physical', 'healingdamage' => 'healing',
		'drowndamage' => 'drown', 'lifedrain' => 'lifedrain', 'manadrain' => 'manadrain', 'poisondamage' => 'earth');
	$c = preg_replace('/^combat_/', '', strtolower($c));
	return $m[$c] ?? '';
}

// --- item names + images --------------------------------------
/**
 * Normalise an image-server base. Accepts:
 *   https://host/path  http://host/path  //host/path   (returned as-is)
 *   /items                                             (site-root relative)
 *   host/path                                          (no scheme -> http://)
 * A local filesystem folder (F:/pics, /var/pics, \\srv\pics) is handled
 * separately by loot_search_local_dir() + the streaming endpoint.
 */
function loot_search_normalize_base(string $srv): string {
	$srv = trim($srv);
	if ($srv === '') return '';
	if (preg_match('#^(https?:)?//#i', $srv)) return $srv;
	if (preg_match('#^[a-zA-Z]:[\\\\/]#', $srv) || strncmp($srv, '\\\\', 2) === 0) return ''; // a disk path, not a URL
	if ($srv[0] === '/') return $srv;
	return 'http://' . $srv;
}
/**
 * The image server (plugin setting, or the matching core config as fallback)
 * resolved to a readable folder on disk, or '' if it is not a local folder.
 */
function loot_search_local_dir(string $which): string {
	static $cache = array();
	if (isset($cache[$which])) return $cache[$which];
	$srv = trim(loot_search_setting($which . '_image_server', ''));
	if ($srv === '') {
		global $config;
		$srv = trim((string) ($which === 'item'
			? ($config['shop']['imageServer'] ?? '')
			: ($config['show_outfits']['imageServer'] ?? '')));
	}
	if ($srv === '' || preg_match('#^(https?:)?//#i', $srv)) return $cache[$which] = '';
	$real = @realpath($srv);
	return $cache[$which] = ($real !== false && @is_dir($real)) ? $real : '';
}
function loot_search_img_endpoint(string $t, int $id): string {
	return 'page.php?loot_search_img=1&t=' . ($t === 'outfit' ? 'outfit' : 'item') . '&id=' . $id;
}
function loot_search_item_image(int $id): string {
	if ($id <= 0) return '';
	if (loot_search_local_dir('item') !== '') return loot_search_img_endpoint('item', $id);
	$srv = trim(loot_search_setting('item_image_server', ''));
	$type = 'gif';
	if ($srv === '') {
		global $config;
		if (!empty($config['shop']['showImage'])) {
			$srv = trim((string) ($config['shop']['imageServer'] ?? ''));
			$type = preg_replace('/[^a-z0-9]/i', '', (string) ($config['shop']['imageType'] ?? 'gif')) ?: 'gif';
		}
	}
	$srv = loot_search_normalize_base($srv);
	if ($srv === '') return '';
	return rtrim($srv, '/') . '/' . $id . '.' . $type;
}
function loot_search_outfit_image(int $looktype): string {
	if ($looktype <= 0) return '';
	if (loot_search_local_dir('outfit') !== '') return loot_search_img_endpoint('outfit', $looktype);
	$srv = trim(loot_search_setting('outfit_image_server', ''));
	if ($srv === '') {
		global $config;
		$srv = trim((string) ($config['show_outfits']['imageServer'] ?? ''));
	}
	$srv = loot_search_normalize_base($srv);
	if ($srv === '') return '';
	return $srv . (strpos($srv, '?') !== false ? '&' : '?') . 'id=' . $looktype . '&addons=0&head=0&body=0&legs=0&feet=0&direction=3';
}
/** Streams a local image file when an image server is set to a disk folder. */
function loot_search_handle_image(): void {
	if (($_GET['loot_search_img'] ?? '') === '' || !isset($_GET['id'])) return;
	while (ob_get_level() > 0) ob_end_clean();
	$t   = (($_GET['t'] ?? 'item') === 'outfit') ? 'outfit' : 'item';
	$id  = (int) $_GET['id'];
	$dir = loot_search_local_dir($t);
	if ($dir === '' || $id <= 0) { http_response_code(404); exit; }

	$exts = ($t === 'item') ? array('png', 'gif', 'jpg', 'jpeg', 'webp') : array('png', 'gif', 'jpg', 'jpeg');
	$cfg  = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) loot_search_setting($t . '_image_type', '')));
	if ($cfg === '' && $t === 'item') {
		global $config;
		$cfg = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) ($config['shop']['imageType'] ?? '')));
	}
	if ($cfg !== '') array_unshift($exts, $cfg);

	$file = '';
	foreach (array_unique($exts) as $e) {
		$p = $dir . DIRECTORY_SEPARATOR . $id . '.' . $e;
		if (is_file($p)) { $file = $p; break; }
	}
	$real = $file !== '' ? realpath($file) : false;
	if ($real === false || strncmp($real, $dir, strlen($dir)) !== 0) { http_response_code(404); exit; }

	$mimes = array('png' => 'image/png', 'gif' => 'image/gif', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp');
	$ext = strtolower(pathinfo($real, PATHINFO_EXTENSION));
	header('Content-Type: ' . ($mimes[$ext] ?? 'application/octet-stream'));
	header('Content-Length: ' . (string) filesize($real));
	header('Cache-Control: public, max-age=86400');
	header('X-Content-Type-Options: nosniff');
	readfile($real);
	exit;
}
/**
 * Directories to scan for monster files. Under $config['server_path'] it adds
 * EVERY <folder>/monster(s) it finds, not just the first - Canary/otservbr keep
 * two (data/monster + data-otservbr-global/monster), and a server can mix XML
 * and Lua across data folders. Plus up to 3 custom paths.
 */
function loot_search_paths(): array {
	$out = array();
	if (loot_search_setting('use_server_path', '1') === '1') {
		global $config;
		$sp = rtrim((string) ($config['server_path'] ?? ''), "/\\");
		if ($sp !== '' && is_dir($sp)) {
			$cands = array($sp . '/monster', $sp . '/monsters');
			foreach ((array) glob($sp . '/*/monster', GLOB_ONLYDIR) as $c) $cands[] = $c;
			foreach ((array) glob($sp . '/*/monsters', GLOB_ONLYDIR) as $c) $cands[] = $c;
			foreach ($cands as $c) if (is_dir($c)) $out[] = $c;
			if (!$out) foreach (array($sp . '/data', $sp) as $c) if (is_dir($c)) { $out[] = $c; break; }
		}
	}
	foreach (array('custom_path_1', 'custom_path_2', 'custom_path_3') as $k) {
		$p = trim(loot_search_setting($k, ''));
		if ($p !== '' && is_dir($p)) $out[] = $p;
	}
	return array_values(array_unique($out));
}
function loot_search_find_items_xml(): string {
	$explicit = trim(loot_search_setting('items_xml_path', ''));
	if ($explicit !== '' && is_file($explicit)) return $explicit;

	$cands = array();
	// near each monster folder (…/monster -> …/../items/items.xml, etc.)
	foreach (loot_search_paths() as $path) {
		$cands[] = $path . '/items.xml';
		$cands[] = $path . '/items/items.xml';
		$cands[] = dirname($path) . '/items.xml';
		$cands[] = dirname($path) . '/items/items.xml';
		$cands[] = dirname(dirname($path)) . '/items/items.xml';
	}
	// anywhere under the server path (data/items/items.xml, data-otservbr-global/items/items.xml, …)
	if (loot_search_setting('use_server_path', '1') === '1') {
		global $config;
		$sp = rtrim((string) ($config['server_path'] ?? ''), "/\\");
		if ($sp !== '' && is_dir($sp)) {
			$cands[] = $sp . '/items.xml';
			$cands[] = $sp . '/items/items.xml';
			foreach ((array) glob($sp . '/*/items/items.xml') as $c) $cands[] = $c;
			foreach ((array) glob($sp . '/*/items.xml') as $c) $cands[] = $c;
		}
	}
	foreach ($cands as $c) if ($c !== '' && is_file($c)) return $c;
	if (function_exists('serverdata_file')) {
		$sf = serverdata_file('items.xml');
		if (is_file($sf)) return $sf;
	}
	return '';
}
function loot_search_items_map(): array {
	$file = loot_search_find_items_xml();
	$map = array();
	if ($file !== '') {
		$xml = @simplexml_load_file($file);
		if ($xml !== false) foreach ($xml->item as $it) {
			$id = (int) $it['id'];
			if ($id > 0) $map[$id] = (string) $it['name'];
			if (isset($it['fromid'], $it['toid'])) {
				for ($i = (int) $it['fromid']; $i <= (int) $it['toid'] && $i - (int) $it['fromid'] < 500; $i++) $map[$i] = (string) $it['name'];
			}
		}
	}
	return $map;
}
/** lowercased item name => lowest id, so name-only loot can be given an id. */
function loot_search_items_by_name(array $idToName): array {
	$byName = array();
	foreach ($idToName as $id => $name) {
		$k = strtolower(trim((string) $name));
		if ($k === '') continue;
		if (!isset($byName[$k]) || (int) $id < $byName[$k]) $byName[$k] = (int) $id;
	}
	return $byName;
}

// --- parsing one monster ------------------------------------
function loot_search_flatten_xml($items, int $level, array &$rows): void {
	foreach ($items as $e) {
		$chance = (float) $e['chance'];
		if (!$chance) $chance = (float) $e['chance1'];
		$rows[] = array(
			'id'    => (int) $e['id'],
			'name'  => (string) $e['name'],
			'min'   => max(1, (int) ($e['countmin'] ?? $e['count'] ?? 1)),
			'max'   => max(1, (int) ($e['countmax'] ?? $e['count'] ?? 1)),
			'chance' => min(100, $chance / 1000),
			'level' => $level,
		);
		if (isset($e->item)) loot_search_flatten_xml($e->item, $level + 1, $rows);
		if (isset($e->inside->item)) loot_search_flatten_xml($e->inside->item, $level + 1, $rows);
	}
}
function loot_search_parse_xml_monster(string $file): ?array {
	$xml = @simplexml_load_file($file);
	if ($xml === false) return null;
	$name = (string) $xml['name'];
	if ($name === '') return null;
	$exp = (int) ($xml['experience'] ?: ($xml->experience['value'] ?? 0));
	$hp  = (int) ($xml['health'] ?: ($xml->health['max'] ?? $xml->health['now'] ?? 0));
	$race = strtolower((string) ($xml['race'] ?: ($xml->race ?? '')));
	$look = (int) ($xml->look['type'] ?? $xml->look['typeex'] ?? 0);
	$speed = (int) ($xml['speed'] ?: ($xml->speed['value'] ?? $xml->flags->flag['runspeed'] ?? 0));
	$armor = (int) ($xml->defense['armor'] ?? $xml->defenses['armor'] ?? 0);
	$defense = (int) ($xml->defense['defense'] ?? $xml->defenses['defense'] ?? 0);

	$elem = array(); $imm = array();
	if (isset($xml->elements->element)) {
		foreach ($xml->elements->element as $el) {
			foreach ($el->attributes() as $an => $av) {
				$k = loot_search_element_from_xml_attr((string) $an);
				if ($k !== '') { $v = (int) $av; $elem[$k] = $v; if ($v >= 100) $imm[$k] = true; }
			}
		}
	}
	if (isset($xml->immunities->immunity)) {
		foreach ($xml->immunities->immunity as $im) {
			foreach ($im->attributes() as $an => $av) {
				if ((string) $av === '1') { $k = loot_search_element_from_xml_attr((string) $an); if ($k !== '') $imm[$k] = true; }
			}
		}
	}

	$rows = array();
	if (isset($xml->loot->item)) loot_search_flatten_xml($xml->loot->item, 1, $rows);
	return array('name' => $name, 'health' => $hp, 'experience' => $exp, 'speed' => $speed, 'armor' => $armor, 'defense' => $defense,
		'race' => $race, 'looktype' => $look, 'elements' => $elem, 'immunities' => array_keys($imm), 'bestiary' => array(), 'loot' => $rows);
}
function loot_search_lua_block(string $src, string $marker): string {
	$p = strpos($src, $marker);
	if ($p === false) return '';
	$p = strpos($src, '{', $p);
	if ($p === false) return '';
	$depth = 0; $out = '';
	for ($i = $p, $n = strlen($src); $i < $n; $i++) {
		$c = $src[$i];
		if ($c === '{') $depth++;
		elseif ($c === '}') { $depth--; if ($depth === 0) break; }
		$out .= $c;
	}
	return substr($out, 1);
}
function loot_search_lua_entries(string $block): array {
	// $block includes its outer { }. Depth 1 = the list; each depth-2 {..} is one entry.
	$entries = array(); $depth = 0; $start = -1;
	for ($i = 0, $n = strlen($block); $i < $n; $i++) {
		$c = $block[$i];
		if ($c === '{') { $depth++; if ($depth === 2) $start = $i + 1; }
		elseif ($c === '}') { if ($depth === 2 && $start >= 0) { $entries[] = substr($block, $start, $i - $start); $start = -1; } $depth--; }
	}
	return $entries;
}
function loot_search_parse_lua_monster(string $file): ?array {
	$src = @file_get_contents($file);
	if ($src === false || $src === '') return null;
	$name = '';
	if (preg_match('/createMonsterType\(\s*["\']([^"\']+)["\']/', $src, $m)) $name = $m[1];
	elseif (preg_match('/monster\.name\s*=\s*["\']([^"\']+)["\']/', $src, $m)) $name = $m[1];
	if ($name === '') return null;
	$exp = preg_match('/monster\.experience\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0;
	$hp = preg_match('/monster\.(?:maxHealth|health)\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0;
	$race = preg_match('/monster\.race\s*=\s*["\']([^"\']+)["\']/', $src, $m) ? strtolower($m[1]) : '';
	$look = preg_match('/\blookType\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : (preg_match('/\blookTypeEx\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0);
	$speed = preg_match('/monster\.speed\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0;
	$armor = preg_match('/monster\.armor\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0;
	$defense = preg_match('/monster\.defense\s*=\s*(\d+)/', $src, $m) ? (int) $m[1] : 0;

	$elem = array();
	$eb = loot_search_lua_block($src, 'monster.elements');
	if ($eb !== '') foreach (loot_search_lua_entries('{' . $eb . '}') as $e) {
		if (preg_match('/type\s*=\s*([A-Za-z_]+).*?percent\s*=\s*(-?\d+)/s', $e, $mm)) {
			$k = loot_search_element_from_lua_const($mm[1]);
			if ($k !== '') $elem[$k] = (int) $mm[2];
		}
	}
	$imm = array();
	$ib = loot_search_lua_block($src, 'monster.immunities');
	if ($ib !== '') foreach (loot_search_lua_entries('{' . $ib . '}') as $e) {
		if (preg_match('/type\s*=\s*["\']?([A-Za-z_]+)/', $e, $mm)) {
			$k = loot_search_element_from_lua_const($mm[1]);
			if ($k === '') $k = (array_key_exists(strtolower($mm[1]), loot_search_elements()) ? strtolower($mm[1]) : '');
			if ($k !== '') $imm[$k] = true;
		}
	}
	foreach ($elem as $k => $v) if ($v >= 100) $imm[$k] = true;

	$best = array();
	$bb = loot_search_lua_block($src, 'monster.bestiary');
	if ($bb !== '') {
		$grab = static function ($k) use ($bb) { return preg_match('/\b' . $k . '\s*=\s*(-?\d+)/i', $bb, $mm) ? (int) $mm[1] : null; };
		$class = preg_match('/\bclass\s*=\s*["\']([^"\']+)["\']/i', $bb, $mm) ? $mm[1] : '';
		$brace = preg_match('/\brace\s*=\s*BESTY_RACE_([A-Z_]+)/i', $bb, $mm) ? ucwords(strtolower(str_replace('_', ' ', $mm[1]))) : '';
		$best = array_filter(array(
			'class'      => $class,
			'race'       => $brace,
			'kills'      => $grab('toKill') ?? $grab('Kills'),
			'first'      => $grab('FirstUnlock'),
			'second'     => $grab('SecondUnlock'),
			'charm'      => $grab('CharmsPoints') ?? $grab('charmPoints'),
			'stars'      => $grab('Stars'),
			'occurrence' => $grab('Occurrence'),
		), static fn($v) => $v !== null && $v !== '');
	}

	$rows = array();
	$lb = loot_search_lua_block($src, 'monster.loot');
	if ($lb !== '') loot_search_lua_loot('{' . $lb . '}', 1, $rows);
	return array('name' => $name, 'health' => $hp, 'experience' => $exp, 'speed' => $speed, 'armor' => $armor, 'defense' => $defense,
		'race' => $race, 'looktype' => $look, 'elements' => $elem, 'immunities' => array_keys($imm), 'bestiary' => $best, 'loot' => $rows);
}
function loot_search_lua_str(string $s, string $key): string {
	if (preg_match('/\b' . $key . '\s*=\s*"([^"]*)"/', $s, $m)) return $m[1];
	if (preg_match("/\\b" . $key . "\\s*=\\s*'([^']*)'/", $s, $m)) return $m[1];
	return '';
}
function loot_search_lua_loot(string $block, int $level, array &$rows): void {
	foreach (loot_search_lua_entries($block) as $e) {
		$childPos = stripos($e, 'child');
		$head = $childPos !== false ? substr($e, 0, $childPos) : $e;
		$id = preg_match('/\bid\s*=\s*(\d+)/', $head, $m) ? (int) $m[1] : 0;
		$nm = loot_search_lua_str($head, 'name');
		$chance = preg_match('/\bchance\s*=\s*(\d+)/', $head, $m) ? (float) $m[1] : 0;
		$maxc = preg_match('/\bmaxCount\s*=\s*(\d+)/', $head, $m) ? (int) $m[1] : 1;
		$minc = preg_match('/\bminCount\s*=\s*(\d+)/', $head, $m) ? (int) $m[1] : 1;
		if ($id > 0 || $nm !== '') {
			$rows[] = array('id' => $id, 'name' => $nm, 'min' => max(1, $minc), 'max' => max(1, $maxc), 'chance' => min(100, $chance / 1000), 'level' => $level);
		}
		if ($childPos !== false) {
			$cb = loot_search_lua_block($e, 'child');
			if ($cb !== '') loot_search_lua_loot('{' . $cb . '}', $level + 1, $rows);
		}
	}
}

// --- boss classification ----------------------------------
function loot_search_boss_names(): array {
	$out = array();
	foreach (preg_split('/[\r\n,;]+/', (string) loot_search_setting('boss_names', '')) as $n) {
		$n = strtolower(trim($n));
		if ($n !== '') $out[$n] = true;
	}
	return $out;
}
function loot_search_is_boss(array $m, string $file, array $bossNames): bool {
	if (isset($bossNames[strtolower($m['name'])])) return true;
	if (stripos($file, 'boss') !== false) return true;
	$he = loot_search_int('boss_min_hp', 0);
	$xe = loot_search_int('boss_min_exp', 0);
	if ($he > 0 && (int) $m['health'] >= $he) return true;
	if ($xe > 0 && (int) $m['experience'] >= $xe) return true;
	return false;
}

// --- build the index --------------------------------------
function loot_search_blank_monster(string $name): array {
	return array('name' => $name, 'health' => 0, 'experience' => 0, 'speed' => 0, 'armor' => 0, 'defense' => 0,
		'race' => '', 'looktype' => 0, 'elements' => array(), 'immunities' => array(), 'bestiary' => array(), 'loot' => array(), '__file' => '');
}
/** Merge $b into $a: keep $a's non-empty fields, fill from $b, take the richer loot. */
function loot_search_merge(array $a, array $b): array {
	foreach (array('health', 'experience', 'speed', 'armor', 'defense', 'looktype') as $k) {
		if ((int) $a[$k] === 0 && (int) ($b[$k] ?? 0) > 0) $a[$k] = (int) $b[$k];
	}
	if ($a['race'] === '' && ($b['race'] ?? '') !== '') $a['race'] = $b['race'];
	if (!$a['elements'] && !empty($b['elements'])) $a['elements'] = $b['elements'];
	if (!$a['immunities'] && !empty($b['immunities'])) $a['immunities'] = $b['immunities'];
	if (!$a['bestiary'] && !empty($b['bestiary'])) $a['bestiary'] = $b['bestiary'];
	if (count((array) ($b['loot'] ?? array())) > count((array) $a['loot'])) { $a['loot'] = $b['loot']; if (($b['__file'] ?? '') !== '') $a['__file'] = $b['__file']; }
	elseif ($a['__file'] === '' && ($b['__file'] ?? '') !== '') $a['__file'] = $b['__file'];
	return $a;
}
function loot_search_scan_path(string $path, array &$monsters, int &$budget): void {
	if (!is_dir($path)) return;
	try {
		$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS));
	} catch (Throwable $e) { return; }
	foreach ($rii as $f) {
		if (--$budget <= 0) return;
		$fp = $f->getPathname();
		$ext = strtolower($f->getExtension());
		$base = strtolower($f->getFilename());
		if ($base === 'items.xml' || $base === 'monsters.xml' || $base === 'monster.xml') continue;
		$m = null;
		if ($ext === 'xml') {
			$peek = @file_get_contents($fp, false, null, 0, 500);
			if ($peek === false || stripos($peek, '<monster') === false) continue;
			$m = loot_search_parse_xml_monster($fp);
		} elseif ($ext === 'lua') {
			$peek = @file_get_contents($fp, false, null, 0, 800);
			if ($peek === false || (stripos($peek, 'createmonstertype') === false && stripos($peek, 'monster.name') === false)) continue;
			$m = loot_search_parse_lua_monster($fp);
		} else {
			continue;
		}
		if (!$m || $m['name'] === '') continue;
		$m['__file'] = $fp;
		$k = strtolower($m['name']);
		$monsters[$k] = isset($monsters[$k]) ? loot_search_merge($monsters[$k], $m) : $m;
	}
}
function loot_search_collect(): array {
	$monsters = array();
	$budget = 12000;

	foreach (loot_search_paths() as $p) loot_search_scan_path($p, $monsters, $budget);

	// ZnoteX Server-Info monster_loot cache (XML upload) - loot already flattened, chance already percent
	if (loot_search_setting('use_znotex_cache', '1') === '1' && class_exists('Cache')) {
		$c = new Cache('engine/cache/monster_loot');
		$c->useMemory(false);
		$c->setExpiration(PHP_INT_MAX);
		$loaded = $c->load();
		if (is_array($loaded) && isset($loaded['monsters'])) {
			foreach ($loaded['monsters'] as $mm) {
				$rows = array();
				foreach ((array) ($mm['loot'] ?? array()) as $d) {
					$rows[] = array('id' => (int) $d['id'], 'name' => '', 'min' => 1, 'max' => max(1, (int) ($d['count'] ?? 1)), 'chance' => (float) ($d['chance'] ?? 0), 'level' => (int) ($d['level'] ?? 1));
				}
				$entry = loot_search_blank_monster((string) $mm['name']);
				$entry['loot'] = $rows;
				$entry['__file'] = (string) ($mm['file'] ?? '');
				$k = strtolower((string) $mm['name']);
				$monsters[$k] = isset($monsters[$k]) ? loot_search_merge($monsters[$k], $entry) : $entry;
			}
		}
	}

	// enrich meta from the parsed creatures cache (health / exp / race / looktype)
	if (function_exists('serverdata_load')) {
		$cr = serverdata_load('creatures');
		if (is_array($cr) && isset($cr['creatures'])) {
			foreach ($cr['creatures'] as $c) {
				$k = strtolower((string) ($c['name'] ?? ''));
				if (!isset($monsters[$k])) continue;
				if ((int) $monsters[$k]['health'] === 0) $monsters[$k]['health'] = (int) ($c['health'] ?? 0);
				if ((int) $monsters[$k]['experience'] === 0) $monsters[$k]['experience'] = (int) ($c['experience'] ?? 0);
				if ($monsters[$k]['race'] === '') $monsters[$k]['race'] = strtolower((string) ($c['race'] ?? ''));
				if ((int) $monsters[$k]['looktype'] === 0) $monsters[$k]['looktype'] = (int) ($c['looktype'] ?? 0);
			}
		}
	}
	return $monsters;
}
function loot_search_rebuild(): array {
	if (!loot_search_tables_ok()) return array('ok' => false, 'message' => 'Tables missing, reinstall the plugin.');
	@set_time_limit(120);
	$monsters = loot_search_collect();
	if (!$monsters) return array('ok' => false, 'message' => loot_search_t('loot_search.err_nodata', 'No monster data found. Configure the source in the admin panel.'));

	$items = loot_search_items_map();
	$itemsByName = loot_search_items_by_name($items);
	$bossNames = loot_search_boss_names();
	$now = time();

	db()->execute("DELETE FROM `znote_loot_index`;");
	db()->execute("DELETE FROM `znote_loot_monster`;");

	$batch = array(); $batchParams = array(); $rowCount = 0; $mCount = 0;
	foreach ($monsters as $m) {
		$file = (string) ($m['__file'] ?? '');
		$boss = loot_search_is_boss($m, $file, $bossNames) ? 1 : 0;
		$mName = $m['name'];
		$mLow = strtolower($mName);
		$seen = array();
		foreach ((array) $m['loot'] as $d) {
			$id = (int) $d['id'];
			$iname = $d['name'] !== '' ? (string) $d['name'] : (string) ($items[$id] ?? '');
			if ($id <= 0 && $iname !== '') $id = (int) ($itemsByName[strtolower(trim($iname))] ?? 0);
			if ($iname === '' && $id > 0) $iname = (string) ($items[$id] ?? ('item ' . $id));
			if ($iname === '') continue;
			$key = $id . '|' . strtolower($iname);
			if (isset($seen[$key])) continue;
			$seen[$key] = true;
			$batch[] = "(?,?,?,?,?,?,?,?,?,?)";
			array_push($batchParams, $id, substr($iname, 0, 190), substr(strtolower($iname), 0, 190), substr($mName, 0, 118), substr($mLow, 0, 118), $boss, (int) ($m['looktype'] ?? 0), number_format(min(100, max(0, (float) $d['chance'])), 5, '.', ''), max(1, (int) $d['min']), max(1, (int) $d['max']));
			$rowCount++;
			if (count($batch) >= 300) { db()->execute("INSERT INTO `znote_loot_index` (`item_id`,`item_name`,`item_name_low`,`monster_name`,`monster_name_low`,`is_boss`,`monster_looktype`,`chance`,`min_count`,`max_count`) VALUES " . implode(',', $batch) . ";", $batchParams); $batch = array(); $batchParams = array(); }
		}
		$imm = implode(',', array_slice((array) ($m['immunities'] ?? array()), 0, 20));
		db()->execute("INSERT INTO `znote_loot_monster` (`name`,`name_low`,`is_boss`,`health`,`experience`,`speed`,`armor`,`defense`,`race`,`looktype`,`elements`,`immunities`,`bestiary`,`loot_count`,`updated_at`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
			. "ON DUPLICATE KEY UPDATE `is_boss`=VALUES(`is_boss`),`health`=VALUES(`health`),`experience`=VALUES(`experience`),`speed`=VALUES(`speed`),`armor`=VALUES(`armor`),`defense`=VALUES(`defense`),`race`=VALUES(`race`),`looktype`=VALUES(`looktype`),`elements`=VALUES(`elements`),`immunities`=VALUES(`immunities`),`bestiary`=VALUES(`bestiary`),`loot_count`=VALUES(`loot_count`),`updated_at`=VALUES(`updated_at`);",
			[substr($mName, 0, 118), substr($mLow, 0, 118), $boss, (int) $m['health'], (int) $m['experience'], (int) ($m['speed'] ?? 0), (int) ($m['armor'] ?? 0), (int) ($m['defense'] ?? 0), substr((string) $m['race'], 0, 22), (int) $m['looktype'], json_encode((object) $m['elements']), substr($imm, 0, 250), substr(json_encode((object) ($m['bestiary'] ?? array())), 0, 900), count((array) $m['loot']), $now]);
		$mCount++;
	}
	if ($batch) db()->execute("INSERT INTO `znote_loot_index` (`item_id`,`item_name`,`item_name_low`,`monster_name`,`monster_name_low`,`is_boss`,`monster_looktype`,`chance`,`min_count`,`max_count`) VALUES " . implode(',', $batch) . ";", $batchParams);

	$noid = db()->fetchOne("SELECT COUNT(DISTINCT `item_name`) AS c FROM `znote_loot_index` WHERE `item_id` = 0;");
	$noid = is_array($noid) ? (int) $noid['c'] : 0;
	$noidRows = db()->fetchAll("SELECT DISTINCT `item_name` FROM `znote_loot_index` WHERE `item_id` = 0 ORDER BY `item_name` ASC LIMIT 80;");
	$noidNames = is_array($noidRows) ? array_map(static fn($r) => (string) $r['item_name'], $noidRows) : array();
	if (function_exists('setting_set')) {
		setting_set('loot_search:built_at', (string) $now);
		setting_set('loot_search:stat_monsters', (string) $mCount);
		setting_set('loot_search:stat_rows', (string) $rowCount);
		setting_set('loot_search:stat_items', (string) count($items));
		setting_set('loot_search:stat_noid', (string) $noid);
		setting_set('loot_search:stat_noid_names', substr(implode(', ', $noidNames), 0, 4000));
		setting_set('loot_search:stat_itemsxml', loot_search_find_items_xml());
	}
	return array('ok' => true, 'message' => loot_search_t('loot_search.rebuilt', 'Index rebuilt: {m} monsters, {r} loot rows.', array('m' => $mCount, 'r' => $rowCount)));
}

// --- search ----------------------------------------------
function loot_search_query(string $q, ?bool $boss = null, int $limit = 80): array {
	if (!loot_search_tables_ok()) return array();
	$q = trim($q);
	if ($q === '') return array();
	$limit = max(1, min(300, $limit));
	$params = array();
	if (ctype_digit($q)) {
		$w = "`item_id` = ?";
		$params[] = (int) $q;
	} else {
		$w = "`item_name_low` LIKE ?";
		$params[] = "%" . strtolower($q) . "%";
	}
	if ($boss !== null) { $w .= " AND `is_boss` = ?"; $params[] = $boss ? 1 : 0; }
	$rows = db()->fetchAll("SELECT `item_id`,`item_name`,`monster_name`,`is_boss`,`monster_looktype`,`chance`,`min_count`,`max_count` FROM `znote_loot_index` WHERE {$w} ORDER BY `item_name` ASC, `chance` DESC LIMIT {$limit};", $params);
	return is_array($rows) ? $rows : array();
}
/** Monsters / bosses whose name matches the query. */
function loot_search_monsters_by_name(string $q, ?bool $boss = null, int $limit = 40): array {
	if (!loot_search_tables_ok()) return array();
	$q = trim($q);
	if ($q === '' || ctype_digit($q)) return array();
	$limit = max(1, min(120, $limit));
	$low = strtolower($q);
	$w = "`name_low` LIKE ?";
	$params = ["%{$low}%"];
	if ($boss !== null) { $w .= " AND `is_boss` = ?"; $params[] = $boss ? 1 : 0; }
	$params[] = $low;
	$rows = db()->fetchAll("SELECT `name`,`is_boss`,`looktype`,`health`,`experience`,`loot_count` FROM `znote_loot_monster` WHERE {$w} ORDER BY (`name_low` = ?) DESC, `is_boss` ASC, `name` ASC LIMIT {$limit};", $params);
	return is_array($rows) ? $rows : array();
}
function loot_search_monster(string $name): ?array {
	if (!loot_search_tables_ok()) return null;
	$low = strtolower(trim($name));
	$meta = db()->fetchOne("SELECT * FROM `znote_loot_monster` WHERE `name_low` = ? LIMIT 1;", [$low]);
	if (!is_array($meta)) return null;
	$rows = db()->fetchAll("SELECT `item_id`,`item_name`,`chance`,`min_count`,`max_count` FROM `znote_loot_index` WHERE `monster_name_low` = ? ORDER BY `chance` DESC, `item_name` ASC LIMIT 200;", [$low]);
	$meta['loot'] = is_array($rows) ? $rows : array();
	$meta['elements_map'] = json_decode((string) $meta['elements'], true) ?: array();
	$meta['bestiary_map'] = json_decode((string) ($meta['bestiary'] ?? ''), true) ?: array();
	$meta['immunities_list'] = array_filter(array_map('trim', explode(',', (string) ($meta['immunities'] ?? ''))));
	return $meta;
}

// --- schema + menu -------------------------------------
function loot_search_ensure_schema(): void {
	static $done = false;
	if ($done) return;
	$done = true;
	if (!function_exists('setting') || !function_exists('db')) return;

	if (setting('loot_search:schema_v', '') !== '3' && function_exists('znote_table_exists') && znote_table_exists('znote_loot_monster') && function_exists('znote_column_exists')) {
		foreach (array('speed' => "int NOT NULL DEFAULT '0' AFTER `experience`", 'armor' => "int NOT NULL DEFAULT '0' AFTER `speed`",
			'defense' => "int NOT NULL DEFAULT '0' AFTER `armor`", 'immunities' => "varchar(255) NOT NULL DEFAULT '' AFTER `elements`", 'bestiary' => "text AFTER `immunities`") as $col => $def) {
			if (!znote_column_exists('znote_loot_monster', $col)) db()->execute("ALTER TABLE `znote_loot_monster` ADD COLUMN `{$col}` {$def};");
		}
		if (znote_table_exists('znote_loot_index') && !znote_column_exists('znote_loot_index', 'monster_looktype'))
			db()->execute("ALTER TABLE `znote_loot_index` ADD COLUMN `monster_looktype` int NOT NULL DEFAULT '0' AFTER `is_boss`;");
		// migrate the old single data_path to custom_path_1
		if (setting('loot_search:source', '') === 'folder' && trim((string) setting('loot_search:data_path', '')) !== '' && trim((string) setting('loot_search:custom_path_1', '')) === '') {
			if (function_exists('setting_set')) setting_set('loot_search:custom_path_1', (string) setting('loot_search:data_path', ''));
		}
		if (function_exists('setting_set')) setting_set('loot_search:schema_v', '3');
	}

	if (setting('loot_search:setup_v', '') === '1') return;
	if (loot_search_setting('show_in_menu', '1') === '1' && function_exists('znote_table_exists') && znote_table_exists('znote_menu')) {
		$has = db()->fetchOne("SELECT `id` FROM `znote_menu` WHERE `url` = 'page.php?plugin=loot_search&p=loot' LIMIT 1;");
		if (!is_array($has)) {
			$lib = db()->fetchOne("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` = 'Library' LIMIT 1;");
			$parent = is_array($lib) ? (int) $lib['id'] : 0;
			$so = 140;
			if ($parent > 0) {
				$mx = db()->fetchOne("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = ?;", [$parent]);
				$so = is_array($mx) ? (int) $mx['s'] + 5 : 50;
			}
			db()->execute("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',?,'Loot Search','page.php?plugin=loot_search&p=loot','fa-search','all',?,1);", [$parent, $so]);
		}
	}
	if (function_exists('setting_set')) setting_set('loot_search:setup_v', '1');
}

}

loot_search_handle_image();
loot_search_ensure_schema();
