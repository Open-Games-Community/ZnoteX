﻿CREATE TABLE IF NOT EXISTS `znote_loot_index` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL DEFAULT '0',
  `item_name` varchar(191) NOT NULL DEFAULT '',
  `item_name_low` varchar(191) NOT NULL DEFAULT '',
  `monster_name` varchar(120) NOT NULL DEFAULT '',
  `monster_name_low` varchar(120) NOT NULL DEFAULT '',
  `is_boss` tinyint NOT NULL DEFAULT '0',
  `monster_looktype` int NOT NULL DEFAULT '0',
  `chance` decimal(9,5) NOT NULL DEFAULT '0.00000',
  `min_count` int NOT NULL DEFAULT '1',
  `max_count` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `item_search` (`item_name_low`),
  KEY `item_id` (`item_id`),
  KEY `monster` (`monster_name_low`, `is_boss`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_loot_monster` (
  `name` varchar(120) NOT NULL,
  `name_low` varchar(120) NOT NULL DEFAULT '',
  `is_boss` tinyint NOT NULL DEFAULT '0',
  `health` int NOT NULL DEFAULT '0',
  `experience` int NOT NULL DEFAULT '0',
  `speed` int NOT NULL DEFAULT '0',
  `armor` int NOT NULL DEFAULT '0',
  `defense` int NOT NULL DEFAULT '0',
  `race` varchar(24) NOT NULL DEFAULT '',
  `looktype` int NOT NULL DEFAULT '0',
  `elements` text,
  `immunities` varchar(255) NOT NULL DEFAULT '',
  `bestiary` text,
  `loot_count` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`),
  KEY `name_low` (`name_low`),
  KEY `boss` (`is_boss`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
