<?php
/**
 * Public page: page.php?plugin=loot_search&p=loot
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'loot_search_h';
$q = trim((string) ($_GET['q'] ?? ''));
$mName = trim((string) ($_GET['m'] ?? ''));
$built = loot_search_int('built_at', 0);
$monster = $mName !== '' ? loot_search_monster($mName) : null;
$results     = ($monster === null && $q !== '') ? loot_search_query($q, null, 160) : array();
$monsterHits = ($monster === null && $q !== '') ? loot_search_monsters_by_name($q, null, 24) : array();

// group flat results by item NAME for display (the same item can carry more than
// one id across data files), and keep one row per monster - the highest chance.
$groups = array();
foreach ($results as $r) {
	$k = strtolower(trim((string) $r['item_name']));
	if ($k === '') $k = 'item#' . (int) $r['item_id'];
	if (!isset($groups[$k])) $groups[$k] = array('id' => (int) $r['item_id'], 'name' => (string) $r['item_name'], 'rows' => array());
	if ((int) $groups[$k]['id'] <= 0 && (int) $r['item_id'] > 0) $groups[$k]['id'] = (int) $r['item_id'];
	$mk = strtolower(trim((string) $r['monster_name']));
	if (!isset($groups[$k]['rows'][$mk]) || (float) $r['chance'] > (float) $groups[$k]['rows'][$mk]['chance']) {
		$groups[$k]['rows'][$mk] = $r;
	}
}
foreach ($groups as &$g) {
	usort($g['rows'], static fn($a, $b) => (float) $b['chance'] <=> (float) $a['chance']);
}
unset($g);
$base = $h(znote_plugin_url('loot_search', 'loot'));
$els = loot_search_elements();
?>
<style>
.ls-wrap{--ls-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--ls-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--ls-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--ls-accent:var(--accent,var(--link,#d1a233));--ls-row:rgba(255,255,255,.03);--ls-head-bg:var(--ls-accent);--ls-head-text:#151515;--ls-tab:rgba(255,255,255,.05);--ls-tab-active:var(--ls-accent);--ls-btn-bg:var(--ls-accent);--ls-btn-text:#151515;--ls-search-bg:rgba(0,0,0,.16);--ls-radius:12px;color:var(--ls-text)}
.ls-wrap *{box-sizing:border-box}
.ls-wrap h1{font-size:26px;margin:0 0 4px}
.ls-lead{opacity:.8;margin:0 0 18px}
.ls-search{display:flex;gap:8px;margin:0 0 18px;flex-wrap:wrap}
.ls-search input{flex:1 1 240px;min-width:200px;padding:11px 14px;border:1px solid var(--ls-border);border-radius:10px;background:var(--ls-search-bg);color:inherit;font:inherit;font-size:15px}
.ls-search button{padding:11px 22px;border:0;border-radius:10px;background:var(--ls-btn-bg);color:var(--ls-btn-text);font-weight:800;cursor:pointer}
.ls-card{border:1px solid var(--ls-border);border-radius:var(--ls-radius);background:var(--ls-surface);overflow:hidden;margin:0 0 18px}
.ls-table{width:100%;border-collapse:collapse;font-size:14px}
.ls-table th{background:var(--ls-head-bg);color:var(--ls-head-text);text-align:left;padding:10px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.05em}
.ls-table td{padding:9px 14px;border-top:1px solid var(--ls-border);vertical-align:middle}
.ls-table tr:nth-child(odd) td{background:var(--ls-row)}
.ls-item{display:flex;align-items:center;gap:10px;font-weight:700}
.ls-item img,.ls-item .ls-ph{width:34px;height:34px;object-fit:contain;image-rendering:pixelated;flex:0 0 auto}
.ls-item .ls-ph{border:1px dashed var(--ls-border);border-radius:6px;opacity:.4}
.ls-mon{display:flex;align-items:center;gap:8px}
.ls-mon img{width:32px;height:32px;object-fit:contain;image-rendering:pixelated;flex:0 0 auto}
.ls-mon a{color:inherit;text-decoration:none}.ls-mon a:hover{color:var(--ls-accent)}
.ls-chance{font-variant-numeric:tabular-nums;color:var(--ls-accent);font-weight:700;white-space:nowrap}
.ls-sec{padding:10px 14px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;background:var(--ls-head-bg);color:var(--ls-head-text)}
.ls-mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px;padding:12px}
.ls-mtile{display:flex;align-items:center;gap:10px;padding:9px 11px;border:1px solid var(--ls-border);border-radius:10px;background:var(--ls-row);color:inherit;text-decoration:none;min-width:0}
.ls-mtile:hover{border-color:var(--ls-accent)}
.ls-mtile img,.ls-mtile__ph{width:40px;height:40px;object-fit:contain;image-rendering:pixelated;flex:0 0 auto}
.ls-mtile__b{min-width:0;display:flex;flex-direction:column;gap:2px}
.ls-mtile__n{font-weight:800;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-mtile__s{font-size:11px;opacity:.6;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-bosspill{font-size:10px;font-weight:800;text-transform:uppercase;padding:1px 6px;border-radius:999px;background:var(--ls-accent);color:#151515;vertical-align:middle}
.ls-empty{opacity:.65;padding:16px}
.ls-note{opacity:.6;font-size:12.5px;margin-top:6px}
.ls-back{display:inline-block;margin-bottom:14px;color:var(--ls-accent);text-decoration:none}
.ls-mhead{display:flex;gap:16px;align-items:center;flex-wrap:wrap;padding:16px;border-bottom:1px solid var(--ls-border)}
.ls-mhead img{width:64px;height:64px;object-fit:contain;image-rendering:pixelated;border:1px solid var(--ls-border);border-radius:10px;background:rgba(0,0,0,.15)}
.ls-mhead h2{margin:0;font-size:20px}
.ls-mstats{display:flex;gap:14px;flex-wrap:wrap;font-size:13px;opacity:.85;margin-top:4px}
.ls-els{display:flex;flex-wrap:wrap;gap:6px;padding:14px 16px}
.ls-bestiary{display:flex;flex-wrap:wrap;gap:14px;padding:12px 16px;border-top:1px solid var(--ls-border);font-size:13px;align-items:center}
.ls-bestiary .ls-b-title{font-weight:800;text-transform:uppercase;font-size:11px;letter-spacing:.06em;opacity:.7}
.ls-bestiary span:not(.ls-b-title){opacity:.9}
.ls-el{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid var(--el-c);background:color-mix(in srgb,var(--el-c) 15%,transparent);color:var(--el-c)}
.ls-el img{width:14px;height:14px}
.ls-el.is-weak{filter:none}.ls-el .v{opacity:.85}
</style>

<div class="ls-wrap" <?= loot_search_style_attr() ?>>

<?php if ($monster !== null): ?>
	<a class="ls-back" href="<?= $base ?>">&larr; <?= $h(loot_search_t('loot_search.back', 'Back to search')) ?></a>
	<div class="ls-card">
		<div class="ls-mhead">
			<?php $oimg = loot_search_outfit_image((int) $monster['looktype']); ?>
			<?php if ($oimg !== ''): ?><img src="<?= $h($oimg) ?>" alt=""><?php endif; ?>
			<div>
				<h2><?= $h($monster['name']) ?><?php if ((int) $monster['is_boss'] === 1): ?> <span style="font-size:12px;padding:2px 8px;border-radius:999px;background:var(--ls-accent);color:#151515;vertical-align:middle"><?= $h(loot_search_t('loot_search.boss', 'Boss')) ?></span><?php endif; ?></h2>
				<div class="ls-mstats">
					<?php if ((int) $monster['health'] > 0): ?><span><?= $h(loot_search_t('loot_search.hp', 'HP')) ?>: <?= number_format((int) $monster['health']) ?></span><?php endif; ?>
					<?php if ((int) $monster['experience'] > 0): ?><span><?= $h(loot_search_t('loot_search.exp', 'Exp')) ?>: <?= number_format((int) $monster['experience']) ?></span><?php endif; ?>
					<?php if ((int) ($monster['speed'] ?? 0) > 0): ?><span><?= $h(loot_search_t('loot_search.speed', 'Speed')) ?>: <?= (int) $monster['speed'] ?></span><?php endif; ?>
					<?php if ((int) ($monster['armor'] ?? 0) > 0): ?><span><?= $h(loot_search_t('loot_search.armor', 'Armor')) ?>: <?= (int) $monster['armor'] ?></span><?php endif; ?>
					<?php if ((int) ($monster['defense'] ?? 0) > 0): ?><span><?= $h(loot_search_t('loot_search.defense', 'Defense')) ?>: <?= (int) $monster['defense'] ?></span><?php endif; ?>
					<?php if ((string) $monster['race'] !== ''): ?><span><?= $h(loot_search_t('loot_search.race', 'Race')) ?>: <?= $h(ucfirst((string) $monster['race'])) ?></span><?php endif; ?>
				</div>
			</div>
		</div>
		<?php if ($monster['elements_map'] || !empty($monster['immunities_list'])): ?>
			<div class="ls-els">
				<?php foreach ($monster['elements_map'] as $ek => $ev): $ev = (int) $ev; if (!isset($els[$ek]) || $ev === 0) continue; $isImm = in_array($ek, (array) ($monster['immunities_list'] ?? array()), true) || $ev >= 100; ?>
					<span class="ls-el" style="--el-c:<?= $h($els[$ek][0]) ?>"><img src="<?= $h(znote_plugin_asset('loot_search', 'img/' . $ek . '.svg')) ?>" alt=""><?= $h($els[$ek][1]) ?> <span class="v"><?= $isImm ? $h(loot_search_t('loot_search.immune', 'immune')) : (($ev > 0 ? '+' : '') . $ev . '%') ?></span></span>
				<?php endforeach; ?>
				<?php foreach ((array) ($monster['immunities_list'] ?? array()) as $ek): if (!isset($els[$ek]) || isset($monster['elements_map'][$ek])) continue; ?>
					<span class="ls-el" style="--el-c:<?= $h($els[$ek][0]) ?>"><img src="<?= $h(znote_plugin_asset('loot_search', 'img/' . $ek . '.svg')) ?>" alt=""><?= $h($els[$ek][1]) ?> <span class="v"><?= $h(loot_search_t('loot_search.immune', 'immune')) ?></span></span>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php $bg = (array) ($monster['bestiary_map'] ?? array()); if ($bg): ?>
			<div class="ls-bestiary">
				<span class="ls-b-title"><?= $h(loot_search_t('loot_search.bestiary', 'Bestiary')) ?></span>
				<?php if (!empty($bg['class'])): ?><span><?= $h(loot_search_t('loot_search.class', 'Class')) ?>: <?= $h(ucwords((string) $bg['class'])) ?></span><?php endif; ?>
				<?php if (!empty($bg['stars'])): ?><span><?= str_repeat('★', min(5, (int) $bg['stars'])) . str_repeat('☆', max(0, 5 - (int) $bg['stars'])) ?></span><?php endif; ?>
				<?php if (isset($bg['occurrence'])): $occ = array(0 => 'Common', 1 => 'Uncommon', 2 => 'Rare', 3 => 'Very Rare'); ?><span><?= $h(loot_search_t('loot_search.occurrence', 'Occurrence')) ?>: <?= $h($occ[(int) $bg['occurrence']] ?? (string) $bg['occurrence']) ?></span><?php endif; ?>
				<?php if (!empty($bg['kills'])): ?><span><?= $h(loot_search_t('loot_search.to_unlock', 'Kills to unlock')) ?>: <?= number_format((int) $bg['kills']) ?></span><?php endif; ?>
				<?php if (!empty($bg['charm'])): ?><span><?= $h(loot_search_t('loot_search.charm', 'Charm points')) ?>: <?= (int) $bg['charm'] ?></span><?php endif; ?>
			</div>
		<?php endif; ?>
		<table class="ls-table">
			<thead><tr><th><?= $h(loot_search_t('loot_search.item', 'Item')) ?></th><th><?= $h(loot_search_t('loot_search.count', 'Count')) ?></th><th><?= $h(loot_search_t('loot_search.chance', 'Chance')) ?></th></tr></thead>
			<tbody>
			<?php if (!$monster['loot']): ?><tr><td colspan="3" class="ls-empty"><?= $h(loot_search_t('loot_search.no_loot', 'No loot recorded.')) ?></td></tr><?php endif; ?>
			<?php foreach ($monster['loot'] as $r): ?>
				<tr>
					<td><span class="ls-item"><?php $img = loot_search_item_image((int) $r['item_id']); if ($img !== ''): ?><img src="<?= $h($img) ?>" alt="" loading="lazy"><?php else: ?><span class="ls-ph"></span><?php endif; ?><?= $h($r['item_name']) ?></span></td>
					<td><?= (int) $r['min_count'] === (int) $r['max_count'] ? (int) $r['max_count'] : (int) $r['min_count'] . '&ndash;' . (int) $r['max_count'] ?></td>
					<td class="ls-chance"><?= rtrim(rtrim(number_format((float) $r['chance'], 4), '0'), '.') ?>%</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>

<?php else: ?>
	<h1><?= $h(loot_search_t('loot_search.title', 'Loot Search')) ?></h1>
	<p class="ls-lead"><?= $h(loot_search_t('loot_search.lead', 'Search an item to see what drops it, or a monster / boss name to see its loot.')) ?></p>

	<form class="ls-search" method="get" action="page.php">
		<input type="hidden" name="plugin" value="loot_search"><input type="hidden" name="p" value="loot">
		<input type="text" name="q" value="<?= $h($q) ?>" placeholder="<?= $h(loot_search_t('loot_search.placeholder', 'Item, monster or boss name (e.g. demon armor, ferumbras)')) ?>" autocomplete="off" autofocus>
		<button type="submit"><?= $h(loot_search_t('loot_search.search', 'Search')) ?></button>
	</form>

	<?php if ($built === 0): ?>
		<p class="ls-empty"><?= $h(loot_search_t('loot_search.not_built', 'The loot index has not been built yet. An admin needs to build it in the admin panel.')) ?></p>
	<?php elseif ($q === ''): ?>
		<p class="ls-empty"><?= $h(loot_search_t('loot_search.type_something', 'Type an item, monster or boss name above to start.')) ?></p>
	<?php elseif (!$groups && !$monsterHits): ?>
		<p class="ls-empty"><?= $h(loot_search_t('loot_search.no_results2', 'Nothing found for "{q}".', array('q' => $q))) ?></p>
	<?php else: ?>
		<?php if ($monsterHits): ?>
			<div class="ls-card">
				<div class="ls-sec"><?= $h(loot_search_t('loot_search.matched_creatures', 'Monsters & bosses')) ?></div>
				<div class="ls-mgrid">
					<?php foreach ($monsterHits as $m): $mo = loot_search_outfit_image((int) $m['looktype']); ?>
						<a class="ls-mtile" href="<?= $base ?>&m=<?= $h(urlencode((string) $m['name'])) ?>">
							<?php if ($mo !== ''): ?><img src="<?= $h($mo) ?>" alt="" loading="lazy"><?php else: ?><span class="ls-mtile__ph"></span><?php endif; ?>
							<span class="ls-mtile__b">
								<span class="ls-mtile__n"><?= $h($m['name']) ?><?php if ((int) $m['is_boss'] === 1): ?> <span class="ls-bosspill"><?= $h(loot_search_t('loot_search.boss', 'Boss')) ?></span><?php endif; ?></span>
								<span class="ls-mtile__s"><?php $bits = array();
									if ((int) $m['health'] > 0) $bits[] = 'HP ' . number_format((int) $m['health']);
									if ((int) $m['experience'] > 0) $bits[] = 'Exp ' . number_format((int) $m['experience']);
									if ((int) $m['loot_count'] > 0) $bits[] = (int) $m['loot_count'] . ' ' . loot_search_t('loot_search.items_l', 'items');
									echo $h(implode(' · ', $bits)); ?></span>
							</span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>

		<?php if ($groups): ?>
			<div class="ls-card">
				<div class="ls-sec"><?= $h(loot_search_t('loot_search.dropped_by', 'Dropped by')) ?></div>
				<table class="ls-table">
					<thead><tr><th><?= $h(loot_search_t('loot_search.item', 'Item')) ?></th><th><?= $h(loot_search_t('loot_search.creature', 'Creature')) ?></th><th><?= $h(loot_search_t('loot_search.count', 'Count')) ?></th><th><?= $h(loot_search_t('loot_search.chance', 'Chance')) ?></th></tr></thead>
					<tbody>
					<?php foreach ($groups as $g): $first = true; foreach ($g['rows'] as $r): ?>
						<tr>
							<td><?php if ($first): $img = loot_search_item_image((int) $g['id']); ?><span class="ls-item"><?php if ($img !== ''): ?><img src="<?= $h($img) ?>" alt="" loading="lazy"><?php else: ?><span class="ls-ph"></span><?php endif; ?><?= $h($g['name']) ?></span><?php $first = false; endif; ?></td>
							<td class="ls-mon"><?php $mo = loot_search_outfit_image((int) ($r['monster_looktype'] ?? 0)); if ($mo !== ''): ?><img src="<?= $h($mo) ?>" alt="" loading="lazy"><?php endif; ?><a href="<?= $base ?>&m=<?= $h(urlencode((string) $r['monster_name'])) ?>"><?= $h($r['monster_name']) ?></a><?php if ((int) ($r['is_boss'] ?? 0) === 1): ?> <span class="ls-bosspill"><?= $h(loot_search_t('loot_search.boss', 'Boss')) ?></span><?php endif; ?></td>
							<td><?= (int) $r['min_count'] === (int) $r['max_count'] ? (int) $r['max_count'] : (int) $r['min_count'] . '&ndash;' . (int) $r['max_count'] ?></td>
							<td class="ls-chance"><?= rtrim(rtrim(number_format((float) $r['chance'], 4), '0'), '.') ?>%</td>
						</tr>
					<?php endforeach; endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ($built > 0): ?><p class="ls-note"><?= $h(loot_search_t('loot_search.built_note', 'Index built {when} · {m} monsters', array('when' => function_exists('getClock') ? getClock($built, true) : date('Y-m-d', $built), 'm' => loot_search_int('stat_monsters', 0)))) ?></p><?php endif; ?>
<?php endif; ?>
</div>
