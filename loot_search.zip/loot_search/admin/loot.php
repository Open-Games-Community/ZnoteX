<?php
/**
 * Title: Loot Search
 * Icon: fa-search
 * Group: Installed Plugins
 * Order: 40
 * Description: Where the monster data comes from, boss rules, styling, and the index rebuild.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'loot_search__loot';
if (function_exists('loot_search_ensure_schema')) loot_search_ensure_schema();

function loot_search_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (($_POST['do'] ?? '') === 'rebuild') {
		$res = loot_search_rebuild();
		if (!empty($res['ok'])) acp_flash_success($res['message']);
		else acp_flash_error($res['message']);
		if (function_exists('acp_log')) acp_log('loot_search.rebuild', $res['message'] ?? '');
		acp_redirect($module);
	}

	setting_set('loot_search:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('loot_search:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
	setting_set('loot_search:use_server_path', !empty($_POST['use_server_path']) ? '1' : '0');
	setting_set('loot_search:use_znotex_cache', !empty($_POST['use_znotex_cache']) ? '1' : '0');
	foreach (array('custom_path_1', 'custom_path_2', 'custom_path_3', 'items_xml_path') as $k)
		setting_set('loot_search:' . $k, trim((string) ($_POST[$k] ?? '')));
	setting_set('loot_search:item_image_server', trim((string) ($_POST['item_image_server'] ?? '')));
	setting_set('loot_search:outfit_image_server', trim((string) ($_POST['outfit_image_server'] ?? '')));
	setting_set('loot_search:boss_names', trim((string) ($_POST['boss_names'] ?? '')));
	setting_set('loot_search:boss_min_hp', (string) max(0, intv($_POST['boss_min_hp'] ?? 0)));
	setting_set('loot_search:boss_min_exp', (string) max(0, intv($_POST['boss_min_exp'] ?? 0)));
	setting_set('loot_search:style_radius', (string) max(0, min(30, intv($_POST['style_radius'] ?? 12))));
	foreach (array('box_bg', 'border', 'text', 'accent', 'row_bg', 'head_bg', 'head_text', 'tab_bg', 'tab_active', 'button_bg', 'button_text', 'search_bg') as $k)
		setting_set('loot_search:style_' . $k, loot_search_admin_color($_POST['style_' . $k] ?? ''));

	if (function_exists('znote_table_exists') && znote_table_exists('znote_menu')) {
		$has = db()->fetchOne("SELECT `id` FROM `znote_menu` WHERE `url` = 'page.php?plugin=loot_search&p=loot' LIMIT 1;");
		if (!empty($_POST['show_in_menu']) && !is_array($has)) {
			$lib = db()->fetchOne("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` = 'Library' LIMIT 1;");
			$parent = is_array($lib) ? (int) $lib['id'] : 0;
			db()->execute("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',?,'Loot Search','page.php?plugin=loot_search&p=loot','fa-search','all',145,1);", [$parent]);
		} elseif (empty($_POST['show_in_menu']) && is_array($has)) {
			db()->execute("DELETE FROM `znote_menu` WHERE `id` = ? LIMIT 1;", [(int) $has['id']]);
		}
	}

	acp_flash_success('Loot Search saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('loot_search:' . $k, $d);
$built = (int) $get('built_at', '0');

/** Describe how an image-server value resolves, for the diagnostics line. */
$imgSrvInfo = static function (string $which) use ($get): string {
	$raw = trim($get($which . '_image_server'));
	$viaShop = false;
	if ($raw === '') {
		$raw = trim((string) ($which === 'item'
			? ($GLOBALS['config']['shop']['imageServer'] ?? '')
			: ($GLOBALS['config']['show_outfits']['imageServer'] ?? '')));
		$viaShop = $raw !== '';
	}
	if ($raw === '') return '<span class="acp-muted">blank &mdash; using ' . ($which === 'item' ? 'the shop image server' : '<code>$config[\'show_outfits\'][\'imageServer\']</code>') . '</span>';
	$src = $viaShop ? ' <span class="acp-muted">(from ' . ($which === 'item' ? 'Shop settings' : 'outfit config') . ')</span>' : '';
	if (preg_match('#^(https?:)?//#i', $raw)) return 'external URL &mdash; <code>' . h($raw) . '</code>' . $src;
	$real = @realpath($raw);
	if ($real !== false && @is_dir($real)) {
		$sample = '';
		foreach ((array) glob($real . DIRECTORY_SEPARATOR . '*.{png,gif,jpg,jpeg,webp}', GLOB_BRACE) as $f) { $sample = basename($f); break; }
		return '<b style="color:#2e7d32">local folder OK</b> &mdash; <code>' . h($real) . '</code>' . $src
			. ($sample !== '' ? ' &middot; e.g. <code>' . h($sample) . '</code>' : ' &middot; <b style="color:#c0392b">but no image files in it</b>');
	}
	if ($raw[0] === '/') return 'site path &mdash; <code>' . h($raw) . '</code>' . $src;
	return '<b style="color:#c0392b">not usable</b> &mdash; <code>' . h($raw) . '</code> is neither a URL nor a folder that exists on disk' . $src;
};
?>
<?php acp_card_open('Loot Search', 'Build a searchable index of monster loot + stats (health, exp, speed, armor, resistances, immunities, bestiary). Sources are merged: <code>$config[\'server_path\']</code>, up to 3 custom folders (XML for TFS/OTHire/OTX, Lua for Canary), and the ZnoteX Server-Info upload. Rebuild after any server data change.'); ?>

<div class="acp-actions" style="margin-bottom:14px">
	<form method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="rebuild"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-refresh"></i> Rebuild index now</button></form>
	<span class="acp-muted">
		<?php if ($built > 0): ?>Last built <?= h(date('Y-m-d H:i', $built)) ?> — <?= (int) $get('stat_monsters', '0') ?> monsters, <?= (int) $get('stat_rows', '0') ?> loot rows.<?php else: ?>Never built.<?php endif; ?>
	</span>
</div>
<?php if ($built > 0): $xmlp = $get('stat_itemsxml', ''); $noid = (int) $get('stat_noid', '0'); $noidN = trim($get('stat_noid_names', '')); ?>
	<p class="acp-muted" style="margin:-8px 0 6px">
		items.xml: <?= $xmlp !== '' ? '<code>' . h($xmlp) . '</code> (' . (int) $get('stat_items', '0') . ' items)' : '<b style="color:#c0392b">not found</b> — set the path below, then rebuild' ?>.
	</p>
	<p class="acp-muted" style="margin:0 0 6px">Item image server resolves as: <?= $imgSrvInfo('item') ?>.</p>
	<p class="acp-muted" style="margin:0 0 14px">Outfit image server resolves as: <?= $imgSrvInfo('outfit') ?>.</p>
	<?php if ($noid > 0): ?>
		<details style="margin:0 0 14px"><summary class="acp-muted"><b><?= $noid ?></b> item name<?= $noid === 1 ? '' : 's' ?> in the loot have no id<?= $xmlp === '' ? ' (no image until items.xml is found)' : ' (not in items.xml — custom items)' ?> — show list</summary>
			<p class="acp-muted" style="margin:8px 0 0"><?= $noidN !== '' ? h($noidN) : '(none)' ?></p></details>
	<?php endif; ?>
<?php endif; ?>

<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Show "Loot Search" under the Library menu</label></div>
		<div class="acp-field"><label class="acp-label">Item image server <span class="acp-muted">(blank = the shop's <code>&lt;server&gt;/&lt;id&gt;.gif</code>). Accepts: an <code>http(s)://</code> URL, <code>//host/path</code>, a site path like <code>/items</code>, or a disk folder like <code>F:/…/item_apngs</code> (files named <code>&lt;id&gt;.png/gif</code> - streamed by the plugin).</span></label><input class="acp-input" name="item_image_server" value="<?= h($get('item_image_server')) ?>" placeholder="/items  or  F:/…/item_apngs  or  https://…/items"></div>
		<div class="acp-field"><label class="acp-label">Outfit image server <span class="acp-muted">(blank = <code>$config['show_outfits']['imageServer']</code>). Same rules - a URL / script, a site path, or a disk folder of <code>&lt;looktype&gt;.png</code> files.</span></label><input class="acp-input" name="outfit_image_server" value="<?= h($get('outfit_image_server')) ?>" placeholder="https://outfit-images.ots.me/…/animoutfit.php  or  F:/…/outfits"></div>
	</div>

	<h3>Data sources <span class="acp-muted">(all enabled sources are merged; a monster's fields are filled from whichever source has them)</span></h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="use_server_path" value="1" <?= $get('use_server_path', '1') === '1' ? 'checked' : '' ?>> Scan <code>$config['server_path']</code> (auto-finds data/monster inside it)</label><p class="acp-muted"><?= h($GLOBALS['config']['server_path'] ?? '') !== '' ? 'Currently: <code>' . h($GLOBALS['config']['server_path']) . '</code>' : 'Not set in config.php.' ?></p></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="use_znotex_cache" value="1" <?= $get('use_znotex_cache', '1') === '1' ? 'checked' : '' ?>> Use the ZnoteX Server-Info upload (items.xml + data/monster zip, from Admin &rarr; Server Info)</label></div>
	</div>
	<div class="acp-field"><label class="acp-label">Custom monster folder 1 <span class="acp-muted">(scanned recursively for *.xml + *.lua)</span></label><input class="acp-input" name="custom_path_1" value="<?= h($get('custom_path_1')) ?>" placeholder="/path/to/server/data/monster"></div>
	<div class="acp-field"><label class="acp-label">Custom monster folder 2 <span class="acp-muted">(e.g. your Lua monsters, or a custom-content folder)</span></label><input class="acp-input" name="custom_path_2" value="<?= h($get('custom_path_2')) ?>"></div>
	<div class="acp-field"><label class="acp-label">Custom monster folder 3</label><input class="acp-input" name="custom_path_3" value="<?= h($get('custom_path_3')) ?>"></div>
	<div class="acp-field"><label class="acp-label">items.xml path <span class="acp-muted">(optional — otherwise auto-found near the folders above or from Server Info)</span></label><input class="acp-input" name="items_xml_path" value="<?= h($get('items_xml_path')) ?>" placeholder="/path/to/server/data/items/items.xml"></div>

	<h3>Boss classification</h3>
	<p class="acp-muted">A monster is a boss if its file path contains "boss", its name is listed below, or it passes a threshold.</p>
	<div class="acp-field"><label class="acp-label">Boss names (one per line or comma separated)</label><textarea class="acp-textarea" name="boss_names" placeholder="Ferumbras&#10;Orshabaal&#10;The Pale Count"><?= h($get('boss_names')) ?></textarea></div>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">…or health &ge; (0 = off)</label><input class="acp-input" type="number" min="0" name="boss_min_hp" value="<?= (int) $get('boss_min_hp', '0') ?>"></div>
		<div class="acp-field"><label class="acp-label">…or experience &ge; (0 = off)</label><input class="acp-input" type="number" min="0" name="boss_min_exp" value="<?= (int) $get('boss_min_exp', '0') ?>"></div>
	</div>

	<h3>Style</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent', 'row_bg' => 'Odd row', 'head_bg' => 'Table header bg', 'head_text' => 'Table header text', 'tab_bg' => 'Inactive tab', 'tab_active' => 'Active tab', 'button_bg' => 'Search button bg', 'button_text' => 'Search button text', 'search_bg' => 'Search field bg') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><?php acp_color_field('style_' . $k, $get('style_' . $k), '#1a1d24'); ?></div>
		<?php endforeach; ?>
		<div class="acp-field"><label class="acp-label">Corner radius (px)</label><input class="acp-input" type="number" min="0" max="30" name="style_radius" value="<?= (int) $get('style_radius', '12') ?>"></div>
	</div>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<?php acp_card_close(); ?>
