CREATE TABLE IF NOT EXISTS `znote_account_security_notes` (
  `account_id` int NOT NULL,
  `last_seen_ip` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
