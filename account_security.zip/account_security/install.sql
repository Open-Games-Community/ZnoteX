CREATE TABLE IF NOT EXISTS `znote_account_security_notes` (
  `account_id` int NOT NULL,
  `last_seen_ip` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_account_security_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `event` varchar(40) NOT NULL,
  `ip` int NOT NULL DEFAULT '0',
  `ip_text` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `session_hash` char(64) NOT NULL DEFAULT '',
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `account_created` (`account_id`, `created_at`),
  KEY `event_created` (`event`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_account_security_sessions` (
  `session_hash` char(64) NOT NULL,
  `account_id` int NOT NULL,
  `ip` int NOT NULL DEFAULT '0',
  `ip_text` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `first_seen` int NOT NULL DEFAULT '0',
  `last_seen` int NOT NULL DEFAULT '0',
  `revoked_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_hash`),
  KEY `account_last_seen` (`account_id`, `last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
