﻿<?php

if (!function_exists('account_security_setting')) {
function account_security_setting(string $key, string $default): string {
	return function_exists('setting') ? (string)setting('account_security:' . $key, $default) : $default;
}

function account_security_enabled(): bool {
	return account_security_setting('enabled', '1') === '1';
}

function account_security_track_sessions(): bool {
	return account_security_setting('track_sessions', '1') === '1';
}

function account_security_h($value): string {
	return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function account_security_style_color(string $key): string {
	$value = trim(account_security_setting('style_' . $key, ''));
	return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value) ? $value : '';
}

function account_security_style_attr(): string {
	$map = array('box_bg' => '--znx-plugin-surface', 'text' => '--znx-plugin-text', 'border' => '--znx-plugin-border');
	$css = '';
	foreach ($map as $key => $var) {
		$value = account_security_style_color($key);
		if ($value !== '') {
			$css .= $var . ':' . $value . ';';
		}
	}

	return $css !== '' ? ' style="' . account_security_h($css) . '"' : '';
}

function account_security_ip($long): string {
	return $long ? long2ip((int)$long) : t_default('account_security.unknown', 'unknown');
}

function account_security_ip_string(): string {
	if (function_exists('getIP')) {
		return substr((string)getIP(), 0, 45);
	}

	return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

function account_security_ip_long(): int {
	$ip = account_security_ip_string();
	if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
		return function_exists('getIPLong') ? (int)getIPLong() : (int)sprintf('%u', ip2long($ip));
	}

	return 0;
}

function account_security_display_ip($long, string $ipText = ''): string {
	$ipText = trim($ipText);
	if ($ipText !== '') {
		return $ipText;
	}

	return account_security_ip($long);
}

function account_security_user_agent(): string {
	return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
}

function account_security_session_hash(): string {
	$id = session_status() === PHP_SESSION_ACTIVE ? session_id() : '';
	return $id !== '' ? hash('sha256', $id) : '';
}

function account_security_account_id(): int {
	if (!empty($GLOBALS['session_user_id'])) {
		return (int)$GLOBALS['session_user_id'];
	}

	if (function_exists('getSession')) {
		return (int)getSession('user_id');
	}

	return 0;
}

function account_security_table_exists(string $table): bool {
	return function_exists('znote_table_exists') ? znote_table_exists($table) : false;
}

function account_security_column_exists(string $table, string $column): bool {
	if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
		return false;
	}

	$row = db()->fetchOne("SHOW COLUMNS FROM `" . $table . "` LIKE ?;", array($column));

	return is_array($row);
}

function account_security_add_column_if_missing(string $table, string $column, string $definition): void {
	if (!account_security_table_exists($table) || account_security_column_exists($table, $column)) {
		return;
	}

	db()->execute("ALTER TABLE `" . $table . "` ADD COLUMN `" . $column . "` " . $definition . ";");
}

function account_security_ensure_schema(): void {
	static $done = false;
	if ($done) {
		return;
	}
	$done = true;

	$db = db();
	$db->execute("CREATE TABLE IF NOT EXISTS `znote_account_security_notes` (
		`account_id` int NOT NULL,
		`last_seen_ip` int NOT NULL DEFAULT '0',
		`updated_at` int NOT NULL DEFAULT '0',
		PRIMARY KEY (`account_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");

	$db->execute("CREATE TABLE IF NOT EXISTS `znote_account_security_events` (
		`id` int NOT NULL AUTO_INCREMENT,
		`account_id` int NOT NULL,
		`event` varchar(40) NOT NULL,
		`ip` int NOT NULL DEFAULT '0',
		`ip_text` varchar(45) NOT NULL DEFAULT '',
		`user_agent` varchar(255) NOT NULL DEFAULT '',
		`session_hash` char(64) NOT NULL DEFAULT '',
		`created_at` int NOT NULL DEFAULT '0',
		PRIMARY KEY (`id`),
		KEY `account_created` (`account_id`, `created_at`),
		KEY `event_created` (`event`, `created_at`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");

	$db->execute("CREATE TABLE IF NOT EXISTS `znote_account_security_sessions` (
		`session_hash` char(64) NOT NULL,
		`account_id` int NOT NULL,
		`ip` int NOT NULL DEFAULT '0',
		`ip_text` varchar(45) NOT NULL DEFAULT '',
		`user_agent` varchar(255) NOT NULL DEFAULT '',
		`first_seen` int NOT NULL DEFAULT '0',
		`last_seen` int NOT NULL DEFAULT '0',
		`revoked_at` int NOT NULL DEFAULT '0',
		PRIMARY KEY (`session_hash`),
		KEY `account_last_seen` (`account_id`, `last_seen`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");

	if (function_exists('setting_set')) {
		account_security_add_column_if_missing('znote_account_security_events', 'ip_text', "varchar(45) NOT NULL DEFAULT '' AFTER `ip`");
		account_security_add_column_if_missing('znote_account_security_sessions', 'ip_text', "varchar(45) NOT NULL DEFAULT '' AFTER `ip`");
		setting_set('account_security:schema_version', '2');
	}
}

function account_security_log_event(int $accountId, string $event, ?string $sessionHash = null): void {
	if ($accountId <= 0) {
		return;
	}

	account_security_ensure_schema();
	db()->execute(
		"INSERT INTO `znote_account_security_events`
		(`account_id`, `event`, `ip`, `ip_text`, `user_agent`, `session_hash`, `created_at`)
		VALUES (?, ?, ?, ?, ?, ?, ?);",
		array($accountId, substr($event, 0, 40), account_security_ip_long(), account_security_ip_string(), account_security_user_agent(), $sessionHash ?? account_security_session_hash(), time())
	);
}

function account_security_touch_session(): void {
	if (!account_security_enabled() || !account_security_track_sessions()) {
		return;
	}

	$accountId = account_security_account_id();
	if ($accountId <= 0) {
		return;
	}

	$sessionHash = account_security_session_hash();
	if ($sessionHash === '') {
		return;
	}

	account_security_ensure_schema();

	$row = db()->fetchOne(
		"SELECT `revoked_at` FROM `znote_account_security_sessions` WHERE `session_hash` = ? AND `account_id` = ? LIMIT 1;",
		array($sessionHash, $accountId)
	);

	if (is_array($row) && (int)$row['revoked_at'] > 0) {
		account_security_log_event($accountId, 'revoked_session_blocked', $sessionHash);
		if (function_exists('znote_session_destroy')) {
			znote_session_destroy();
		}
		if (!headers_sent()) {
			header('Location: login.php');
		}
		exit;
	}

	$now = time();
	if ($row === false) {
		db()->execute(
			"INSERT INTO `znote_account_security_sessions`
			(`session_hash`, `account_id`, `ip`, `ip_text`, `user_agent`, `first_seen`, `last_seen`, `revoked_at`)
			VALUES (?, ?, ?, ?, ?, ?, ?, 0);",
			array($sessionHash, $accountId, account_security_ip_long(), account_security_ip_string(), account_security_user_agent(), $now, $now)
		);
		account_security_log_event($accountId, 'session_started', $sessionHash);
	} else {
		db()->execute(
			"UPDATE `znote_account_security_sessions`
			SET `ip` = ?, `ip_text` = ?, `user_agent` = ?, `last_seen` = ?
			WHERE `session_hash` = ? AND `account_id` = ?;",
			array(account_security_ip_long(), account_security_ip_string(), account_security_user_agent(), $now, $sessionHash, $accountId)
		);
	}

	db()->execute(
		"INSERT INTO `znote_account_security_notes` (`account_id`, `last_seen_ip`, `updated_at`)
		VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE `last_seen_ip` = VALUES(`last_seen_ip`), `updated_at` = VALUES(`updated_at`);",
		array($accountId, account_security_ip_long(), $now)
	);
}

function account_security_handle_post(): void {
	if (!account_security_enabled()
		|| ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST'
		|| (string)($_POST['account_security_action'] ?? '') !== 'revoke_session'
		|| account_security_account_id() <= 0
	) {
		return;
	}

	if (!class_exists('Token') || !Token::isValid($_POST['token'] ?? null)) {
		http_response_code(400);
		die('Invalid or expired form token.');
	}

	$accountId = account_security_account_id();
	$current = account_security_session_hash();
	$target = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_POST['session_hash'] ?? '')));
	if (strlen($target) === 64 && $target !== $current) {
		account_security_ensure_schema();
		db()->execute(
			"UPDATE `znote_account_security_sessions`
			SET `revoked_at` = ?
			WHERE `account_id` = ? AND `session_hash` = ? AND `revoked_at` = 0;",
			array(time(), $accountId, $target)
		);
		account_security_log_event($accountId, 'session_revoked', $target);
	}

	if (!headers_sent()) {
		header('Location: myaccount.php');
	}
	exit;
}

function account_security_event_label(string $event): string {
	$labels = array(
		'session_started' => t_default('account_security.event.session_started', 'Session started'),
		'session_revoked' => t_default('account_security.event.session_revoked', 'Session revoked'),
		'revoked_session_blocked' => t_default('account_security.event.revoked_session_blocked', 'Revoked session blocked'),
	);

	return $labels[$event] ?? ucwords(str_replace('_', ' ', $event));
}

function account_security_footer(): string {
	if (!account_security_enabled() || basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'myaccount.php' || account_security_account_id() <= 0) {
		return '';
	}

	account_security_touch_session();

	$accountId = account_security_account_id();
	account_security_ensure_schema();

	$recentIpRows = db()->fetchAll(
		"SELECT `ip`, `time`, `type` FROM `znote_visitors_details` WHERE `account_id` = ? ORDER BY `time` DESC LIMIT 6;",
		array($accountId)
	);
	$recentIpHtml = '';
	if (is_array($recentIpRows)) {
		foreach ($recentIpRows as $row) {
			$recentIpHtml .= '<li><span>' . account_security_h(account_security_ip($row['ip'])) . '</span><small>' . date('Y-m-d H:i', (int)$row['time']) . '</small></li>';
		}
	}

	$eventRows = db()->fetchAll(
		"SELECT `event`, `ip`, `ip_text`, `created_at` FROM `znote_account_security_events` WHERE `account_id` = ? ORDER BY `created_at` DESC LIMIT 6;",
		array($accountId)
	);
	$eventsHtml = '';
	if (is_array($eventRows)) {
		foreach ($eventRows as $row) {
			$eventsHtml .= '<li><span>' . account_security_h(account_security_event_label((string)$row['event'])) . ' &middot; ' . account_security_h(account_security_display_ip($row['ip'], (string)($row['ip_text'] ?? ''))) . '</span><small>' . date('Y-m-d H:i', (int)$row['created_at']) . '</small></li>';
		}
	}

	$current = account_security_session_hash();
	$activeSince = time() - 86400 * max(1, (int)account_security_setting('active_days', '30'));
	$sessionRows = db()->fetchAll(
		"SELECT `session_hash`, `ip`, `ip_text`, `user_agent`, `first_seen`, `last_seen`, `revoked_at`
		FROM `znote_account_security_sessions`
		WHERE `account_id` = ? AND `last_seen` >= ?
		ORDER BY `last_seen` DESC LIMIT 8;",
		array($accountId, $activeSince)
	);
	$sessionsHtml = '';
	if (is_array($sessionRows)) {
		foreach ($sessionRows as $row) {
			$isCurrent = hash_equals($current, (string)$row['session_hash']);
			$revoked = (int)$row['revoked_at'] > 0;
			$title = trim((string)$row['user_agent']) !== '' ? (string)$row['user_agent'] : t_default('account_security.unknown_browser', 'Unknown browser');
			$action = (!$isCurrent && !$revoked)
				? '<form method="post" style="margin:0">' . (function_exists('znote_csrf_field') ? znote_csrf_field() : '') . '<input type="hidden" name="account_security_action" value="revoke_session"><input type="hidden" name="session_hash" value="' . account_security_h($row['session_hash']) . '"><button type="submit">' . account_security_h(t_default('account_security.revoke', 'Revoke')) . '</button></form>'
				: '<small>' . account_security_h($isCurrent ? t_default('account_security.current', 'Current') : t_default('account_security.revoked', 'Revoked')) . '</small>';
			$sessionsHtml .= '<li><span title="' . account_security_h($title) . '">' . account_security_h(account_security_display_ip($row['ip'], (string)($row['ip_text'] ?? ''))) . '<small>' . date('Y-m-d H:i', (int)$row['last_seen']) . '</small></span>' . $action . '</li>';
		}
	}

	$twofa = t_default('account_security.unknown_c', 'Unknown');
	if (!empty($GLOBALS['config']['twoFactorAuthenticator'])) {
		$query = db()->fetchOne("SELECT `secret` FROM `accounts` WHERE `id` = ? LIMIT 1;", array($accountId));
		$twofa = (is_array($query) && !empty($query['secret'])) ? t_default('account_security.enabled', 'Enabled') : t_default('account_security.disabled', 'Disabled');
	}

	$css = '.as-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 18px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.96;overflow:hidden}.as-box *{box-sizing:border-box}.as-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}.as-box p{margin:6px 0}.as-box ul{margin:8px 0 0;padding:0;list-style:none}.as-box li{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:6px 10px;padding:7px 0;border-top:1px solid var(--znx-plugin-border);opacity:.9;overflow-wrap:anywhere}.as-box small{display:block;opacity:.7}.as-box b,.as-box span{overflow-wrap:anywhere}.as-box button{border:1px solid var(--znx-plugin-border);border-radius:6px;background:transparent;color:inherit;padding:4px 8px;cursor:pointer}.as-box button:hover{opacity:.8}';
	$html = '<div id="accountSecurityBox" class="as-box"' . account_security_style_attr() . '><strong>' . account_security_h(t_default('account_security.title', 'Account Security')) . '</strong><div class="as-grid"><div><p>' . account_security_h(t_default('account_security.twofa', '2FA status:')) . ' <b>' . account_security_h($twofa) . '</b></p><p>' . account_security_h(t_default('account_security.current_ip', 'Current IP:')) . ' <b>' . account_security_h(function_exists('getIP') ? getIP() : t_default('account_security.unknown', 'unknown')) . '</b></p></div><div><b>' . account_security_h(t_default('account_security.sessions', 'Active sessions')) . '</b><ul>' . ($sessionsHtml ?: '<li>' . account_security_h(t_default('account_security.none', 'No recent activity found.')) . '</li>') . '</ul></div><div><b>' . account_security_h(t_default('account_security.events', 'Security events')) . '</b><ul>' . ($eventsHtml ?: '<li>' . account_security_h(t_default('account_security.none', 'No recent activity found.')) . '</li>') . '</ul></div><div><b>' . account_security_h(t_default('account_security.recent', 'Recent IP activity')) . '</b><ul>' . ($recentIpHtml ?: '<li>' . account_security_h(t_default('account_security.none', 'No recent activity found.')) . '</li>') . '</ul></div></div></div>';

	return '<script>(function(){if(document.getElementById("accountSecurityBox"))return;var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);var root=document.getElementById("myaccount")||document.querySelector("main,#content,.content");if(!root)return;var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';root.appendChild(w.firstChild);}());</script>';
}
}

if (account_security_enabled()) {
	account_security_touch_session();
	account_security_handle_post();
}

if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'account_security_footer');
}

