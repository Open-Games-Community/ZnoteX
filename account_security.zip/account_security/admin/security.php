<?php
/**
 * Title: Account Security
 * Icon: fa-shield
 * Group: Installed Plugins
 * Order: 50
 * Description: Configure the My Account security panel.
 */
if(!defined('ACP_ROOT')){http_response_code(403);die('Direct access denied.');}
function account_security_admin_color($v):string{$v=trim((string)$v);return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$v)?$v:'';}
if($_SERVER['REQUEST_METHOD']==='POST'){setting_set('account_security:enabled',!empty($_POST['enabled'])?'1':'0');foreach(['box_bg','text','border'] as $k)setting_set('account_security:style_'.$k,account_security_admin_color($_POST['style_'.$k]??''));acp_flash_success('Account Security settings saved.');acp_redirect('account_security__security');}
$enabled=(string)setting('account_security:enabled','1')==='1';
$styleKeys=['box_bg'=>'Box background','text'=>'Text color','border'=>'Border color'];
?>
<?php acp_card_open('Account Security Center','Shows recent account IP activity and 2FA status without forcing 2FA.'); ?>
<form method="post"><?= acp_csrf_field() ?><div class="acp-field"><label><input type="checkbox" name="enabled" value="1" <?= $enabled?'checked':'' ?>> Enabled</label></div><h3>Style</h3><p class="acp-muted">Leave empty to inherit the theme, with default theme fallback.</p><div class="acp-grid acp-grid--2"><?php foreach($styleKeys as $k=>$label):?><div class="acp-field"><label class="acp-label"><?= h($label) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h(setting('account_security:style_'.$k,'')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)"></div><?php endforeach;?></div><div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit">Save</button></div></form>
<?php acp_card_close(); ?>
