<?php
/**
 * Title: Account Security
 * Icon: fa-shield
 * Group: Installed Plugins
 * Order: 50
 * Description: Configure the My Account security center.
 */

if (!defined('ACP_ROOT')) {
	http_response_code(403);
	die('Direct access denied.');
}

if (function_exists('account_security_ensure_schema')) {
	account_security_ensure_schema();
}

function account_security_admin_color($value): string {
	$value = trim((string)$value);
	return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value) ? $value : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	setting_set('account_security:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('account_security:track_sessions', !empty($_POST['track_sessions']) ? '1' : '0');
	setting_set('account_security:active_days', (string)max(1, min(365, (int)($_POST['active_days'] ?? 30))));

	foreach (array('box_bg', 'text', 'border') as $key) {
		setting_set('account_security:style_' . $key, account_security_admin_color($_POST['style_' . $key] ?? ''));
	}

	acp_flash_success('Account Security settings saved.');
	acp_redirect('account_security__security');
}

$enabled = (string)setting('account_security:enabled', '1') === '1';
$trackSessions = (string)setting('account_security:track_sessions', '1') === '1';
$activeDays = max(1, min(365, (int)setting('account_security:active_days', '30')));
$styleKeys = array('box_bg' => 'Box background', 'text' => 'Text color', 'border' => 'Border color');

$eventRows = function_exists('account_security_table_exists') && account_security_table_exists('znote_account_security_events')
	? db()->fetchAll("SELECT `e`.`account_id`, `e`.`event`, `e`.`ip`, `e`.`ip_text`, `e`.`created_at`, `a`.`name`
		FROM `znote_account_security_events` AS `e`
		LEFT JOIN `accounts` AS `a` ON `a`.`id` = `e`.`account_id`
		ORDER BY `e`.`created_at` DESC LIMIT 20;")
	: array();

$sessionRows = function_exists('account_security_table_exists') && account_security_table_exists('znote_account_security_sessions')
	? db()->fetchAll("SELECT `s`.`account_id`, `s`.`ip`, `s`.`ip_text`, `s`.`user_agent`, `s`.`first_seen`, `s`.`last_seen`, `s`.`revoked_at`, `a`.`name`
		FROM `znote_account_security_sessions` AS `s`
		LEFT JOIN `accounts` AS `a` ON `a`.`id` = `s`.`account_id`
		ORDER BY `s`.`last_seen` DESC LIMIT 20;")
	: array();
?>

<?php acp_card_open('Account Security Center', 'Shows account sessions, security events, recent IP activity and 2FA status on My Account.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field">
			<label><input type="checkbox" name="enabled" value="1" <?= $enabled ? 'checked' : '' ?>> Enabled</label>
			<p class="acp-muted">Display the security center on My Account.</p>
		</div>
		<div class="acp-field">
			<label><input type="checkbox" name="track_sessions" value="1" <?= $trackSessions ? 'checked' : '' ?>> Track web sessions</label>
			<p class="acp-muted">Allows users to see and revoke other website sessions.</p>
		</div>
		<div class="acp-field">
			<label class="acp-label">Active session window</label>
			<input class="acp-input" type="number" min="1" max="365" name="active_days" value="<?= h((string)$activeDays) ?>">
			<p class="acp-muted">Sessions seen during the last N days are shown to the user.</p>
		</div>
	</div>

	<h3>Style</h3>
	<p class="acp-muted">Leave empty to inherit the theme, with default theme fallback.</p>
	<div class="acp-grid acp-grid--2">
		<?php foreach ($styleKeys as $key => $label): ?>
			<div class="acp-field">
				<label class="acp-label"><?= h($label) ?></label>
				<input class="acp-input" name="style_<?= h($key) ?>" value="<?= h(setting('account_security:style_' . $key, '')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)">
			</div>
		<?php endforeach; ?>
	</div>

	<div class="acp-actions">
		<button class="acp-btn acp-btn--green" type="submit">Save</button>
	</div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Latest security events', 'Most recent security events recorded by the plugin.'); ?>
<table class="acp-table">
	<thead><tr><th>Account</th><th>Event</th><th>IP</th><th>Date</th></tr></thead>
	<tbody>
	<?php if (is_array($eventRows) && $eventRows): foreach ($eventRows as $row): ?>
		<tr>
			<td><?= h(($row['name'] ?? '') !== '' ? $row['name'] : '#' . $row['account_id']) ?></td>
			<td><?= h(function_exists('account_security_event_label') ? account_security_event_label((string)$row['event']) : (string)$row['event']) ?></td>
			<td><?= h(function_exists('account_security_display_ip') ? account_security_display_ip($row['ip'], (string)($row['ip_text'] ?? '')) : (string)$row['ip']) ?></td>
			<td><?= h(date('Y-m-d H:i', (int)$row['created_at'])) ?></td>
		</tr>
	<?php endforeach; else: ?>
		<tr><td colspan="4" class="acp-muted">No events recorded yet.</td></tr>
	<?php endif; ?>
	</tbody>
</table>
<?php acp_card_close(); ?>

<?php acp_card_open('Latest web sessions', 'Recent website sessions seen by the plugin.'); ?>
<table class="acp-table">
	<thead><tr><th>Account</th><th>IP</th><th>First seen</th><th>Last seen</th><th>Status</th></tr></thead>
	<tbody>
	<?php if (is_array($sessionRows) && $sessionRows): foreach ($sessionRows as $row): ?>
		<tr title="<?= h((string)$row['user_agent']) ?>">
			<td><?= h(($row['name'] ?? '') !== '' ? $row['name'] : '#' . $row['account_id']) ?></td>
			<td><?= h(function_exists('account_security_display_ip') ? account_security_display_ip($row['ip'], (string)($row['ip_text'] ?? '')) : (string)$row['ip']) ?></td>
			<td><?= h(date('Y-m-d H:i', (int)$row['first_seen'])) ?></td>
			<td><?= h(date('Y-m-d H:i', (int)$row['last_seen'])) ?></td>
			<td><?= ((int)$row['revoked_at'] > 0) ? 'Revoked' : 'Active' ?></td>
		</tr>
	<?php endforeach; else: ?>
		<tr><td colspan="5" class="acp-muted">No sessions recorded yet.</td></tr>
	<?php endif; ?>
	</tbody>
</table>
<?php acp_card_close(); ?>
