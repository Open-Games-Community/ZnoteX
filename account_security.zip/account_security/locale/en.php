<?php

return array(
	'account_security.title' => 'Account Security',
	'account_security.twofa' => '2FA status:',
	'account_security.current_ip' => 'Current IP:',
	'account_security.unknown' => 'unknown',
	'account_security.unknown_c' => 'Unknown',
	'account_security.enabled' => 'Enabled',
	'account_security.disabled' => 'Disabled',
	'account_security.recent' => 'Recent IP activity',
	'account_security.sessions' => 'Active sessions',
	'account_security.events' => 'Security events',
	'account_security.current' => 'Current',
	'account_security.revoked' => 'Revoked',
	'account_security.revoke' => 'Revoke',
	'account_security.unknown_browser' => 'Unknown browser',
	'account_security.event.session_started' => 'Session started',
	'account_security.event.session_revoked' => 'Session revoked',
	'account_security.event.revoked_session_blocked' => 'Revoked session blocked',
	'account_security.none' => 'No recent activity found.',
);
