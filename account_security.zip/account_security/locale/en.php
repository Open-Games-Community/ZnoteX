<?php

return array(
	'account_security.title' => 'Account Security',
	'account_security.twofa' => '2FA status:',
	'account_security.current_ip' => 'Current IP:',
	'account_security.unknown' => 'unknown',
	'account_security.unknown_c' => 'Unknown',
	'account_security.enabled' => 'Enabled',
	'account_security.disabled' => 'Disabled',
	'account_security.recent' => 'Recent activity',
	'account_security.none' => 'No recent activity found.',
);
