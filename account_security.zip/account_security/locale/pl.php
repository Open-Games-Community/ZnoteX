<?php

return array(
	'account_security.title' => 'Bezpieczeństwo konta',
	'account_security.twofa' => 'Status 2FA:',
	'account_security.current_ip' => 'Bieżące IP:',
	'account_security.unknown' => 'nieznane',
	'account_security.unknown_c' => 'Nieznany',
	'account_security.enabled' => 'Włączone',
	'account_security.disabled' => 'Wyłączone',
	'account_security.recent' => 'Ostatnia aktywność',
	'account_security.none' => 'Brak ostatniej aktywności.',
);
