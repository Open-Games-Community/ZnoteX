<?php

return array(
	'account_security.title' => 'Seguridad de la cuenta',
	'account_security.twofa' => 'Estado 2FA:',
	'account_security.current_ip' => 'IP actual:',
	'account_security.unknown' => 'desconocida',
	'account_security.unknown_c' => 'Desconocido',
	'account_security.enabled' => 'Activado',
	'account_security.disabled' => 'Desactivado',
	'account_security.recent' => 'Actividad reciente',
	'account_security.none' => 'No se encontró actividad reciente.',
);
