<?php

return array(
	'account_security.title' => 'Segurança da conta',
	'account_security.twofa' => 'Status 2FA:',
	'account_security.current_ip' => 'IP atual:',
	'account_security.unknown' => 'desconhecido',
	'account_security.unknown_c' => 'Desconhecido',
	'account_security.enabled' => 'Ativado',
	'account_security.disabled' => 'Desativado',
	'account_security.recent' => 'Atividade recente',
	'account_security.none' => 'Nenhuma atividade recente encontrada.',
);
