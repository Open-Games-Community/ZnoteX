<?php

return array(
	'account_security.title' => 'Kontosicherheit',
	'account_security.twofa' => '2FA-Status:',
	'account_security.current_ip' => 'Aktuelle IP:',
	'account_security.unknown' => 'unbekannt',
	'account_security.unknown_c' => 'Unbekannt',
	'account_security.enabled' => 'Aktiviert',
	'account_security.disabled' => 'Deaktiviert',
	'account_security.recent' => 'Letzte Aktivität',
	'account_security.none' => 'Keine Aktivität gefunden.',
);
