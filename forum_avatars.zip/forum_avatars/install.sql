﻿CREATE TABLE IF NOT EXISTS `znote_forum_avatars` (
  `player_id` int NOT NULL,
  `account_id` int NOT NULL DEFAULT '0',
  `character_name` varchar(64) NOT NULL DEFAULT '',
  `mode` varchar(10) NOT NULL DEFAULT 'outfit',
  `source` varchar(10) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(10) NOT NULL DEFAULT 'ok',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  KEY `mode_status` (`mode`, `status`),
  KEY `account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
