<?php
/**
 * Title: Forum Avatars
 * Icon: fa-user-circle
 * Group: Installed Plugins
 * Order: 39
 * Description: Gallery, upload rules and the moderation queue for player avatars.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'forum_avatars__avatars';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? 'config');

	if ($do === 'moderate') {
		$pid = intv($_POST['player_id'] ?? 0);
		$act = (string) ($_POST['act'] ?? '');
		$row = db()->fetchOne("SELECT * FROM `znote_forum_avatars` WHERE `player_id` = ? LIMIT 1;", [$pid]);
		if (is_array($row)) {
			if ($act === 'approve') db()->execute("UPDATE `znote_forum_avatars` SET `status` = 'ok' WHERE `player_id` = ? LIMIT 1;", [$pid]);
			elseif ($act === 'reject') db()->execute("UPDATE `znote_forum_avatars` SET `status` = 'rejected', `mode` = 'outfit' WHERE `player_id` = ? LIMIT 1;", [$pid]);
			elseif ($act === 'delete') {
				if ((string) $row['source'] === 'upload' && (string) $row['url'] !== '') {
					$base = basename(parse_url((string) $row['url'], PHP_URL_PATH));
					$f = dirname(__DIR__) . '/assets/uploads/' . $base;
					if (is_file($f) && strpos(realpath($f), realpath(dirname(__DIR__) . '/assets/uploads')) === 0) @unlink($f);
				}
				db()->execute("DELETE FROM `znote_forum_avatars` WHERE `player_id` = ? LIMIT 1;", [$pid]);
			}
			if (function_exists('acp_log')) acp_log('forum_avatars.' . $act, (string) $row['character_name']);
		}
		acp_flash_success('Done.');
		acp_redirect($module);
	}

	setting_set('forum_avatars:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('forum_avatars:require_approval', !empty($_POST['require_approval']) ? '1' : '0');
	setting_set('forum_avatars:max_kb', (string) max(64, min(4096, intv($_POST['max_kb'] ?? 2048))));
	setting_set('forum_avatars:gallery_urls', trim((string) ($_POST['gallery_urls'] ?? '')));
	acp_flash_success('Settings saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('forum_avatars:' . $k, $d);
$rows = db()->fetchAll("SELECT * FROM `znote_forum_avatars` WHERE `mode` = 'avatar' ORDER BY (`status` = 'pending') DESC, `updated_at` DESC LIMIT 100;");
$rows = is_array($rows) ? $rows : array();
$galleryDir = dirname(__DIR__) . '/assets/gallery';
$galleryFiles = is_dir($galleryDir) ? array_map('basename', (array) glob($galleryDir . '/*.{png,jpg,jpeg,gif,webp,svg}', GLOB_BRACE)) : array();
?>
<?php acp_card_open('Forum Avatars', 'Players swap their forum outfit picture for an avatar from My Account. Uploads are re-encoded to a 160&times;160 PNG. Drop gallery images into <code>plugins/forum_avatars/assets/gallery/</code> or list URLs below.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="require_approval" value="1" <?= $get('require_approval', '1') === '1' ? 'checked' : '' ?>> Uploaded avatars need staff approval before they show</label></div>
		<div class="acp-field"><label class="acp-label">Max upload size (KB)</label><input class="acp-input" type="number" min="64" max="4096" name="max_kb" value="<?= (int) $get('max_kb', '2048') ?>"></div>
	</div>
	<div class="acp-field"><label class="acp-label">Extra gallery image URLs (one per line)</label><textarea class="acp-textarea" name="gallery_urls" placeholder="https://…/avatars/knight.png"><?= h($get('gallery_urls')) ?></textarea></div>
	<p class="acp-muted">Files found in <code>assets/gallery/</code>: <?= $galleryFiles ? '<code>' . h(implode(', ', $galleryFiles)) . '</code>' : 'none' ?>.</p>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Player avatars', 'Pending uploads first. Reject also switches the character back to its outfit.'); ?>
<?php if (!$rows): ?><p class="acp-muted">No custom avatars yet.</p><?php else: ?>
<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th></th><th>Character</th><th>Source</th><th>Status</th><th></th></tr></thead><tbody>
	<?php foreach ($rows as $r): $pid = (int) $r['player_id']; ?>
		<tr>
			<td><?php if ((string) $r['url'] !== ''): ?><img src="<?= h($r['url']) ?>" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:8px"><?php endif; ?></td>
			<td><?= h($r['character_name']) ?></td>
			<td><?= h($r['source']) ?></td>
			<td><?= h($r['status']) ?></td>
			<td style="white-space:nowrap">
				<?php if ((string) $r['status'] === 'pending'): ?>
					<form class="acp-inline-form" method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="moderate"><input type="hidden" name="player_id" value="<?= $pid ?>"><input type="hidden" name="act" value="approve"><button class="acp-btn acp-btn--green acp-btn--sm" type="submit"><i class="fa fa-check"></i></button></form>
				<?php endif; ?>
				<form class="acp-inline-form" method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="moderate"><input type="hidden" name="player_id" value="<?= $pid ?>"><input type="hidden" name="act" value="reject"><button class="acp-btn acp-btn--sm" type="submit"><i class="fa fa-ban"></i></button></form>
				<form class="acp-inline-form" method="post" data-confirm="Delete this avatar?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="moderate"><input type="hidden" name="player_id" value="<?= $pid ?>"><input type="hidden" name="act" value="delete"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button></form>
			</td>
		</tr>
	<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
<?php acp_card_close(); ?>
