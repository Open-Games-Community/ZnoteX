<?php
/**
 * Forum Avatars - custom avatars on the forum, chosen from My Account.
 *
 * The ZnoteX forum renders the outfit image itself; this plugin does NOT touch
 * the core. Instead a page.footer script on forum.php / characterprofile.php
 * finds each `.avatar` cell, reads the character name from its link and swaps
 * the image for the player's avatar. Upload goes through GD (re-encoded to a
 * fixed-size PNG, so nothing but a clean image is ever stored).
 */
if (!function_exists('forum_avatars_setting')) {

function forum_avatars_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('forum_avatars:' . $k, $d) : $d;
}
function forum_avatars_enabled(): bool { return forum_avatars_setting('enabled', '1') === '1'; }
function forum_avatars_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function forum_avatars_int(string $k, int $d): int { $v = forum_avatars_setting($k, ''); return $v === '' ? $d : (int) $v; }
function forum_avatars_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function forum_avatars_tables_ok(): bool {
	return function_exists('znote_table_exists') && znote_table_exists('znote_forum_avatars');
}
function forum_avatars_require_approval(): bool { return forum_avatars_setting('require_approval', '1') === '1'; }

// --- gallery + storage -------------------------------------------
function forum_avatars_gallery(): array {
	static $g = null;
	if ($g !== null) return $g;
	$g = array();
	$dir = __DIR__ . '/assets/gallery';
	if (is_dir($dir)) {
		foreach ((array) glob($dir . '/*.{png,jpg,jpeg,gif,webp,svg}', GLOB_BRACE) as $f) {
			$g[] = znote_plugin_asset('forum_avatars', 'gallery/' . basename($f));
		}
	}
	foreach (preg_split('/[\s,]+/', (string) forum_avatars_setting('gallery_urls', '')) as $u) {
		$u = trim($u);
		if ($u !== '' && (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $u) || (isset($u[0]) && $u[0] === '/'))) $g[] = $u;
	}
	$g = array_values(array_unique($g));
	return $g;
}
function forum_avatars_uploads_dir(): ?string {
	$d = __DIR__ . '/assets/uploads';
	if (!is_dir($d)) @mkdir($d, 0775, true);
	return (is_dir($d) && is_writable($d)) ? $d : null;
}
function forum_avatars_for_player(int $playerId): ?array {
	if ($playerId <= 0 || !forum_avatars_tables_ok()) return null;
	$r = db()->fetchOne("SELECT * FROM `znote_forum_avatars` WHERE `player_id` = ? LIMIT 1;", [$playerId]);
	return is_array($r) ? $r : null;
}
function forum_avatars_save(int $playerId, int $accountId, string $name, string $mode, string $source, string $url, string $status): void {
	if (!forum_avatars_tables_ok()) return;
	$now = time();
	db()->execute("INSERT INTO `znote_forum_avatars` (`player_id`,`account_id`,`character_name`,`mode`,`source`,`url`,`status`,`updated_at`) VALUES (?,?,?,?,?,?,?,?) "
		. "ON DUPLICATE KEY UPDATE `account_id`=VALUES(`account_id`),`character_name`=VALUES(`character_name`),`mode`=VALUES(`mode`),`source`=VALUES(`source`),`url`=VALUES(`url`),`status`=VALUES(`status`),`updated_at`=VALUES(`updated_at`);",
		[$playerId, $accountId, $name, $mode, $source, $url, $status, $now]);
}
function forum_avatars_outfit_url(int $playerId): string {
	global $config;
	$srv = trim((string) ($config['show_outfits']['imageServer'] ?? ''));
	if ($srv === '' || $playerId <= 0) return '';
	$p = db()->fetchOne("SELECT `looktype`,`lookaddons`,`lookhead`,`lookbody`,`looklegs`,`lookfeet` FROM `players` WHERE `id` = ? LIMIT 1;", [$playerId]);
	if (!is_array($p)) return '';
	return $srv . (strpos($srv, '?') !== false ? '&' : '?')
		. 'id=' . (int) $p['looktype']
		. '&addons=' . (int) $p['lookaddons']
		. '&head=' . (int) $p['lookhead']
		. '&body=' . (int) $p['lookbody']
		. '&legs=' . (int) $p['looklegs']
		. '&feet=' . (int) $p['lookfeet'];
}
function forum_avatars_map(): array {
	static $m = null;
	if ($m !== null) return $m;
	$m = array();
	if (!forum_avatars_tables_ok()) return $m;
	$rows = db()->fetchAll("SELECT `character_name`,`url` FROM `znote_forum_avatars` WHERE `mode` = 'avatar' AND `status` = 'ok' AND `url` <> '';");
	if (is_array($rows)) foreach ($rows as $r) $m[strtolower((string) $r['character_name'])] = (string) $r['url'];
	return $m;
}

// --- upload ---------------------------------------------------
function forum_avatars_process_upload(array $file, int $playerId): array {
	$err = static fn(string $m) => array('ok' => false, 'message' => $m);
	if (!isset($file['tmp_name']) || $file['tmp_name'] === '' || !is_uploaded_file($file['tmp_name'])) return $err(forum_avatars_t('forum_avatars.err_upload', 'Upload failed.'));
	if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return $err(forum_avatars_t('forum_avatars.err_upload', 'Upload failed.'));
	$maxKb = max(64, forum_avatars_int('max_kb', 2048));
	if (($file['size'] ?? 0) > $maxKb * 1024) return $err(forum_avatars_t('forum_avatars.err_toobig', 'Image is larger than {n} KB.', array('n' => $maxKb)));
	if (!function_exists('imagecreatetruecolor')) return $err(forum_avatars_t('forum_avatars.err_gd', 'Image uploads are unavailable, pick from the gallery instead.'));

	$info = @getimagesize($file['tmp_name']);
	if (!is_array($info)) return $err(forum_avatars_t('forum_avatars.err_notimage', 'That file is not an image.'));
	[$w, $h, $type] = array($info[0], $info[1], $info[2]);
	if ($w < 16 || $h < 16 || $w > 6000 || $h > 6000) return $err(forum_avatars_t('forum_avatars.err_dims', 'Image dimensions are out of range.'));

	$src = null;
	if ($type === IMAGETYPE_JPEG) $src = @imagecreatefromjpeg($file['tmp_name']);
	elseif ($type === IMAGETYPE_PNG) $src = @imagecreatefrompng($file['tmp_name']);
	elseif ($type === IMAGETYPE_GIF) $src = @imagecreatefromgif($file['tmp_name']);
	elseif ($type === IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')) $src = @imagecreatefromwebp($file['tmp_name']);
	if (!$src) return $err(forum_avatars_t('forum_avatars.err_type', 'Use a JPG, PNG, GIF or WebP image.'));

	$sz = 160;
	$s = min($w, $h);
	$sx = (int) (($w - $s) / 2);
	$sy = (int) (($h - $s) / 2);
	$dst = imagecreatetruecolor($sz, $sz);
	imagealphablending($dst, false);
	imagesavealpha($dst, true);
	imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $sz, $sz, $s, $s);
	imagedestroy($src);

	$dir = forum_avatars_uploads_dir();
	if ($dir === null) { imagedestroy($dst); return $err(forum_avatars_t('forum_avatars.err_dir', 'Upload folder is not writable.')); }
	foreach ((array) glob($dir . '/' . $playerId . '_*.png') as $old) @unlink($old);
	$fname = $playerId . '_' . substr(bin2hex(random_bytes(5)), 0, 9) . '.png';
	$ok = imagepng($dst, $dir . '/' . $fname, 6);
	imagedestroy($dst);
	if (!$ok) return $err(forum_avatars_t('forum_avatars.err_save', 'Could not save the image.'));
	return array('ok' => true, 'url' => znote_plugin_asset('forum_avatars', 'uploads/' . $fname));
}

// --- the shared save handler (used by pages/avatar.php) ------
function forum_avatars_handle_post(int $accountId): array {
	$fail = static fn(string $m) => array('ok' => false, 'message' => $m);
	if (!forum_avatars_enabled() || !forum_avatars_tables_ok()) return $fail(forum_avatars_t('forum_avatars.err_disabled', 'Forum avatars are disabled.'));
	if ($accountId <= 0) return $fail(forum_avatars_t('forum_avatars.err_login', 'Log in to change your avatar.'));
	if (class_exists('Token') && !Token::isValid($_POST['token'] ?? null)) return $fail(forum_avatars_t('forum_avatars.err_session', 'Session expired, reload and try again.'));

	$pid = (int) ($_POST['player_id'] ?? 0);
	$name = '';
	if (function_exists('user_character_list')) {
		foreach ((array) user_character_list($accountId) as $c) {
			if ((int) ($c['id'] ?? 0) === $pid) { $name = (string) $c['name']; break; }
		}
	}
	if ($name === '') return $fail(forum_avatars_t('forum_avatars.err_char', 'Pick one of your characters.'));

	$mode = ($_POST['mode'] ?? 'outfit') === 'avatar' ? 'avatar' : 'outfit';

	if ($mode === 'outfit') {
		forum_avatars_save($pid, $accountId, $name, 'outfit', '', '', 'ok');
		return array('ok' => true, 'message' => forum_avatars_t('forum_avatars.saved_outfit', 'Your outfit will be shown on the forum.'));
	}

	if (($_POST['source'] ?? '') === 'gallery') {
		$url = (string) ($_POST['gallery'] ?? '');
		if (!in_array($url, forum_avatars_gallery(), true)) return $fail(forum_avatars_t('forum_avatars.err_gallery', 'Pick an avatar from the gallery.'));
		forum_avatars_save($pid, $accountId, $name, 'avatar', 'gallery', $url, 'ok');
		return array('ok' => true, 'message' => forum_avatars_t('forum_avatars.saved_avatar', 'Avatar updated.'));
	}

	if (!empty($_FILES['file']['name'])) {
		$res = forum_avatars_process_upload($_FILES['file'], $pid);
		if (empty($res['ok'])) return $fail($res['message']);
		$status = forum_avatars_require_approval() ? 'pending' : 'ok';
		forum_avatars_save($pid, $accountId, $name, 'avatar', 'upload', $res['url'], $status);
		return array('ok' => true, 'message' => $status === 'pending'
			? forum_avatars_t('forum_avatars.saved_pending', 'Uploaded — it will show once a staff member approves it.')
			: forum_avatars_t('forum_avatars.saved_avatar', 'Avatar updated.'));
	}

	$cur = forum_avatars_for_player($pid);
	if (is_array($cur) && (string) $cur['url'] !== '') {
		forum_avatars_save($pid, $accountId, $name, 'avatar', (string) $cur['source'], (string) $cur['url'], (string) $cur['status']);
		return array('ok' => true, 'message' => forum_avatars_t('forum_avatars.saved_avatar', 'Avatar updated.'));
	}
	return $fail(forum_avatars_t('forum_avatars.err_noimage', 'Choose an image or a gallery avatar first.'));
}

// --- the My Account editor (rendered on the plugin page and injected) -
function forum_avatars_editor_html(int $accountId, string $formAction, bool $withReturn = false): string {
	$chars = function_exists('user_character_list') ? (array) user_character_list($accountId) : array();
	if (!$chars) return '';
	$gallery = forum_avatars_gallery();
	$token = '';
	if (class_exists('Token')) { ob_start(); Token::create(); $token = ob_get_clean(); }

	$rows = array();
	$opts = '';
	foreach ($chars as $c) {
		$pid = (int) ($c['id'] ?? 0);
		if ($pid <= 0) continue;
		$cur = forum_avatars_for_player($pid);
		$rows[$pid] = array('name' => (string) ($c['name'] ?? ''), 'mode' => is_array($cur) ? (string) $cur['mode'] : 'outfit', 'url' => is_array($cur) ? (string) $cur['url'] : '', 'status' => is_array($cur) ? (string) $cur['status'] : 'ok', 'outfit' => forum_avatars_outfit_url($pid));
		$opts .= '<option value="' . $pid . '">' . forum_avatars_h($c['name'] ?? '') . '</option>';
	}
	if (!$rows) return '';
	$first = array_key_first($rows);

	$galleryHtml = '';
	foreach ($gallery as $g) $galleryHtml .= '<label class="favatar-gallery-item"><input type="radio" name="gallery" value="' . forum_avatars_h($g) . '"><img src="' . forum_avatars_h($g) . '" alt=""></label>';

	$maxKb = max(64, forum_avatars_int('max_kb', 2048));
	$maxLabel = $maxKb >= 1024
		? rtrim(rtrim(number_format($maxKb / 1024, 1, '.', ''), '0'), '.') . ' MB'
		: $maxKb . ' KB';
	$h = 'forum_avatars_h';

	return '<div id="forumAvatarBox" class="favatar-box">'
		. '<style>#forumAvatarBox{--fa-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--fa-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--fa-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--fa-accent:var(--accent,var(--link,#d1a233));margin:0 0 18px;padding:16px;border:1px solid var(--fa-border);border-radius:12px;background:var(--fa-surface);color:var(--fa-text)}'
		. '#forumAvatarBox *{box-sizing:border-box}#forumAvatarBox h3{margin:0 0 4px;font-size:15px}#forumAvatarBox p.favatar-lead{margin:0 0 14px;opacity:.75;font-size:13px}'
		. '#forumAvatarBox .favatar-row{display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start}'
		. '#forumAvatarBox .favatar-prev{width:96px;height:96px;flex:0 0 auto;border:1px solid var(--fa-border);border-radius:12px;object-fit:contain;background:rgba(0,0,0,.15)}'
		. '#forumAvatarBox .favatar-fields{flex:1 1 260px;min-width:240px;display:grid;gap:10px}'
		. '#forumAvatarBox label.favatar-lbl{font-size:12px;font-weight:700;opacity:.8}'
		. '#forumAvatarBox select,#forumAvatarBox input[type=file]{width:100%;padding:8px 10px;border:1px solid var(--fa-border);border-radius:8px;background:rgba(0,0,0,.14);color:inherit;font:inherit}'
		. '#forumAvatarBox select{max-width:320px;background:#f4f5f8;color:#1c1e24}#forumAvatarBox select option{background:#fff;color:#1c1e24}'
		. '#forumAvatarBox .favatar-modes{display:flex;gap:14px;font-size:13px}#forumAvatarBox .favatar-modes label{display:flex;align-items:center;gap:6px}'
		. '#forumAvatarBox details{border:1px solid var(--fa-border);border-radius:8px;padding:8px 10px}#forumAvatarBox summary{cursor:pointer;font-size:13px;font-weight:700}'
		. '#forumAvatarBox .favatar-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;max-height:190px;overflow:auto}'
		. '#forumAvatarBox .favatar-gallery-item{cursor:pointer}#forumAvatarBox .favatar-gallery-item input{display:none}#forumAvatarBox .favatar-gallery-item img{width:56px;height:56px;object-fit:cover;border:2px solid transparent;border-radius:10px}'
		. '#forumAvatarBox .favatar-gallery-item input:checked+img{border-color:var(--fa-accent)}'
		. '#forumAvatarBox .favatar-save{margin-top:4px;padding:10px 16px;border:0;border-radius:9px;background:var(--fa-accent);color:#151515;font-weight:800;cursor:pointer}'
		. '#forumAvatarBox .favatar-note{font-size:12px;opacity:.65}</style>'
		. '<h3>' . $h(forum_avatars_t('forum_avatars.title', 'Forum avatar')) . '</h3>'
		. '<p class="favatar-lead">' . $h(forum_avatars_t('forum_avatars.lead', 'Show a custom picture instead of your outfit on the forum. Per character.')) . '</p>'
		. '<form method="post" enctype="multipart/form-data" action="' . $h($formAction) . '">' . $token
		. ($withReturn ? '<input type="hidden" name="return" value="myaccount">' : '')
		. '<div class="favatar-row">'
		. '<img id="faPreview" class="favatar-prev" src="' . $h($rows[$first]['url'] !== '' ? $rows[$first]['url'] : $rows[$first]['outfit']) . '" alt="">'
		. '<div class="favatar-fields">'
		. '<div><label class="favatar-lbl">' . $h(forum_avatars_t('forum_avatars.character', 'Character')) . '</label><select name="player_id" id="faChar">' . $opts . '</select></div>'
		. '<div class="favatar-modes"><label><input type="radio" name="mode" value="outfit" checked> ' . $h(forum_avatars_t('forum_avatars.use_outfit', 'Show outfit')) . '</label>'
		. '<label><input type="radio" name="mode" value="avatar"> ' . $h(forum_avatars_t('forum_avatars.use_avatar', 'Show avatar')) . '</label></div>'
		. '<div><label class="favatar-lbl">' . $h(forum_avatars_t('forum_avatars.upload', 'Upload an image')) . ' <span class="favatar-note">(' . $h(forum_avatars_t('forum_avatars.uploadhint', 'max {size}, any size - it is resized and cropped to a square', array('size' => $maxLabel))) . ')</span></label><input type="file" name="file" accept="image/*" data-maxkb="' . $maxKb . '"><span class="favatar-note" id="faSizeErr" style="color:#e5534b;display:none"></span></div>'
		. ($galleryHtml !== '' ? '<details><summary>' . $h(forum_avatars_t('forum_avatars.gallery', 'Or pick from the gallery')) . '</summary><div class="favatar-grid">' . $galleryHtml . '</div></details>' : '')
		. '<button class="favatar-save" type="submit">' . $h(forum_avatars_t('forum_avatars.save', 'Save avatar')) . '</button>'
		. '</div></div></form>'
		. '<script>(function(){var D=' . json_encode(array_map(fn($r) => array('mode' => $r['mode'], 'url' => $r['url'], 'outfit' => $r['outfit'], 'status' => $r['status']), $rows)) . ';'
		. 'var sel=document.getElementById("faChar"),prev=document.getElementById("faPreview"),box=document.getElementById("forumAvatarBox");'
		. 'var fileEl=box.querySelector(\'input[name=file]\'),errEl=document.getElementById("faSizeErr"),localUrl="";'
		. 'function modeVal(){var m=box.querySelector(\'input[name=mode]:checked\');return m?m.value:"outfit";}'
		. 'function render(){var d=D[sel.value]||{};var src="";'
		. 'if(modeVal()==="avatar"){var g=box.querySelector(\'.favatar-gallery-item input:checked\');src=localUrl||(g?g.value:"")||d.url||"";}'
		. 'else{src=d.outfit||"";}'
		. 'prev.src=src;prev.style.display=src?"":"none";}'
		. 'function loadChar(){var d=D[sel.value]||{};localUrl="";if(fileEl)fileEl.value="";if(errEl)errEl.style.display="none";'
		. 'box.querySelectorAll(\'input[name=mode]\').forEach(function(r){r.checked=(r.value===(d.mode||"outfit"));});'
		. 'box.querySelectorAll(\'.favatar-gallery-item input\').forEach(function(r){r.checked=(d.url&&r.value===d.url);});render();}'
		. 'sel.addEventListener("change",loadChar);'
		. 'box.querySelectorAll(\'input[name=mode]\').forEach(function(r){r.addEventListener("change",render);});'
		. 'box.querySelectorAll(\'.favatar-gallery-item input\').forEach(function(r){r.addEventListener("change",function(){localUrl="";box.querySelector(\'input[name=mode][value=avatar]\').checked=true;render();});});'
		. 'if(fileEl)fileEl.addEventListener("change",function(){var f=fileEl.files&&fileEl.files[0];var mx=+fileEl.getAttribute("data-maxkb")||2048;'
		. 'if(f&&f.size>mx*1024){fileEl.value="";localUrl="";if(errEl){errEl.textContent=' . json_encode(forum_avatars_t('forum_avatars.err_toobig', 'Image is larger than {n} KB.', array('n' => $maxKb))) . ';errEl.style.display="";}render();return;}'
		. 'if(errEl)errEl.style.display="none";'
		. 'if(f){localUrl=URL.createObjectURL(f);box.querySelector(\'input[name=mode][value=avatar]\').checked=true;}else{localUrl="";}render();});'
		. 'loadChar();'
		. '}());</script>'
		. '</div>';
}

// --- footer: forum swap + myaccount card -------------------
function forum_avatars_footer(): string {
	if (!forum_avatars_enabled()) return '';
	$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
	$out = '';

	if (in_array($script, array('forum.php', 'characterprofile.php'), true)) {
		$map = forum_avatars_map();
		if ($map) {
			$out .= '<script>(function(){var M=' . json_encode($map, JSON_UNESCAPED_SLASHES) . ';'
				. 'function nm(s){try{return decodeURIComponent(s.replace(/\+/g," "))}catch(e){return s}}'
				. 'document.querySelectorAll(".avatar").forEach(function(cell){'
				. 'var a=cell.querySelector(\'a[href*="characterprofile.php?name="]\')||cell.querySelector("a");if(!a)return;'
				. 'var mm=(a.getAttribute("href")||"").match(/name=([^&]+)/);'
				. 'var name=(mm?nm(mm[1]):(a.textContent||"")).trim().toLowerCase();'
				. 'var url=M[name];if(!url)return;'
				. 'var img=cell.querySelector("img");'
				. 'if(img){img.removeAttribute("srcset");img.src=url;}else{img=document.createElement("img");img.alt="";a.insertAdjacentElement("afterend",img);img.src=url;}'
				. 'img.style.width="110px";img.style.height="110px";img.style.objectFit="cover";img.style.borderRadius="10px";'
				. '});}());</script>';
		}
	}

	if ($script === 'myaccount.php' && !empty($GLOBALS['session_user_id'])) {
		$card = forum_avatars_editor_html((int) $GLOBALS['session_user_id'], znote_plugin_url('forum_avatars', 'avatar'), true);
		if ($card !== '') {
			$out .= '<script>(function(){if(document.getElementById("forumAvatarBox"))return;var w=document.createElement("div");w.innerHTML=' . json_encode($card) . ';var el=w.firstChild;'
				. 'var host=document.getElementById("myaccount")||document.querySelector(".ec-content,main,#content,.content");'
				. 'if(host){var h=host.querySelector("h1,h2,h3");if(h&&h.parentNode)h.parentNode.insertBefore(el,h.nextSibling);else host.appendChild(el);}else{document.body.appendChild(el);}}());</script>';
		}
	}
	return $out;
}

}

if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'forum_avatars_footer');
}
