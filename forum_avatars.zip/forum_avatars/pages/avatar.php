<?php
/**
 * Public page: page.php?plugin=forum_avatars&p=avatar
 * Standalone avatar editor + the POST target for the My Account card.
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'forum_avatars_h';
$accountId = !empty($GLOBALS['session_user_id']) ? (int) $GLOBALS['session_user_id']
	: ((function_exists('user_logged_in') && user_logged_in() === true) ? (int) getSession('user_id') : 0);

$flash = null;
if ($accountId > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
	$flash = forum_avatars_handle_post($accountId);
}
$backToMyAccount = ($_POST['return'] ?? $_GET['return'] ?? '') === 'myaccount';
?>
<div style="max-width:640px">
	<h1><?= $h(forum_avatars_t('forum_avatars.page_title', 'Forum Avatar')) ?></h1>

	<?php if ($accountId === 0): ?>
		<p><?= forum_avatars_t('forum_avatars.login_html', 'You need to <a href="login.php">log in</a> to set an avatar.') ?></p>
	<?php else: ?>
		<?php if ($flash !== null): ?>
			<p style="padding:10px 14px;border-radius:9px;border:1px solid <?= !empty($flash['ok']) ? '#3f7d43' : '#9a3d3d' ?>;background:<?= !empty($flash['ok']) ? 'rgba(63,125,67,.14)' : 'rgba(154,61,61,.14)' ?>">
				<?= $h($flash['message']) ?>
			</p>
			<?php if (!empty($flash['ok']) && $backToMyAccount): ?>
				<script>setTimeout(function(){location.href='myaccount.php';},1100);</script>
				<p><a href="myaccount.php"><?= $h(forum_avatars_t('forum_avatars.back_account', 'Back to My Account')) ?></a></p>
			<?php endif; ?>
		<?php endif; ?>

		<?= forum_avatars_editor_html($accountId, znote_plugin_url('forum_avatars', 'avatar'), $backToMyAccount) ?>
	<?php endif; ?>
</div>
