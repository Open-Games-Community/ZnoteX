<?php
/**
 * Title: Daily Rewards
 * Icon: fa-calendar-check-o
 * Group: Installed Plugins
 * Order: 20
 * Description: Configure weekly login streak rewards.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }
function daily_rewards_admin_color($v): string { $v = trim((string)$v); return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v) ? $v : ''; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
	$rewards=[]; for($i=1;$i<=28;$i++) $rewards[$i]=['points'=>max(0,(int)($_POST['points'][$i]??0)),'premdays'=>max(0,(int)($_POST['premdays'][$i]??0)),'itemid'=>max(0,(int)($_POST['itemid'][$i]??0)),'count'=>max(0,(int)($_POST['count'][$i]??0))];
	setting_set('daily_rewards:enabled', !empty($_POST['enabled'])?'1':'0'); setting_set('daily_rewards:rewards', json_encode($rewards));
	foreach(['box_bg','text','border','tile_bg','today','check_bg','check_text','button_bg','button_text'] as $k) setting_set('daily_rewards:style_'.$k, daily_rewards_admin_color($_POST['style_'.$k]??''));
	acp_flash_success('Daily rewards saved.'); acp_redirect('daily_rewards__rewards');
}
$raw=json_decode((string)setting('daily_rewards:rewards',''),true); $rewards=is_array($raw)?$raw:daily_rewards_default_rewards(); $enabled=(string)setting('daily_rewards:enabled','1')==='1';
$styleKeys=['box_bg'=>'Box background','text'=>'Text color','border'=>'Border color','tile_bg'=>'Day tile background','today'=>'Next reward outline','check_bg'=>'Claimed check background','check_text'=>'Claimed check mark','button_bg'=>'Button background','button_text'=>'Button text'];
?>
<?php acp_card_open('Daily Rewards', 'Each daily claim advances the player one tile (Day 1, Day 2 ...). The 7-tile row resets every Monday, and it uses the reward row for the current week of the month. Item rewards are sent as pending shop item orders.'); ?>
<form method="post"><?= acp_csrf_field() ?><div class="acp-field"><label><input type="checkbox" name="enabled" value="1" <?= $enabled?'checked':'' ?>> Enabled</label></div>
<h3>Style</h3><p class="acp-muted">Leave empty to inherit the theme, with default theme fallback.</p><div class="acp-grid acp-grid--2"><?php foreach($styleKeys as $k=>$label):?><div class="acp-field"><label class="acp-label"><?= h($label) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h(setting('daily_rewards:style_'.$k,'')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)"></div><?php endforeach;?></div>
<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Day</th><th>Points</th><th>Premium days</th><th>Item ID</th><th>Count</th></tr></thead><tbody>
<?php for($i=1;$i<=28;$i++): $r=$rewards[$i]??[]; $week=(int)ceil($i/7); $day=(($i-1)%7)+1; ?><tr><td>Week <?= $week ?> / Day <?= $day ?></td><td><input class="acp-input" type="number" min="0" name="points[<?= $i ?>]" value="<?= (int)($r['points']??0) ?>"></td><td><input class="acp-input" type="number" min="0" name="premdays[<?= $i ?>]" value="<?= (int)($r['premdays']??0) ?>"></td><td><input class="acp-input" type="number" min="0" name="itemid[<?= $i ?>]" value="<?= (int)($r['itemid']??0) ?>"></td><td><input class="acp-input" type="number" min="0" name="count[<?= $i ?>]" value="<?= (int)($r['count']??0) ?>"></td></tr><?php endfor; ?>
</tbody></table></div><div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div></form>
<?php acp_card_close(); ?>
