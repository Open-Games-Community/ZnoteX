<?php

return array(
	'daily_rewards.disabled' => 'As recompensas diárias estão desativadas.',
	'daily_rewards.not_installed' => 'As recompensas diárias ainda não foram instaladas.',
	'daily_rewards.already_claimed' => 'Já resgatado hoje.',
	'daily_rewards.claimed_ok' => 'Recompensa resgatada.',
	'daily_rewards.title' => 'Recompensas Diárias - Semana {week}',
	'daily_rewards.day' => 'Dia {n}',
	'daily_rewards.pts' => '{n} pts',
	'daily_rewards.prem' => '{n} prem',
	'daily_rewards.item' => 'item',
	'daily_rewards.claimed' => 'Resgatado',
	'daily_rewards.claim' => 'Resgatar hoje',
	'daily_rewards.busy' => 'Tente novamente.',
);
