<?php

return array(
	'daily_rewards.disabled' => 'Codzienne nagrody są wyłączone.',
	'daily_rewards.not_installed' => 'Codzienne nagrody nie są jeszcze zainstalowane.',
	'daily_rewards.already_claimed' => 'Już odebrano dzisiaj.',
	'daily_rewards.claimed_ok' => 'Nagroda odebrana.',
	'daily_rewards.title' => 'Codzienne nagrody - Tydzień {week}',
	'daily_rewards.day' => 'Dzień {n}',
	'daily_rewards.pts' => '{n} pkt',
	'daily_rewards.prem' => '{n} prem',
	'daily_rewards.item' => 'przedmiot',
	'daily_rewards.claimed' => 'Odebrano',
	'daily_rewards.claim' => 'Odbierz dzisiaj',
);
