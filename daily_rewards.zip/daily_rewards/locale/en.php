<?php

return array(
	'daily_rewards.disabled' => 'Daily rewards are disabled.',
	'daily_rewards.not_installed' => 'Daily rewards are not installed yet.',
	'daily_rewards.already_claimed' => 'Already claimed today.',
	'daily_rewards.claimed_ok' => 'Reward claimed.',
	'daily_rewards.title' => 'Daily Rewards - Week {week}',
	'daily_rewards.day' => 'Day {n}',
	'daily_rewards.pts' => '{n} pts',
	'daily_rewards.prem' => '{n} prem',
	'daily_rewards.item' => 'item',
	'daily_rewards.claimed' => 'Claimed',
	'daily_rewards.claim' => 'Claim today',
);
