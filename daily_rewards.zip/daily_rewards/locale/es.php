<?php

return array(
	'daily_rewards.disabled' => 'Las recompensas diarias están desactivadas.',
	'daily_rewards.not_installed' => 'Las recompensas diarias aún no están instaladas.',
	'daily_rewards.already_claimed' => 'Ya reclamado hoy.',
	'daily_rewards.claimed_ok' => 'Recompensa reclamada.',
	'daily_rewards.title' => 'Recompensas diarias - Semana {week}',
	'daily_rewards.day' => 'Día {n}',
	'daily_rewards.pts' => '{n} pts',
	'daily_rewards.prem' => '{n} prem',
	'daily_rewards.item' => 'objeto',
	'daily_rewards.claimed' => 'Reclamado',
	'daily_rewards.claim' => 'Reclamar hoy',
	'daily_rewards.busy' => 'Inténtalo de nuevo.',
);
