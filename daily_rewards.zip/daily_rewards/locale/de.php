<?php

return array(
	'daily_rewards.disabled' => 'Tägliche Belohnungen sind deaktiviert.',
	'daily_rewards.not_installed' => 'Tägliche Belohnungen sind noch nicht installiert.',
	'daily_rewards.already_claimed' => 'Heute bereits abgeholt.',
	'daily_rewards.claimed_ok' => 'Belohnung abgeholt.',
	'daily_rewards.title' => 'Tägliche Belohnungen - Woche {week}',
	'daily_rewards.day' => 'Tag {n}',
	'daily_rewards.pts' => '{n} Pkt.',
	'daily_rewards.prem' => '{n} Prem',
	'daily_rewards.item' => 'Gegenstand',
	'daily_rewards.claimed' => 'Abgeholt',
	'daily_rewards.claim' => 'Heute abholen',
	'daily_rewards.busy' => 'Bitte versuche es erneut.',
);
