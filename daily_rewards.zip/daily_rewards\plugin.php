<?php
if (!function_exists('daily_rewards_setting')) {
function daily_rewards_setting(string $key, string $default): string { return function_exists('setting') ? (string)setting('daily_rewards:' . $key, $default) : $default; }
function daily_rewards_enabled(): bool { return daily_rewards_setting('enabled', '1') === '1'; }
function daily_rewards_h($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function daily_rewards_style_color(string $key): string { $value = trim(daily_rewards_setting('style_' . $key, '')); return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value) ? $value : ''; }
function daily_rewards_style_attr(): string { $map = ['box_bg'=>'--znx-plugin-surface','text'=>'--znx-plugin-text','border'=>'--znx-plugin-border','tile_bg'=>'--dr-tile-bg','today'=>'--dr-today-color','check_bg'=>'--dr-check-bg','check_text'=>'--dr-check-text','button_bg'=>'--dr-button-bg','button_text'=>'--dr-button-text']; $css = ''; foreach ($map as $key => $var) { $value = daily_rewards_style_color($key); if ($value !== '') $css .= $var . ':' . $value . ';'; } return $css !== '' ? ' style="' . daily_rewards_h($css) . '"' : ''; }
function daily_rewards_week_start(): string { return date('Y-m-d', strtotime('monday this week')); }
function daily_rewards_day_index(): int { return (int)date('N'); }
function daily_rewards_month_week(): int { return max(1, min(4, (int)ceil((int)date('j') / 7))); }
function daily_rewards_reward_index(?int $day = null): int { $day = $day ?: daily_rewards_day_index(); return ((daily_rewards_month_week() - 1) * 7) + $day; }
function daily_rewards_default_rewards(): array {
	$rewards = [];
	for ($i = 1; $i <= 28; $i++) {
		$rewards[$i] = ['points' => 5 + (int)floor(($i - 1) / 7) * 5, 'premdays' => ($i % 7 === 0 ? 1 : 0), 'itemid' => 0, 'count' => 0];
	}
	return $rewards;
}
function daily_rewards_config(): array { $raw = json_decode(daily_rewards_setting('rewards', ''), true); return is_array($raw) ? $raw : daily_rewards_default_rewards(); }
// Day N = the Nth claim of the current week, not the weekday. Claiming advances
// one tile; the week resets every Monday.
function daily_rewards_progress(int $accountId): int {
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_daily_rewards_claims')) return 0;
	$row = db()->fetchOne("SELECT COUNT(*) AS `c` FROM `znote_daily_rewards_claims` WHERE `account_id` = ? AND `week_start` = ?;", [$accountId, daily_rewards_week_start()]);
	return is_array($row) ? min(7, (int)$row['c']) : 0;
}
function daily_rewards_claimed_today(int $accountId): bool {
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_daily_rewards_claims')) return false;
	return is_array(db()->fetchOne("SELECT `id` FROM `znote_daily_rewards_claims` WHERE `account_id` = ? AND `reward_date` = ? LIMIT 1;", [$accountId, date('Y-m-d')]));
}
function daily_rewards_add_points(int $accountId, int $points): void { if ($points > 0) db()->execute("UPDATE `znote_accounts` SET `points`=COALESCE(`points`,0)+? WHERE `account_id`=?;", [$points, $accountId]); }
function daily_rewards_add_item(int $accountId, int $itemid, int $count): void {
	if ($itemid > 0 && $count > 0) db()->execute("INSERT INTO `znote_shop_orders` (`account_id`, `type`, `itemid`, `count`, `time`) VALUES (?, 1, ?, ?, ?);", [$accountId, $itemid, $count, time()]);
}
function daily_rewards_claim(int $accountId): string {
	if (!daily_rewards_enabled()) return t_default('daily_rewards.disabled','Daily rewards are disabled.');
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_daily_rewards_claims')) return t_default('daily_rewards.not_installed','Daily rewards are not installed yet.');

	// Named lock serializes concurrent claims from the same account, so a
	// double-submit cannot pass the "already claimed" check twice and credit
	// the reward more than once.
	$lockName = 'znx_daily_reward_' . $accountId;
	$lockRow = db()->fetchOne("SELECT GET_LOCK(?, 2) AS l;", [$lockName]);
	if (!is_array($lockRow) || (int)$lockRow['l'] !== 1) return t_default('daily_rewards.busy','Please try again.');

	try {
		$today = date('Y-m-d'); $week = daily_rewards_week_start();
		$exists = db()->fetchOne("SELECT `id` FROM `znote_daily_rewards_claims` WHERE `account_id` = ? AND `reward_date` = ? LIMIT 1;", [$accountId, $today]);
		if (is_array($exists)) return t_default('daily_rewards.already_claimed','Already claimed today.');
		$day = min(7, daily_rewards_progress($accountId) + 1);
		$cfg = daily_rewards_config(); $rewardIndex = daily_rewards_reward_index($day); $r = $cfg[$rewardIndex] ?? ['points'=>0,'premdays'=>0,'itemid'=>0,'count'=>0];
		$points = max(0, (int)($r['points'] ?? 0)); $prem = max(0, (int)($r['premdays'] ?? 0)); $item = max(0, (int)($r['itemid'] ?? 0)); $count = max(0, (int)($r['count'] ?? 0)); $now = time();
		db()->execute("INSERT INTO `znote_daily_rewards_claims` (`account_id`,`reward_date`,`week_start`,`day_index`,`points`,`premdays`,`itemid`,`item_count`,`created_at`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);", [$accountId, $today, $week, $day, $points, $prem, $item, $count, $now]);
		daily_rewards_add_points($accountId, $points);
		if ($prem > 0 && function_exists('user_account_add_premdays')) user_account_add_premdays($accountId, $prem);
		daily_rewards_add_item($accountId, $item, $count);
		return t_default('daily_rewards.claimed_ok','Reward claimed.');
	} finally {
		db()->fetchOne("SELECT RELEASE_LOCK(?);", [$lockName]);
	}
}
function daily_rewards_footer(): string {
	if (!daily_rewards_enabled() || basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'myaccount.php' || empty($GLOBALS['session_user_id'])) return '';
	$accountId = (int)$GLOBALS['session_user_id'];
	if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['daily_rewards_action'] ?? '') === 'claim' && class_exists('Token') && Token::isValid($_POST['token'] ?? null)) $GLOBALS['daily_rewards_message'] = daily_rewards_claim($accountId);
	$progress = daily_rewards_progress($accountId); $claimedToday = daily_rewards_claimed_today($accountId); $cfg = daily_rewards_config(); $tiles = '';
	$nextSlot = $claimedToday ? 0 : min(7, $progress + 1);
	for ($i=1;$i<=7;$i++) { $r=$cfg[daily_rewards_reward_index($i)] ?? []; $done=$i<=$progress; $isNext=$i===$nextSlot; $rl=t_default('daily_rewards.pts','{n} pts',['n'=>(int)($r['points']??0)]); if((int)($r['premdays']??0)>0)$rl.=' + '.t_default('daily_rewards.prem','{n} prem',['n'=>(int)$r['premdays']]); if((int)($r['itemid']??0)>0)$rl.=' + '.t_default('daily_rewards.item','item'); $txt=t_default('daily_rewards.day','Day {n}',['n'=>$i]).'<small>'.$rl.'</small>'; $tiles.='<div class="dr-tile '.($done?'is-done ':'').($isNext?'is-today':'').'">'.($done?'<span class="dr-check" aria-hidden="true">&#10003;</span>':'').$txt.'</div>'; }
	$button = $claimedToday ? '<button class="dr-btn" type="button" disabled>'.t_default('daily_rewards.claimed','Claimed').'</button>' : '<button class="dr-btn" type="submit">'.t_default('daily_rewards.claim','Claim today').'</button>';
	ob_start(); Token::create(); $token = ob_get_clean(); $msg = daily_rewards_h($GLOBALS['daily_rewards_message'] ?? '');
	$css='.dr-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 18px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.96;overflow:hidden}.dr-box *{box-sizing:border-box}.dr-head{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-bottom:10px}.dr-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(92px,1fr));gap:8px}.dr-tile{position:relative;min-width:0;padding:10px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:var(--dr-tile-bg,var(--znx-plugin-surface));text-align:center;font-weight:700;overflow-wrap:anywhere}.dr-tile small{display:block;margin-top:4px;font-size:11px;font-weight:400;opacity:.75}.dr-tile.is-done{opacity:.6}.dr-tile.is-done::after{content:"";position:absolute;left:7px;right:7px;top:50%;height:2px;background:currentColor;opacity:.45;transform:rotate(-13deg)}.dr-check{position:absolute;top:3px;right:4px;min-width:15px;height:15px;line-height:15px;padding:0 2px;text-align:center;font-size:11px;font-weight:800;border-radius:8px;background:var(--dr-check-bg,#2f9e5e);color:var(--dr-check-text,#fff);opacity:1}.dr-tile.is-today{outline:2px solid var(--dr-today-color,var(--znx-plugin-border));outline-offset:1px}.dr-btn{padding:8px 12px;border-radius:6px;border:1px solid var(--znx-plugin-border);background:var(--dr-button-bg,var(--znx-plugin-surface));color:var(--dr-button-text,var(--znx-plugin-text));cursor:pointer}.dr-btn:hover{filter:brightness(1.08)}.dr-btn:disabled,.dr-btn[disabled]{opacity:.5;cursor:default;filter:none}.dr-msg{margin:8px 0 0;overflow-wrap:anywhere}';
	$html='<div id="dailyRewardsBox" class="dr-box"'.daily_rewards_style_attr().'><div class="dr-head"><strong>'.daily_rewards_h(t_default('daily_rewards.title','Daily Rewards - Week {week}',['week'=>daily_rewards_month_week()])).'</strong><form method="post">'.$token.'<input type="hidden" name="daily_rewards_action" value="claim">'.$button.'</form></div><div class="dr-grid">'.$tiles.'</div>'.($msg!==''?'<p class="dr-msg">'.$msg.'</p>':'').'</div>';
	return '<script>(function(){if(document.getElementById("dailyRewardsBox"))return;var s=document.createElement("style");s.textContent='.json_encode($css).';document.head.appendChild(s);var root=document.getElementById("myaccount")||document.querySelector("main,#content,.content");if(!root)return;var w=document.createElement("div");w.innerHTML='.json_encode($html).';root.insertBefore(w.firstChild,root.firstChild);}());</script>';
}
}
if (function_exists('znote_hook_register')) znote_hook_register('page.footer', 'daily_rewards_footer');
