﻿CREATE TABLE IF NOT EXISTS `znote_daily_rewards_claims` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `reward_date` date NOT NULL,
  `week_start` date NOT NULL,
  `day_index` tinyint NOT NULL DEFAULT '1',
  `points` int NOT NULL DEFAULT '0',
  `premdays` int NOT NULL DEFAULT '0',
  `itemid` int NOT NULL DEFAULT '0',
  `item_count` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_day` (`account_id`, `reward_date`),
  KEY `account_week` (`account_id`, `week_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
