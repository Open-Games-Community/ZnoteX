<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

theme_open();

if ($config['log_ip'])
	znote_visitor_insert_detailed_data(3);

$querystring_id = &$_GET['id'];
$townid = ($querystring_id) ? (int)$_GET['id'] : $config['houseConfig']['HouseListDefaultTown'];
$towns = $config['towns'];

$order = &$_GET['order'];
$type = &$_GET['type'];
?>
<h1><?= t('common.town') ?></h1>

<form action="" method="get">
	<select name="id">
		<?php foreach ($towns as $id => $name): ?>
			<option value="<?= $h($id) ?>" <?= $townid == $id ? 'selected' : '' ?>><?= $h($name) ?></option>
		<?php endforeach; ?>
	</select>

	<?php
	$order_allowed = array('id', 'name', 'size', 'beds', 'rent', 'owner');
	$order_labels = array('id' => 'ID', 'name' => t('common.name'), 'size' => t('house.size'), 'beds' => t('house.beds'), 'rent' => t('house.rent'), 'owner' => t('house.owner'));
	?>
	<select name="order">
		<?php foreach ($order_allowed as $o): ?>
			<option value="<?= $h($o) ?>" <?= $o == $order ? 'selected' : '' ?>><?= $h($order_labels[$o]) ?></option>
		<?php endforeach; ?>
	</select>

	<?php $type_allowed = array('desc', 'asc'); ?>
	<select name="type">
		<?php foreach ($type_allowed as $t): ?>
			<option value="<?= $h($t) ?>" <?= $t == $type ? 'selected' : '' ?>><?= $t == 'desc' ? t('houses.descending') : t('houses.ascending') ?></option>
		<?php endforeach; ?>
	</select>

	<button type="submit"><?= t('houses.fetch') ?></button>
</form>

<?php
if (!in_array($order, $order_allowed))
	$order = 'id';

if (!in_array($type, $type_allowed))
	$type = 'desc';

$cache = new Cache('engine/cache/houses/houses-' . $order . '-' . $type);
$houses = array();

if ($cache->hasExpired()) {

	$houses = db()->fetchAll("
		SELECT
			`id`, `owner`, `paid`, `warnings`, `name`, `rent`, `town_id`,
			`size`, `beds`, " . houseSelect(array('bid','bid_end','last_bid','highest_bidder')) . "
		FROM `houses`
		ORDER BY {$order} {$type};
	");

	if ($houses !== false) {
		$playerlist = array();

		foreach ($houses as $houseRow)
			if ($houseRow['owner'] > 0)
				$playerlist[] = (int)$houseRow['owner'];

		if (!empty($playerlist)) {
			$placeholders = implode(',', array_fill(0, count($playerlist), '?'));
			$tmpPlayers = db()->fetchAll("SELECT `id`, `name` FROM players WHERE `id` IN ($placeholders);", $playerlist);

			$tmpById = array();
			foreach ($tmpPlayers as $p)
				$tmpById[$p['id']] = $p['name'];

			for ($i = 0; $i < count($houses); $i++)
				if ($houses[$i]['owner'] > 0)
					$houses[$i]['ownername'] = $tmpById[$houses[$i]['owner']];
		}

		$cache->setContent($houses);
		$cache->save();
	}
} else
	$houses = $cache->load();

if ($houses !== false || !empty($houses)) {
	?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-home"></i> <?= $h($towns[$townid] ?? t('common.town')) ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('common.name') ?></th>
					<th style="text-align:right;"><?= t('house.size') ?></th>
					<th style="text-align:right;"><?= t('house.beds') ?></th>
					<th style="text-align:right;"><?= t('house.rent') ?></th>
					<th><?= t('house.owner') ?></th>
					<th><?= t('common.town') ?></th>
				</tr>
				<?php $i = 0; ?>
				<?php foreach ($houses as $house): ?>
					<?php if ($house['town_id'] == $townid): ?>
						<?php $town_name = $towns[$house['town_id']] ?? null; ?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<td><a href="house.php?id=<?= (int) $house['id'] ?>"><?= $h($house['name']) ?></a></td>
							<td style="text-align:right;"><?= (int) $house['size'] ?></td>
							<td style="text-align:right;"><?= (int) $house['beds'] ?></td>
							<td style="text-align:right;"><?= (int) $house['rent'] ?></td>
							<?php if ($house['owner'] != 0): ?>
								<td><a href="characterprofile.php?name=<?= $h($house['ownername']) ?>" target="_blank"><?= $h($house['ownername']) ?></a></td>
							<?php else: ?>
								<td><?= ($house['highest_bidder'] == 0) ? $h(t('common.none')) : '<b>' . $h(t_default('houses.selling', 'Selling')) . '</b>' ?></td>
							<?php endif; ?>
							<td><?= $town_name ? $h($town_name) : $h(t_default('houses.unknown_town', 'Specify town id') . ' ' . $house['town_id'] . ' ' . t_default('houses.unknown_town_suffix', 'name in config.php first.')) ?></td>
						</tr>
						<?php $i++; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
	<?php
} else {
	?>
	<h1><?= t('houses.fetch_failed') ?></h1>
	<p class="lead"><?= t('houses.empty') ?></p>
	<?php
}

theme_close();
