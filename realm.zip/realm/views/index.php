<?php
require_once __DIR__ . '/../boxes.php';
$rmOnline  = (int) (function_exists('user_count_online') ? user_count_online() : 0);
$rmServerOnline = realm_server_online();
$rmSave    = realm_server_save();
$rmForum   = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$rmDiscord = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$rmTagline = function_exists('theme_option') ? trim(theme_option('hero_tagline')) : '';
if ($rmTagline === '') $rmTagline = (string) ($config['site_title'] ?? '');
$rmLaunchAt = realm_launch_countdown();
?>
<section class="hero hero--vivid hero--open">
	<div class="hero__scrim"></div>
	<div class="hero__inner">
		<div class="hero__eyebrow"><span class="dot <?= $rmServerOnline ? '' : 'dot--off' ?>"></span> <?= $rmServerOnline ? t('realm.hero.online') : t('realm.hero.offline') ?></div>
		<h1 class="hero__title"><?= h((string) ($config['site_title'] ?? 'Realm')) ?></h1>
		<?php if ($rmTagline !== ''): ?><p class="hero__tagline"><?= h($rmTagline) ?></p><?php endif; ?>
		<div class="hero__cta">
			<a class="btn btn--grass btn--lg" href="downloads.php"><i class="fas fa-download"></i> <?= t('realm.hero.play') ?></a>
			<a class="btn btn--amber btn--lg" href="register.php"><?= t('realm.header.register') ?></a>
		</div>
		<div class="pulse">
			<div class="pulse__cell">
				<div class="pulse__label"><?= t('realm.hero.players_online') ?></div>
				<div class="pulse__value <?= $rmServerOnline ? 'pulse__value--online' : 'pulse__value--offline' ?>"><?= $rmOnline ?></div>
			</div>
			<?php if ($rmServerOnline && $rmSave['since'] !== null): ?>
			<div class="pulse__cell">
				<div class="pulse__label"><?= t('realm.hero.uptime') ?></div>
				<div class="pulse__value"><?= h(realm_duration_short($rmSave['since'])) ?></div>
			</div>
			<div class="pulse__cell">
				<div class="pulse__label"><?= t('realm.hero.server_save') ?></div>
				<div class="pulse__value" data-countdown="<?= h(date('c', $rmSave['next'])) ?>"></div>
			</div>
			<?php endif; ?>
			<div class="pulse__cell">
				<div class="pulse__label"><?= t('realm.hero.client') ?></div>
				<div class="pulse__value"><?= isset($config['client']) ? h((string) ((int) $config['client'] / 100)) : '&mdash;' ?></div>
			</div>
		</div>
		<?php if ($rmLaunchAt !== null): ?>
		<div class="pulse pulse--launch">
			<div class="pulse__cell">
				<div class="pulse__label"><?= t('realm.hero.launch_countdown') ?></div>
				<div class="pulse__value pulse__value--launch" data-countdown="<?= h(date('c', $rmLaunchAt)) ?>"></div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</section>

<main class="shell">
	<aside class="rail rail--left">
		<?php realm_render_left_rail(); ?>
	</aside>

	<div class="col-main feedContainer">
		<?php if ($config['UseChangelogTicker'] && isset($changelogs) && $changelogs): ?>
			<div class="card">
				<div class="card__head"><i class="fas fa-list"></i> <?= t('news.changelog_ticker') ?> (<a href="changelog.php"><?= t('news.changelog_full') ?></a>)</div>
				<div class="card__body card__body--flush clog-list">
						<?php for ($i = 0; $i < count($changelogs) && $i < 5; $i++): ?>
							<details class="clog-row">
								<summary class="clog-row__summary">
									<span class="clog-row__time"><?= getClock($changelogs[$i]['time'], true, true) ?></span>
									<span class="clog-row__preview"><?= $changelogs[$i]['text'] ?></span>
									<span class="clog-row__toggle" aria-hidden="true"></span>
								</summary>
								<div class="clog-row__full"><?= $changelogs[$i]['text'] ?></div>
							</details>
						<?php endfor; ?>
					</div>
			</div>
		<?php endif; ?>

		<?php if ($news): ?>
			<?php
			$total_news = count($news);
			$page_amount = ceil($total_news / $config['news_per_page']);
			$current = $config['news_per_page'] * $page;
			?>
			<?php for ($i = $current; $i < $current + $config['news_per_page'] && $i < $total_news; $i++): ?>
				<div class="card">
					<div class="card__head"><i class="fas fa-scroll"></i> <?= znote_bbcode_raw($news[$i]['title']) ?></div>
					<div class="card__body">
						<p style="opacity:.7;font-size:.85em;margin-top:0;">
							<?= getClock($news[$i]['date'], true) ?> &middot; <?= t('news.by') ?> <a href="characterprofile.php?name=<?= h((string) $news[$i]['name']) ?>"><?= h((string) $news[$i]['name']) ?></a>
						</p>
						<?= znote_bbcode_raw($news[$i]['text']) ?>
					</div>
				</div>
			<?php endfor; ?>
			<?php if ($page_amount > 1): ?>
				<div class="card__body" style="display:flex;gap:8px;flex-wrap:wrap;">
					<?php for ($i = 0; $i < $page_amount; $i++): ?>
						<a class="btn btn--azure<?= $i === $page ? '' : ' btn--ghost' ?>" href="?page=<?= $i ?>"><?= $i + 1 ?></a>
					<?php endfor; ?>
				</div>
			<?php endif; ?>
		<?php else: ?>
			<div class="card"><div class="card__body"><?= t('news.no_news') ?></div></div>
		<?php endif; ?>
	</div>

	<aside class="rail">
		<?php realm_render_right_rail(); ?>
	</aside>
</main>
