<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

$rmProviderConfigs = array(
	'paypal' => $paypal,
	'stripe' => $stripe,
	'mercadopago' => $mercadopago,
);
$rmProviderLabels = array(
	'paypal' => t('buypoints.paypal'),
	'stripe' => 'Stripe',
	'mercadopago' => 'Mercado Pago',
);
$rmProviders = array();
foreach (array('paypal', 'stripe', 'mercadopago') as $rmKey) {
	if (!empty($rmProviderConfigs[$rmKey]['enabled'])) $rmProviders[] = $rmKey;
}
$rmHasPagseguro = !empty($config['pagseguro']['enabled']);
$rmHasPaygol = !empty($config['paygol']['enabled']);
$rmAnyEnabled = $rmProviders || $rmHasPagseguro || $rmHasPaygol;
$rmFirstBlock = true;
?>
<section class="store-shell buypoints">
	<header class="store-head">
		<h1><?= t('buypoints.title') ?></h1>
	</header>

	<?php if (!$rmAnyEnabled): ?>
		<p class="lead"><?= t('buypoints.disabled') ?></p>
		<p><?= t('buypoints.disabled_text') ?></p>
	<?php else: ?>

		<?php foreach ($rmProviders as $rmProvider): ?>
			<?php
			$rmCfg = $rmProviderConfigs[$rmProvider];
			$rmShowBonus = !empty($rmCfg['showBonus']);
			$rmCurrency = (string) ($rmCfg['currency'] ?? '');
			$rmPointsPerCurrency = (float) ($rmCfg['points_per_currency'] ?? 0);
			?>
			<div class="TableContainer"<?= $rmFirstBlock ? ' id="buypointsTable"' : '' ?>>
				<div class="CaptionContainer">
					<div class="CaptionInnerContainer">
						<div class="Text"><i class="fas fa-coins"></i> <?= $h($rmProviderLabels[$rmProvider]) ?></div>
					</div>
				</div>
				<div class="TableContentContainer">
					<table class="TableContent" width="100%">
						<tr>
							<th><?= t('buypoints.price') ?></th>
							<th><?= t('buypoints.points') ?></th>
							<?php if ($rmShowBonus): ?><th><?= t('buypoints.bonus_col') ?></th><?php endif; ?>
							<th><?= t('buypoints.action') ?></th>
						</tr>
						<?php $rmRow = 0; foreach ($prices as $price => $points): ?>
							<tr class="<?= $rmRow++ % 2 === 0 ? 'Odd' : 'Even' ?>">
								<td><?= $h($price) ?> (<?= $h($rmCurrency) ?>)</td>
								<td><?= (int) $points ?></td>
								<?php if ($rmShowBonus): ?>
									<td><?= $h(calculate_discount($rmPointsPerCurrency * $price, $points)) ?> <?= t('buypoints.bonus') ?></td>
								<?php endif; ?>
								<td>
									<?php if ($rmProvider === 'paypal'): ?>
										<form action="https://www.paypal.com/cgi-bin/webscr" method="POST">
											<input type="hidden" name="cmd" value="_xclick">
											<input type="hidden" name="business" value="<?= $h($paypal['email']) ?>">
											<input type="hidden" name="item_name" value="<?= $h(t('buypoints.shop_points_on', ['points' => $points, 'site' => $config['site_title']])) ?>">
											<input type="hidden" name="item_number" value="1">
											<input type="hidden" name="amount" value="<?= $h($price) ?>">
											<input type="hidden" name="no_shipping" value="1">
											<input type="hidden" name="no_note" value="1">
											<input type="hidden" name="currency_code" value="<?= $h($paypal['currency']) ?>">
											<input type="hidden" name="lc" value="GB">
											<input type="hidden" name="bn" value="PP-BuyNowBF">
											<input type="hidden" name="return" value="<?= $h($paypal['success']) ?>">
											<input type="hidden" name="cancel_return" value="<?= $h($paypal['failed']) ?>">
											<input type="hidden" name="rm" value="2">
											<input type="hidden" name="notify_url" value="<?= $h($paypal['ipn']) ?>">
											<input type="hidden" name="custom" value="<?= (int) $session_user_id ?>">
											<button type="submit" class="btn btn--amber"><?= t('buypoints.purchase') ?></button>
										</form>
									<?php else: ?>
										<form action="payment.php" method="post">
											<?php Token::create(); ?>
											<input type="hidden" name="provider" value="<?= $h($rmProvider) ?>">
											<input type="hidden" name="price" value="<?= $h($price) ?>">
											<button type="submit" class="btn btn--amber"><?= t('buypoints.purchase') ?></button>
										</form>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</div>
			</div>
			<?php $rmFirstBlock = false; ?>
		<?php endforeach; ?>

		<?php if ($rmHasPagseguro): $rmPagseguro = $config['pagseguro']; ?>
			<div class="TableContainer"<?= $rmFirstBlock ? ' id="buypointsTable"' : '' ?>>
				<div class="CaptionContainer">
					<div class="CaptionInnerContainer">
						<div class="Text"><i class="fas fa-coins"></i> <?= t('buypoints.pagseguro') ?></div>
					</div>
				</div>
				<div class="TableContentContainer" style="padding:18px;">
					<form target="pagseguro" action="https://<?= $h($rmPagseguro['urls']['www']) ?>/checkout/checkout.jhtml" method="post">
						<input type="hidden" name="email_cobranca" value="<?= $h($rmPagseguro['email']) ?>">
						<input type="hidden" name="tipo" value="CP">
						<input type="hidden" name="moeda" value="<?= $h($rmPagseguro['currency']) ?>">
						<input type="hidden" name="ref_transacao" value="<?= (int) $session_user_id ?>">
						<input type="hidden" name="item_id_1" value="1">
						<input type="hidden" name="item_descr_1" value="<?= $h($rmPagseguro['product_name']) ?>">
						<input type="number" name="item_quant_1" min="1" step="4" value="1">
						<input type="hidden" name="item_peso_1" value="0">
						<input type="hidden" name="item_valor_1" value="<?= $h($rmPagseguro['price']) ?>">
						<button type="submit" class="btn btn--amber"><?= t('buypoints.purchase') ?></button>
					</form>
				</div>
			</div>
			<?php $rmFirstBlock = false; ?>
		<?php endif; ?>

		<?php if ($rmHasPaygol): $rmPaygol = $config['paygol']; ?>
			<div class="TableContainer"<?= $rmFirstBlock ? ' id="buypointsTable"' : '' ?>>
				<div class="CaptionContainer">
					<div class="CaptionInnerContainer">
						<div class="Text"><i class="fas fa-coins"></i> <?= t('buypoints.paygol') ?></div>
					</div>
				</div>
				<div class="TableContentContainer" style="padding:18px;">
					<p style="margin:0 0 14px;"><?= t('buypoints.paygol_line', ['price' => $rmPaygol['price'], 'currency' => $h($rmPaygol['currency']), 'points' => $rmPaygol['points']]) ?></p>
					<form name="pg_frm" method="post" action="http://www.paygol.com/micropayment/paynow">
						<input type="hidden" name="pg_serviceid" value="<?= $h($rmPaygol['serviceID']) ?>">
						<input type="hidden" name="pg_currency" value="<?= $h($rmPaygol['currency']) ?>">
						<input type="hidden" name="pg_name" value="<?= $h($rmPaygol['name']) ?>">
						<input type="hidden" name="pg_custom" value="<?= $h($session_user_id) ?>">
						<input type="hidden" name="pg_price" value="<?= $h($rmPaygol['price']) ?>">
						<input type="hidden" name="pg_return_url" value="<?= $h($rmPaygol['returnURL']) ?>">
						<input type="hidden" name="pg_cancel_url" value="<?= $h($rmPaygol['cancelURL']) ?>">
						<input type="image" name="pg_button" src="https://www.paygol.com/micropayment/img/buttons/150/black_en_pbm.png" border="0" alt="PayGol">
					</form>
				</div>
			</div>
		<?php endif; ?>

	<?php endif; ?>
</section>
