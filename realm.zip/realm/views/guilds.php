<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<h1><?= t('guild.title') ?></h1>

<?php if (!empty($guilds) && $guilds !== false): ?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-shield-alt"></i> <?= t('guild.title') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th style="width:100px;"><?= t('guild.logo_label') ?></th>
					<th><?= t('common.description') ?></th>
					<th><?= t('guild.data') ?></th>
				</tr>
				<?php $i = 0; ?>
				<?php foreach ($guilds as $guild): ?>
					<?php if ((int) $guild['total'] >= 1): ?>
						<?php
						$url = url('guilds.php?name=' . $guild['name']);
						$level = is_array($guild['level']) ? $guild['level'] : ['players' => 0, 'avg' => 0, 'total' => 0];
						?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>" style="cursor:pointer;" onclick="window.location.href='<?= $h($url) ?>'">
							<td style="width:100px;"><img src="<?php logo_exists($guild['name']); ?>" alt="" style="max-width:100px;max-height:100px;display:block;margin:auto;"></td>
							<td>
								<a href="<?= $h($url) ?>"><strong><?= $h($guild['name']) ?></strong></a>
								<?php if (strlen((string) $guild['motd']) > 0): ?><br><?= $h($guild['motd']) ?><?php endif; ?>
							</td>
							<td>
								<?= t('guild.members') ?>: <?= (int) $level['players'] ?><br>
								<?= t_default('guild.guild_level', 'Guild level') ?>: <?= (int) $level['total'] ?><br>
								<?= t_default('guild.average_level', 'Average level') ?>: <?= (int) $level['avg'] ?>
							</td>
						</tr>
						<?php $i++; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
<?php else: ?>
	<p class="lead"><?= t('guild.empty_list') ?></p>
<?php endif; ?>
