<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

$rmClientVersion = isset($config['client']) ? ((int) $config['client'] / 100) : '';
$rmEntriesBySection = znote_download_entries_by_section();
$rmOfficial = $rmEntriesBySection['official'] ?? [];
unset($rmEntriesBySection['official']);
$rmIpChanger = 'https://github.com/jo3bingham/tibia-ip-changer/releases/latest';
$rmServerAddress = (string) ($_SERVER['SERVER_NAME'] ?? '');
?>
<div class="panel">
	<div class="panel__head"><h2 class="panel__title"><?= t('downloads.title') ?></h2></div>
	<div class="panel__body panel__body--flush">

		<div class="dl-hero">
			<div class="dl-hero__eyebrow"><?= t_default('downloads.eyebrow', 'Official Game Client') ?></div>
			<h1 class="dl-hero__title"><?= $h($config['site_title'] ?? 'Realm') ?></h1>
			<p class="dl-hero__lead"><?= t('downloads.intro') ?></p>

			<?php foreach ($rmOfficial as $i => $entry): ?>
				<a class="btn <?= $i === 0 ? 'btn--grass' : 'btn--azure' ?> dl-btn" href="<?= $h($entry['url']) ?>" target="_blank" rel="noopener">
					<i class="fas fa-download"></i> <?= $h($entry['label']) ?>
				</a>
			<?php endforeach; ?>

			<div class="dl-meta">
				<?php if ($rmClientVersion !== ''): ?>
					<span><i class="fas fa-code-branch"></i> <?= t_default('downloads.meta_version', 'Client ' . $rmClientVersion, ['version' => $rmClientVersion]) ?></span>
				<?php endif; ?>
				<span><i class="fas fa-shield-alt"></i> <?= t_default('downloads.meta_official', 'Official build') ?></span>
			</div>
		</div>

		<div class="dl-section">
			<h3 class="dl-section__title"><?= t('downloads.howto') ?></h3>
			<div class="dl-steps">
				<div class="dl-step">
					<div class="dl-step__n">1</div>
					<div>
						<div class="dl-step__t"><?= t('downloads.download') ?></div>
						<div class="dl-step__d"><?= t('downloads.step1') ?></div>
					</div>
				</div>
				<div class="dl-step">
					<div class="dl-step__n">2</div>
					<div>
						<div class="dl-step__t"><?= t('downloads.ipchanger') ?></div>
						<div class="dl-step__d"><?= t('downloads.step2') ?> <a href="<?= $h($rmIpChanger) ?>"><?= t('downloads.here') ?></a></div>
					</div>
				</div>
				<div class="dl-step">
					<div class="dl-step__n">3</div>
					<div>
						<div class="dl-step__t"><?= t_default('downloads.step_path_title', 'Client path') ?></div>
						<div class="dl-step__d"><?= t('downloads.step3') ?></div>
					</div>
				</div>
				<div class="dl-step">
					<div class="dl-step__n">4</div>
					<div>
						<div class="dl-step__t"><?= t_default('downloads.step_address_title', 'Server address') ?></div>
						<div class="dl-step__d"><?= t('downloads.step4') ?> <strong><?= $h($rmServerAddress) ?></strong></div>
					</div>
				</div>
				<div class="dl-step">
					<div class="dl-step__n">5</div>
					<div>
						<div class="dl-step__t"><?= t_default('downloads.step_play_title', 'Play') ?></div>
						<div class="dl-step__d"><?= t('downloads.step5') ?> <strong>Apply</strong>. <?= t('downloads.step5b') ?> <a href="register.php"><?= t('downloads.here') ?></a></div>
					</div>
				</div>
			</div>
		</div>

		<?php if ($rmEntriesBySection): ?>
			<div class="dl-section">
				<h3 class="dl-section__title"><?= t_default('downloads.more', 'More downloads') ?></h3>
				<div class="dl-reqs">
					<?php foreach ($rmEntriesBySection as $section => $entries): ?>
						<?php foreach ($entries as $entry): ?>
							<div>
								<b><?= $h($entry['label']) ?></b>
								<span><a href="<?= $h($entry['url']) ?>"><?= t('downloads.download') ?></a></span>
							</div>
						<?php endforeach; ?>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="dl-legal">
			<strong><?= t_default('downloads.disclaimer_title', 'Disclaimer') ?></strong>
			<?= t_default('downloads.disclaimer_text', 'The software and any related documentation is provided "as is" without warranty of any kind. The entire risk arising out of use of the software remains with you.') ?>
		</div>

	</div>
</div>
