<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

$rmItemName = static function (array $o) use ($items): string {
	return isset($items[$o['item_id']]) ? (string) $items[$o['item_id']] : (string) $o['item_id'];
};
$rmSeller = static function (array $o) use ($h): string {
	if ((int) $o['anonymous'] === 1) return t('market.anonymous');
	return '<a target="_blank" href="characterprofile.php?name=' . $h($o['player_name']) . '">' . $h($o['player_name']) . '</a>';
};

$rmOfferRows = static function (array $offers, bool $withCompare) use ($h, $rmItemName, $rmSeller): void {
	$i = 0;
	foreach ($offers as $o):
		?>
		<tr class="<?= $i++ % 2 === 0 ? 'Odd' : 'Even' ?>">
			<td>
				<img src="<?= $h(znote_item_image_url((int) $o['item_id'])) ?>" alt="<?= $h(t('market.item_image_alt')) ?>" style="width:28px;height:28px;vertical-align:middle;margin-right:8px;">
				<?= $h($rmItemName($o)) ?>
			</td>
			<td style="text-align:right;"><?= (int) $o['amount'] ?></td>
			<td style="text-align:right;"><?= $h(number_format($o['price'], 0, '', ' ')) ?></td>
			<td><?= $h(getClock($o['created'], true, true)) ?></td>
			<td><?= $rmSeller($o) ?></td>
			<?php if ($withCompare): ?>
				<td><a href="?compare=<?= (int) $o['item_id'] ?>" class="btn btn--azure btn--sm"><?= t('market.compare') ?></a></td>
			<?php endif; ?>
		</tr>
	<?php endforeach;
};
?>
<div class="pagehead">
	<h1 class="pagehead__title"><?= t('market.title') ?></h1>
</div>

<?php if ($marketLoadError !== ''): ?>

	<p class="lead"><?= t('market.load_failed2') ?></p>
	<p><?= t('market.tried_file') ?> <?= $h($marketLoadError) ?></p>
	<p><?= t('market.fix_path') ?></p>
	<p><?= t('market.check_permissions') ?></p>

<?php elseif ($marketMode === 'list'): ?>

	<p class="lead">
		<?= t('market.hint') ?> <a target="_blank" href="http://znote.eu/images/depotmarket.jpg"><?= t('market.depot_link_text') ?></a><br>
		<?= t('market.sell_instructions') ?>
	</p>

	<form action="" class="market-search">
		<label for="compareSearch"><?= t('market.search') ?></label>
		<input type="text" id="compareSearch" name="compare">
		<button type="submit"><?= t('common.search') ?></button>
	</form>

	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-store"></i> <?= t('market.wts') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('market.item_name') ?></th>
					<th style="text-align:right;"><?= t('common.count') ?></th>
					<th style="text-align:right;"><?= t('market.price_for_1') ?></th>
					<th><?= t('common.added') ?></th>
					<th><?= t('common.by') ?></th>
					<th><?= t('market.compare') ?></th>
				</tr>
				<?php $rmOfferRows($offers['wts'] ?: array(), true); ?>
			</table>
		</div>
	</div>

	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-hand-holding-usd"></i> <?= t('market.wtb') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('market.item_name') ?></th>
					<th style="text-align:right;"><?= t('common.count') ?></th>
					<th style="text-align:right;"><?= t('market.price_for_1') ?></th>
					<th><?= t('common.added') ?></th>
					<th><?= t('common.by') ?></th>
					<th><?= t('market.compare') ?></th>
				</tr>
				<?php $rmOfferRows($offers['wtb'] ?: array(), true); ?>
			</table>
		</div>
	</div>

<?php else: ?>

	<p class="lead">
		<?php if (!is_string($compare)): ?>
			<?= t('market.comparing_item', ['name' => $itemname]) ?>
		<?php else: ?>
			<?= t('market.search_result', ['query' => stripslashes($compare)]) ?>
		<?php endif; ?>
	</p>
	<p><a href="market.php" class="btn btn--ghost btn--sm"><?= t('market.go_back') ?></a></p>

	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-store"></i> <?= t('market.active') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('market.item_name') ?></th>
					<th style="text-align:right;"><?= t('common.count') ?></th>
					<th style="text-align:right;"><?= t('market.price_for_1') ?></th>
					<th><?= t('common.added') ?></th>
					<th><?= t('common.by') ?></th>
				</tr>
				<?php $rmOfferRows($activeSellOffers, false); ?>
			</table>
		</div>
	</div>

	<?php if ($buylist !== false): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-hand-holding-usd"></i> <?= t('market.want_to_buy') ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<th><?= t('market.item_name') ?></th>
						<th style="text-align:right;"><?= t('common.count') ?></th>
						<th style="text-align:right;"><?= t('market.price_for_1') ?></th>
						<th><?= t('common.added') ?></th>
						<th><?= t('common.by') ?></th>
					</tr>
					<?php $rmOfferRows($buylist, false); ?>
				</table>
			</div>
		</div>
	<?php endif; ?>

	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-history"></i> <?= t('market.old') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('market.item_name') ?></th>
					<th style="text-align:right;"><?= t('common.count') ?></th>
					<th style="text-align:right;"><?= t('market.price_for_1') ?></th>
					<th><?= t('market.sold') ?></th>
				</tr>
				<?php $i = 0; foreach (($historyOffers ?: array()) as $o): ?>
					<tr class="<?= $i++ % 2 === 0 ? 'Odd' : 'Even' ?>">
						<td>
							<img src="<?= $h(znote_item_image_url((int) $o['item_id'])) ?>" alt="<?= $h(t('market.item_image_alt')) ?>" style="width:28px;height:28px;vertical-align:middle;margin-right:8px;">
							<?= $h($rmItemName($o)) ?>
						</td>
						<td style="text-align:right;"><?= (int) $o['amount'] ?></td>
						<td style="text-align:right;"><?= $h(number_format($o['price'], 0, '', ' ')) ?></td>
						<td><?= $h(getClock($o['inserted'], true, true)) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php endif; ?>
