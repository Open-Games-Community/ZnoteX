<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<h1><?= t('topguilds.title') ?></h1>

<?php if (!empty($guilds) && $guilds !== false): ?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-skull-crossbones"></i> <?= t('topguilds.title') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th style="width:60px;">#</th>
					<th><?= t('online.label_name') ?></th>
					<th style="text-align:right;"><?= t('topguilds.frags') ?></th>
				</tr>
				<?php foreach ($guilds as $i => $guild): ?>
					<?php
					$rank = $i + 1;
					$url = url('guilds.php?name=' . $guild['name']);
					$rankClass = $rank === 1 ? ' Rank1' : ($rank === 2 ? ' Rank2' : ($rank === 3 ? ' Rank3' : ''));
					?>
					<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?><?= $rankClass ?>" style="cursor:pointer;" onclick="window.location.href='<?= $h($url) ?>'">
						<td class="RankCell" style="text-align:right;"><?= $h(convert_number_to_words($rank)) ?></td>
						<td><a href="<?= $h($url) ?>"><?= $h($guild['name']) ?></a></td>
						<td style="text-align:right;"><?= (int) $guild['frags'] ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
<?php else: ?>
	<p class="lead"><?= t('topguilds.no_frags') ?></p>
<?php endif; ?>
