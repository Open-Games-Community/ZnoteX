<div id="myaccount" class="account-manage">
	<div class="account-nav">
		<div class="account-menu account-menu--conta">
			<a class="is-active" href="myaccount.php"><?= t('realm.acc.myaccount') ?></a>
			<a href="changepassword.php"><?= t('realm.acc.password') ?></a>
			<a href="twofa.php">2FA</a>
		</div>
		<div class="account-menu account-menu--personagem">
			<a href="createcharacter.php"><?= t('realm.acc.create_char') ?></a>
			<?php if (function_exists('has_admin_panel_access') && has_admin_panel_access($user_data)): ?>
				<a class="account-menu__admin" href="admin/index.php"><i class="fas fa-sliders-h"></i> <?= t('realm.acc.admin_panel') ?></a>
			<?php endif; ?>
			<a class="account-menu__logout" href="logout.php"><?= t('realm.header.logout') ?></a>
		</div>
	</div>

	<p class="lead">
		<?= t('acc.welcome') ?> <?= htmlspecialchars((string) $user_data['name'], ENT_QUOTES, 'UTF-8') ?><br>
		<?= $user_data['premdays'] != 0 ? t('acc.premium_days', ['days' => $user_data['premdays']]) : t('acc.free_account') ?>
	</p>

	<h2 class="u-visually-hidden">Account plugins</h2>

	<?php if ($twofa2_status !== null || $legacy_twofa_status !== null): ?>
	<a name="Security"></a>
	<div class="panel">
		<div class="panel__head"><h2 class="panel__title"><?= t('realm.acc.security') ?></h2></div>
		<div class="panel__body">
			<table class="info-table">
				<?php if ($twofa2_status !== null): ?>
					<tr><td><?= t_default('twofa2.website_status', 'Website 2FA:') ?></td><td><a href="twofa.php"><?= $twofa2_status['any_enabled'] ? t_default('common.enabled', 'Enabled') : t_default('common.disabled', 'Disabled') ?></a></td></tr>
				<?php endif; ?>
				<?php if ($legacy_twofa_status !== null): ?>
					<tr><td><?= t_default('twofa2.legacy_status', 'Legacy game 2FA:') ?></td><td><a href="twofa.php"><?= $legacy_twofa_status ? t_default('common.enabled', 'Enabled') : t_default('common.disabled', 'Disabled') ?></a></td></tr>
				<?php endif; ?>
			</table>
		</div>
	</div>
	<?php endif; ?>

	<a name="Characters"></a>
	<div class="panel">
		<div class="panel__head"><h2 class="panel__title"><?= t('common.character') ?> &mdash; <?= (int) $char_count ?></h2></div>
		<div class="panel__body">
			<?php if ($char_array): ?>
				<table>
					<tr>
						<th><?= t('realm.acc.col_name') ?></th>
						<th><?= t('realm.acc.col_level') ?></th>
						<th><?= t('realm.acc.col_vocation') ?></th>
						<th><?= t('realm.acc.col_town') ?></th>
						<th><?= t('realm.acc.col_lastlogin') ?></th>
						<th><?= t('realm.acc.col_status') ?></th>
						<th><?= t('realm.acc.col_hide') ?></th>
					</tr>
					<?php foreach ($char_array as $value): ?>
						<tr>
							<td><a href="characterprofile.php?name=<?= htmlspecialchars((string) $value['name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string) $value['name'], ENT_QUOTES, 'UTF-8') ?></a></td>
							<td><?= (int) $value['level'] ?></td>
							<td><?= htmlspecialchars((string) $value['vocation'], ENT_QUOTES, 'UTF-8') ?></td>
							<td><?= htmlspecialchars((string) $value['town_id'], ENT_QUOTES, 'UTF-8') ?></td>
							<td><?= htmlspecialchars((string) $value['lastlogin'], ENT_QUOTES, 'UTF-8') ?></td>
							<td><?= $value['online'] ?></td>
							<td><?= hide_char_to_name($value['hide_char']) ?></td>
						</tr>
					<?php endforeach; ?>
				</table>

				<form action="" method="post" style="margin-top:16px;">
					<table class="info-table">
						<tr>
							<td>
								<select id="selected_character" name="selected_character" class="form-control">
									<?php foreach ($char_array as $character): ?>
										<option value="<?= htmlspecialchars((string) $character['name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string) $character['name'], ENT_QUOTES, 'UTF-8') ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td>
								<select id="action" name="action" class="form-control" onChange="realmAccChanged(this)">
									<option value="none" selected><?= t('acc.select_action') ?></option>
									<option value="toggle_hide"><?= t('acc.toggle_hide') ?></option>
									<option value="change_comment"><?= t('acc.change_comment') ?></option>
									<option value="change_gender"><?= t('acc.change_gender') ?></option>
									<option value="change_name"><?= t('acc.change_name') ?></option>
									<option value="delete_character" class="needconfirmation"><?= t('acc.delete_char') ?></option>
								</select>
							</td>
							<td id="submit_form">
								<?php Token::create(); ?>
								<input id="submit_button" type="submit" value="<?= t('common.submit') ?>" class="BigButtonText">
							</td>
						</tr>
					</table>
				</form>
			<?php else: ?>
				<p><?= t('realm.acc.no_characters') ?> <a href="createcharacter.php"><?= t('realm.acc.create_char') ?></a>?</p>
			<?php endif; ?>
		</div>
	</div>
</div>
<script>
function realmAccChanged(e) {
	if (e.value == 'change_name') {
		var lastCell = document.getElementById('submit_form');
		var x = document.createElement('TD');
		x.id = 'new_name';
		x.innerHTML = '<input type="text" name="newName" placeholder="New Name" class="form-control">';
		lastCell.parentNode.insertBefore(x, lastCell);
	} else {
		var child = document.getElementById('new_name');
		if (child) child.parentNode.removeChild(child);
	}
}
document.addEventListener('DOMContentLoaded', function () {
	var submitButton = document.getElementById('submit_button');
	var actionSelect = document.getElementById('action');
	var characterSelect = document.getElementById('selected_character');
	if (!submitButton || !actionSelect || !characterSelect) return;
	submitButton.addEventListener('click', function (event) {
		var selectedAction = actionSelect.options[actionSelect.selectedIndex];
		if (selectedAction && selectedAction.classList.contains('needconfirmation')) {
			var selectedCharacter = characterSelect.options[characterSelect.selectedIndex];
			var name = selectedCharacter ? selectedCharacter.text : '';
			if (!confirm('Do you really want to DELETE character: ' + name + '?')) event.preventDefault();
		}
	});
});
</script>
