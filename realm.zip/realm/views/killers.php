<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<?php if ($killersMode === 'modern'): ?>

	<h1><?= t('killers.biggest_murders') ?></h1>
	<?php if ($killers): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-skull"></i> <?= t('killers.biggest_murders') ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<th><?= t('common.name') ?></th>
						<th style="text-align:right;"><?= t('killers.kills') ?></th>
					</tr>
					<?php foreach ($killers as $i => $killer): ?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<td><a href="characterprofile.php?name=<?= $h($killer['killed_by']) ?>"><?= $h($killer['killed_by']) ?></a></td>
							<td style="text-align:right;"><?= (int) $killer['kills'] ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php else: ?>
		<p class="lead"><?= t('killers.no_kills') ?></p>
	<?php endif; ?>

	<h1><?= t('killers.biggest_victims') ?></h1>
	<?php if ($victims): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-heart-broken"></i> <?= t('killers.biggest_victims') ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<th><?= t('common.name') ?></th>
						<th style="text-align:right;"><?= t('killers.deaths') ?></th>
					</tr>
					<?php foreach ($victims as $i => $victim): ?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<td><a href="characterprofile.php?name=<?= $h($victim['name']) ?>"><?= $h($victim['name']) ?></a></td>
							<td style="text-align:right;"><?= (int) $victim['Deaths'] ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php else: ?>
		<p class="lead"><?= t('killers.no_kills') ?></p>
	<?php endif; ?>

	<h1><?= t('killers.latest_kills') ?></h1>
	<?php if ($latests): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-clock"></i> <?= t('killers.latest_kills') ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<th style="width:64px;"><?= t('common.rank') ?></th>
						<th style="width:140px;"><?= t('common.time') ?></th>
						<th><?= t('deaths.latest') ?></th>
					</tr>
					<?php foreach ($latests as $i => $last): ?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<td style="text-align:right;"><?= $i + 1 ?></td>
							<td><?= $h(getClock($last['time'], true)) ?></td>
							<td>
								<a href="characterprofile.php?name=<?= $h($last['killed_by']) ?>"><?= $h($last['killed_by']) ?></a>
								&mdash;
								<a href="characterprofile.php?name=<?= $h($last['victim']) ?>"><?= $h($last['victim']) ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php else: ?>
		<p class="lead"><?= t('killers.no_kills') ?></p>
	<?php endif; ?>

<?php elseif ($killersMode === 'legacy'): ?>

	<h1><?= t('killers.latest') ?></h1>
	<?php if ($deaths): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-skull-crossbones"></i> <?= t('killers.latest') ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<th style="width:64px;"><?= t('common.rank') ?></th>
						<th style="width:140px;"><?= t('common.time') ?></th>
						<th><?= t('deaths.latest') ?></th>
					</tr>
					<?php foreach ($deaths as $i => $death): ?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<td style="text-align:right;"><?= $i + 1 ?></td>
							<td><?= $h(getClock($death['time'], true)) ?></td>
							<td>
								<a href="characterprofile.php?name=<?= $h($death['killed_by']) ?>"><?= $h($death['killed_by']) ?></a>
								<?= t('deaths.at_level', ['level' => (int) $death['level']]) ?>
								<a href="characterprofile.php?name=<?= $h($death['victim']) ?>"><?= $h($death['victim']) ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php else: ?>
		<p class="lead"><?= t('killers.no_deaths') ?></p>
	<?php endif; ?>

<?php else: ?>
	<h1><?= t('killers.latest') ?></h1>
	<p class="lead"><?= t('killers.unsupported') ?></p>
<?php endif; ?>
