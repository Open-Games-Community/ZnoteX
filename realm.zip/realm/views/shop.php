<?php
$rmShopSession = '';
if ($loggedin === true) {
	$rmShopSession = bin2hex(random_bytes(32));
	$_SESSION['shop_session'] = $rmShopSession;
}
?>
<?php if ($shop['enabled']): ?>

<section class="store-shell shop" id="stripe-store">
	<header class="store-head">
		<h1><?= t('shop.offers') ?></h1>
		<?php if ($loggedin === true): ?>
			<p><?= t('shop.you_have') ?> <strong><?= (int) $user_znote_data['points'] ?></strong> <?= t('common.points') ?>. (<a href="buypoints.php"><?= t('shop.buy_points') ?></a>)</p>
		<?php else: ?>
			<p><?= t('shop.need_login') ?></p>
		<?php endif; ?>
	</header>

	<?php
	$rmOutfitsIds = array(136,137,138,139,140,141,142,147,148,149,150,155,156,157,158,252,269,270,279,288,324,336,366,431,433,464,466,471,513,514,542,128,129,130,131,132,133,134,143,144,145,146,151,152,153,154,251,268,273,278,289,325,335,367,430,432,463,465,472,512,516,541);
	$rmCats = array('items' => array(), 'premium' => array(), 'outfits' => array(), 'mounts' => array(), 'misc' => array());
	foreach ($shop_list as $key => $offer) {
		switch ($offer['type']) {
			case 1: $rmCats['items'][$key] = $offer; break;
			case 2: $rmCats['premium'][$key] = $offer; break;
			case 5: $rmCats['outfits'][$key] = $offer; break;
			case 6: $rmCats['mounts'][$key] = $offer; break;
			default: $rmCats['misc'][$key] = $offer; break;
		}
	}
	$rmCatLabels = array(
		'items'   => t('shop.cat_items'),
		'premium' => t('shop.cat_premium'),
		'outfits' => t('shop.cat_outfits'),
		'mounts'  => t('shop.cat_mounts'),
		'misc'    => t('shop.cat_misc'),
	);
	$rmFirst = true;
	?>

	<nav class="store-tabs" aria-label="<?= h(t('shop.offers')) ?>">
		<?php foreach ($rmCats as $rmKey => $rmItems): if (!$rmItems) continue; ?>
			<button type="button" class="store-tab<?= $rmFirst ? ' is-active' : '' ?>" data-store-tab="<?= h($rmKey) ?>"><?= h($rmCatLabels[$rmKey]) ?></button>
			<?php $rmFirst = false; ?>
		<?php endforeach; ?>
	</nav>

	<?php $rmFirst = true; ?>
	<?php foreach ($rmCats as $rmKey => $rmItems): if (!$rmItems) continue; ?>
		<section class="store-panel<?= $rmFirst ? ' is-active' : '' ?>" data-store-panel="<?= h($rmKey) ?>">
			<div class="store-grid">
				<?php foreach ($rmItems as $key => $offers):
					$rmImg = '';
					if ($rmKey === 'items' || $rmKey === 'misc') {
						$rmImg = znote_item_image_url((int) $offers['itemid']);
					} elseif ($rmKey === 'outfits' && $config['show_outfits']['shop']) {
						$ids = is_array($offers['itemid']) ? $offers['itemid'] : array($offers['itemid']);
						$rmImg = $config['show_outfits']['imageServer'] . '?id=' . (int) $ids[0] . '&addons=' . (int) $offers['count'] . '&head=78&body=68&legs=58&feet=76';
					} elseif ($rmKey === 'mounts' && $config['show_outfits']['shop']) {
						$rmImg = $config['show_outfits']['imageServer'] . '?id=' . (int) $rmOutfitsIds[array_rand($rmOutfitsIds)] . '&addons=3&head=78&body=68&legs=58&feet=76&mount=' . (int) $offers['itemid'] . '&direction=2';
					}
				?>
					<div class="store-card">
						<span class="store-card__top">
							<span class="store-card__name"><?= $offers['description'] ?></span>
							<span class="store-card__price"><?= (int) $offers['points'] ?> <?= h(t('common.points')) ?></span>
						</span>
						<?php if ($rmImg !== ''): ?><img src="<?= h($rmImg) ?>" alt="" style="max-height:64px;margin:6px 0;"><?php endif; ?>
						<?php if ($rmKey === 'premium'): ?>
							<span class="store-card__summary"><?= h(t('shop.days', array('count' => $offers['count']))) ?></span>
						<?php elseif ($rmKey === 'items' && (int) $offers['count'] > 1): ?>
							<span class="store-card__summary"><?= (int) $offers['count'] ?>x</span>
						<?php endif; ?>
						<?php if ($loggedin === true): ?>
							<form action="" method="POST" style="margin-top:10px;">
								<input type="hidden" name="buy" value="<?= (int) $key ?>">
								<input type="hidden" name="session" value="<?= h($rmShopSession) ?>">
								<button type="submit" class="btn btn--amber btn--block needconfirmation" data-item-name="<?= h(strip_tags((string) $offers['description'])) ?>" data-item-cost="<?= (int) $offers['points'] ?>"><?= h(t('shop.purchase')) ?></button>
							</form>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
		<?php $rmFirst = false; ?>
	<?php endforeach; ?>
</section>

<?php if ($shop['enableShopConfirmation']): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
	document.querySelectorAll('.store-tab').forEach(function (tab) {
		tab.addEventListener('click', function () {
			document.querySelectorAll('.store-tab').forEach(function (t) { t.classList.toggle('is-active', t === tab); });
			var code = tab.getAttribute('data-store-tab');
			document.querySelectorAll('.store-panel').forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-store-panel') === code); });
		});
	});
	document.querySelectorAll('.needconfirmation').forEach(function (button) {
		button.addEventListener('click', function (event) {
			var itemName = this.getAttribute('data-item-name') || 'this offer';
			var itemCost = this.getAttribute('data-item-cost') || '0';
			if (!confirm('Do you really want to purchase ' + itemName + ' for ' + itemCost + ' points?')) {
				event.preventDefault();
			}
		});
	});
});
</script>
<?php endif; ?>

<?php else: ?>
	<h1><?= t('buypoints.disabled') ?></h1>
	<p><?= t('buypoints.disabled_text') ?></p>
<?php endif; ?>
