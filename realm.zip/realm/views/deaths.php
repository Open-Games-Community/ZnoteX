<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<h1><?= t('deaths.latest') ?></h1>

<?php if ($deaths): ?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-skull"></i> <?= t('deaths.latest') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<th><?= t('killers.victim') ?></th>
					<th><?= t('common.time') ?></th>
					<th><?= t('killers.killer') ?></th>
				</tr>
				<?php foreach ($deaths as $i => $death): ?>
					<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
						<td>
							<?= t('deaths.at_level', ['level' => (int) $death['level']]) ?>
							<a href="characterprofile.php?name=<?= $h($death['victim']) ?>"><?= $h($death['victim']) ?></a>
						</td>
						<td><?= $h(getClock($death['time'], true)) ?></td>
						<?php if ((int) $death['is_player'] === 1): ?>
							<td>
								<?= t('deaths.player') ?>
								<a href="characterprofile.php?name=<?= $h($death['killed_by']) ?>"><?= $h($death['killed_by']) ?></a>
							</td>
						<?php elseif ((int) $death['is_player'] === 0): ?>
							<td>
								<?= t('deaths.monster') ?>
								<?php if (znote_server_adapter()->normalizedEngine() === 'TFS_03'): ?>
									<?= $h(ucfirst(str_replace('a ', '', $death['killed_by']))) ?>
								<?php else: ?>
									<?= $h(ucfirst($death['killed_by'])) ?>
								<?php endif; ?>
							</td>
						<?php else: ?>
							<td><?= $h($death['killed_by']) ?></td>
						<?php endif; ?>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
<?php else: ?>
	<p class="lead"><?= t('deaths.none') ?></p>
<?php endif; ?>
