<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<h1><?= t('online.heading') ?></h1>

<?php if (!empty($onlineRecord['players'])): ?>
	<p class="lead">
		<?php if (!empty($onlineBroken)): ?>
			<strong><?= t('online.new_record') ?></strong>
			<?= t('online.new_record_line', ['count' => (int) $onlineNow]) ?>
		<?php else: ?>
			<?= t('online.record_line', ['count' => (int) $onlineRecord['players'], 'date' => $h(getClock((int) $onlineRecord['time'], true))]) ?>
		<?php endif; ?>
	</p>
<?php endif; ?>

<?php if (!empty($array) && $array !== false): ?>
	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-users"></i> <?= t('online.currently') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<?php if ($loadOutfits): ?><th style="width:56px;"><?= t('common.outfit') ?></th><?php endif; ?>
					<th><?= t('online.label_name') ?></th>
					<th><?= t('online.label_guild') ?></th>
					<th style="text-align:right;"><?= t('online.label_level') ?></th>
					<th style="text-align:right;"><?= t('online.label_vocation') ?></th>
				</tr>
				<?php foreach ($array as $i => $value): ?>
					<?php
					$flag = ($loadFlags === true && strlen((string) $value['flag']) > 1) ? '<img src="' . $h($config['country_flags']['server']) . '/' . $h($value['flag']) . '.png" alt="" style="width:16px;vertical-align:middle;margin-right:4px;">' : '';
					$guildname = !empty($value['gname']) ? '<a href="guilds.php?name=' . $h($value['gname']) . '">' . $h($value['gname']) . '</a>' : '';
					?>
					<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
						<?php if ($loadOutfits): ?>
							<td><img src="<?= $h($config['show_outfits']['imageServer']) ?>?id=<?= (int) $value['type'] ?>&addons=<?= (int) ($value['addons'] ?? 0) ?>&head=<?= (int) $value['head'] ?>&body=<?= (int) $value['body'] ?>&legs=<?= (int) $value['legs'] ?>&feet=<?= (int) $value['feet'] ?>" alt="" style="width:32px;height:32px;"></td>
						<?php endif; ?>
						<td><?= $flag ?><a href="characterprofile.php?name=<?= $h($value['name']) ?>"><?= $h($value['name']) ?></a></td>
						<td><?= $guildname ?></td>
						<td style="text-align:right;"><?= (int) $value['level'] ?></td>
						<td style="text-align:right;"><?= $h(vocation_id_to_name($value['vocation'])) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
<?php else: ?>
	<p class="lead"><?= t('online.nobody') ?></p>
<?php endif; ?>

<?php if ($history['enabled']): ?>
	<?php if (!empty($recents) && $recents !== false): ?>
		<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer">
					<div class="Text"><i class="fas fa-clock"></i> <?= t('online.past_days', ['days' => $history['days']]) ?></div>
				</div>
			</div>
			<div class="TableContentContainer">
				<table class="TableContent" width="100%">
					<tr>
						<?php if ($loadOutfits): ?><th style="width:56px;"><?= t('common.outfit') ?></th><?php endif; ?>
						<th><?= t('online.label_name') ?></th>
						<th><?= t('online.label_guild') ?></th>
						<th style="text-align:right;"><?= t('online.label_level') ?></th>
						<th style="text-align:right;"><?= t('online.logout_days') ?></th>
					</tr>
					<?php $now = time(); ?>
					<?php foreach ($recents as $i => $value): ?>
						<?php
						$days = floor(($now - $value['lastlogout']) / 86400);
						$flag = ($loadFlags === true && strlen((string) $value['flag']) > 1) ? '<img src="' . $h($config['country_flags']['server']) . '/' . $h($value['flag']) . '.png" alt="" style="width:16px;vertical-align:middle;margin-right:4px;">' : '';
						$guildname = !empty($value['gname']) ? '<a href="guilds.php?name=' . $h($value['gname']) . '">' . $h($value['gname']) . '</a>' : '';
						?>
						<tr class="<?= $i % 2 === 0 ? 'Odd' : 'Even' ?>">
							<?php if ($loadOutfits): ?>
								<td><img src="<?= $h($config['show_outfits']['imageServer']) ?>?id=<?= (int) $value['type'] ?>&addons=<?= (int) ($value['addons'] ?? 0) ?>&head=<?= (int) $value['head'] ?>&body=<?= (int) $value['body'] ?>&legs=<?= (int) $value['legs'] ?>&feet=<?= (int) $value['feet'] ?>" alt="" style="width:32px;height:32px;"></td>
							<?php endif; ?>
							<td><?= $flag ?><a href="characterprofile.php?name=<?= $h($value['name']) ?>"><?= $h($value['name']) ?></a></td>
							<td><?= $guildname ?></td>
							<td style="text-align:right;"><?= (int) $value['level'] ?></td>
							<td style="text-align:right;"><?= (int) $days ?>D: <?= $h(getClock($value['lastlogout'], true)) ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	<?php else: ?>
		<p class="lead"><?= t('online.nobody_past_days', ['days' => $history['days']]) ?></p>
	<?php endif; ?>
<?php endif; ?>
