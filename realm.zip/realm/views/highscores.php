<?php
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
?>
<?php if ($vocGroups): ?>
	<?php
	$vocGroup = (is_array($vocGroups[$vocation])) ? $vocGroups[$vocation] : $vocGroups[$vocGroups[$vocation]];
	$rmWhat = skillName($type) . ', ' . (($vocation === 'all') ? t('vocation.any_lower') : vocation_id_to_name($vocation));
	$rmColspan = 3 + ($loadOutfits ? 1 : 0) + ($type === 7 ? 1 : 0);
	?>
	<h1><?= t('highscores.heading', ['what' => $h($rmWhat)]) ?></h1>

	<form action="" method="GET">
		<select name="type">
			<option value="7" <?= $type == 7 ? 'selected' : '' ?>><?= t('skill.experience') ?></option>
			<option value="8" <?= $type == 8 ? 'selected' : '' ?>><?= t('skill.magic') ?></option>
			<option value="5" <?= $type == 5 ? 'selected' : '' ?>><?= t('skill.shield') ?></option>
			<option value="2" <?= $type == 2 ? 'selected' : '' ?>><?= t('skill.sword') ?></option>
			<option value="1" <?= $type == 1 ? 'selected' : '' ?>><?= t('skill.club') ?></option>
			<option value="3" <?= $type == 3 ? 'selected' : '' ?>><?= t('skill.axe') ?></option>
			<option value="4" <?= $type == 4 ? 'selected' : '' ?>><?= t('skill.distance') ?></option>
			<option value="6" <?= $type == 6 ? 'selected' : '' ?>><?= t('skill.fishing') ?></option>
			<option value="9" <?= $type == 9 ? 'selected' : '' ?>><?= t('skill.fist') ?></option>
		</select>

		<select name="vocation">
			<option value="all" <?= !is_int($vocation) ? 'selected' : '' ?>><?= t('vocation.any') ?></option>
			<?php foreach ($configVocations as $v_id => $v_data): ?>
				<?php if ($v_data['fromVoc'] === false): ?>
					<option value="<?= $h($v_id) ?>" <?= (is_int($vocation) && $vocation == $v_id) ? 'selected' : '' ?>><?= $h($v_data['name']) ?></option>
				<?php endif; ?>
			<?php endforeach; ?>
		</select>

		<select name="page">
			<?php
			$rmPages = ($vocGroup[$type] !== false) ? ceil(min(($highscore['rows'] / $highscore['rowsPerPage']), (count($vocGroup[$type]) / $highscore['rowsPerPage']))) : 1;
			for ($rmI = 0; $rmI < $rmPages; $rmI++):
				$rmX = $rmI + 1;
			?>
				<option value="<?= $rmX ?>" <?= $rmX == $page ? 'selected' : '' ?>><?= t('highscores.page', ['n' => $rmX]) ?></option>
			<?php endfor; ?>
		</select>

		<button type="submit"><?= t('common.view') ?></button>
	</form>

	<div class="TableContainer">
		<div class="CaptionContainer">
			<div class="CaptionInnerContainer">
				<div class="Text"><i class="fas fa-trophy"></i> <?= t('highscores.title') ?></div>
			</div>
		</div>
		<div class="TableContentContainer">
			<table class="TableContent" width="100%">
				<tr>
					<?php if ($loadOutfits): ?><th style="width:56px;"><?= t('common.outfit') ?></th><?php endif; ?>
					<th style="width:56px;text-align:right;"><?= t('common.rank') ?></th>
					<th><?= t('common.name') ?></th>
					<th><?= t('common.vocation') ?></th>
					<th style="text-align:right;"><?= t('common.level') ?></th>
					<?php if ($type === 7): ?><th style="text-align:right;"><?= t('common.points') ?></th><?php endif; ?>
				</tr>
				<?php if ($vocGroup[$type] === false): ?>
					<tr class="Odd">
						<td colspan="<?= $rmColspan ?>"><?= t('common.nothing') ?></td>
					</tr>
				<?php else: ?>
					<?php $rmRow = 0; ?>
					<?php for ($rmIdx = 0; $rmIdx < count($vocGroup[$type]); $rmIdx++): ?>
						<?php if (pageCheck($rmIdx, $page, $rowsPerPage)): ?>
							<?php
							$entry = $vocGroup[$type][$rmIdx];
							$rank = $rmIdx + 1;
							$flag = ($loadFlags === true && strlen((string) $entry['flag']) > 1) ? '<img src="' . $h($config['country_flags']['server']) . '/' . $h($entry['flag']) . '.png" alt="" style="width:16px;vertical-align:middle;margin-right:4px;">' : '';
							$rankClass = $rank === 1 ? ' Rank1' : ($rank === 2 ? ' Rank2' : ($rank === 3 ? ' Rank3' : ''));
							?>
							<tr class="<?= $rmRow % 2 === 0 ? 'Odd' : 'Even' ?><?= $rankClass ?>">
								<?php if ($loadOutfits): ?>
									<td><img src="<?= $h($config['show_outfits']['imageServer']) ?>?id=<?= (int) $entry['type'] ?>&addons=<?= (int) ($entry['addons'] ?? 0) ?>&head=<?= (int) $entry['head'] ?>&body=<?= (int) $entry['body'] ?>&legs=<?= (int) $entry['legs'] ?>&feet=<?= (int) $entry['feet'] ?>" alt="" style="width:32px;height:32px;"></td>
								<?php endif; ?>
								<td class="RankCell" style="text-align:right;"><?= $rank ?></td>
								<td><?= $flag ?><a href="characterprofile.php?name=<?= $h($entry['name']) ?>"><?= $h($entry['name']) ?></a></td>
								<td><?= $h(vocation_id_to_name($entry['vocation'])) ?></td>
								<td style="text-align:right;"><?= $h($entry['value']) ?></td>
								<?php if ($type === 7): ?><td style="text-align:right;"><?= $h($entry['experience']) ?></td><?php endif; ?>
							</tr>
							<?php $rmRow++; ?>
						<?php endif; ?>
					<?php endfor; ?>
				<?php endif; ?>
			</table>
		</div>
	</div>
<?php else: ?>
	<p class="lead"><?= t('highscores.empty') ?></p>
<?php endif; ?>
