<?php

// Realm renders the boosted plugin's data as an anchored card in the left
// rail (see realm_render_left_rail() below). Claiming the embedded renderer
// stops the plugin from also injecting its own floating side box.
if (function_exists('boosted_creatures_claim_embedded_renderer')) {
	boosted_creatures_claim_embedded_renderer();
}

function realm_custom_boxes(string $side): array {
	if (!function_exists('theme_option')) {
		return array();
	}
	$boxes = array();
	for ($i = 1; $i <= 3; $i++) {
		$title = trim((string) theme_option('box_' . $side . '_' . $i . '_title'));
		$content = trim((string) theme_option('box_' . $side . '_' . $i . '_content'));
		if ($title === '' && $content === '') {
			continue;
		}
		$boxes[] = array('title' => $title, 'content' => $content);
	}
	return $boxes;
}

function realm_render_custom_boxes(string $side): void {
	foreach (realm_custom_boxes($side) as $box) {
		?>
		<div class="card">
			<?php if ($box['title'] !== ''): ?>
				<div class="card__head"><?= htmlspecialchars($box['title'], ENT_QUOTES, 'UTF-8') ?></div>
			<?php endif; ?>
			<div class="card__body"><?= $box['content'] ?></div>
		</div>
		<?php
	}
}

function realm_server_save(): array {
	$time = function_exists('theme_option') ? trim((string) theme_option('server_save_time', '06:00', 'realm')) : '06:00';
	if (!preg_match('/^([01]?[0-9]|2[0-3]):([0-5][0-9])$/', $time, $m)) {
		return array('next' => null, 'since' => null);
	}
	$hour = (int) $m[1];
	$minute = (int) $m[2];
	$now = time();
	$today = mktime($hour, $minute, 0, (int) date('n'), (int) date('j'), (int) date('Y'));
	$next = $today > $now ? $today : strtotime('+1 day', $today);
	$prev = $today <= $now ? $today : strtotime('-1 day', $today);
	return array('next' => $next, 'since' => $now - $prev);
}

/** The configured launch date, or null when empty/invalid/already past. */
function realm_launch_countdown(): ?int {
	$raw = function_exists('theme_option') ? trim((string) theme_option('launch_countdown', '', 'realm')) : '';
	if ($raw === '') {
		return null;
	}
	$date = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $raw);
	$errors = DateTimeImmutable::getLastErrors();
	if ($date === false || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
		return null;
	}
	$at = $date->getTimestamp();
	return $at > time() ? $at : null;
}

function realm_duration_short(int $seconds): string {
	$seconds = max(0, $seconds);
	$h = intdiv($seconds, 3600);
	$m = intdiv($seconds % 3600, 60);
	return $h . 'h ' . $m . 'm';
}

/**
 * Real TCP probe to the login port, cached ~60s. Same idea as the wildlands
 * theme's status check, kept local so it works from any page, not only index.
 */
function realm_server_online(): bool {
	global $config;
	$cfg  = is_array($config['status'] ?? null) ? $config['status'] : array();
	$ip   = (string) ($cfg['status_ip'] ?? ($config['ip'] ?? '127.0.0.1'));
	$port = (int) ($cfg['status_port'] ?? ($config['port'] ?? 7171));
	if ($ip === '' || $port <= 0) {
		return false;
	}
	$probe = static function () use ($ip, $port): bool {
		$sock = @fsockopen($ip, $port, $errNo, $errStr, 0.7);
		if ($sock) {
			@fclose($sock);
			return true;
		}
		return false;
	};
	if (class_exists('Cache')) {
		$cache = new Cache('engine/cache/realm_status');
		if ($cache->hasExpired()) {
			$online = $probe();
			$cache->setContent($online ? 1 : 0);
			$cache->save();
			return $online;
		}
		return ((int) $cache->load()) === 1;
	}
	return $probe();
}

/**
 * The left sidebar: server status, boosted-today (if the plugin is on), then
 * up to 3 admin-configured free boxes. Shared by every page, not just index,
 * so the rail looks the same everywhere.
 */
function realm_render_left_rail(): void {
	global $config;
	$online = realm_server_online();
	?>
	<div class="card">
		<div class="card__head"><i class="fas fa-signal"></i> <?= t('realm.hero.server_status') ?></div>
		<div class="card__body">
			<ul class="statlist">
				<li><span><?= t('realm.hero.status') ?></span><span><?= $online ? t('realm.hero.online') : t('realm.hero.offline') ?></span></li>
				<li><span><?= t('realm.hero.players_online') ?></span><span><?= (int) (function_exists('user_count_online') ? user_count_online() : 0) ?></span></li>
				<li><span><?= t('realm.hero.world') ?></span><span><?= htmlspecialchars((string) ($config['site_title'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span></li>
			</ul>
		</div>
	</div>
	<?php
	if (function_exists('boosted_creatures_data') && function_exists('boosted_creatures_enabled') && boosted_creatures_enabled()) {
		$boost = boosted_creatures_data();
		$cells = array();
		if (!empty($boost['creature'])) {
			$cells[] = array('kind' => t('realm.hero.boosted_creature'), 'row' => $boost['creature']);
		}
		if (!empty($boost['boss'])) {
			$cells[] = array('kind' => t('realm.hero.boosted_boss'), 'row' => $boost['boss']);
		}
		if ($cells) {
			?>
			<div class="card">
				<div class="card__head"><i class="fas fa-bolt"></i> <?= t('realm.hero.boosted_today') ?></div>
				<div class="card__body">
					<div class="boosted">
						<?php foreach ($cells as $cell): ?>
							<?php $art = function_exists('boosted_creatures_outfit_url') ? boosted_creatures_outfit_url($cell['row']) : ''; ?>
							<div class="boosted__cell">
								<div class="boosted__art"><?php if ($art !== ''): ?><img src="<?= htmlspecialchars($art, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php endif; ?></div>
								<div class="boosted__kind"><?= $cell['kind'] ?></div>
								<div class="boosted__name"><?= htmlspecialchars((string) ($cell['row']['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
			<?php
		}
	}
	realm_render_custom_boxes('left');
}

/**
 * The right sidebar: top characters ladder, community/discord, then up to 3
 * admin-configured free boxes. Shared by every page, same as the left rail.
 */
function realm_render_right_rail(): void {
	global $config;
	$top = array();
	if (function_exists('db')) {
		$ignoreGroup = (int) ($config['highscore']['ignoreGroupId'] ?? 0);
		$rows = db()->fetchAll("
			SELECT `name`, `level`, `vocation`, `looktype`, `lookhead`, `lookbody`, `looklegs`, `lookfeet`, `lookaddons`
			FROM `players`
			WHERE `group_id` < ?
			ORDER BY `experience` DESC
			LIMIT 5;
		", array($ignoreGroup));
		$top = is_array($rows) ? $rows : array();
	}
	$loadOutfits = !empty($config['show_outfits']['highscores']);
	$discord = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';

	if ($top) {
		?>
		<div class="card">
			<div class="card__head"><i class="fas fa-crown"></i> <?= t('realm.hero.top_characters') ?></div>
			<div class="card__body card__body--flush">
				<ol class="ladder">
					<?php foreach ($top as $i => $p): ?>
						<li class="ladder__row ladder__row--<?= $i + 1 ?>">
							<span class="ladder__rank"><?= $i + 1 ?></span>
							<?php if ($loadOutfits): ?>
								<span class="ladder__outfit">
									<img src="<?= htmlspecialchars((string) $config['show_outfits']['imageServer'], ENT_QUOTES, 'UTF-8') ?>?id=<?= (int) $p['looktype'] ?>&addons=<?= (int) $p['lookaddons'] ?>&head=<?= (int) $p['lookhead'] ?>&body=<?= (int) $p['lookbody'] ?>&legs=<?= (int) $p['looklegs'] ?>&feet=<?= (int) $p['lookfeet'] ?>" alt="" loading="lazy">
								</span>
							<?php endif; ?>
							<span class="ladder__info">
								<a class="ladder__name" href="characterprofile.php?name=<?= htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8') ?></a>
								<span class="ladder__meta"><?= htmlspecialchars(function_exists('vocation_id_to_name') ? vocation_id_to_name((int) $p['vocation']) : '', ENT_QUOTES, 'UTF-8') ?></span>
							</span>
							<span class="ladder__level"><?= (int) $p['level'] ?></span>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
			<div class="card__body"><a class="btn btn--azure btn--block" href="highscores.php"><?= t('realm.hero.full_highscores') ?></a></div>
		</div>
		<?php
	}

	if ($discord !== '') {
		?>
		<div class="card">
			<div class="card__head"><i class="fab fa-discord"></i> <?= t('realm.hero.community') ?></div>
			<div class="card__body discord">
				<a class="btn btn--blurple btn--block" href="<?= htmlspecialchars($discord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><i class="fab fa-discord"></i> <?= t('realm.hero.join_discord') ?></a>
			</div>
		</div>
		<?php
	}

	realm_render_custom_boxes('right');
}
