(function () {
    'use strict';

    window.CollapseTable = function (containerId) {
        var container = document.getElementById(containerId);
        if (!container) {
            return;
        }

        var isHidden = window.getComputedStyle(container).display === 'none';
        container.style.display = isHidden ? 'block' : 'none';

        var indicator = document.getElementById('Indicator_' + containerId);
        if (indicator) {
            indicator.classList.toggle('CircleSymbolMinus', isHidden);
            indicator.classList.toggle('CircleSymbolPlus', !isHidden);
            indicator.style.backgroundImage = indicator.style.backgroundImage.replace(
                /circle-symbol-(?:plus|minus)\.gif/,
                isHidden ? 'circle-symbol-minus.gif' : 'circle-symbol-plus.gif'
            );
        }
    };

    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('mainNav');

    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            var open = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        nav.querySelectorAll('.nav__item > .nav__link').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.matchMedia('(max-width: 860px)').matches) {
                    link.parentNode.classList.toggle('is-open');
                }
            });
        });
    }

    var topbar = document.querySelector('.topbar');
    var toTop = document.getElementById('toTop');
    var ticking = false;
    var lastStuck = null;
    var lastTop = null;

    function onFrame() {
        ticking = false;

        var y = window.scrollY;

        var stuck = y > 24;
        if (topbar && stuck !== lastStuck) {
            topbar.classList.toggle('is-stuck', stuck);
            lastStuck = stuck;
        }

        var showTop = y > 400;
        if (toTop && showTop !== lastTop) {
            toTop.classList.toggle('is-visible', showTop);
            lastTop = showTop;
        }
    }

    function onScroll() {
        if (!ticking) {
            ticking = true;
            window.requestAnimationFrame(onFrame);
        }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    onFrame();

    if (toTop) {
        toTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
        });
    }

    var revealTargets = Array.prototype.filter.call(
        document.querySelectorAll('.panel, .card, .pagehead'),
        function (el) {
            return !el.closest('#myaccount');
        }
    );

    if (!reduceMotion && 'IntersectionObserver' in window && revealTargets.length) {
        var pending = [];

        revealTargets.forEach(function (el) {
            if (el.getBoundingClientRect().top < window.innerHeight) {
                return;
            }

            el.classList.add('reveal');
            pending.push(el);
        });

        if (pending.length) {
            var reveal = function (el) {
                el.classList.add('is-in');
            };

            var observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    reveal(entry.target);
                    observer.unobserve(entry.target);
                });
            }, { rootMargin: '0px 0px -40px 0px', threshold: 0.06 });

            pending.forEach(function (el) {
                observer.observe(el);
            });

            setTimeout(function () {
                var unrevealed = pending.filter(function (el) {
                    return !el.classList.contains('is-in');
                });

                if (!unrevealed.length) {
                    return;
                }

                unrevealed.forEach(function (el) {
                    observer.unobserve(el);
                    reveal(el);
                });
            }, 2000);
        }
    }

    var ticker = document.querySelector('.ticker__list');

    if (ticker) {
        ticker.addEventListener('click', function (e) {
            var head = e.target.closest('.ticker__head');
            if (!head) {
                return;
            }

            var item = head.parentNode;
            var open = item.classList.toggle('is-open');
            head.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    var clocks = Array.prototype.slice.call(document.querySelectorAll('[data-countdown]'))
        .map(function (el) {
            return { el: el, at: new Date(el.getAttribute('data-countdown')).getTime() };
        })
        .filter(function (c) {
            return !isNaN(c.at);
        });

    if (clocks.length) {
        var pad = function (n) {
            return n < 10 ? '0' + n : String(n);
        };

        var tick = function () {
            var now = Date.now();

            clocks.forEach(function (clock) {
                var left = clock.at - now;

                if (left <= 0) {
                    clock.el.textContent = 'Now';
                    return;
                }

                clock.el.textContent =
                    pad(Math.floor(left / 3600000)) + ':' +
                    pad(Math.floor((left % 3600000) / 60000)) + ':' +
                    pad(Math.floor((left % 60000) / 1000));
            });
        };

        tick();
        var timer = setInterval(tick, 1000);

        document.addEventListener('visibilitychange', function () {
            if (document.hidden) {
                clearInterval(timer);
            } else {
                tick();
                timer = setInterval(tick, 1000);
            }
        });
    }
})();
