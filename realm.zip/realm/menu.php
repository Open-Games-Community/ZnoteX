<?php
$rmMenu    = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$rmHasMenu = function_exists('theme_menu_available') ? theme_menu_available() : (bool) $rmMenu;
$rmCur     = (string) ($page_filename ?? 'index');
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$ml = static function ($v): string {
	$label = function_exists('theme_menu_label') ? theme_menu_label((string) $v) : (string) $v;
	return htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
};
$rmActive = static function (string $url) use ($rmCur): bool {
	if ($url === '') return false;
	if ($rmCur === 'index') return $url === 'index.php' || $url === '/' || $url === '';
	return strpos($url, $rmCur . '.php') === 0;
};
?>
<nav class="nav" id="mainNav">
	<?php if ($rmHasMenu): ?>
		<?php foreach ($rmMenu as $item): ?>
			<?php $hasDrop = !empty($item['children']); $href = $item['url'] !== '' ? $item['url'] : '#'; $target = $item['target'] !== '' ? ' target="' . $h($item['target']) . '" rel="noopener"' : ''; ?>
			<div class="nav__item<?= $rmActive($item['url']) ? ' is-active' : '' ?>">
				<?php if ($hasDrop): ?>
					<span class="nav__link"><?= $ml($item['label']) ?></span>
					<div class="nav__drop">
						<?php foreach ($item['children'] as $child): ?>
							<a href="<?= $h($child['url'] !== '' ? $child['url'] : '#') ?>"<?= $child['target'] !== '' ? ' target="' . $h($child['target']) . '" rel="noopener"' : '' ?>><?= $ml($child['label']) ?></a>
						<?php endforeach; ?>
					</div>
				<?php else: ?>
					<a class="nav__link" href="<?= $h($href) ?>"<?= $target ?>><?= $ml($item['label']) ?></a>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	<?php else: ?>
		<div class="nav__item<?= $rmCur === 'index' ? ' is-active' : '' ?>">
			<a class="nav__link" href="index.php"><?= $h(t('realm.nav.news')) ?></a>
		</div>
		<div class="nav__item">
			<span class="nav__link"><?= $h(t('realm.nav.account')) ?></span>
			<div class="nav__drop">
				<a href="myaccount.php"><?= $h(t('realm.nav.account_manage')) ?></a>
				<a href="register.php"><?= $h(t('realm.nav.account_create')) ?></a>
				<a href="recovery.php"><?= $h(t('realm.nav.account_lost')) ?></a>
				<a href="downloads.php"><?= $h(t('nav.download')) ?></a>
			</div>
		</div>
		<div class="nav__item">
			<span class="nav__link"><?= $h(t('realm.nav.community')) ?></span>
			<div class="nav__drop">
				<a href="onlinelist.php"><?= $h(t('realm.nav.online')) ?></a>
				<a href="highscores.php"><?= $h(t('nav.highscores')) ?></a>
				<a href="deaths.php"><?= $h(t('realm.nav.lastkills')) ?></a>
				<a href="houses.php"><?= $h(t('nav.houses')) ?></a>
				<a href="guilds.php"><?= $h(t('nav.guilds')) ?></a>
				<a href="bans.php"><?= $h(t('realm.nav.bans')) ?></a>
				<a href="team.php"><?= $h(t('realm.nav.team')) ?></a>
			</div>
		</div>
		<div class="nav__item">
			<a class="nav__link" href="forum.php"><?= $h(t('nav.forum')) ?></a>
		</div>
		<div class="nav__item">
			<span class="nav__link"><?= $h(t('realm.nav.library')) ?></span>
			<div class="nav__drop">
				<a href="creatures.php"><?= $h(t('realm.nav.creatures')) ?></a>
				<a href="spells.php"><?= $h(t('realm.nav.spells')) ?></a>
				<a href="gallery.php"><?= $h(t('realm.nav.gallery')) ?></a>
				<a href="serverinfo.php"><?= $h(t('nav.serverinfo')) ?></a>
			</div>
		</div>
		<div class="nav__item">
			<a class="nav__link" href="auctionChar.php"><?= $h(t('realm.nav.bazaar')) ?></a>
		</div>
		<div class="nav__item">
			<span class="nav__link"><?= $h(t('nav.shop')) ?></span>
			<div class="nav__drop">
				<a href="shop.php"><?= $h(t('realm.nav.donate')) ?></a>
				<a href="payment.php"><?= $h(t('realm.nav.payments')) ?></a>
			</div>
		</div>
	<?php endif; ?>
</nav>
