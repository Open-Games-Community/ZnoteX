<?php
require_once __DIR__ . '/../boxes.php';
$rmOpt = static function (string $k, string $d = ''): string {
	if (!function_exists('theme_option')) return $d;
	$v = trim((string) theme_option($k));
	return $v !== '' ? $v : $d;
};
$rmCrest    = function_exists('theme_image') ? theme_image('crest', theme_asset('images/crest.svg')) : theme_asset('images/crest.svg');
$rmFavicon  = function_exists('theme_image') ? theme_image('favicon', theme_asset('images/crest.svg')) : theme_asset('images/crest.svg');
$rmBg       = function_exists('theme_image') ? theme_image('background_image', theme_asset('images/background.jpg')) : theme_asset('images/background.jpg');
if ($rmBg !== '' && !preg_match('#^(https?:)?//#i', $rmBg) && $rmBg[0] !== '/') {
	$rmBg = '/' . $rmBg;
}
$rmDiscord  = $rmOpt('discord_url');
$rmForum    = $rmOpt('forum_url', 'forum.php');
$rmFootHtml = $rmOpt('footer_html');
$rmAssetV = static function (string $rel): string {
	$path = __DIR__ . '/../assets/' . $rel;
	$url  = theme_asset($rel);
	return is_file($path) ? $url . '?v=' . filemtime($path) : $url;
};
$rmLang     = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';
$rmOnline   = (int) (function_exists('user_count_online') ? user_count_online() : 0);
$rmLogged   = function_exists('user_logged_in')
	? user_logged_in()
	: (function_exists('getSession') && getSession('user_id') !== false);
$rmPage     = (string) ($page_filename ?? 'index');
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

$rmLangSel = '';
if (function_exists('translate_selector')) {
	$rmLangSel = translate_selector();
}
?>
<!DOCTYPE html>
<html lang="<?= $h($rmLang) ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#0c0f14">
	<title><?= theme_title() ?></title>
	<?php if ($rmFavicon !== ''): ?><link rel="icon" href="<?= $rmFavicon ?>"><?php endif; ?>

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

	<link rel="stylesheet" href="<?= $rmAssetV('css/obsidian.css') ?>">
	<link rel="stylesheet" href="<?= $rmAssetV('css/legacy.css') ?>">
	<style>:root{--page-art:url('<?= $rmBg ?>');--art-fade:.34}</style>
</head>
<body class="<?= theme_body_class() ?>">

<header class="topbar">
	<div class="topbar__inner">
		<a class="brand" href="index.php">
			<img class="brand__crest" src="<?= $rmCrest ?>" alt="" width="32" height="36">
			<span class="brand__name"><?= theme_title() ?></span>
		</a>

		<button class="navtoggle" id="navToggle" aria-label="<?= $h(t('realm.header.menu')) ?>" aria-expanded="false">
			<i class="fas fa-bars"></i>
		</button>

		<?php require __DIR__ . '/../menu.php'; ?>

		<div class="topbar__actions">
			<?php if ($rmLangSel !== ''): ?>
				<?= $rmLangSel ?>
				<?php if (function_exists('translate_selector_assets')) echo translate_selector_assets(); ?>
				<?php if (function_exists('translate_selector_rendered')) translate_selector_rendered(true); ?>
			<?php endif; ?>
			<?php if (!$rmLogged): ?>
				<a class="btn btn--azure" href="login.php"><?= $h(t('realm.header.login')) ?></a>
				<a class="btn btn--amber" href="register.php"><?= $h(t('realm.header.register')) ?></a>
			<?php else: ?>
				<a class="btn btn--azure" href="myaccount.php"><?= $h((string) ($user_data['name'] ?? t('realm.header.account'))) ?></a>
				<a class="btn btn--amber" href="logout.php"><?= $h(t('realm.header.logout')) ?></a>
			<?php endif; ?>
		</div>
	</div>
</header>

<div class="page-content">
<?php if ($rmPage === 'index'): ?>
	<?php theme_content(); ?>
<?php else: ?>
	<main class="shell">
		<aside class="rail rail--left"><?php realm_render_left_rail(); ?></aside>
		<div class="col-main feedContainer">
			<div class="card">
				<div class="card__head"><i class="fas fa-scroll"></i> <?= $h($GLOBALS['page_title'] ?? ucwords(str_replace(array('-', '_'), ' ', $rmPage))) ?></div>
				<div class="card__body">
					<?php theme_content(); ?>
				</div>
			</div>
		</div>
		<aside class="rail"><?php realm_render_right_rail(); ?></aside>
	</main>
<?php endif; ?>
</div>

<footer class="footer">
	<div class="footer__inner">
		<div>
			&copy; <?= date('Y') ?> <?= theme_title() ?>. <?= $h(t('realm.footer.rights')) ?>
			<?php if ($rmDiscord !== ''): ?> &middot; <a href="<?= $h($rmDiscord) ?>" target="_blank" rel="noopener"><i class="fab fa-discord"></i> Discord</a><?php endif; ?>
			<?php if (trim(strip_tags($rmFootHtml)) !== ''): ?> &middot; <?= $rmFootHtml ?><?php endif; ?>
			<br><?= $h(t('realm.footer.powered')) ?> <a href="credits.php">ZnoteX</a> &middot; <?= function_exists('elapsedTime') ? elapsedTime() : '0' ?>s
		</div>
	</div>
</footer>

<button class="totop" id="toTop" type="button" aria-label="<?= $h(t('realm.footer.totop')) ?>">
	<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 19V5M5.5 11.5 12 5l6.5 6.5"/></svg>
</button>

<script src="<?= $rmAssetV('js/realm.js') ?>" defer></script>
</body>
</html>
