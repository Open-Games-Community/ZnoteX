<?php

return array(
	'server_goals.panel_title' => 'Gemeinschaftsziele',
	'server_goals.default_title' => 'Gemeinschaftsziel',
	'server_goals.reward' => 'Belohnung: {reward}',
	'server_goals.unlocked' => '{reward} freigeschaltet!',
	'server_goals.hide' => 'Ausblenden',
	'server_goals.show' => 'Anzeigen',
);
