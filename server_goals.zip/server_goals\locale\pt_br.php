<?php

return array(
	'server_goals.panel_title' => 'Metas da comunidade',
	'server_goals.default_title' => 'Meta da comunidade',
	'server_goals.reward' => 'Recompensa: {reward}',
	'server_goals.unlocked' => '{reward} desbloqueado!',
	'server_goals.hide' => 'Ocultar',
	'server_goals.show' => 'Mostrar',
);
