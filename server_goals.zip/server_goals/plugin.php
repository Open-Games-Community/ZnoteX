<?php
/**
 * Server Goals - community goals with a live progress bar in a side box.
 *
 * The website cannot see kills. Progress therefore comes from one of:
 *   lua_counter    a downloadable buffered Lua counter (writes znote_server_goal_counters)
 *   global_storage a game global storage key (table / columns configurable)
 *   metric         a built-in whitelisted COUNT/SUM query
 *
 * On completion the plugin writes a game global storage value so a Lua event
 * can trigger the reward. Nothing else is written to the game database.
 */
if (!function_exists('server_goals_setting')) {

function server_goals_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('server_goals:' . $key, $default) : $default;
}
function server_goals_enabled(): bool { return server_goals_setting('enabled', '1') === '1'; }
function server_goals_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function server_goals_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string) $v, $text);
	return $text;
}
function server_goals_ident(string $v): string { $v = trim($v); return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : ''; }
function server_goals_css_value(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function server_goals_color(string $key): string { return server_goals_css_value(server_goals_setting('style_' . $key, '')); }
function server_goals_url_value(string $key): string {
	$v = trim(server_goals_setting($key, ''));
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function server_goals_asset_image(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$path = __DIR__ . '/assets/img/' . $file;
	return is_file($path) ? znote_plugin_asset('server_goals', 'img/' . $file) : '';
}
function server_goals_style_attr(): string {
	$map = array('box_bg' => '--sg-surface', 'border' => '--sg-border', 'text' => '--sg-text', 'accent' => '--sg-accent', 'bar_bg' => '--sg-bar-bg', 'bar_fill' => '--sg-bar-fill', 'title_bg' => '--sg-title-bg', 'title_text' => '--sg-title-text');
	$css = '';
	foreach ($map as $k => $var) { $v = server_goals_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	$radius = (int) server_goals_setting('style_radius', '14');
	if ($radius >= 0 && $radius <= 40) $css .= '--sg-radius:' . $radius . 'px;';
	return $css !== '' ? ' style="' . server_goals_h($css) . '"' : '';
}

// --- goals -----------------------------------------------------------
function server_goals_table_ok(): bool {
	return function_exists('znote_table_exists') && znote_table_exists('znote_server_goals');
}
function server_goals_all(bool $activeOnly = false): array {
	if (!server_goals_table_ok()) return array();
	$where = $activeOnly ? ' WHERE `active` = 1' : '';
	$rows = db()->fetchAll("SELECT * FROM `znote_server_goals`{$where} ORDER BY `sort_order` ASC, `id` ASC;");
	return is_array($rows) ? $rows : array();
}
function server_goals_get(int $id): ?array {
	if ($id <= 0 || !server_goals_table_ok()) return null;
	$row = db()->fetchOne("SELECT * FROM `znote_server_goals` WHERE `id` = ? LIMIT 1;", [$id]);
	return is_array($row) ? $row : null;
}

// --- progress sources ----------------------------------------------
function server_goals_metrics(): array {
	return array(
		'players_created'  => array('label' => 'Characters created',   'table' => 'players',        'sql' => "SELECT COUNT(*) AS v FROM `players`"),
		'accounts_created' => array('label' => 'Accounts registered',  'table' => 'accounts',       'sql' => "SELECT COUNT(*) AS v FROM `accounts`"),
		'total_deaths'     => array('label' => 'Character deaths',      'table' => 'player_deaths',  'sql' => "SELECT COUNT(*) AS v FROM `player_deaths`"),
		'total_level'      => array('label' => 'Sum of all levels',    'table' => 'players',        'sql' => "SELECT COALESCE(SUM(`level`),0) AS v FROM `players`"),
		'online_now'       => array('label' => 'Players online now',   'table' => 'players_online', 'sql' => "SELECT COUNT(*) AS v FROM `players_online`"),
	);
}
function server_goals_gstore_read(int $key): ?int {
	$table = server_goals_ident(server_goals_setting('gstore_table', 'global_storage')) ?: 'global_storage';
	$kc = server_goals_ident(server_goals_setting('gstore_key_col', 'key')) ?: 'key';
	$vc = server_goals_ident(server_goals_setting('gstore_val_col', 'value')) ?: 'value';
	if (!function_exists('znote_table_exists') || !znote_table_exists($table)) return null;
	$row = db()->fetchOne("SELECT `{$vc}` AS `v` FROM `{$table}` WHERE `{$kc}` = ? LIMIT 1;", [$key]);
	return is_array($row) ? (int) $row['v'] : 0;
}
function server_goals_gstore_write(int $key, int $value): void {
	$table = server_goals_ident(server_goals_setting('gstore_table', 'global_storage')) ?: 'global_storage';
	$kc = server_goals_ident(server_goals_setting('gstore_key_col', 'key')) ?: 'key';
	$vc = server_goals_ident(server_goals_setting('gstore_val_col', 'value')) ?: 'value';
	if ($key <= 0 || !function_exists('znote_table_exists') || !znote_table_exists($table)) return;
	db()->execute("INSERT INTO `{$table}` (`{$kc}`,`{$vc}`) VALUES (?,?) ON DUPLICATE KEY UPDATE `{$vc}` = GREATEST(`{$vc}`, ?);", [$key, $value, $value]);
}
function server_goals_counter_read(string $param): int {
	$param = trim($param);
	if ($param === '' || !function_exists('znote_table_exists') || !znote_table_exists('znote_server_goal_counters')) return 0;
	$row = db()->fetchOne("SELECT `value` FROM `znote_server_goal_counters` WHERE `goal_key` = ? LIMIT 1;", [$param]);
	return is_array($row) ? max(0, (int) $row['value']) : 0;
}
function server_goals_raw(array $g): int {
	switch ((string) $g['source']) {
		case 'manual':         return max(0, (int) $g['manual_value']);
		case 'lua_counter':    return server_goals_counter_read((string) $g['source_param']);
		case 'global_storage': return max(0, (int) (server_goals_gstore_read((int) $g['source_param']) ?? 0));
		case 'metric':
			$m = server_goals_metrics()[(string) $g['source_param']] ?? null;
			if (!$m || (isset($m['table']) && function_exists('znote_table_exists') && !znote_table_exists($m['table']))) return 0;
			$row = db()->rawFetchOne($m['sql'] . ' LIMIT 1;');
			return is_array($row) ? max(0, (int) $row['v']) : 0;
	}
	return 0;
}
function server_goals_progress(array $g): int {
	return max(0, server_goals_raw($g) - (int) $g['baseline']);
}

// --- completion ---------------------------------------------------
function server_goals_maybe_complete(array $g, int $progress): array {
	$id = (int) $g['id'];
	if ((int) $g['completed_at'] > 0 || $progress < (int) $g['target'] || (int) $g['target'] <= 0) return $g;

	$fresh = server_goals_get($id);
	if (!$fresh || (int) $fresh['completed_at'] > 0) return $fresh ?: $g;

	$now = time();
	db()->execute("UPDATE `znote_server_goals` SET `completed_at` = ?, `updated_at` = ? WHERE `id` = ? AND `completed_at` = 0;", [$now, $now, $id]);

	$mode = (string) $g['complete_mode'];
	$val = $mode === 'one' ? 1 : ($mode === 'value' ? max(0, (int) $g['complete_value']) : $now);
	if ((int) $g['complete_key'] > 0) server_goals_gstore_write((int) $g['complete_key'], $val);

	if (function_exists('znote_table_exists') && znote_table_exists('znote_server_goal_log'))
		db()->execute("INSERT INTO `znote_server_goal_log` (`goal_id`,`event`,`value`,`created_at`) VALUES (?,'completed',?,?);", [$id, $progress, $now]);

	if (function_exists('znote_hook')) znote_hook('server_goal.completed', array('goal_id' => $id, 'title' => (string) $g['title'], 'value' => $progress, 'storage_key' => (int) $g['complete_key'], 'storage_value' => $val));

	$g['completed_at'] = $now;
	return $g;
}

/** Active goals with computed progress, cached (default 120 s). */
function server_goals_data(bool $refresh = false): array {
	static $mem = null;
	if ($mem !== null && !$refresh) return $mem;

	$ttl = max(15, (int) server_goals_setting('cache_ttl', '120'));
	$at  = (int) server_goals_setting('cache_at', '0');
	$raw = server_goals_setting('cache', '');
	if (!$refresh && $at > 0 && $at + $ttl > time() && $raw !== '') {
		$d = json_decode($raw, true);
		if (is_array($d)) return $mem = $d;
	}

	$now = time();
	$out = array();
	foreach (server_goals_all(true) as $g) {
		if ((int) $g['starts_at'] > 0 && $g['starts_at'] > $now) continue;
		if ((int) $g['ends_at'] > 0 && $g['ends_at'] < $now && (int) $g['completed_at'] === 0) continue;
		$progress = server_goals_progress($g);
		$g = server_goals_maybe_complete($g, $progress);
		$target = max(1, (int) $g['target']);
		$out[] = array(
			'id'        => (int) $g['id'],
			'title'     => (string) $g['title'],
			'line'      => (string) $g['line'],
			'progress'  => min($progress, $target),
			'raw'       => $progress,
			'target'    => $target,
			'pct'       => (int) floor(min(100, $progress / $target * 100)),
			'reward'    => (string) $g['reward_text'],
			'completed' => (int) $g['completed_at'] > 0,
		);
	}

	if (function_exists('setting_set')) {
		setting_set('server_goals:cache', json_encode($out));
		setting_set('server_goals:cache_at', (string) time());
	}
	return $mem = $out;
}
function server_goals_clear_cache(): void {
	if (function_exists('setting_set')) { setting_set('server_goals:cache', ''); setting_set('server_goals:cache_at', '0'); }
}

// --- script bundle download -------------------------------------
function server_goals_distros(): array {
	return array(
		'tfs_revscript' => 'TFS 1.1+ / Nekiro 1.5 (revscriptsys)',
		'canary'        => 'Canary / otservbr-global',
		'tfs_legacy'    => 'TFS 0.3.6 / 0.4 / 1.0 (XML scripts)',
	);
}
function server_goals_handle_download(): void {
	if (($_GET['server_goals_dl'] ?? '') === '' || headers_sent()) return;
	$d = preg_replace('/[^a-z0-9_]/', '', (string) $_GET['server_goals_dl']);
	if (!isset(server_goals_distros()[$d])) { http_response_code(404); exit; }
	$dir = __DIR__ . '/assets/lua/' . $d;
	if (!is_dir($dir)) { http_response_code(404); exit; }

	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: text/plain; charset=utf-8');
	header('Content-Disposition: attachment; filename="server_goals_' . $d . '.txt"');

	$files = glob($dir . '/*');
	sort($files);
	foreach ($files as $f) {
		if (!is_file($f)) continue;
		echo "\n===== FILE: " . basename($f) . " =====\n\n";
		echo file_get_contents($f);
		echo "\n";
	}
	exit;
}

// --- live progress endpoint ------------------------------------
function server_goals_handle_ajax(): void {
	if (($_GET['server_goals_progress'] ?? '') === '' || headers_sent()) return;
	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: application/json; charset=utf-8');
	header('X-Content-Type-Options: nosniff');
	$data = server_goals_enabled() ? server_goals_data() : array();
	$slim = array();
	foreach ($data as $g) $slim[] = array('id' => $g['id'], 'progress' => $g['progress'], 'target' => $g['target'], 'pct' => $g['pct'], 'completed' => $g['completed']);
	echo json_encode($slim, JSON_UNESCAPED_SLASHES);
	exit;
}

// --- the side panel -------------------------------------------
function server_goals_fmt(int $n): string { return number_format($n); }
function server_goals_goal_html(array $g): string {
	$done = $g['completed'];
	$title = server_goals_h($g['title'] !== '' ? $g['title'] : server_goals_t('server_goals.default_title', 'Community Goal'));
	$line = server_goals_h($g['line']);
	$reward = trim($g['reward']);
	$pct = max(0, min(100, (int) $g['pct']));

	$rewardHtml = $reward !== ''
		? '<div class="sg-goal__reward">' . ($done
			? server_goals_h(server_goals_t('server_goals.unlocked', '{reward} unlocked!', array('reward' => $reward)))
			: server_goals_h(server_goals_t('server_goals.reward', 'Reward: {reward}', array('reward' => $reward)))) . '</div>'
		: '';

	return '<div class="sg-goal' . ($done ? ' is-done' : '') . '" data-sg-id="' . (int) $g['id'] . '">'
		. '<div class="sg-goal__head">' . ($done ? '✅ ' : '🔥 ') . $title . '</div>'
		. ($line !== '' ? '<div class="sg-goal__line">' . $line . '</div>' : '')
		. '<div class="sg-bar"><i style="width:' . $pct . '%"></i></div>'
		. '<div class="sg-goal__nums"><span class="sg-cur">' . server_goals_h(server_goals_fmt((int) $g['progress'])) . '</span> / ' . server_goals_h(server_goals_fmt((int) $g['target'])) . ' <span class="sg-pct">(' . $pct . '%)</span></div>'
		. $rewardHtml
		. '</div>';
}
function server_goals_footer(): string {
	if (!server_goals_enabled()) return '';
	$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
	$pages = array_filter(array_map('trim', explode(',', server_goals_setting('pages', 'index.php'))));
	if ($pages && !in_array($script, $pages, true)) return '';

	$data = server_goals_data();
	if (!$data) return '';

	$goals = '';
	foreach ($data as $g) $goals .= server_goals_goal_html($g);

	$side = server_goals_setting('side', 'right') === 'left' ? 'left' : 'right';
	$offset = (int) server_goals_setting('offset_top', '90');
	if ($offset < 0 || $offset > 800) $offset = 90;
	$shadow = server_goals_setting('style_shadow', '1') === '1';
	$title = server_goals_h(trim(server_goals_setting('panel_title', '')) !== '' ? server_goals_setting('panel_title', '') : server_goals_t('server_goals.panel_title', 'Community Goals'));
	$banner = server_goals_url_value('banner_img');
	$poll = max(0, (int) server_goals_setting('poll_seconds', '45'));

	$bannerHtml = $banner !== '' ? '<div class="sg-banner" style="background-image:url(' . server_goals_h($banner) . ')"></div>' : '';

	$css = '#sgPanel{--sg-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(24,27,34))))))));--sg-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--sg-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--sg-accent:var(--accent,var(--link,var(--nz-accent,#f4c542)));--sg-bar-bg:rgba(255,255,255,.09);--sg-bar-fill:var(--sg-accent);--sg-title-bg:var(--sg-accent);--sg-title-text:#151515;--sg-radius:14px;position:fixed;top:' . $offset . 'px;' . $side . ':14px;z-index:929;width:238px;max-width:calc(100vw - 28px);color:var(--sg-text);font-size:13px;animation:sgIn .35s ease both}'
		. '@keyframes sgIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
		. '#sgPanel *{box-sizing:border-box}'
		. '#sgPanel .sg-inner{border:1px solid var(--sg-border);border-radius:var(--sg-radius);background:var(--sg-surface);overflow:hidden' . ($shadow ? ';box-shadow:0 12px 34px rgba(0,0,0,.4)' : '') . '}'
		. '#sgPanel .sg-top{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:7px 10px;background:var(--sg-title-bg);color:var(--sg-title-text);font-weight:800;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em}'
		. '#sgPanel .sg-toggle{border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;opacity:.85;padding:0}'
		. '#sgPanel .sg-banner{height:56px;background-size:cover;background-position:center}'
		. '#sgPanel .sg-body[hidden]{display:none}'
		. '#sgPanel .sg-goal{padding:11px 12px;border-top:1px solid var(--sg-border)}#sgPanel .sg-goal:first-child{border-top:0}'
		. '#sgPanel .sg-goal__head{font-weight:800;font-size:12px;margin-bottom:2px}'
		. '#sgPanel .sg-goal__line{font-size:13.5px;margin-bottom:7px;overflow-wrap:anywhere}'
		. '#sgPanel .sg-bar{height:12px;border-radius:99px;background:var(--sg-bar-bg);overflow:hidden;border:1px solid var(--sg-border)}'
		. '#sgPanel .sg-bar i{display:block;height:100%;background:var(--sg-bar-fill);border-radius:99px;transition:width .8s cubic-bezier(.2,.7,.2,1)}'
		. '#sgPanel .sg-goal__nums{margin-top:5px;font-size:12px;font-variant-numeric:tabular-nums}'
		. '#sgPanel .sg-cur{font-weight:800;color:var(--sg-accent)}#sgPanel .sg-pct{opacity:.6}'
		. '#sgPanel .sg-goal__reward{margin-top:5px;font-size:11.5px;color:var(--sg-accent)}'
		. '#sgPanel .sg-goal.is-done .sg-bar i{background:#2f9e5e}#sgPanel .sg-goal.is-done .sg-cur{color:#37c172}'
		. '@media(max-width:820px){#sgPanel{position:static;width:auto;margin:0 0 14px;animation:none}}'
		. '@media(prefers-reduced-motion:reduce){#sgPanel{animation:none}#sgPanel .sg-bar i{transition:none}}';

	$html = '<div id="sgPanel"' . server_goals_style_attr() . '><div class="sg-inner">'
		. '<div class="sg-top"><span>' . $title . '</span><button type="button" class="sg-toggle" aria-expanded="true">' . server_goals_h(server_goals_t('server_goals.hide', 'Hide')) . '</button></div>'
		. '<div class="sg-body">' . $bannerHtml . $goals . '</div>'
		. '</div></div>';

	$showTxt = json_encode(server_goals_t('server_goals.show', 'Show'));
	$hideTxt = json_encode(server_goals_t('server_goals.hide', 'Hide'));

	$js = '(function(){if(document.getElementById("sgPanel"))return;'
		. 'var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';var p=w.firstChild;'
		. 'var host=document.querySelector("main,#content,.content,.container")||document.body;'
		. '(window.matchMedia&&window.matchMedia("(max-width:820px)").matches?host:document.body).appendChild(p);'
		. 'var b=p.querySelector(".sg-body"),t=p.querySelector(".sg-toggle");'
		. 'try{if(localStorage.getItem("sgCollapsed")==="1"){b.hidden=true;t.textContent=' . $showTxt . ';t.setAttribute("aria-expanded","false");}}catch(e){}'
		. 't.addEventListener("click",function(){var h=!b.hidden;b.hidden=h;t.textContent=h?' . $showTxt . ':' . $hideTxt . ';t.setAttribute("aria-expanded",String(!h));try{localStorage.setItem("sgCollapsed",h?"1":"0");}catch(e){}});';

	if ($poll > 0) {
		$js .= 'function fmt(n){return (n||0).toLocaleString("en-US");}'
			. 'function upd(){fetch("?server_goals_progress=1",{credentials:"same-origin"}).then(function(r){return r.json();}).then(function(list){(list||[]).forEach(function(g){var el=p.querySelector(\'[data-sg-id="\'+g.id+\'"]\');if(!el)return;var bar=el.querySelector(".sg-bar i");if(bar)bar.style.width=Math.max(0,Math.min(100,g.pct))+"%";var cur=el.querySelector(".sg-cur");if(cur)cur.textContent=fmt(g.progress);var pc=el.querySelector(".sg-pct");if(pc)pc.textContent="("+g.pct+"%)";if(g.completed)el.classList.add("is-done");});}).catch(function(){});}'
			. 'setInterval(upd,' . ($poll * 1000) . ');';
	}
	$js .= '}());';

	return '<script>' . $js . '</script>';
}

}

server_goals_handle_download();
server_goals_handle_ajax();
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'server_goals_footer');
}
