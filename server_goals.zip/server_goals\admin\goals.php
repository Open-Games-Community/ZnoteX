<?php
/**
 * Title: Server Goals
 * Icon: fa-bullseye
 * Group: Installed Plugins
 * Order: 35
 * Description: Community goals, the side panel, and the downloadable kill-counter script.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'server_goals__goals';
$sources = array('lua_counter', 'global_storage', 'metric', 'manual');
$modes   = array('timestamp', 'one', 'value');

function server_goals_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function server_goals_admin_url($v): string {
	$v = trim((string) $v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function server_goals_admin_ident($v): string {
	$v = trim((string) $v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}
function server_goals_admin_ts($v): int {
	$v = trim((string) $v);
	if ($v === '') return 0;
	$t = strtotime($v);
	return $t !== false ? $t : 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_server_goals` WHERE `id` = ? LIMIT 1;", [$id]);
		db()->execute("DELETE FROM `znote_server_goal_log` WHERE `goal_id` = ?;", [$id]);
		server_goals_clear_cache();
		if (function_exists('acp_log')) acp_log('server_goals.delete', '#' . $id);
		acp_flash_success('Goal deleted.');
		acp_redirect($module);
	}

	if ($do === 'config') {
		setting_set('server_goals:enabled', !empty($_POST['enabled']) ? '1' : '0');
		setting_set('server_goals:pages', trim((string) ($_POST['pages'] ?? 'index.php')));
		setting_set('server_goals:placement', array_key_exists(($_POST['placement'] ?? ''), server_goals_placements()) ? $_POST['placement'] : 'right');
		setting_set('server_goals:offset_top', (string) max(0, min(800, intv($_POST['offset_top'] ?? 90))));
		setting_set('server_goals:poll_seconds', (string) max(0, min(3600, intv($_POST['poll_seconds'] ?? 45))));
		setting_set('server_goals:cache_ttl', (string) max(15, min(86400, intv($_POST['cache_ttl'] ?? 120))));
		setting_set('server_goals:panel_title', trim((string) ($_POST['panel_title'] ?? '')));
		setting_set('server_goals:banner_img', server_goals_admin_url($_POST['banner_img'] ?? ''));
		setting_set('server_goals:gstore_table', server_goals_admin_ident($_POST['gstore_table'] ?? '') ?: 'global_storage');
		setting_set('server_goals:gstore_key_col', server_goals_admin_ident($_POST['gstore_key_col'] ?? '') ?: 'key');
		setting_set('server_goals:gstore_val_col', server_goals_admin_ident($_POST['gstore_val_col'] ?? '') ?: 'value');
		foreach (array('box_bg', 'border', 'text', 'accent', 'bar_bg', 'bar_fill', 'title_bg', 'title_text') as $k)
			setting_set('server_goals:style_' . $k, server_goals_admin_color($_POST['style_' . $k] ?? ''));
		setting_set('server_goals:style_radius', (string) max(0, min(40, intv($_POST['style_radius'] ?? 14))));
		setting_set('server_goals:style_shadow', !empty($_POST['style_shadow']) ? '1' : '0');
		server_goals_clear_cache();
		acp_flash_success('Panel settings saved.');
		acp_redirect($module);
	}

	if ($do === 'create' || $do === 'update') {
		$src = in_array(($_POST['source'] ?? ''), $sources, true) ? $_POST['source'] : 'lua_counter';
		$param = '';
		if ($src === 'lua_counter') $param = server_goals_admin_ident($_POST['param_counter'] ?? '');
		elseif ($src === 'global_storage') $param = (string) max(0, intv($_POST['param_storage'] ?? 0));
		elseif ($src === 'metric') $param = array_key_exists(($_POST['param_metric'] ?? ''), server_goals_metrics()) ? $_POST['param_metric'] : '';

		$fields = array(
			'title'         => trim((string) ($_POST['title'] ?? '')),
			'line'          => trim((string) ($_POST['line'] ?? '')),
			'target'        => max(1, intv($_POST['target'] ?? 1)),
			'source'        => $src,
			'source_param'  => $param,
			'manual_value'  => max(0, intv($_POST['manual_value'] ?? 0)),
			'baseline'      => max(0, intv($_POST['baseline'] ?? 0)),
			'reward_text'   => trim((string) ($_POST['reward_text'] ?? '')),
			'complete_key'  => max(0, intv($_POST['complete_key'] ?? 0)),
			'complete_mode' => in_array(($_POST['complete_mode'] ?? ''), $modes, true) ? $_POST['complete_mode'] : 'timestamp',
			'complete_value'=> max(0, intv($_POST['complete_value'] ?? 1)),
			'active'        => !empty($_POST['active']) ? 1 : 0,
			'sort_order'    => intv($_POST['sort_order'] ?? 0),
			'starts_at'     => server_goals_admin_ts($_POST['starts_at'] ?? ''),
			'ends_at'       => server_goals_admin_ts($_POST['ends_at'] ?? ''),
			'updated_at'    => time(),
		);

		if (trim((string) ($_POST['line'] ?? '')) === '') {
			acp_flash_error('The goal line (e.g. "Kill 100,000 Demons") is required.');
			acp_redirect($module, array('action' => $do === 'update' ? 'edit' : 'add', 'id' => $id));
		}

		if ($do === 'update' && $id > 0) {
			$set = array(); $params = array();
			foreach ($fields as $k => $v) { $set[] = "`{$k}` = ?"; $params[] = $v; }
			$params[] = $id;
			db()->execute("UPDATE `znote_server_goals` SET " . implode(',', $set) . " WHERE `id` = ? LIMIT 1;", $params);
			$msg = 'Goal updated.';
		} else {
			$fields['created_at'] = time();
			$cols = array_keys($fields);
			$ph = implode(',', array_fill(0, count($cols), '?'));
			db()->execute("INSERT INTO `znote_server_goals` (`" . implode('`,`', $cols) . "`) VALUES ({$ph});", array_values($fields));
			$msg = 'Goal created.';
		}
		server_goals_clear_cache();
		if (function_exists('acp_log')) acp_log('server_goals.save', trim((string) ($_POST['line'] ?? '')));
		acp_flash_success($msg);
		acp_redirect($module);
	}
}

$action  = (string) ($_GET['action'] ?? 'list');
$editId  = intv($_GET['id'] ?? 0);
$editing = ($action === 'edit' && $editId > 0) ? server_goals_get($editId) : null;
if ($action === 'edit' && !$editing) { acp_flash_error('Goal not found.'); acp_redirect($module); }
$g = static fn(string $k, $d = '') => $editing !== null && isset($editing[$k]) ? $editing[$k] : $d;
$get = static fn(string $k, string $d = '') => (string) setting('server_goals:' . $k, $d);
$goals = server_goals_all(false);
$live  = server_goals_data(true);
$liveById = array();
foreach ($live as $lg) $liveById[$lg['id']] = $lg;
?>

<?php acp_card_open('Server Goals', 'Community goals with a live progress bar in the side panel. Progress comes from the downloadable Lua counter (recommended), a game global storage key, or a built-in metric. On completion a game global storage value is written so a Lua event can start the reward.'); ?>

<?php if ($action === 'add' || $editing !== null): ?>
	<form method="post">
		<?= acp_csrf_field() ?>
		<input type="hidden" name="do" value="<?= $editing ? 'update' : 'create' ?>">
		<?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>

		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Header (small line above)</label><input class="acp-input" name="title" value="<?= h($g('title')) ?>" placeholder="Community Goal"></div>
			<div class="acp-field"><label class="acp-label">Goal line *</label><input class="acp-input" name="line" value="<?= h($g('line')) ?>" placeholder="Kill 100,000 Demons" required></div>
			<div class="acp-field"><label class="acp-label">Target</label><input class="acp-input" type="number" min="1" name="target" value="<?= (int) $g('target', 100000) ?>"></div>
			<div class="acp-field"><label class="acp-label">Reward text</label><input class="acp-input" name="reward_text" value="<?= h($g('reward_text')) ?>" placeholder="Double XP Weekend"></div>
		</div>

		<h3>Progress source</h3>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Source</label>
				<select class="acp-select" name="source">
					<option value="lua_counter" <?= $g('source', 'lua_counter') === 'lua_counter' ? 'selected' : '' ?>>Lua kill counter (recommended)</option>
					<option value="global_storage" <?= $g('source') === 'global_storage' ? 'selected' : '' ?>>Game global storage key</option>
					<option value="metric" <?= $g('source') === 'metric' ? 'selected' : '' ?>>Built-in metric</option>
					<option value="manual" <?= $g('source') === 'manual' ? 'selected' : '' ?>>Manual value</option>
				</select>
			</div>
			<div class="acp-field"><label class="acp-label">Lua counter key <span class="acp-muted">(source: Lua counter)</span></label><input class="acp-input" name="param_counter" value="<?= h($g('source') === 'lua_counter' || $g('source', 'lua_counter') === 'lua_counter' ? $g('source_param') : '') ?>" placeholder="demons"></div>
			<div class="acp-field"><label class="acp-label">Global storage key <span class="acp-muted">(source: global storage)</span></label><input class="acp-input" type="number" name="param_storage" value="<?= (int) ($g('source') === 'global_storage' ? $g('source_param') : 0) ?>"></div>
			<div class="acp-field"><label class="acp-label">Metric <span class="acp-muted">(source: metric)</span></label>
				<select class="acp-select" name="param_metric">
					<?php foreach (server_goals_metrics() as $k => $m): ?>
						<option value="<?= h($k) ?>" <?= $g('source') === 'metric' && $g('source_param') === $k ? 'selected' : '' ?>><?= h($m['label']) ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="acp-field"><label class="acp-label">Manual value <span class="acp-muted">(source: manual)</span></label><input class="acp-input" type="number" min="0" name="manual_value" value="<?= (int) $g('manual_value', 0) ?>"></div>
			<div class="acp-field"><label class="acp-label">Baseline (subtract from the reading — start from now)</label><input class="acp-input" type="number" min="0" name="baseline" value="<?= (int) $g('baseline', 0) ?>"></div>
		</div>

		<h3>On completion</h3>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Write game global storage key (0 = none)</label><input class="acp-input" type="number" min="0" name="complete_key" value="<?= (int) $g('complete_key', 0) ?>"></div>
			<div class="acp-field"><label class="acp-label">Value to write</label>
				<select class="acp-select" name="complete_mode">
					<option value="timestamp" <?= $g('complete_mode', 'timestamp') === 'timestamp' ? 'selected' : '' ?>>os.time() (recommended — reward window)</option>
					<option value="one" <?= $g('complete_mode') === 'one' ? 'selected' : '' ?>>1</option>
					<option value="value" <?= $g('complete_mode') === 'value' ? 'selected' : '' ?>>Custom value</option>
				</select>
			</div>
			<div class="acp-field"><label class="acp-label">Custom value</label><input class="acp-input" type="number" min="0" name="complete_value" value="<?= (int) $g('complete_value', 1) ?>"></div>
		</div>

		<h3>Schedule</h3>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Starts at (optional)</label><input class="acp-input" type="datetime-local" name="starts_at" value="<?= (int) $g('starts_at', 0) > 0 ? date('Y-m-d\TH:i', (int) $g('starts_at')) : '' ?>"></div>
			<div class="acp-field"><label class="acp-label">Ends at (optional)</label><input class="acp-input" type="datetime-local" name="ends_at" value="<?= (int) $g('ends_at', 0) > 0 ? date('Y-m-d\TH:i', (int) $g('ends_at')) : '' ?>"></div>
			<div class="acp-field"><label class="acp-label">Sort order</label><input class="acp-input" type="number" name="sort_order" value="<?= (int) $g('sort_order', 0) ?>"></div>
			<div class="acp-field"><label class="acp-label"><input type="checkbox" name="active" value="1" <?= (int) $g('active', 1) === 1 ? 'checked' : '' ?>> Active</label></div>
		</div>

		<div class="acp-actions">
			<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? 'Save goal' : 'Create goal' ?></button>
			<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url($module)) ?>">Cancel</a>
		</div>
	</form>

<?php else: ?>
	<div class="acp-actions"><a class="acp-btn" href="<?= h(acp_url($module, array('action' => 'add'))) ?>"><i class="fa fa-plus"></i> New goal</a></div>
	<?php if (!$goals): ?>
		<p class="acp-muted">No goals yet.</p>
	<?php else: ?>
		<div class="acp-table-wrap"><table class="acp-table">
			<thead><tr><th>#</th><th>Goal</th><th>Source</th><th>Progress</th><th>Status</th><th></th></tr></thead>
			<tbody>
			<?php foreach ($goals as $row):
				$rid = (int) $row['id'];
				$lg = $liveById[$rid] ?? null;
			?>
				<tr>
					<td><?= $rid ?></td>
					<td><strong><?= h($row['line']) ?></strong><?php if ($row['reward_text'] !== ''): ?><br><span class="acp-muted"><?= h($row['reward_text']) ?></span><?php endif; ?></td>
					<td><?= h($row['source']) ?><?php if ($row['source_param'] !== ''): ?> <span class="acp-muted">(<?= h($row['source_param']) ?>)</span><?php endif; ?></td>
					<td><?php if ($lg): ?><?= number_format($lg['raw']) ?> / <?= number_format($lg['target']) ?> — <?= $lg['pct'] ?>%<?php else: ?>—<?php endif; ?></td>
					<td><?php if ((int) $row['completed_at'] > 0): ?><span style="color:#37c172">completed <?= h(date('Y-m-d', (int) $row['completed_at'])) ?></span><?php elseif ((int) $row['active'] === 1): ?>active<?php else: ?><span class="acp-muted">inactive</span><?php endif; ?></td>
					<td style="white-space:nowrap">
						<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url($module, array('action' => 'edit', 'id' => $rid))) ?>"><i class="fa fa-pencil"></i></a>
						<form class="acp-inline-form" method="post" data-confirm="Delete this goal?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $rid ?>"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button></form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php endif; ?>
<?php endif; ?>
<?php acp_card_close(); ?>

<?php if ($action === 'list'): ?>
<?php acp_card_open('Panel &amp; style', 'Where the box shows and how it looks. Colours empty = inherit the theme.'); ?>
<form method="post">
	<?= acp_csrf_field() ?><input type="hidden" name="do" value="config">
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label">Show on pages (comma separated, blank = all)</label><input class="acp-input" name="pages" value="<?= h($get('pages', 'index.php')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Placement</label><select class="acp-select" name="placement">
			<?php $curPlacement = server_goals_placement(); foreach (server_goals_placements() as $pk => $pl): ?>
				<option value="<?= h($pk) ?>" <?= $curPlacement === $pk ? 'selected' : '' ?>><?= h($pl) ?></option>
			<?php endforeach; ?>
		</select><p class="acp-muted">Right/Left/Middle/Bottom float over the page. Box drops it inline into the theme's content area instead, like a normal page box.</p></div>
		<div class="acp-field"><label class="acp-label">Top offset (px) <span class="acp-muted">(Right/Left/Middle only)</span></label><input class="acp-input" type="number" name="offset_top" value="<?= (int) $get('offset_top', '90') ?>"></div>
		<div class="acp-field"><label class="acp-label">Live refresh every N seconds (0 = off)</label><input class="acp-input" type="number" min="0" name="poll_seconds" value="<?= (int) $get('poll_seconds', '45') ?>"></div>
		<div class="acp-field"><label class="acp-label">Server-side cache (seconds)</label><input class="acp-input" type="number" min="15" name="cache_ttl" value="<?= (int) $get('cache_ttl', '120') ?>"></div>
		<div class="acp-field"><label class="acp-label">Panel title</label><input class="acp-input" name="panel_title" value="<?= h($get('panel_title')) ?>" placeholder="Community Goals"></div>
		<div class="acp-field"><label class="acp-label">Banner image URL</label><input class="acp-input" name="banner_img" value="<?= h($get('banner_img')) ?>"></div>
	</div>
	<h3>Game global storage table (for reading keys &amp; writing completions)</h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Table</label><input class="acp-input" name="gstore_table" value="<?= h($get('gstore_table', 'global_storage')) ?>" placeholder="global_storage"></div>
		<div class="acp-field"><label class="acp-label">Key column</label><input class="acp-input" name="gstore_key_col" value="<?= h($get('gstore_key_col', 'key')) ?>" placeholder="key"></div>
		<div class="acp-field"><label class="acp-label">Value column</label><input class="acp-input" name="gstore_val_col" value="<?= h($get('gstore_val_col', 'value')) ?>" placeholder="value"></div>
	</div>
	<h3>Colours</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent', 'bar_bg' => 'Bar track', 'bar_fill' => 'Bar fill', 'title_bg' => 'Title bar background', 'title_text' => 'Title bar text') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>" placeholder="#1a1d24 or rgba(...)"></div>
		<?php endforeach; ?>
		<div class="acp-field"><label class="acp-label">Corner radius (px)</label><input class="acp-input" type="number" min="0" max="40" name="style_radius" value="<?= (int) $get('style_radius', '14') ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="style_shadow" value="1" <?= $get('style_shadow', '1') === '1' ? 'checked' : '' ?>> Drop shadow</label></div>
	</div>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save panel settings</button></div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Kill counter script', 'For "Lua kill counter" goals. Pick your server, download the bundle, follow the notes inside. Kills are buffered in memory and written once every 30 s, so a busy server does one query per counter per flush - not one per kill.'); ?>
<div class="acp-field">
	<label class="acp-label">Server</label>
	<select class="acp-select" id="sgDistro">
		<?php foreach (server_goals_distros() as $key => $label): ?>
			<option value="<?= h($key) ?>"><?= h($label) ?></option>
		<?php endforeach; ?>
	</select>
</div>
<div class="acp-actions">
	<a class="acp-btn acp-btn--green" id="sgDownload" href="../index.php?server_goals_dl=tfs_revscript"><i class="fa fa-download"></i> Download script bundle</a>
</div>
<p class="acp-muted">In the script set <code>COUNTER_KEY</code> to the goal's <em>Lua counter key</em> and list the monster names that count. The plugin table <code>znote_server_goal_counters</code> was created on install.</p>
<script>
(function(){var s=document.getElementById('sgDistro'),a=document.getElementById('sgDownload');
if(s&&a)s.addEventListener('change',function(){a.href='../index.php?server_goals_dl='+encodeURIComponent(s.value);});}());
</script>
<?php acp_card_close(); ?>
<?php endif; ?>
