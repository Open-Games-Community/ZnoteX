--[[  ZnoteX - Server Goals : kill counter
      TFS 1.1+ and Nekiro 1.5 downgrades (revscriptsys).

      INSTALL
        1. Copy this file to:  data/scripts/server_goal_kills.lua
        2. Edit COUNTER_KEY so it matches the goal's "Lua counter key" in the ACP.
        3. Edit MONSTERS (lowercase names). Leave it as {} to count every monster.
        4. /reload scripts   (or restart)

      Kills are counted in memory and flushed to the database once every
      FLUSH_SECONDS - one UPDATE per counter per flush, never one per kill.
      The plugin created the table `znote_server_goal_counters` on install.
]]--

local COUNTER_KEY   = "demons"
local MONSTERS      = { ["demon"] = true }
local FLUSH_SECONDS = 30

local buffer = {}

local function flush()
	for key, n in pairs(buffer) do
		if n > 0 then
			local now = os.time()
			db.asyncQuery("INSERT INTO `znote_server_goal_counters` (`goal_key`, `value`, `updated_at`) VALUES (" ..
				db.escapeString(key) .. ", " .. n .. ", " .. now ..
				") ON DUPLICATE KEY UPDATE `value` = `value` + " .. n .. ", `updated_at` = " .. now)
		end
	end
	buffer = {}
end

local kill = CreatureEvent("ZnoteServerGoalKill")
function kill.onKill(creature, target)
	if not target or not target:isMonster() then
		return true
	end
	local byPlayer = creature:isPlayer()
	if not byPlayer then
		local master = creature:getMaster()
		byPlayer = master ~= nil and master:isPlayer()
	end
	if not byPlayer then
		return true
	end
	if next(MONSTERS) ~= nil and not MONSTERS[target:getName():lower()] then
		return true
	end
	buffer[COUNTER_KEY] = (buffer[COUNTER_KEY] or 0) + 1
	return true
end
kill:register()

local login = CreatureEvent("ZnoteServerGoalLogin")
function login.onLogin(player)
	player:registerEvent("ZnoteServerGoalKill")
	return true
end
login:register()

local flushEv = GlobalEvent("ZnoteServerGoalFlush")
function flushEv.onThink(interval)
	flush()
	return true
end
flushEv:interval(FLUSH_SECONDS * 1000)
flushEv:register()

local shutdownEv = GlobalEvent("ZnoteServerGoalShutdown")
function shutdownEv.onShutdown()
	flush()
	return true
end
shutdownEv:register()
