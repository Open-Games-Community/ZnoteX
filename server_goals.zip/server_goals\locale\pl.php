<?php

return array(
	'server_goals.panel_title' => 'Cele społeczności',
	'server_goals.default_title' => 'Cel społeczności',
	'server_goals.reward' => 'Nagroda: {reward}',
	'server_goals.unlocked' => '{reward} odblokowane!',
	'server_goals.hide' => 'Ukryj',
	'server_goals.show' => 'Pokaż',
);
