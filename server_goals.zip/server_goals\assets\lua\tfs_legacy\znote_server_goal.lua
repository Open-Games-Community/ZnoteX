--[[  ZnoteX - Server Goals : kill counter (creaturescript)
      TFS 0.3.6 / 0.4 / 1.0 and other XML-script forks.

      INSTALL
        1. Copy this file to:  data/creaturescripts/scripts/znote_server_goal.lua
        2. Copy znote_server_goal_flush.lua to data/globalevents/scripts/
        3. Add the lines from XML_lines.txt to creaturescripts.xml and globalevents.xml
        4. Set COUNTER_KEY / MONSTERS below.
        5. Restart (or /reload).

      Counts are buffered in a shared global table and written every 30 s by the
      globalevent - never one query per kill.
]]--

local COUNTER_KEY = "demons"
local MONSTERS    = { ["demon"] = true }

if _ZNOTE_GOAL_BUFFER == nil then
	_ZNOTE_GOAL_BUFFER = {}
end

function onKill(cid, target)
	if not isPlayer(cid) or not isMonster(target) then
		return true
	end
	if next(MONSTERS) ~= nil and not MONSTERS[string.lower(getCreatureName(target))] then
		return true
	end
	_ZNOTE_GOAL_BUFFER[COUNTER_KEY] = (_ZNOTE_GOAL_BUFFER[COUNTER_KEY] or 0) + 1
	return true
end

function onLogin(cid)
	registerCreatureEvent(cid, "ZnoteServerGoalKill")
	return true
end
