<?php

return array(
	'server_goals.panel_title' => 'Metas de la comunidad',
	'server_goals.default_title' => 'Meta de la comunidad',
	'server_goals.reward' => 'Recompensa: {reward}',
	'server_goals.unlocked' => '¡{reward} desbloqueado!',
	'server_goals.hide' => 'Ocultar',
	'server_goals.show' => 'Mostrar',
);
