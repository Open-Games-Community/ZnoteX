﻿CREATE TABLE IF NOT EXISTS `znote_server_goals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `line` varchar(160) NOT NULL DEFAULT '',
  `target` bigint NOT NULL DEFAULT '1',
  `source` varchar(24) NOT NULL DEFAULT 'lua_counter',
  `source_param` varchar(64) NOT NULL DEFAULT '',
  `manual_value` bigint NOT NULL DEFAULT '0',
  `baseline` bigint NOT NULL DEFAULT '0',
  `reward_text` varchar(200) NOT NULL DEFAULT '',
  `complete_key` int NOT NULL DEFAULT '0',
  `complete_mode` varchar(16) NOT NULL DEFAULT 'timestamp',
  `complete_value` bigint NOT NULL DEFAULT '1',
  `completed_at` int NOT NULL DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `starts_at` int NOT NULL DEFAULT '0',
  `ends_at` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active_sort` (`active`, `sort_order`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_server_goal_counters` (
  `goal_key` varchar(64) NOT NULL,
  `value` bigint NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`goal_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_server_goal_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `goal_id` int NOT NULL,
  `event` varchar(24) NOT NULL DEFAULT '',
  `value` bigint NOT NULL DEFAULT '0',
  `created_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `goal` (`goal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
