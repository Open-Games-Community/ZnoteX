--[[  ZnoteX - Server Goals : buffer flush (globalevent)
      Copy to data/globalevents/scripts/znote_server_goal_flush.lua
      Registered from globalevents.xml (see XML_lines.txt), runs every 30 s.
]]--

function onThink(interval, lastExecution)
	if _ZNOTE_GOAL_BUFFER == nil then
		return true
	end
	local now = os.time()
	for key, n in pairs(_ZNOTE_GOAL_BUFFER) do
		if n > 0 then
			local q = "INSERT INTO `znote_server_goal_counters` (`goal_key`, `value`, `updated_at`) VALUES (" ..
				db.escapeString(key) .. ", " .. n .. ", " .. now ..
				") ON DUPLICATE KEY UPDATE `value` = `value` + " .. n .. ", `updated_at` = " .. now
			if db.executeQuery then
				db.executeQuery(q)
			else
				db.query(q)
			end
		end
	end
	_ZNOTE_GOAL_BUFFER = {}
	return true
end
