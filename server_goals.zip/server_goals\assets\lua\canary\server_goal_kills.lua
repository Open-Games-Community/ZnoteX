--[[  ZnoteX - Server Goals : kill counter
      Canary / otservbr-global (revscriptsys).

      INSTALL
        1. Copy this file to:  data/scripts/server_goal_kills.lua
        2. Set COUNTER_KEY to match the goal's "Lua counter key" in the ACP.
        3. Set MONSTERS (lowercase). Leave {} to count every monster.
        4. /reload scripts   (or restart)

      Buffered in memory, flushed once every FLUSH_SECONDS.
      Table `znote_server_goal_counters` was created by the plugin on install.
]]--

local COUNTER_KEY   = "demons"
local MONSTERS      = { ["demon"] = true }
local FLUSH_SECONDS = 30

local buffer = {}

local function flush()
	for key, n in pairs(buffer) do
		if n > 0 then
			local now = os.time()
			db.asyncQuery("INSERT INTO `znote_server_goal_counters` (`goal_key`, `value`, `updated_at`) VALUES (" ..
				db.escapeString(key) .. ", " .. n .. ", " .. now ..
				") ON DUPLICATE KEY UPDATE `value` = `value` + " .. n .. ", `updated_at` = " .. now)
		end
	end
	buffer = {}
end

local kill = CreatureEvent("ZnoteServerGoalKill")
function kill.onKill(creature, target)
	if not target or not target:isMonster() then
		return true
	end
	local byPlayer = creature:isPlayer()
	if not byPlayer then
		local master = creature:getMaster()
		byPlayer = master ~= nil and master:isPlayer()
	end
	if not byPlayer then
		return true
	end
	if next(MONSTERS) ~= nil and not MONSTERS[target:getName():lower()] then
		return true
	end
	buffer[COUNTER_KEY] = (buffer[COUNTER_KEY] or 0) + 1
	return true
end
kill:register()

local login = CreatureEvent("ZnoteServerGoalLogin")
function login.onLogin(player)
	player:registerEvent("ZnoteServerGoalKill")
	return true
end
login:register()

local flushEv = GlobalEvent("ZnoteServerGoalFlush")
function flushEv.onThink(interval)
	flush()
	return true
end
flushEv:interval(FLUSH_SECONDS * 1000)
flushEv:register()

local shutdownEv = GlobalEvent("ZnoteServerGoalShutdown")
function shutdownEv.onShutdown()
	flush()
	return true
end
shutdownEv:register()
