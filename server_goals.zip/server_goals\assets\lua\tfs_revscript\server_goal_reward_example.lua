--[[  ZnoteX - Server Goals : reward example (OPTIONAL)
      Turns a completed goal into a timed Double XP.

      When a goal completes, the plugin writes os.time() into the global storage
      key you set as the goal's "Write game global storage key" (with value mode
      "os.time()"). The bonus below is active while  now < stored_time + DURATION.

      Copy to data/scripts/ and set STORAGE to that same key.
]]--

local STORAGE  = 50000
local DURATION = 48 * 3600   -- 48h
local MULT     = 2.0

local function bonusActive()
	local ts = Game.getStorageValue(STORAGE)
	return ts and ts > 0 and os.time() < ts + DURATION
end

local ec = EventCallback
ec.onGainExperience = function(self, source, exp, rawExp)
	if bonusActive() then
		return math.floor(exp * MULT)
	end
	return exp
end
ec:register(-1)

local announce = GlobalEvent("ZnoteServerGoalAnnounce")
function announce.onThink(interval)
	if bonusActive() then
		Game.broadcastMessage("Community goal reached - Double XP is active!", MESSAGE_STATUS_WARNING)
	end
	return true
end
announce:interval(30 * 60 * 1000)
announce:register()
