<?php

return array(
	'server_goals.panel_title' => 'Community Goals',
	'server_goals.default_title' => 'Community Goal',
	'server_goals.reward' => 'Reward: {reward}',
	'server_goals.unlocked' => '{reward} unlocked!',
	'server_goals.hide' => 'Hide',
	'server_goals.show' => 'Show',
);
