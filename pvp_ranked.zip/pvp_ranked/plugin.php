<?php
/**
 * PvP Ranked - an ELO ladder from player_deaths.
 *
 * Read-only on the game DB (only its own znote_pvp_* tables are written).
 * pvp_ranked_process() walks new PvP death rows since the stored last id and
 * applies ELO, guarded by a GET_LOCK so two web requests never double-count a
 * kill. Seasons, decay and per-pair anti-farm cooldown. Menu entry next to
 * Guilds; tier badge injected on character profiles.
 */
if (!function_exists('pvp_ranked_setting')) {

function pvp_ranked_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('pvp_ranked:' . $k, $d) : $d;
}
function pvp_ranked_enabled(): bool { return pvp_ranked_setting('enabled', '1') === '1'; }
function pvp_ranked_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function pvp_ranked_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function pvp_ranked_ident(string $v): string { $v = trim($v); return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : ''; }
function pvp_ranked_int(string $k, int $d): int { $v = pvp_ranked_setting($k, ''); return $v === '' ? $d : (int) $v; }
function pvp_ranked_css(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function pvp_ranked_color(string $k): string { return pvp_ranked_css(pvp_ranked_setting('style_' . $k, '')); }
function pvp_ranked_url(string $v): string {
	$v = trim($v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function pvp_ranked_base(): int { return max(100, pvp_ranked_int('base_rating', 1000)); }
function pvp_ranked_season(): int { return max(1, pvp_ranked_int('season', 1)); }
function pvp_ranked_tables_ok(): bool { return function_exists('znote_table_exists') && znote_table_exists('znote_pvp_ranked'); }

// --- tiers --------------------------------------------------------
function pvp_ranked_default_tiers(): array {
	$b = pvp_ranked_base();
	return array(
		array('name' => 'Unranked',    'min' => 0,          'color' => '#5b6470', 'icon' => ''),
		array('name' => 'Bronze',      'min' => $b - 100,   'color' => '#cd7f45', 'icon' => ''),
		array('name' => 'Silver',      'min' => $b + 60,    'color' => '#c9d1d9', 'icon' => ''),
		array('name' => 'Gold',        'min' => $b + 180,   'color' => '#f4c542', 'icon' => ''),
		array('name' => 'Platinum',    'min' => $b + 320,   'color' => '#4fd1c5', 'icon' => ''),
		array('name' => 'Diamond',     'min' => $b + 480,   'color' => '#5aa9ff', 'icon' => ''),
		array('name' => 'Master',      'min' => $b + 650,   'color' => '#c084fc', 'icon' => ''),
		array('name' => 'Grandmaster', 'min' => $b + 850,   'color' => '#ff6b6b', 'icon' => ''),
		array('name' => 'Legend',      'min' => $b + 1100,  'color' => '#ff3b3b', 'icon' => ''),
	);
}
/** Best-guess icon in assets/img/ for a tier name (bronze.png, grand_master.png, ...). */
function pvp_ranked_tier_auto_icon(string $name): string {
	static $files = null;
	if ($files === null) {
		$files = array();
		foreach ((array) glob(__DIR__ . '/assets/img/*.{png,jpg,jpeg,gif,svg,webp}', GLOB_BRACE) as $f) {
			$base = strtolower((string) pathinfo($f, PATHINFO_FILENAME));
			$key = preg_replace('/[^a-z0-9]/', '', $base);
			if ($key === '' || in_array($key, array('points', 'vip'), true)) continue;
			$files[$key] = basename($f);
		}
	}
	$want = preg_replace('/[^a-z0-9]/', '', strtolower($name));
	if ($want === '' || !$files) return '';
	if (isset($files[$want])) return znote_plugin_asset('pvp_ranked', 'img/' . $files[$want]);
	foreach ($files as $key => $file) {
		if (strpos($key, $want) === 0 || strpos($want, $key) === 0) {
			return znote_plugin_asset('pvp_ranked', 'img/' . $file);
		}
		$pct = 0.0;
		similar_text($key, $want, $pct);
		if ($pct >= 78) return znote_plugin_asset('pvp_ranked', 'img/' . $file);
	}
	return '';
}
function pvp_ranked_tiers(): array {
	static $cache = null;
	if ($cache !== null) return $cache;
	$raw = json_decode(pvp_ranked_setting('tiers', ''), true);
	if (!is_array($raw) || !$raw) $raw = pvp_ranked_default_tiers();
	$out = array();
	foreach (array_slice(array_values($raw), 0, 10) as $t) {
		$t = (array) $t;
		$name = trim((string) ($t['name'] ?? 'Tier'));
		$icon = pvp_ranked_icon((string) ($t['icon'] ?? ''));
		if ($icon === '') $icon = pvp_ranked_tier_auto_icon($name);
		$out[] = array(
			'name'  => $name,
			'min'   => (int) ($t['min'] ?? 0),
			'color' => pvp_ranked_css((string) ($t['color'] ?? '')) ?: '#5b6470',
			'icon'  => $icon,
		);
	}
	usort($out, static fn($a, $b) => $a['min'] <=> $b['min']);
	return $cache = $out;
}
function pvp_ranked_tier_for(int $rating): array {
	$tier = array('name' => '-', 'min' => 0, 'color' => '#5b6470', 'icon' => '');
	foreach (pvp_ranked_tiers() as $t) if ($rating >= $t['min']) $tier = $t;
	return $tier;
}
function pvp_ranked_badge(int $rating, string $cls = 'pr-badge'): string {
	$t = pvp_ranked_tier_for($rating);
	$icon = $t['icon'] !== '' ? '<img src="' . pvp_ranked_h($t['icon']) . '" alt="">' : '';
	return '<span class="' . pvp_ranked_h($cls) . '" style="--pr-tier:' . pvp_ranked_h($t['color']) . '">' . $icon . pvp_ranked_h($t['name']) . '</span>';
}

// --- game column resolution ------------------------------------
function pvp_ranked_tbl(string $k, string $def): string { return pvp_ranked_ident(pvp_ranked_setting($k, '')) ?: $def; }
function pvp_ranked_col(string $table, string $setting, array $cands): string {
	$o = pvp_ranked_ident(pvp_ranked_setting($setting, ''));
	if ($o !== '') return $o;
	foreach ($cands as $c) if (function_exists('znote_column_exists') && znote_column_exists($table, $c)) return $c;
	return $cands[0] ?? '';
}
function pvp_ranked_account_of(string $name): int {
	static $cache = array();
	$k = strtolower($name);
	if (isset($cache[$k])) return $cache[$k];
	$pt = pvp_ranked_tbl('players_table', 'players');
	$nc = pvp_ranked_col($pt, 'players_name_col', array('name'));
	$ac = pvp_ranked_col($pt, 'players_acc_col', array('account_id'));
	if (!function_exists('znote_table_exists') || !znote_table_exists($pt)) return $cache[$k] = 0;
	$r = mysql_select_single("SELECT `{$ac}` AS a FROM `{$pt}` WHERE `{$nc}` = '" . mysql_znote_escape_string($name) . "' LIMIT 1;");
	return $cache[$k] = is_array($r) ? (int) $r['a'] : 0;
}

// --- rating rows ---------------------------------------------
function pvp_ranked_row(int $season, string $name): array {
	$base = pvp_ranked_base();
	if (!pvp_ranked_tables_ok()) return array('rating' => $base, 'wins' => 0, 'losses' => 0, 'streak' => 0);
	$r = mysql_select_single("SELECT `rating`,`wins`,`losses`,`streak` FROM `znote_pvp_ranked` WHERE `season` = {$season} AND `character_name` = '" . mysql_znote_escape_string($name) . "' LIMIT 1;");
	return is_array($r) ? array('rating' => (int) $r['rating'], 'wins' => (int) $r['wins'], 'losses' => (int) $r['losses'], 'streak' => (int) $r['streak']) : array('rating' => $base, 'wins' => 0, 'losses' => 0, 'streak' => 0);
}
function pvp_ranked_apply(int $season, string $name, int $delta, bool $win): void {
	$now = time();
	$safe = mysql_znote_escape_string($name);
	$base = pvp_ranked_base();
	$floor = $base - max(0, pvp_ranked_int('rating_floor_below_base', 400));
	$w = $win ? 1 : 0; $l = $win ? 0 : 1;
	$streak = $win ? 1 : -1;
	mysql_insert("INSERT INTO `znote_pvp_ranked` (`season`,`character_name`,`rating`,`peak_rating`,`wins`,`losses`,`streak`,`last_kill_at`,`updated_at`) VALUES ({$season},'{$safe}'," . ($base + $delta) . "," . max($base, $base + $delta) . ",{$w},{$l},{$streak}," . ($win ? $now : 0) . ",{$now}) ON DUPLICATE KEY UPDATE "
		. "`peak_rating` = GREATEST(`peak_rating`, GREATEST({$floor}, `rating` + ({$delta}))), `rating` = GREATEST({$floor}, `rating` + ({$delta})), `wins` = `wins` + {$w}, `losses` = `losses` + {$l}, "
		. "`streak` = IF(" . ($win ? '`streak` >= 0' : '`streak` <= 0') . ", `streak` + ({$streak}), {$streak}), "
		. ($win ? "`last_kill_at` = {$now}, " : '') . "`updated_at` = {$now};");
}

// --- processing --------------------------------------------
function pvp_ranked_process(bool $force = false): void {
	if (!pvp_ranked_enabled() || !pvp_ranked_tables_ok()) return;
	$every = max(15, pvp_ranked_int('process_every', 60));
	$lastAt = pvp_ranked_int('last_process_at', 0);
	if (!$force && $lastAt + $every > time()) return;

	$lock = mysql_select_single("SELECT GET_LOCK('znx_pvpr', 1) AS l;");
	if (!is_array($lock) || (int) $lock['l'] !== 1) return;
	try {
		if (function_exists('setting_set')) setting_set('pvp_ranked:last_process_at', (string) time());

		$dt = pvp_ranked_tbl('deaths_table', 'player_deaths');
		if (!znote_table_exists($dt)) return;
		$idc = pvp_ranked_col($dt, 'deaths_id_col', array('id'));
		$pc  = pvp_ranked_col($dt, 'deaths_player_col', array('player_id'));
		$kc  = pvp_ranked_col($dt, 'deaths_killedby_col', array('killed_by'));
		$ip  = pvp_ranked_col($dt, 'deaths_isplayer_col', array('is_player'));
		$tc  = pvp_ranked_col($dt, 'deaths_time_col', array('time', 'date'));
		$pt  = pvp_ranked_tbl('players_table', 'players');
		$nc  = pvp_ranked_col($pt, 'players_name_col', array('name'));
		$pic = pvp_ranked_col($pt, 'players_id_col', array('id'));

		$season = pvp_ranked_season();
		$base = pvp_ranked_base();
		$K = max(4, pvp_ranked_int('k_factor', 32));
		$cooldown = max(0, pvp_ranked_int('pair_cooldown', 3600));
		$lastId = pvp_ranked_int('last_death_id', 0);

		$where = "`d`.`{$idc}` > {$lastId} AND `d`.`{$ip}` = 1";
		if (pvp_ranked_setting('unjustified_only', '0') === '1') {
			$uj = pvp_ranked_col($dt, 'deaths_unjust_col', array('unjustified'));
			if ($uj !== '') $where .= " AND `d`.`{$uj}` = 1";
		}
		$rows = mysql_select_multi("SELECT `d`.`{$idc}` AS id, `d`.`{$kc}` AS killer, `d`.`{$tc}` AS t, `p`.`{$nc}` AS victim FROM `{$dt}` `d` JOIN `{$pt}` `p` ON `p`.`{$pic}` = `d`.`{$pc}` WHERE {$where} ORDER BY `d`.`{$idc}` ASC LIMIT 300;");
		if (!is_array($rows)) return;

		$maxId = $lastId;
		foreach ($rows as $r) {
			$maxId = max($maxId, (int) $r['id']);
			$killer = trim((string) $r['killer']);
			$victim = trim((string) $r['victim']);
			if ($killer === '' || $victim === '' || strcasecmp($killer, $victim) === 0) continue;

			$ka = pvp_ranked_account_of($killer);
			$va = pvp_ranked_account_of($victim);
			if ($ka > 0 && $ka === $va) continue; // same account

			if ($cooldown > 0) {
				$since = time() - $cooldown;
				$recent = mysql_select_single("SELECT `id` FROM `znote_pvp_ranked_log` WHERE `season` = {$season} AND `winner` = '" . mysql_znote_escape_string($killer) . "' AND `loser` = '" . mysql_znote_escape_string($victim) . "' AND `created_at` > {$since} LIMIT 1;");
				if (is_array($recent)) continue; // farming the same target
			}

			$kr = pvp_ranked_row($season, $killer)['rating'];
			$vr = pvp_ranked_row($season, $victim)['rating'];
			$expK = 1 / (1 + pow(10, ($vr - $kr) / 400));
			$dW = (int) round($K * (1 - $expK));
			$dL = (int) round($K * (0 - (1 - $expK)));
			if ($dW < 1) $dW = 1;
			if ($dL > -1) $dL = -1;

			pvp_ranked_apply($season, $killer, $dW, true);
			pvp_ranked_apply($season, $victim, $dL, false);
			mysql_insert("INSERT INTO `znote_pvp_ranked_log` (`season`,`winner`,`loser`,`delta_w`,`delta_l`,`created_at`) VALUES ({$season},'" . mysql_znote_escape_string($killer) . "','" . mysql_znote_escape_string($victim) . "',{$dW},{$dL}," . time() . ");");
			if (function_exists('znote_hook')) znote_hook('pvp_ranked.kill', array('season' => $season, 'winner' => $killer, 'loser' => $victim, 'delta' => $dW));
		}
		if ($maxId > $lastId && function_exists('setting_set')) setting_set('pvp_ranked:last_death_id', (string) $maxId);

		// decay
		$dd = pvp_ranked_int('decay_days', 14);
		$dp = pvp_ranked_int('decay_per_day', 10);
		if ($dd > 0 && $dp > 0) {
			$cut = time() - $dd * 86400;
			mysql_update("UPDATE `znote_pvp_ranked` SET `rating` = GREATEST({$base}, `rating` - {$dp} * FLOOR((" . time() . " - `updated_at`) / 86400)), `updated_at` = " . time() . " WHERE `season` = {$season} AND `updated_at` < {$cut} AND `rating` > {$base};");
		}
	} catch (Throwable $e) {
		error_log('[pvp_ranked] process failed: ' . $e->getMessage());
	} finally {
		mysql_select_single("SELECT RELEASE_LOCK('znx_pvpr');");
	}
}

// --- ladder read ------------------------------------------
function pvp_ranked_ladder(int $limit = 100, string $youName = ''): array {
	if (!pvp_ranked_tables_ok()) return array();
	$season = pvp_ranked_season();
	$limit = max(3, min(500, $limit));
	$peakSel = (function_exists('znote_column_exists') && znote_column_exists('znote_pvp_ranked', 'peak_rating')) ? '`peak_rating`' : '`rating` AS `peak_rating`';
	$rows = mysql_select_multi("SELECT `character_name`,`rating`,{$peakSel},`wins`,`losses`,`streak` FROM `znote_pvp_ranked` WHERE `season` = {$season} AND (`wins` + `losses`) > 0 ORDER BY `rating` DESC, `wins` DESC LIMIT {$limit};");
	if (!is_array($rows)) return array();

	// Frags from each character's most recent finished season.
	$lastWins = array();
	if ($rows && function_exists('znote_table_exists') && znote_table_exists('znote_pvp_ranked_history')) {
		$in = array();
		foreach ($rows as $r) $in[] = "'" . mysql_znote_escape_string((string) $r['character_name']) . "'";
		$in = implode(',', $in);
		$hrows = mysql_select_multi(
			"SELECT `h`.`character_name` AS `n`, `h`.`wins` AS `w` FROM `znote_pvp_ranked_history` `h` "
			. "JOIN (SELECT `character_name`, MAX(`season`) AS `ms` FROM `znote_pvp_ranked_history` WHERE `character_name` IN ({$in}) GROUP BY `character_name`) `m` "
			. "ON `m`.`character_name` = `h`.`character_name` AND `m`.`ms` = `h`.`season`;"
		);
		if (is_array($hrows)) foreach ($hrows as $hr) $lastWins[strtolower((string) $hr['n'])] = (int) $hr['w'];
	}

	$you = strtolower(trim($youName));
	$out = array(); $rank = 0;
	foreach ($rows as $r) {
		$rank++;
		$tier = pvp_ranked_tier_for((int) $r['rating']);
		$peak = max((int) $r['rating'], (int) $r['peak_rating']);
		$peakTier = pvp_ranked_tier_for($peak);
		$lw = $lastWins[strtolower((string) $r['character_name'])] ?? null;
		$out[] = array(
			'rank' => $rank, 'name' => (string) $r['character_name'], 'rating' => (int) $r['rating'],
			'wins' => (int) $r['wins'], 'losses' => (int) $r['losses'], 'streak' => (int) $r['streak'],
			'tier' => $tier['name'], 'tier_color' => $tier['color'], 'tier_icon' => $tier['icon'],
			'last_wins' => $lw,
			'peak_rating' => $peak, 'peak_tier' => $peakTier['name'],
			'peak_tier_color' => $peakTier['color'], 'peak_tier_icon' => $peakTier['icon'],
			'you' => $you !== '' && strtolower((string) $r['character_name']) === $you,
		);
	}
	return $out;
}
function pvp_ranked_history(int $limit = 80): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_pvp_ranked_history')) return array();
	$rows = mysql_select_multi("SELECT * FROM `znote_pvp_ranked_history` ORDER BY `season` DESC, `rank` ASC LIMIT " . max(1, min(300, $limit)) . ";");
	return is_array($rows) ? $rows : array();
}

// --- season roll -----------------------------------------
function pvp_ranked_new_season(): int {
	if (!pvp_ranked_tables_ok()) return 0;
	$lock = mysql_select_single("SELECT GET_LOCK('znx_pvpr', 3) AS l;");
	if (!is_array($lock) || (int) $lock['l'] !== 1) return 0;
	try {
		$season = pvp_ranked_season();
		$now = time();
		$prizes = pvp_ranked_prize_map(); // tierKey => reward spec

		$rank = 0;
		foreach (pvp_ranked_ladder(500) as $r) {
			$rank = $r['rank'];
			$tier = pvp_ranked_tier_for((int) $r['rating']);
			$spec = ($tier['name'] !== '' && strtolower($tier['name']) !== 'unranked')
				? ($prizes[pvp_ranked_tier_key($tier['name'])] ?? null) : null;
			$given = is_array($spec) ? pvp_ranked_grant($r['name'], $spec) : '';
			if ($rank <= 20 || $given !== '') {
				mysql_insert("INSERT INTO `znote_pvp_ranked_history` (`season`,`rank`,`character_name`,`rating`,`wins`,`losses`,`reward`,`closed_at`) VALUES ({$season},{$rank},'" . mysql_znote_escape_string($r['name']) . "'," . (int) $r['rating'] . "," . (int) $r['wins'] . "," . (int) $r['losses'] . ",'" . mysql_znote_escape_string($given) . "',{$now});");
			}
		}

		$soft = max(0, min(100, pvp_ranked_int('soft_reset_pct', 50)));
		$base = pvp_ranked_base();
		mysql_update("UPDATE `znote_pvp_ranked` SET `rating` = {$base} + ROUND((`rating` - {$base}) * {$soft} / 100), `wins` = 0, `losses` = 0, `streak` = 0, `updated_at` = {$now} WHERE `season` = {$season};");
		mysql_update("UPDATE `znote_pvp_ranked` SET `season` = " . ($season + 1) . " WHERE `season` = {$season};");
		mysql_delete("DELETE FROM `znote_pvp_ranked_log` WHERE `season` = {$season};");
		if (function_exists('setting_set')) setting_set('pvp_ranked:season', (string) ($season + 1));
		if (function_exists('znote_hook')) znote_hook('pvp_ranked.season', array('closed' => $season, 'new' => $season + 1));
		return $season + 1;
	} finally {
		mysql_select_single("SELECT RELEASE_LOCK('znx_pvpr');");
	}
}
function pvp_ranked_grant(string $name, array $prize): string {
	$acc = pvp_ranked_account_of($name);
	if ($acc <= 0) return '';
	$parts = array(); $now = time();
	$pts = max(0, (int) ($prize['points'] ?? 0));
	if ($pts > 0) { mysql_update("UPDATE `znote_accounts` SET `points` = COALESCE(`points`,0) + {$pts} WHERE `account_id` = {$acc};"); $parts[] = $pts . ' points'; }
	$prem = max(0, (int) ($prize['premium'] ?? 0));
	if ($prem > 0 && function_exists('user_account_add_premdays')) { user_account_add_premdays($acc, $prem); $parts[] = $prem . ' prem'; }
	$itemid = max(0, (int) ($prize['itemid'] ?? 0)); $count = max(0, (int) ($prize['count'] ?? 0));
	if ($itemid > 0 && $count > 0 && znote_table_exists('znote_shop_orders')) {
		mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$acc},1,{$itemid},{$count},{$now});");
		$parts[] = $count . 'x ' . $itemid;
	}
	return implode(', ', $parts);
}

// --- assets + reward boxes ------------------------------
function pvp_ranked_asset(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$p = __DIR__ . '/assets/img/' . $file;
	return is_file($p) ? znote_plugin_asset('pvp_ranked', 'img/' . $file) : '';
}
/** Accepts a full URL, a root-relative path, or a bare filename in assets/img/. */
function pvp_ranked_icon(string $v): string {
	$v = trim($v);
	if ($v === '') return '';
	$u = pvp_ranked_url($v);
	if ($u !== '') return $u;
	return pvp_ranked_asset($v);
}
function pvp_ranked_prize_icon(string $which): string {
	$key = $which === 'premium' ? 'prize_icon_premium' : 'prize_icon_points';
	$u = pvp_ranked_icon(pvp_ranked_setting($key, ''));
	if ($u !== '') return $u;
	return pvp_ranked_asset($which === 'premium' ? 'vip.png' : 'points.png');
}
function pvp_ranked_item_image(int $itemid): string {
	if ($itemid <= 0) return '';
	global $config;
	$srv = trim((string) pvp_ranked_setting('item_image_server', ''));
	if ($srv === '' && function_exists('znote_item_image_url')) return znote_item_image_url($itemid);
	if ($srv === '') $srv = trim((string) ($config['shop']['imageServer'] ?? ''));
	if ($srv === '') return '';
	$ext = trim((string) ($config['shop']['imageType'] ?? 'gif')) ?: 'gif';
	if (function_exists('znote_media_base')) { $b = znote_media_base($srv); return $b === '' ? '' : $b . '/' . $itemid . '.' . $ext; }
	if (!preg_match('#^([a-z][a-z0-9+.\-]*:)?//#i', $srv)) $srv = 'http://' . $srv;
	return rtrim($srv, '/') . '/' . $itemid . '.' . $ext;
}
/** Normalised key for a tier name, used to store its reward. */
function pvp_ranked_tier_key(string $name): string {
	return preg_replace('/[^a-z0-9]/', '', strtolower(trim($name)));
}
/** One reward per rank (tier). tierKey => spec + 'tier' meta. Only configured ones. */
function pvp_ranked_prize_map(): array {
	$p = json_decode(pvp_ranked_setting('season_prizes', ''), true);
	$p = is_array($p) ? $p : array();
	$out = array();
	foreach (pvp_ranked_tiers() as $t) {
		if ($t['name'] === '' || strtolower($t['name']) === 'unranked') continue;
		$key = pvp_ranked_tier_key($t['name']);
		if ($key === '') continue;
		$s = is_array($p[$key] ?? null) ? $p[$key] : array();
		$points  = max(0, (int) ($s['points'] ?? 0));
		$premium = max(0, (int) ($s['premium'] ?? 0));
		$itemid  = max(0, (int) ($s['itemid'] ?? 0));
		$count   = max(0, (int) ($s['count'] ?? 0));
		if ($points > 0 || $premium > 0 || ($itemid > 0 && $count > 0)) {
			$out[$key] = array('tier' => $t, 'points' => $points, 'premium' => $premium, 'itemid' => $itemid, 'count' => $count);
		}
	}
	return $out;
}
/**
 * One cell per rank/tier, ordered Bronze -> Legend (Unranked excluded). Always
 * spans the whole ladder; a tier with no configured reward has `has_reward` false
 * and just shows its icon / name / rating threshold.
 */
function pvp_ranked_prize_cells(): array {
	$map = pvp_ranked_prize_map();
	$cells = array();
	foreach (pvp_ranked_tiers() as $t) {
		if ($t['name'] === '' || strtolower($t['name']) === 'unranked') continue;
		$k = pvp_ranked_tier_key($t['name']);
		if ($k === '') continue;
		$s = $map[$k] ?? array('points' => 0, 'premium' => 0, 'itemid' => 0, 'count' => 0);
		$itemid = (int) $s['itemid']; $count = (int) $s['count'];
		$cells[] = array(
			'label'      => $t['name'],
			'color'      => $t['color'],
			'icon'       => $t['icon'],
			'min'        => (int) $t['min'],
			'points'     => (int) $s['points'],
			'premium'    => (int) $s['premium'],
			'itemid'     => $itemid,
			'count'      => $count,
			'has_reward' => isset($map[$k]),
			'item_image' => ($itemid > 0 && $count > 0) ? pvp_ranked_item_image($itemid) : '',
		);
	}
	return $cells;
}

// --- schema + menu --------------------------------------
function pvp_ranked_ensure_schema(): void {
	static $done = false;
	if ($done) return;
	$done = true;
	if (!function_exists('setting')) return;

	if (setting('pvp_ranked:schema_v', '') !== '2'
		&& function_exists('znote_table_exists') && znote_table_exists('znote_pvp_ranked')
		&& function_exists('znote_column_exists')) {
		if (!znote_column_exists('znote_pvp_ranked', 'peak_rating')) {
			mysql_update("ALTER TABLE `znote_pvp_ranked` ADD COLUMN `peak_rating` int NOT NULL DEFAULT 0 AFTER `rating`;");
		}
		mysql_update("UPDATE `znote_pvp_ranked` SET `peak_rating` = `rating` WHERE `peak_rating` < `rating`;");
		if (function_exists('setting_set')) setting_set('pvp_ranked:schema_v', '2');
	}

	$state = 'v2:' . (pvp_ranked_enabled() ? '1' : '0') . (pvp_ranked_setting('show_in_menu', '1') === '1' ? '1' : '0');
	if (setting('pvp_ranked:setup_v', '') === $state) return;
	pvp_ranked_sync_menu();
	if (function_exists('setting_set')) setting_set('pvp_ranked:setup_v', $state);
}

function pvp_ranked_sync_menu(): void {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_menu')) return;
	mysql_delete("DELETE FROM `znote_menu` WHERE `url` = 'page.php?plugin=pvp_ranked&p=ladder';");
	if (!pvp_ranked_enabled() || pvp_ranked_setting('show_in_menu', '1') !== '1') return;

	$p = mysql_select_single("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` LIKE '%communit%' ORDER BY `id` ASC LIMIT 1;");
	$parent = is_array($p) ? (int) $p['id'] : 0;
	if ($parent > 0) {
		$mx = mysql_select_single("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = {$parent};");
		$so = is_array($mx) ? (int) $mx['s'] + 1 : 1;
	} else {
		$g = mysql_select_single("SELECT `sort_order` FROM `znote_menu` WHERE `location` = 'main' AND `url` LIKE '%guild%' ORDER BY `sort_order` ASC LIMIT 1;");
		$so = is_array($g) ? (int) $g['sort_order'] + 2 : 56;
	}
	mysql_insert("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',{$parent},'PvP Ranked','page.php?plugin=pvp_ranked&p=ladder','fa-shield','all',{$so},1);");
}

// --- profile badge -------------------------------------
function pvp_ranked_footer(): string {
	if (!pvp_ranked_enabled() || pvp_ranked_setting('profile_badge', '1') !== '1') return '';
	if (basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')) !== 'characterprofile.php') return '';
	$name = trim((string) ($_GET['name'] ?? ''));
	if ($name === '' || !pvp_ranked_tables_ok()) return '';
	$season = pvp_ranked_season();
	$r = mysql_select_single("SELECT `rating`,`wins`,`losses` FROM `znote_pvp_ranked` WHERE `season` = {$season} AND `character_name` = '" . mysql_znote_escape_string($name) . "' LIMIT 1;");
	if (!is_array($r) || ((int) $r['wins'] + (int) $r['losses']) === 0) return '';
	$rank = mysql_select_single("SELECT COUNT(*) + 1 AS r FROM `znote_pvp_ranked` WHERE `season` = {$season} AND `rating` > " . (int) $r['rating'] . " AND (`wins` + `losses`) > 0;");
	$rankTxt = is_array($rank) ? '#' . (int) $rank['r'] : '';
	$url = pvp_ranked_h(znote_plugin_url('pvp_ranked', 'ladder'));
	$css = '.pr-pbadge{display:inline-flex;align-items:center;gap:8px;margin:8px 0;padding:7px 12px;border-radius:8px;border:1px solid var(--pr-tier,#5b6470);background:color-mix(in srgb,var(--pr-tier,#5b6470) 16%,transparent);font:13px system-ui,Arial;text-decoration:none;color:inherit}'
		. '.pr-pbadge b{color:var(--pr-tier,#5b6470)}.pr-pbadge img{width:18px;height:18px;object-fit:contain}';
	$t = pvp_ranked_tier_for((int) $r['rating']);
	$html = '<a class="pr-pbadge" href="' . $url . '" style="--pr-tier:' . pvp_ranked_h($t['color']) . '">'
		. ($t['icon'] !== '' ? '<img src="' . pvp_ranked_h($t['icon']) . '" alt="">' : '⚔️ ')
		. '<span>PvP: <b>' . pvp_ranked_h($t['name']) . '</b> ' . (int) $r['rating'] . ' · ' . pvp_ranked_h($rankTxt)
		. ' · ' . (int) $r['wins'] . 'W ' . (int) $r['losses'] . 'L</span></a>';
	return '<script>(function(){if(document.getElementById("prPbadge"))return;var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';var el=w.firstChild;el.id="prPbadge";'
		. 'var host=document.querySelector("#characters,.character-profile,main,#content,.content")||document.body;host.insertBefore(el,host.firstChild);}());</script>';
}

function pvp_ranked_view(string $youName = ''): array {
	pvp_ranked_ensure_schema();
	pvp_ranked_process();
	$hasPast = (function_exists('znote_table_exists') && znote_table_exists('znote_pvp_ranked_history'))
		&& is_array(mysql_select_single("SELECT 1 AS x FROM `znote_pvp_ranked_history` LIMIT 1;"));
	return array(
		'season'   => pvp_ranked_season(),
		'ladder'   => pvp_ranked_ladder(pvp_ranked_int('ladder_size', 100), $youName),
		'tiers'    => pvp_ranked_tiers(),
		'has_past' => $hasPast,
	);
}
function pvp_ranked_style_attr(): string {
	$map = array('box_bg' => '--pr-surface', 'border' => '--pr-border', 'text' => '--pr-text', 'accent' => '--pr-accent', 'row_bg' => '--pr-row', 'you_bg' => '--pr-you', 'head_bg' => '--pr-head-bg', 'head_text' => '--pr-head-text');
	$css = '';
	foreach ($map as $k => $var) { $v = pvp_ranked_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	return $css !== '' ? ' style="' . pvp_ranked_h($css) . '"' : '';
}

}

pvp_ranked_ensure_schema();
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'pvp_ranked_footer');
}
