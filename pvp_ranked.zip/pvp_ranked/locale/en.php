<?php

return array(
	'pvp_ranked.title' => 'PvP Ranked',
	'pvp_ranked.season' => 'Season {n}',
	'pvp_ranked.current' => 'Current ladder',
	'pvp_ranked.past_seasons' => 'Past seasons',
	'pvp_ranked.no_history' => 'No finished seasons yet.',
	'pvp_ranked.empty' => 'No ranked kills yet this season.',
	'pvp_ranked.character' => 'Character',
	'pvp_ranked.tier' => 'Tier',
	'pvp_ranked.rating' => 'Rating',
	'pvp_ranked.record' => 'W / L',
	'pvp_ranked.rank_n' => 'Rank {n}',
	'pvp_ranked.pts' => '{n} points',
	'pvp_ranked.premd' => '{n} premium days',
	'pvp_ranked.tiers' => 'Ranks',
	'pvp_ranked.frags' => 'Frags',
	'pvp_ranked.last_frags' => 'Last season',
	'pvp_ranked.peak' => 'Peak',
	'pvp_ranked.rank_col' => 'Rank',
	'pvp_ranked.no_reward' => 'No reward',
);
