<?php

return array(
	'pvp_ranked.title' => 'PvP Rangliste',
	'pvp_ranked.season' => 'Saison {n}',
	'pvp_ranked.current' => 'Aktuelle Rangliste',
	'pvp_ranked.past_seasons' => 'Vergangene Saisons',
	'pvp_ranked.no_history' => 'Noch keine abgeschlossenen Saisons.',
	'pvp_ranked.empty' => 'Diese Saison noch keine gewerteten Kills.',
	'pvp_ranked.character' => 'Charakter',
	'pvp_ranked.tier' => 'Stufe',
	'pvp_ranked.rating' => 'Wertung',
	'pvp_ranked.record' => 'S / N',
	'pvp_ranked.rank_n' => 'Platz {n}',
	'pvp_ranked.pts' => '{n} Punkte',
	'pvp_ranked.premd' => '{n} Premium-Tage',
	'pvp_ranked.tiers' => 'Ränge',
	'pvp_ranked.frags' => 'Frags',
	'pvp_ranked.last_frags' => 'Letzte Saison',
	'pvp_ranked.peak' => 'Höchststand',
	'pvp_ranked.rank_col' => 'Rang',
	'pvp_ranked.no_reward' => 'Keine Belohnung',
);
