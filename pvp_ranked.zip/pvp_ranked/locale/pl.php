<?php

return array(
	'pvp_ranked.title' => 'PvP Rankingowe',
	'pvp_ranked.season' => 'Sezon {n}',
	'pvp_ranked.current' => 'Aktualny ranking',
	'pvp_ranked.past_seasons' => 'Poprzednie sezony',
	'pvp_ranked.no_history' => 'Brak zakończonych sezonów.',
	'pvp_ranked.empty' => 'Brak rankingowych zabójstw w tym sezonie.',
	'pvp_ranked.character' => 'Postać',
	'pvp_ranked.tier' => 'Próg',
	'pvp_ranked.rating' => 'Ranking',
	'pvp_ranked.record' => 'W / P',
	'pvp_ranked.rank_n' => 'Miejsce {n}',
	'pvp_ranked.pts' => '{n} punktów',
	'pvp_ranked.premd' => '{n} dni premium',
	'pvp_ranked.tiers' => 'Rangi',
	'pvp_ranked.frags' => 'Fragi',
	'pvp_ranked.last_frags' => 'Poprz. sezon',
	'pvp_ranked.peak' => 'Rekord',
	'pvp_ranked.rank_col' => 'Ranga',
	'pvp_ranked.no_reward' => 'Brak nagrody',
);
