<?php

return array(
	'pvp_ranked.title' => 'PvP Ranqueado',
	'pvp_ranked.season' => 'Temporada {n}',
	'pvp_ranked.current' => 'Ranking atual',
	'pvp_ranked.past_seasons' => 'Temporadas anteriores',
	'pvp_ranked.no_history' => 'Nenhuma temporada concluída ainda.',
	'pvp_ranked.empty' => 'Nenhum abate ranqueado nesta temporada.',
	'pvp_ranked.character' => 'Personagem',
	'pvp_ranked.tier' => 'Divisão',
	'pvp_ranked.rating' => 'Pontuação',
	'pvp_ranked.record' => 'V / D',
	'pvp_ranked.rank_n' => 'Posição {n}',
	'pvp_ranked.pts' => '{n} pontos',
	'pvp_ranked.premd' => '{n} dias premium',
	'pvp_ranked.tiers' => 'Rangos',
	'pvp_ranked.frags' => 'Frags',
	'pvp_ranked.last_frags' => 'Temp. anterior',
	'pvp_ranked.peak' => 'Recorde',
	'pvp_ranked.rank_col' => 'Rank',
	'pvp_ranked.no_reward' => 'Sem recompensa',
);
