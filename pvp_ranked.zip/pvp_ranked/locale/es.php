<?php

return array(
	'pvp_ranked.title' => 'PvP Clasificado',
	'pvp_ranked.season' => 'Temporada {n}',
	'pvp_ranked.current' => 'Clasificación actual',
	'pvp_ranked.past_seasons' => 'Temporadas pasadas',
	'pvp_ranked.no_history' => 'Aún no hay temporadas terminadas.',
	'pvp_ranked.empty' => 'Aún no hay muertes clasificadas esta temporada.',
	'pvp_ranked.character' => 'Personaje',
	'pvp_ranked.tier' => 'Rango',
	'pvp_ranked.rating' => 'Puntuación',
	'pvp_ranked.record' => 'V / D',
	'pvp_ranked.rank_n' => 'Puesto {n}',
	'pvp_ranked.pts' => '{n} puntos',
	'pvp_ranked.premd' => '{n} días premium',
	'pvp_ranked.tiers' => 'Rangos',
	'pvp_ranked.frags' => 'Frags',
	'pvp_ranked.last_frags' => 'Temp. anterior',
	'pvp_ranked.peak' => 'Máximo',
	'pvp_ranked.rank_col' => 'Rango',
	'pvp_ranked.no_reward' => 'Sin recompensa',
);
