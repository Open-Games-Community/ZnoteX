CREATE TABLE IF NOT EXISTS `znote_pvp_ranked` (
  `season` int NOT NULL DEFAULT '1',
  `character_name` varchar(64) NOT NULL,
  `rating` int NOT NULL DEFAULT '1000',
  `peak_rating` int NOT NULL DEFAULT '0',
  `wins` int NOT NULL DEFAULT '0',
  `losses` int NOT NULL DEFAULT '0',
  `streak` int NOT NULL DEFAULT '0',
  `last_kill_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`season`, `character_name`),
  KEY `ladder` (`season`, `rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_pvp_ranked_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `season` int NOT NULL DEFAULT '1',
  `winner` varchar(64) NOT NULL DEFAULT '',
  `loser` varchar(64) NOT NULL DEFAULT '',
  `delta_w` int NOT NULL DEFAULT '0',
  `delta_l` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pair` (`season`, `winner`, `loser`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_pvp_ranked_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `season` int NOT NULL DEFAULT '1',
  `rank` int NOT NULL DEFAULT '0',
  `character_name` varchar(64) NOT NULL DEFAULT '',
  `rating` int NOT NULL DEFAULT '0',
  `wins` int NOT NULL DEFAULT '0',
  `losses` int NOT NULL DEFAULT '0',
  `reward` varchar(120) NOT NULL DEFAULT '',
  `closed_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `season_rank` (`season`, `rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
