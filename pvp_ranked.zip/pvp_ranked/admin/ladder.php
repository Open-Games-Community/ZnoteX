<?php
/**
 * Title: PvP Ranked
 * Icon: fa-shield
 * Group: Installed Plugins
 * Order: 38
 * Description: ELO settings, tiers, season rewards and manual season roll.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'pvp_ranked__ladder';
if (function_exists('pvp_ranked_ensure_schema')) pvp_ranked_ensure_schema();

function pvp_ranked_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function pvp_ranked_admin_url($v): string {
	$v = trim((string) $v);
	if (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) return $v;
	// A bare filename is allowed too: it resolves against the plugin's assets/img/.
	return preg_match('#^[A-Za-z0-9_.\-/]{1,120}$#', $v) && strpos($v, '..') === false ? $v : '';
}
function pvp_ranked_admin_ident($v): string {
	$v = trim((string) $v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? 'config');

	if ($do === 'new_season') {
		$n = pvp_ranked_new_season();
		acp_flash_success($n > 0 ? 'Season closed. Now on season ' . $n . '.' : 'Could not roll the season (locked).');
		acp_redirect($module);
	}
	if ($do === 'process') {
		pvp_ranked_process(true);
		acp_flash_success('Processed new PvP kills.');
		acp_redirect($module);
	}

	// config
	setting_set('pvp_ranked:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('pvp_ranked:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
	setting_set('pvp_ranked:profile_badge', !empty($_POST['profile_badge']) ? '1' : '0');
	setting_set('pvp_ranked:unjustified_only', !empty($_POST['unjustified_only']) ? '1' : '0');
	setting_set('pvp_ranked:base_rating', (string) max(100, intv($_POST['base_rating'] ?? 1000)));
	setting_set('pvp_ranked:k_factor', (string) max(4, min(128, intv($_POST['k_factor'] ?? 32))));
	setting_set('pvp_ranked:pair_cooldown', (string) max(0, intv($_POST['pair_cooldown'] ?? 3600)));
	setting_set('pvp_ranked:decay_days', (string) max(0, intv($_POST['decay_days'] ?? 14)));
	setting_set('pvp_ranked:decay_per_day', (string) max(0, intv($_POST['decay_per_day'] ?? 10)));
	setting_set('pvp_ranked:rating_floor_below_base', (string) max(0, intv($_POST['rating_floor_below_base'] ?? 400)));
	setting_set('pvp_ranked:soft_reset_pct', (string) max(0, min(100, intv($_POST['soft_reset_pct'] ?? 50))));
	setting_set('pvp_ranked:process_every', (string) max(15, intv($_POST['process_every'] ?? 60)));
	setting_set('pvp_ranked:ladder_size', (string) max(10, min(500, intv($_POST['ladder_size'] ?? 100))));

	foreach (array('players_table', 'players_name_col', 'players_acc_col', 'deaths_table', 'deaths_id_col', 'deaths_time_col', 'deaths_killedby_col', 'deaths_player_col', 'deaths_isplayer_col', 'deaths_unjust_col') as $k)
		setting_set('pvp_ranked:' . $k, pvp_ranked_admin_ident($_POST[$k] ?? ''));

	foreach (array('box_bg', 'border', 'text', 'accent', 'row_bg', 'you_bg', 'head_bg', 'head_text') as $k)
		setting_set('pvp_ranked:style_' . $k, pvp_ranked_admin_color($_POST['style_' . $k] ?? ''));

	// tiers
	$tiers = array();
	for ($i = 0; $i < 10; $i++) {
		$name = trim((string) ($_POST['tier_name'][$i] ?? ''));
		if ($name === '') continue;
		$tiers[] = array('name' => $name, 'min' => max(0, intv($_POST['tier_min'][$i] ?? 0)), 'color' => pvp_ranked_admin_color($_POST['tier_color'][$i] ?? '') ?: '#5b6470', 'icon' => pvp_ranked_admin_url($_POST['tier_icon'][$i] ?? ''));
	}
	if ($tiers) setting_set('pvp_ranked:tiers', json_encode($tiers));

	// season prizes - one reward per rank (tier), keyed by tier name
	$sp = array();
	foreach (pvp_ranked_tiers() as $t) {
		if ($t['name'] === '' || strtolower($t['name']) === 'unranked') continue;
		$k = pvp_ranked_tier_key($t['name']);
		if ($k === '') continue;
		$p = 'sp_' . $k;
		$row = array('points' => max(0, intv($_POST[$p . '_points'] ?? 0)), 'premium' => max(0, intv($_POST[$p . '_premium'] ?? 0)), 'itemid' => max(0, intv($_POST[$p . '_itemid'] ?? 0)), 'count' => max(0, intv($_POST[$p . '_count'] ?? 0)));
		if ($row['points'] || $row['premium'] || ($row['itemid'] && $row['count'])) $sp[$k] = $row;
	}
	setting_set('pvp_ranked:season_prizes', json_encode($sp));

	// reward boxes (horizontal scroller)
	setting_set('pvp_ranked:prize_box_w', (string) max(90, min(280, intv($_POST['prize_box_w'] ?? 210))));
	setting_set('pvp_ranked:prize_scale', (string) max(60, min(200, intv($_POST['prize_scale'] ?? 100))));
	setting_set('pvp_ranked:prize_icon_points', pvp_ranked_admin_url($_POST['prize_icon_points'] ?? ''));
	setting_set('pvp_ranked:prize_icon_premium', pvp_ranked_admin_url($_POST['prize_icon_premium'] ?? ''));

	// menu sync
	setting_set('pvp_ranked:setup_v', '');
	if (function_exists('pvp_ranked_sync_menu')) pvp_ranked_sync_menu();

	if (function_exists('acp_log')) acp_log('pvp_ranked.config', '');
	acp_flash_success('PvP Ranked saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('pvp_ranked:' . $k, $d);
// Raw tier rows for the editor inputs (what the admin typed - not the auto-resolved icon path).
$tiers = json_decode($get('tiers', ''), true);
if (!is_array($tiers) || !$tiers) $tiers = pvp_ranked_default_tiers();
$tiers = array_slice(array_values(array_map(static fn($t) => (array) $t, $tiers)), 0, 10);
foreach ($tiers as &$_t) { $_t += array('name' => '', 'min' => 0, 'color' => '#5b6470', 'icon' => ''); } unset($_t);
while (count($tiers) < 8) $tiers[] = array('name' => '', 'min' => 0, 'color' => '#5b6470', 'icon' => '');
$sp = json_decode($get('season_prizes', ''), true); $sp = is_array($sp) ? $sp : array();
$spv = static fn(string $slot, string $key) => (int) ($sp[$slot][$key] ?? 0);
// Plugin asset paths are web-root relative; the ACP lives one level down.
$acpImg = static fn(string $u): string => $u === '' ? '' : (preg_match('#^(https?:)?//#i', $u) ? $u : (function_exists('acp_site') ? acp_site(ltrim($u, '/')) : '../' . ltrim($u, '/')));
?>
<?php acp_card_open('PvP Ranked', 'ELO from player_deaths PvP kills. The web processes new death rows on a timer (GET_LOCK guarded so a kill is never counted twice). "New season" archives the ladder, pays rewards and soft-resets ratings.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Show "PvP Ranked" in the Community menu</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="profile_badge" value="1" <?= $get('profile_badge', '1') === '1' ? 'checked' : '' ?>> Show a tier badge on character profiles</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="unjustified_only" value="1" <?= $get('unjustified_only', '0') === '1' ? 'checked' : '' ?>> Only count unjustified kills</label></div>
		<div class="acp-field"><label class="acp-label">Base rating</label><input class="acp-input" type="number" min="100" name="base_rating" value="<?= (int) $get('base_rating', '1000') ?>"></div>
		<div class="acp-field"><label class="acp-label">K-factor (rating swing per kill)</label><input class="acp-input" type="number" min="4" max="128" name="k_factor" value="<?= (int) $get('k_factor', '32') ?>"></div>
		<div class="acp-field"><label class="acp-label">Same killer→victim cooldown (seconds, anti-farm)</label><input class="acp-input" type="number" min="0" name="pair_cooldown" value="<?= (int) $get('pair_cooldown', '3600') ?>"></div>
		<div class="acp-field"><label class="acp-label">Rating floor (points below base)</label><input class="acp-input" type="number" min="0" name="rating_floor_below_base" value="<?= (int) $get('rating_floor_below_base', '400') ?>"></div>
		<div class="acp-field"><label class="acp-label">Decay after N idle days (0 = off)</label><input class="acp-input" type="number" min="0" name="decay_days" value="<?= (int) $get('decay_days', '14') ?>"></div>
		<div class="acp-field"><label class="acp-label">Decay per day</label><input class="acp-input" type="number" min="0" name="decay_per_day" value="<?= (int) $get('decay_per_day', '10') ?>"></div>
		<div class="acp-field"><label class="acp-label">New season soft-reset (% of rating above base kept)</label><input class="acp-input" type="number" min="0" max="100" name="soft_reset_pct" value="<?= (int) $get('soft_reset_pct', '50') ?>"></div>
		<div class="acp-field"><label class="acp-label">Process interval (seconds)</label><input class="acp-input" type="number" min="15" name="process_every" value="<?= (int) $get('process_every', '60') ?>"></div>
		<div class="acp-field"><label class="acp-label">Ladder size shown</label><input class="acp-input" type="number" min="10" max="500" name="ladder_size" value="<?= (int) $get('ladder_size', '100') ?>"></div>
	</div>

	<h3>Tiers <span class="acp-muted">(leave name empty to skip a row; icon blank = auto-match a file in <code>assets/img/</code> by name)</span></h3>
	<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Name</th><th>Min rating</th><th>Colour</th><th>Icon (URL or file)</th></tr></thead><tbody>
		<?php foreach ($tiers as $i => $t):
			$prev = $t['icon'] !== '' ? pvp_ranked_icon((string) $t['icon']) : ($t['name'] !== '' ? pvp_ranked_tier_auto_icon((string) $t['name']) : '');
		?>
			<tr>
				<td><input class="acp-input" name="tier_name[<?= $i ?>]" value="<?= h($t['name']) ?>"></td>
				<td><input class="acp-input" type="number" name="tier_min[<?= $i ?>]" value="<?= (int) $t['min'] ?>"></td>
				<td><input class="acp-input" name="tier_color[<?= $i ?>]" value="<?= h($t['color']) ?>"></td>
				<td style="white-space:nowrap"><input class="acp-input" style="width:auto;display:inline-block" name="tier_icon[<?= $i ?>]" value="<?= h($t['icon']) ?>" placeholder="<?= $t['name'] !== '' ? h(strtolower(preg_replace('/[^a-z0-9]/i', '', $t['name'])) . '.png') : 'icon.png' ?>"><?php if ($prev !== ''): ?> <img src="<?= h($acpImg($prev)) ?>" alt="" style="width:22px;height:22px;object-fit:contain;vertical-align:middle"><?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
	</tbody></table></div>

	<h3>Season rewards <span class="acp-muted">(one row per rank / tier - leave a row blank to skip it; every player finishing in that tier gets it)</span></h3>
	<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Rank</th><th>Points</th><th>Premium days</th><th>Item ID</th><th>Count</th></tr></thead><tbody>
		<?php foreach (pvp_ranked_tiers() as $t): if ($t['name'] === '' || strtolower($t['name']) === 'unranked') continue; $k = pvp_ranked_tier_key($t['name']); if ($k === '') continue; ?>
			<tr><td><?php if ($t['icon'] !== ''): ?><img src="<?= h($acpImg($t['icon'])) ?>" alt="" style="width:22px;height:22px;object-fit:contain;vertical-align:middle;margin-right:6px"><?php endif; ?><b style="color:<?= h($t['color']) ?>"><?= h($t['name']) ?></b> <span class="acp-muted"><?= (int) $t['min'] ?>+</span></td>
				<td><input class="acp-input" type="number" min="0" name="sp_<?= h($k) ?>_points" value="<?= $spv($k, 'points') ?>"></td>
				<td><input class="acp-input" type="number" min="0" name="sp_<?= h($k) ?>_premium" value="<?= $spv($k, 'premium') ?>"></td>
				<td><input class="acp-input" type="number" min="0" name="sp_<?= h($k) ?>_itemid" value="<?= $spv($k, 'itemid') ?>"></td>
				<td><input class="acp-input" type="number" min="0" name="sp_<?= h($k) ?>_count" value="<?= $spv($k, 'count') ?>"></td>
			</tr>
		<?php endforeach; ?>
	</tbody></table></div>

	<h3>Reward boxes <span class="acp-muted">(shown above the ladder, horizontal scroller with arrows)</span></h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Box width (px)</label><input class="acp-input" type="number" min="90" max="280" name="prize_box_w" value="<?= (int) $get('prize_box_w', '210') ?>"></div>
		<div class="acp-field"><label class="acp-label">Content scale (%)</label><input class="acp-input" type="number" min="60" max="200" name="prize_scale" value="<?= (int) $get('prize_scale', '100') ?>"></div>
		<div class="acp-field"><label class="acp-label">Points icon (blank = bundled <code>assets/img/points.png</code>)</label><input class="acp-input" name="prize_icon_points" value="<?= h($get('prize_icon_points', '')) ?>" placeholder="points.png or https://..."></div>
		<div class="acp-field"><label class="acp-label">Premium days icon (blank = bundled <code>assets/img/vip.png</code>)</label><input class="acp-input" name="prize_icon_premium" value="<?= h($get('prize_icon_premium', '')) ?>" placeholder="vip.png or https://..."></div>
	</div>

	<h3>Colours &amp; tables <span class="acp-muted">(blank = inherit / autodetect)</span></h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent / rating', 'row_bg' => 'Odd row', 'you_bg' => 'Your row', 'head_bg' => 'Header background', 'head_text' => 'Header text') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>"></div>
		<?php endforeach; ?>
		<?php foreach (array('players_table' => 'players table', 'players_name_col' => 'players: name', 'players_acc_col' => 'players: account_id', 'deaths_table' => 'player_deaths table', 'deaths_id_col' => 'deaths: id', 'deaths_time_col' => 'deaths: time', 'deaths_killedby_col' => 'deaths: killer name', 'deaths_player_col' => 'deaths: victim id', 'deaths_isplayer_col' => 'deaths: is_player', 'deaths_unjust_col' => 'deaths: unjustified') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="<?= h($k) ?>" value="<?= h($get($k)) ?>" placeholder="auto"></div>
		<?php endforeach; ?>
	</div>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<div class="acp-actions">
	<form class="acp-inline-form" method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="process"><button class="acp-btn" type="submit"><i class="fa fa-refresh"></i> Process kills now</button></form>
	<form class="acp-inline-form" method="post" data-confirm="Close the current season, pay rewards and soft-reset every rating?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="new_season"><button class="acp-btn acp-btn--red" type="submit"><i class="fa fa-flag"></i> Start new season</button></form>
	<span class="acp-muted">Current: season <?= (int) pvp_ranked_season() ?>, last processed death id <?= (int) pvp_ranked_int('last_death_id', 0) ?></span>
</div>
<?php acp_card_close(); ?>
