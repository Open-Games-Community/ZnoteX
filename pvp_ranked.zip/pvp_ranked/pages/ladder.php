<?php
/**
 * Public page: page.php?plugin=pvp_ranked&p=ladder
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'pvp_ranked_h';
$accountId = !empty($GLOBALS['session_user_id']) ? (int) $GLOBALS['session_user_id']
	: ((function_exists('user_logged_in') && user_logged_in() === true) ? (int) getSession('user_id') : 0);
$youName = '';
if ($accountId > 0 && function_exists('user_character_list')) {
	foreach ((array) user_character_list($accountId) as $c) { $youName = (string) ($c['name'] ?? ''); break; }
}

$data = pvp_ranked_enabled() ? pvp_ranked_view($youName) : array('season' => 1, 'ladder' => array(), 'tiers' => array());
$showHist = isset($_GET['history']);
$hist = $showHist ? pvp_ranked_history(120) : array();

$prBoxW  = max(90, min(280, (int) pvp_ranked_setting('prize_box_w', '210')));
$prScale = max(60, min(200, (int) pvp_ranked_setting('prize_scale', '100')));
$prIconPts  = pvp_ranked_prize_icon('points');
$prIconPrem = pvp_ranked_prize_icon('premium');
$prPrizes = $showHist ? array() : pvp_ranked_prize_cells();
?>
<style>
.pr-wrap{--prp-scale:<?= number_format($prScale / 100, 2, '.', '') ?>;--prp-w:<?= (int) $prBoxW ?>px}
</style>
<style>
.pr-wrap{--pr-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--pr-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--pr-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--pr-accent:var(--accent,var(--link,#f4c542));--pr-row:rgba(255,255,255,.03);--pr-you:rgba(244,197,66,.14);--pr-head-bg:var(--pr-accent);--pr-head-text:#151515;color:var(--pr-text)}
.pr-wrap *{box-sizing:border-box}
.pr-wrap h1{font-size:26px;margin:0 0 4px}
.pr-sub{opacity:.8;margin:0 0 16px;display:flex;gap:14px;flex-wrap:wrap;align-items:center}
.pr-sub a{color:var(--pr-accent);text-decoration:none}
.pr-rankbox{border:1px solid var(--pr-border);border-radius:12px;background:var(--pr-surface);overflow:hidden;margin:0 0 18px}
.pr-rankbox__h{background:var(--pr-head-bg);color:var(--pr-head-text);font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:9px 14px}
.pr-rankbox__wrap{position:relative;padding:12px}
.pr-rankbox__scroll{display:flex;gap:10px;overflow-x:auto;scroll-behavior:smooth;scrollbar-width:thin;padding:2px}
.pr-rankbox__scroll::-webkit-scrollbar{height:8px}
.pr-rankbox__scroll::-webkit-scrollbar-thumb{background:var(--pr-border);border-radius:8px}
.pr-rankcard{flex:0 0 var(--prp-w,210px);display:flex;gap:calc(11px * var(--prp-scale));align-items:flex-start;padding:calc(12px * var(--prp-scale)) calc(13px * var(--prp-scale));border:1px solid color-mix(in srgb,var(--pr-tier) 45%,var(--pr-border));border-radius:12px;background:color-mix(in srgb,var(--pr-tier) 10%,var(--pr-row))}
.pr-rankcard__ic{width:calc(56px * var(--prp-scale));height:calc(56px * var(--prp-scale));object-fit:contain;flex:0 0 auto}
.pr-rankcard__body{min-width:0;display:flex;flex-direction:column;gap:calc(3px * var(--prp-scale));font-size:calc(12px * var(--prp-scale))}
.pr-rankcard__name{display:flex;flex-direction:column;line-height:1.15;margin-bottom:calc(3px * var(--prp-scale))}
.pr-rankcard__name b{color:var(--pr-tier);font-size:calc(14.5px * var(--prp-scale));font-weight:800}
.pr-rankcard__name span{font-size:calc(10.5px * var(--prp-scale));opacity:.55;font-variant-numeric:tabular-nums}
.pr-rankcard__line{display:flex;align-items:center;gap:5px;color:var(--pr-accent);font-weight:700;line-height:1.25;white-space:nowrap}
.pr-rankcard__line img{width:calc(15px * var(--prp-scale));height:calc(15px * var(--prp-scale));object-fit:contain}
.pr-rankcard__item{position:relative;display:inline-block}
.pr-rankcard__item img{width:calc(30px * var(--prp-scale));height:calc(30px * var(--prp-scale));object-fit:contain;image-rendering:pixelated}
.pr-rankcard__item em{position:absolute;right:-6px;bottom:-4px;font-style:normal;font-weight:800;font-size:10px;background:var(--pr-surface);border:1px solid var(--pr-border);border-radius:4px;padding:0 3px}
.pr-rankcard__none{opacity:.45;font-size:calc(11px * var(--prp-scale))}
.pr-rankcard.no-reward{opacity:.72}
.pr-tiercell{display:inline-flex;align-items:center;gap:8px;font-weight:800;color:var(--pr-tier);font-size:13px;white-space:nowrap}
.pr-tiercell img{width:24px;height:24px;object-fit:contain}
.pr-tiercell--sm{font-size:12px;font-weight:700;opacity:.9}
.pr-tiercell--sm img{width:18px;height:18px}
.pr-tablewrap{overflow-x:auto}
.pr-table .pr-c{text-align:center;font-variant-numeric:tabular-nums}
.pr-table th.pr-c{text-align:center}
.pr-frags{font-weight:800}
.pr-frags--old{font-weight:600;opacity:.65}
.pr-dash{opacity:.4}
.pr-card{border:1px solid var(--pr-border);border-radius:12px;background:var(--pr-surface);overflow:hidden}
.pr-table{width:100%;border-collapse:collapse;font-size:14px}
.pr-table th{background:var(--pr-head-bg);color:var(--pr-head-text);text-align:left;padding:9px 12px;font-size:11px;text-transform:uppercase;letter-spacing:.05em}
.pr-table td{padding:8px 12px;border-top:1px solid var(--pr-border)}
.pr-table tr:nth-child(odd) td{background:var(--pr-row)}
.pr-table tr.is-you td{background:var(--pr-you);font-weight:700}
.pr-rank{width:44px;text-align:center;font-weight:800;font-variant-numeric:tabular-nums}
.pr-rating{font-weight:800;color:var(--pr-accent);font-variant-numeric:tabular-nums}
.pr-wl{font-variant-numeric:tabular-nums;opacity:.85;white-space:nowrap}
.pr-streak{font-size:12px;opacity:.7}
.pr-name a{color:inherit;text-decoration:none}.pr-name a:hover{color:var(--pr-accent)}
.pr-empty{opacity:.6;padding:16px}
.pr-wrap{--prp-scale:1;--prp-w:210px}
.pr-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:2;width:32px;height:32px;border-radius:50%;border:1px solid var(--pr-border);background:var(--pr-surface);color:var(--pr-text);font:700 16px/1 system-ui,Arial;cursor:pointer;display:none;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,.25)}
.pr-rankbox.has-of .pr-arrow{display:flex}
.pr-arrow--l{left:2px}.pr-arrow--r{right:2px}
.pr-arrow[disabled]{opacity:.25;cursor:default}
</style>

<div class="pr-wrap" <?= pvp_ranked_style_attr() ?>>
	<h1><?= $h(pvp_ranked_t('pvp_ranked.title', 'PvP Ranked')) ?></h1>
	<div class="pr-sub">
		<span><?= $h(pvp_ranked_t('pvp_ranked.season', 'Season {n}', array('n' => $data['season']))) ?></span>
		<?php if ($showHist): ?>
			<a href="<?= $h(znote_plugin_url('pvp_ranked', 'ladder')) ?>">&larr; <?= $h(pvp_ranked_t('pvp_ranked.current', 'Current ladder')) ?></a>
		<?php else: ?>
			<a href="?plugin=pvp_ranked&p=ladder&history=1"><?= $h(pvp_ranked_t('pvp_ranked.past_seasons', 'Past seasons')) ?> &rarr;</a>
		<?php endif; ?>
	</div>

	<?php if (!$showHist && $prPrizes): ?>
		<div class="pr-rankbox" id="prRewards">
			<div class="pr-rankbox__h"><?= $h(pvp_ranked_t('pvp_ranked.tiers', 'Ranks')) ?></div>
			<div class="pr-rankbox__wrap">
				<button type="button" class="pr-arrow pr-arrow--l" aria-label="scroll left">&#8249;</button>
				<div class="pr-rankbox__scroll">
				<?php foreach ($prPrizes as $pz): $rw = !empty($pz['has_reward']); ?>
					<div class="pr-rankcard<?= $rw ? '' : ' no-reward' ?>" style="--pr-tier:<?= $h($pz['color']) ?>">
						<?php if ($pz['icon'] !== ''): ?><img class="pr-rankcard__ic" src="<?= $h($pz['icon']) ?>" alt=""><?php endif; ?>
						<div class="pr-rankcard__body">
							<span class="pr-rankcard__name"><b><?= $h($pz['label']) ?></b><span><?= (int) $pz['min'] ?>+</span></span>
							<?php if ($pz['points'] > 0): ?><span class="pr-rankcard__line"><?php if ($prIconPts !== ''): ?><img src="<?= $h($prIconPts) ?>" alt=""><?php endif; ?><?= $h(pvp_ranked_t('pvp_ranked.pts', '{n} points', array('n' => $pz['points']))) ?></span><?php endif; ?>
							<?php if ($pz['premium'] > 0): ?><span class="pr-rankcard__line"><?php if ($prIconPrem !== ''): ?><img src="<?= $h($prIconPrem) ?>" alt=""><?php endif; ?><?= $h(pvp_ranked_t('pvp_ranked.premd', '{n} premium days', array('n' => $pz['premium']))) ?></span><?php endif; ?>
							<?php if ($pz['item_image'] !== ''): ?><span class="pr-rankcard__line"><span class="pr-rankcard__item"><img src="<?= $h($pz['item_image']) ?>" alt=""><?php if ($pz['count'] > 1): ?><em><?= (int) $pz['count'] ?>&times;</em><?php endif; ?></span></span><?php endif; ?>
							<?php if (!$rw): ?><span class="pr-rankcard__none"><?= $h(pvp_ranked_t('pvp_ranked.no_reward', 'No reward')) ?></span><?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
				</div>
				<button type="button" class="pr-arrow pr-arrow--r" aria-label="scroll right">&#8250;</button>
			</div>
		</div>
		<script>(function(){var w=document.getElementById("prRewards");if(!w)return;var s=w.querySelector(".pr-rankbox__scroll"),l=w.querySelector(".pr-arrow--l"),r=w.querySelector(".pr-arrow--r");
		function upd(){var of=s.scrollWidth-s.clientWidth-1;w.classList.toggle("has-of",of>0);l.disabled=s.scrollLeft<=0;r.disabled=s.scrollLeft>=of;}
		function step(d){s.scrollBy({left:d*Math.max(180,s.clientWidth*0.8),behavior:"smooth"});}
		l.addEventListener("click",function(){step(-1);});r.addEventListener("click",function(){step(1);});
		s.addEventListener("scroll",upd);window.addEventListener("resize",upd);upd();}());</script>
	<?php endif; ?>

	<?php if ($showHist): ?>
		<?php if (!$hist): ?><p class="pr-empty"><?= $h(pvp_ranked_t('pvp_ranked.no_history', 'No finished seasons yet.')) ?></p>
		<?php else: ?>
			<div class="pr-card"><table class="pr-table"><tbody>
			<?php $cs = null; foreach ($hist as $r): ?>
				<?php if ($cs !== (int) $r['season']): $cs = (int) $r['season']; ?>
					<tr><td colspan="4" style="background:var(--pr-head-bg);color:var(--pr-head-text);font-weight:800"><?= $h(pvp_ranked_t('pvp_ranked.season', 'Season {n}', array('n' => $cs))) ?></td></tr>
				<?php endif; ?>
				<tr>
					<td class="pr-rank"><?= (int) $r['rank'] ?></td>
					<td class="pr-name"><a href="characterprofile.php?name=<?= $h(urlencode($r['character_name'])) ?>"><?= $h($r['character_name']) ?></a><?= $r['reward'] !== '' ? ' <span style="opacity:.6;font-size:12px">(' . $h($r['reward']) . ')</span>' : '' ?></td>
					<td class="pr-rating"><?= (int) $r['rating'] ?></td>
					<td class="pr-wl"><?= (int) $r['wins'] ?>W&nbsp;<?= (int) $r['losses'] ?>L</td>
				</tr>
			<?php endforeach; ?>
			</tbody></table></div>
		<?php endif; ?>
	<?php elseif (!$data['ladder']): ?>
		<p class="pr-empty"><?= $h(pvp_ranked_t('pvp_ranked.empty', 'No ranked kills yet this season.')) ?></p>
	<?php else: ?>
		<?php $prPast = !empty($data['has_past']); ?>
		<div class="pr-card pr-tablewrap"><table class="pr-table">
			<thead><tr>
				<th>#</th>
				<th><?= $h(pvp_ranked_t('pvp_ranked.rank_col', 'Rank')) ?></th>
				<th><?= $h(pvp_ranked_t('pvp_ranked.character', 'Character')) ?></th>
				<th class="pr-c"><?= $h(pvp_ranked_t('pvp_ranked.rating', 'Rating')) ?></th>
				<th class="pr-c"><?= $h(pvp_ranked_t('pvp_ranked.frags', 'Frags')) ?></th>
				<?php if ($prPast): ?><th class="pr-c"><?= $h(pvp_ranked_t('pvp_ranked.last_frags', 'Last season')) ?></th><?php endif; ?>
				<th><?= $h(pvp_ranked_t('pvp_ranked.peak', 'Peak')) ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ($data['ladder'] as $r): ?>
				<tr class="<?= $r['you'] ? 'is-you' : '' ?>">
					<td class="pr-rank"><?= (int) $r['rank'] ?></td>
					<td><span class="pr-tiercell" style="--pr-tier:<?= $h($r['tier_color']) ?>"><?php if ($r['tier_icon'] !== ''): ?><img src="<?= $h($r['tier_icon']) ?>" alt=""><?php endif; ?><?= $h($r['tier']) ?></span></td>
					<td class="pr-name"><a href="characterprofile.php?name=<?= $h(urlencode($r['name'])) ?>"><?= $h($r['name']) ?></a>
						<?php if ($r['streak'] >= 3): ?><span class="pr-streak">🔥<?= (int) $r['streak'] ?></span><?php elseif ($r['streak'] <= -3): ?><span class="pr-streak">❄<?= abs((int) $r['streak']) ?></span><?php endif; ?>
					</td>
					<td class="pr-rating pr-c"><?= (int) $r['rating'] ?></td>
					<td class="pr-c pr-frags"><?= (int) $r['wins'] ?></td>
					<?php if ($prPast): ?><td class="pr-c pr-frags pr-frags--old"><?= $r['last_wins'] === null ? '<span class="pr-dash">&mdash;</span>' : (int) $r['last_wins'] ?></td><?php endif; ?>
					<td><span class="pr-tiercell pr-tiercell--sm" style="--pr-tier:<?= $h($r['peak_tier_color']) ?>" title="<?= (int) $r['peak_rating'] ?>"><?php if ($r['peak_tier_icon'] !== ''): ?><img src="<?= $h($r['peak_tier_icon']) ?>" alt=""><?php endif; ?><?= $h($r['peak_tier']) ?></span></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php endif; ?>
</div>
