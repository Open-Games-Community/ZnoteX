-- Storage-backed custom stats for the Armory: an admin names a player_storage
-- key and how to format its value, and the Armory shows it live for whatever
-- character is loaded, whenever the value is greater than 0. Not tied to any
-- item - the value lives on the player (set by a Lua script), so this is the
-- only way to represent a per-character bonus like a rarity roll.
CREATE TABLE IF NOT EXISTS `znote_build_sim_storage_stats` (
	`id` int NOT NULL AUTO_INCREMENT,
	`storage_key` int NOT NULL,
	`label` varchar(100) NOT NULL,
	`format` varchar(20) NOT NULL DEFAULT 'value',
	`active` tinyint NOT NULL DEFAULT 1,
	`sort_order` int NOT NULL DEFAULT 0,
	`created_at` int NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`),
	KEY `storage_key` (`storage_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Paperdoll slots. Seeded with the classic 9-slot scheme (slotType/weaponType
-- values TFS and Canary/OTServBR-Global both use), but every value here is
-- just data an admin can edit - some engines/configs use a different
-- vocabulary (e.g. "right-hand"/"two-handed" instead of listing weapon
-- classes), and some servers add extra slots (a second ring, etc). Nothing in
-- the plugin's PHP hardcodes these past the first install.
CREATE TABLE IF NOT EXISTS `znote_build_sim_slots` (
	`id` int NOT NULL AUTO_INCREMENT,
	`slot_key` varchar(32) NOT NULL,
	`label` varchar(50) NOT NULL,
	`match_values` varchar(255) NOT NULL DEFAULT '',
	`icon` varchar(255) NOT NULL DEFAULT '',
	`active` tinyint NOT NULL DEFAULT 1,
	`sort_order` int NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`),
	UNIQUE KEY `slot_key` (`slot_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `znote_build_sim_slots` (`slot_key`, `label`, `match_values`, `sort_order`) VALUES
	('head', 'Head', 'head', 10),
	('necklace', 'Necklace', 'necklace', 20),
	('armor', 'Armor', 'body', 30),
	('shield', 'Shield', 'shield', 40),
	('weapon', 'Weapon', 'sword,axe,club,distance,wand', 50),
	('legs', 'Legs', 'legs', 60),
	('feet', 'Boots', 'feet', 70),
	('ring', 'Ring', 'ring', 80),
	('ammo', 'Ammo', 'ammunition', 90);
