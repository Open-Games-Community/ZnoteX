<?php
/**
 * Public page: page.php?plugin=build_simulator&p=armory
 *
 * The Simulator, but starting from a real character's current gear instead
 * of an empty paperdoll: search a name, every slot pre-fills with what that
 * character actually has equipped, then - exactly like the Simulator - swap
 * any slot for something else and watch the combined stats change live. A
 * "what if I had this instead" tool, not just a read-only profile.
 *
 * Below the item-derived stats, a separate block shows storage-backed stats:
 * admin-configured player_storage keys (Admin Panel > Installed Plugins >
 * Build Simulator Storage Stats) read live from THIS character, whenever the
 * value is greater than 0. These aren't tied to any item - they're whatever
 * a Lua script set on the player (a rarity roll, a quest bonus, etc), so they
 * only ever show up here, never in the Simulator's empty paperdoll.
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

if (!build_simulator_enabled()) {
	echo '<p>' . build_simulator_h(t_default('bsim.disabled', 'This feature is currently disabled.')) . '</p>';
	return;
}

$bsimSlots = build_simulator_slots();
$bsimItemsBySlot = build_simulator_items_by_slot();

$bsimPayload = array();
foreach ($bsimItemsBySlot as $slotKey => $items) {
	$bsimPayload[$slotKey] = array();
	foreach ($items as $item) {
		$bsimPayload[$slotKey][] = array(
			'id'      => $item['id'],
			'name'    => $item['name'],
			'image'   => $item['image'],
			'stats'   => build_simulator_item_stats($item),
		);
	}
}

$bsimHasItems = false;
foreach ($bsimItemsBySlot as $items) {
	if ($items) { $bsimHasItems = true; break; }
}

// --- Load a character's current gear, if one was searched for ------------
$armoryName = trim((string) ($_GET['name'] ?? ''));
$armoryChar = $armoryName !== '' ? build_simulator_character_equipment($armoryName) : null;
$armoryNotFound = ($armoryName !== '' && $armoryChar === null);

$armoryStorageStats = array();
if ($armoryChar) {
	$armoryStorageStats = build_simulator_character_storage_stats((int) $armoryChar['player']['id']);
}

// Which slot each equipped item pre-selects: the same weaponType/slotType
// matching rule items_by_slot() uses, not by pid - a custom slot (a second
// ring, say) has no pid of its own to match against.
$armoryPreselect = array();
if ($armoryChar) {
	foreach ($armoryChar['gear'] as $item) {
		$attributes = (array) $item['attributes'];
		foreach ($bsimSlots as $slotKey => $slot) {
			if (build_simulator_item_matches_slot($attributes, $slot['values']) && !isset($armoryPreselect[$slotKey])) {
				$armoryPreselect[$slotKey] = $item['id'];
			}
		}
	}
}

// The classic Tibia equipment-window cross: head above, necklace/ring either
// side of the weapon/armor/shield row, legs/boots below - laid out via CSS
// grid-area so admin-added slots outside these 9 keys don't need a position
// (they render in their own row underneath instead).
$bsimCrossOrder = array('head', 'necklace', 'weapon', 'armor', 'shield', 'ring', 'ammo', 'legs', 'feet');
$bsimDollCross = array();
$bsimDollExtra = array();
foreach ($bsimSlots as $slotKey => $slot) {
	if (in_array($slotKey, $bsimCrossOrder, true)) {
		$bsimDollCross[$slotKey] = $slot;
	} else {
		$bsimDollExtra[$slotKey] = $slot;
	}
}

$loadOutfits = !empty($config['show_outfits']['imageServer']);

// Your own account's characters, for a quick-pick list instead of typing a name.
$armoryOwnChars = array();
$armoryAccountId = !empty($GLOBALS['session_user_id']) ? (int) $GLOBALS['session_user_id']
	: ((function_exists('user_logged_in') && user_logged_in() === true) ? (int) getSession('user_id') : 0);
if ($armoryAccountId > 0 && function_exists('user_character_list')) {
	$armoryOwnChars = (array) user_character_list($armoryAccountId);
}
?>
<style>
.bsim-wrap{--bsim-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--bsim-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bsim-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--bsim-accent:var(--accent,var(--link,#f4c542));color:var(--bsim-text)}
<?= build_simulator_color_style() ?>
.bsim-wrap *{box-sizing:border-box}
.bsim-wrap h1{font-size:26px;margin:0 0 4px}
.bsim-lead{opacity:.8;margin:0 0 20px}
.bsim-search{display:flex;gap:8px;margin-bottom:12px;max-width:420px;flex-wrap:wrap}
.bsim-search input[type="text"]{flex:1;min-width:160px;padding:8px 10px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-surface);color:var(--bsim-text)}
.bsim-search select{padding:8px 10px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-surface);color:var(--bsim-text)}
.bsim-search button{padding:8px 16px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-accent);color:#151515;font-weight:700;cursor:pointer}
.bsim-armory-head{display:flex;gap:14px;align-items:center;margin-bottom:18px}
.bsim-armory-head img{image-rendering:pixelated}
.bsim-armory-head h2{margin:0;font-size:19px}
.bsim-armory-head p{margin:2px 0 0;opacity:.75;font-size:13px}
.bsim-doll{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;margin-bottom:22px}
.bsim-doll-cross{
	display:grid;gap:10px;margin:0 auto 22px;max-width:420px;
	grid-template-columns:repeat(3,minmax(110px,1fr));
	grid-template-areas:
		"necklace head     ring"
		"shield   armor    weapon"
		".        legs     ammo"
		".        feet     .";
}
.bsim-doll-cross .bsim-slot[data-slot-key="head"]     { grid-area:head; }
.bsim-doll-cross .bsim-slot[data-slot-key="necklace"] { grid-area:necklace; }
.bsim-doll-cross .bsim-slot[data-slot-key="weapon"]   { grid-area:weapon; }
.bsim-doll-cross .bsim-slot[data-slot-key="armor"]    { grid-area:armor; }
.bsim-doll-cross .bsim-slot[data-slot-key="shield"]   { grid-area:shield; }
.bsim-doll-cross .bsim-slot[data-slot-key="ring"]     { grid-area:ring; }
.bsim-doll-cross .bsim-slot[data-slot-key="ammo"]     { grid-area:ammo; }
.bsim-doll-cross .bsim-slot[data-slot-key="legs"]     { grid-area:legs; }
.bsim-doll-cross .bsim-slot[data-slot-key="feet"]     { grid-area:feet; }
.bsim-slot{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);padding:10px;text-align:center}
.bsim-slot-icon{width:48px;height:48px;margin:0 auto 8px;border:1px dashed var(--bsim-border);border-radius:8px;display:flex;align-items:center;justify-content:center;opacity:.6}
.bsim-slot-icon img{max-width:40px;max-height:40px}
.bsim-slot-label{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.05em;opacity:.7;margin-bottom:6px}
.bsim-select{width:100%;font-size:12.5px;padding:5px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-surface);color:var(--bsim-text)}
.bsim-stats{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);padding:16px}
.bsim-stats h2{margin:0 0 10px;font-size:17px}
.bsim-stats h3{margin:16px 0 8px;font-size:13px;opacity:.8}
.bsim-stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px}
.bsim-stat{display:flex;justify-content:space-between;gap:8px;padding:6px 10px;border:1px solid var(--bsim-border);border-radius:6px;font-size:13px}
.bsim-stat-val{color:var(--bsim-accent);font-weight:700;font-variant-numeric:tabular-nums}
.bsim-empty{opacity:.6;margin:0}
</style>

<div class="bsim-wrap">
	<h1><?= build_simulator_h(t_default('bsim.armory_title', 'Armory')) ?></h1>
	<p class="bsim-lead"><?= build_simulator_h(t_default('bsim.armory_lead', 'Load a character\'s current gear, then swap any slot to test a different item and see the stats change live.')) ?></p>

	<form class="bsim-search" method="get">
		<input type="hidden" name="plugin" value="build_simulator">
		<input type="hidden" name="p" value="armory">
		<?php if ($armoryOwnChars): ?>
			<select onchange="if(this.value){document.getElementById('bsimArmoryNameInput').value=this.value;this.form.submit();}">
				<option value=""><?= build_simulator_h(t_default('bsim.armory_pick_yours', '-- one of your characters --')) ?></option>
				<?php foreach ($armoryOwnChars as $c): ?>
					<option value="<?= build_simulator_h((string) ($c['name'] ?? '')) ?>" <?= (($c['name'] ?? '') === $armoryName) ? 'selected' : '' ?>><?= build_simulator_h((string) ($c['name'] ?? '')) ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
		<input type="text" id="bsimArmoryNameInput" name="name" value="<?= build_simulator_h($armoryName) ?>" placeholder="<?= build_simulator_h(t_default('bsim.armory_placeholder', 'Character name')) ?>">
		<button type="submit"><?= build_simulator_h(t_default('bsim.armory_search', 'Load')) ?></button>
	</form>

	<?php if ($armoryNotFound): ?>
		<p class="bsim-empty"><?= build_simulator_h(t_default('bsim.armory_not_found', 'No character with that name.')) ?></p>
	<?php elseif ($armoryChar): ?>
		<?php $p = $armoryChar['player']; ?>
		<div class="bsim-armory-head">
			<?php if ($loadOutfits): ?>
				<img src="<?= build_simulator_h($config['show_outfits']['imageServer']) ?>?id=<?= (int) $p['looktype'] ?>&addons=<?= (int) $p['lookaddons'] ?>&head=<?= (int) $p['lookhead'] ?>&body=<?= (int) $p['lookbody'] ?>&legs=<?= (int) $p['looklegs'] ?>&feet=<?= (int) $p['lookfeet'] ?><?= !empty($p['lookmount']) ? '&mount=' . (int) $p['lookmount'] : '' ?>" alt="<?= build_simulator_h($p['name']) ?>">
			<?php endif; ?>
			<div>
				<h2><?= build_simulator_h($p['name']) ?></h2>
				<p><?= build_simulator_h(t_default('bsim.armory_level_voc', 'Level {level} {vocation}', [
					'level' => (int) $p['level'],
					'vocation' => function_exists('vocation_id_to_name') ? vocation_id_to_name((int) $p['vocation']) : (string) $p['vocation'],
				])) ?></p>
			</div>
		</div>
	<?php endif; ?>

	<?php if (!$bsimHasItems): ?>
		<p><?= build_simulator_h(t_default('bsim.no_items', 'No equipable items are loaded yet - upload items.xml under Admin Panel > Server Info.')) ?></p>
	<?php else: ?>
		<?php
		$bsimSlotCard = function (string $slotKey, array $slot) use ($bsimItemsBySlot, $armoryPreselect): void {
			?>
			<div class="bsim-slot" data-slot-key="<?= build_simulator_h($slotKey) ?>">
					<div class="bsim-slot-icon" id="bsimIcon_<?= build_simulator_h($slotKey) ?>">
						<?php if (!empty($slot['icon'])): ?>
							<img src="<?= build_simulator_h($slot['icon']) ?>" alt="">
						<?php else: ?>
							<i class="fa fa-plus"></i>
						<?php endif; ?>
					</div>
					<label class="bsim-slot-label" for="bsimSelect_<?= build_simulator_h($slotKey) ?>"><?= build_simulator_h(t_default('bsim.slot_' . $slotKey, $slot['label'])) ?></label>
					<select class="bsim-select" id="bsimSelect_<?= build_simulator_h($slotKey) ?>" data-bsim-slot="<?= build_simulator_h($slotKey) ?>">
						<option value="0"><?= build_simulator_h(t_default('bsim.none', '-- none --')) ?></option>
						<?php foreach (($bsimItemsBySlot[$slotKey] ?? array()) as $item): ?>
							<option value="<?= (int) $item['id'] ?>" <?= (($armoryPreselect[$slotKey] ?? null) === $item['id']) ? 'selected' : '' ?>><?= build_simulator_h($item['name']) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<?php
		};
		?>
		<?php if ($bsimDollCross): ?>
			<div class="bsim-doll-cross">
				<?php foreach ($bsimDollCross as $slotKey => $slot): $bsimSlotCard($slotKey, $slot); endforeach; ?>
			</div>
		<?php endif; ?>
		<?php if ($bsimDollExtra): ?>
			<div class="bsim-doll">
				<?php foreach ($bsimDollExtra as $slotKey => $slot): $bsimSlotCard($slotKey, $slot); endforeach; ?>
			</div>
		<?php endif; ?>

		<div class="bsim-stats">
			<h2><?= build_simulator_h(t_default('bsim.stats_title', 'Combined stats')) ?></h2>
			<div id="bsimStatsBody" class="bsim-stats-grid">
				<p class="bsim-empty"><?= build_simulator_h(t_default('bsim.stats_empty', 'Pick some items to see combined stats.')) ?></p>
			</div>

			<?php if ($armoryStorageStats): ?>
				<h3><?= build_simulator_h(t_default('bsim.storage_stats_title', 'Custom stats')) ?></h3>
				<div class="bsim-stats-grid">
					<?php foreach ($armoryStorageStats as $stat): ?>
						<div class="bsim-stat">
							<span><?= build_simulator_h($stat['label']) ?></span>
							<span class="bsim-stat-val"><?= build_simulator_h($stat['value']) ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<script>
		(function () {
			var DATA = <?= json_encode($bsimPayload, JSON_UNESCAPED_UNICODE) ?>;
			var slots = Object.keys(DATA);
			var selected = {};

			function esc(s) {
				var d = document.createElement('div');
				d.textContent = String(s == null ? '' : s);
				return d.innerHTML;
			}

			function itemById(slotKey, id) {
				id = parseInt(id, 10);
				var list = DATA[slotKey] || [];
				for (var i = 0; i < list.length; i++) {
					if (list[i].id === id) return list[i];
				}
				return null;
			}

			var emptyIconHtml = {};
			slots.forEach(function (slotKey) {
				var el = document.getElementById('bsimIcon_' + slotKey);
				if (el) emptyIconHtml[slotKey] = el.innerHTML;
			});

			function recalc() {
				var totals = {};

				slots.forEach(function (slotKey) {
					var item = selected[slotKey];
					var iconEl = document.getElementById('bsimIcon_' + slotKey);
					if (!item) {
						if (iconEl) iconEl.innerHTML = emptyIconHtml[slotKey] || '<i class="fa fa-plus"></i>';
						return;
					}
					if (iconEl) iconEl.innerHTML = '<img src="' + esc(item.image) + '" alt="' + esc(item.name) + '" title="' + esc(item.name) + '">';

					Object.keys(item.stats || {}).forEach(function (label) {
						var s = item.stats[label];
						if (!totals[label]) totals[label] = { value: 0, suffix: s.suffix };
						totals[label].value += Number(s.value) || 0;
					});
				});

				var statsBody = document.getElementById('bsimStatsBody');
				var labels = Object.keys(totals).sort();
				if (!labels.length) {
					statsBody.innerHTML = '<p class="bsim-empty"><?= build_simulator_h(t_default('bsim.stats_empty', 'Pick some items to see combined stats.')) ?></p>';
				} else {
					statsBody.innerHTML = labels.map(function (label) {
						var t = totals[label];
						var val = Math.round(t.value * 100) / 100;
						var sign = val > 0 ? '+' : '';
						return '<div class="bsim-stat"><span>' + esc(label) + '</span><span class="bsim-stat-val">' + sign + val + esc(t.suffix) + '</span></div>';
					}).join('');
				}
			}

			// Pre-select whatever the server already marked as `selected` in each
			// <option> (the character's currently equipped items), then run one
			// recalc so the stats panel matches the paperdoll from the start.
			slots.forEach(function (slotKey) {
				var sel = document.getElementById('bsimSelect_' + slotKey);
				if (!sel) return;
				if (sel.value !== '0') {
					selected[slotKey] = itemById(slotKey, sel.value);
				}
				sel.addEventListener('change', function () {
					selected[slotKey] = sel.value !== '0' ? itemById(slotKey, sel.value) : null;
					recalc();
				});
			});

			recalc();
		})();
		</script>
	<?php endif; ?>
</div>
