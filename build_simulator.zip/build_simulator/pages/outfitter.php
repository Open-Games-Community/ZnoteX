<?php
/**
 * Public page: page.php?plugin=build_simulator&p=outfitter
 *
 * A live outfit/mount color previewer, in the spirit of RubinOT's wiki
 * outfitter. There is no local outfit renderer - this leans entirely on the
 * same outfit image service every other outfit preview in ZnoteX already
 * uses ($config['show_outfits']['imageServer']), so the preview is a real
 * rendered sprite, not an approximation. Moving a slider just rebuilds the
 * image URL client-side; the color IS the preview, nothing to fake.
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

if (!build_simulator_enabled()) {
	echo '<p>' . build_simulator_h(t_default('bsim.disabled', 'This feature is currently disabled.')) . '</p>';
	return;
}

$outfitterServer = (string) ($config['show_outfits']['imageServer'] ?? '');
if ($outfitterServer === '') {
	echo '<p>' . build_simulator_h(t_default('bsim.outfitter_no_service', 'Outfit images are not configured on this server.')) . '</p>';
	return;
}

$bsimOutfitsList = build_simulator_outfits_list();
$bsimMountsList = build_simulator_mounts_list();
?>
<style>
.bsim-wrap{--bsim-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--bsim-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bsim-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--bsim-accent:var(--accent,var(--link,#f4c542));color:var(--bsim-text)}
<?= build_simulator_color_style() ?>
.bsim-wrap *{box-sizing:border-box}
.bsim-wrap h1{font-size:26px;margin:0 0 4px}
.bsim-lead{opacity:.8;margin:0 0 20px}
.bsim-outfitter{display:grid;grid-template-columns:220px 1fr;gap:20px}
@media(max-width:600px){.bsim-outfitter{grid-template-columns:1fr}}
.bsim-preview{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;min-height:220px;overflow:hidden}
.bsim-preview img{image-rendering:pixelated;min-height:64px;transition:transform .08s linear}
.bsim-controls{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);padding:16px}
.bsim-row{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.bsim-row label{flex:0 0 100px;font-size:12.5px;opacity:.85}
.bsim-row input[type="number"]{width:70px;padding:5px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-surface);color:var(--bsim-text)}
.bsim-row input[type="range"]{flex:1}
.bsim-row .bsim-range-val{width:34px;text-align:right;font-variant-numeric:tabular-nums;font-size:12px;opacity:.8}
.bsim-row input[type="checkbox"]{width:16px;height:16px}
.bsim-section-title{font-size:11px;text-transform:uppercase;letter-spacing:.05em;opacity:.6;margin:14px 0 8px}
.bsim-section-title:first-child{margin-top:0}
</style>

<div class="bsim-wrap">
	<h1><?= build_simulator_h(t_default('bsim.outfitter_title', 'Outfitter')) ?></h1>
	<p class="bsim-lead"><?= build_simulator_h(t_default('bsim.outfitter_lead', 'Preview any outfit or mount with any colors and addons before you commit to it in game.')) ?></p>

	<div class="bsim-outfitter">
		<div class="bsim-preview">
			<img id="bsimOutfitImg" src="" alt="">
		</div>

		<div class="bsim-controls">
			<div class="bsim-section-title"><?= build_simulator_h(t_default('bsim.outfitter_outfit', 'Outfit')) ?></div>
			<div class="bsim-row">
				<label for="bsimOfId"><?= build_simulator_h(t_default('bsim.outfitter_id', 'Outfit ID')) ?></label>
				<?php if ($bsimOutfitsList): ?>
					<select id="bsimOfId" class="bsim-select">
						<?php foreach ($bsimOutfitsList as $o): ?>
							<option value="<?= (int) $o['id'] ?>" <?= (int) $o['id'] === 128 ? 'selected' : '' ?>><?= build_simulator_h($o['name']) ?> (<?= (int) $o['id'] ?>)</option>
						<?php endforeach; ?>
					</select>
				<?php else: ?>
					<input type="number" id="bsimOfId" min="0" value="128">
				<?php endif; ?>
			</div>
			<div class="bsim-row">
				<label for="bsimOfAddons"><?= build_simulator_h(t_default('bsim.outfitter_addons', 'Addons')) ?></label>
				<select id="bsimOfAddons" class="bsim-select">
					<option value="0"><?= build_simulator_h(t_default('bsim.outfitter_addons_none', 'None')) ?></option>
					<option value="1"><?= build_simulator_h(t_default('bsim.outfitter_addons_1', 'Addon 1')) ?></option>
					<option value="2"><?= build_simulator_h(t_default('bsim.outfitter_addons_2', 'Addon 2')) ?></option>
					<option value="3" selected><?= build_simulator_h(t_default('bsim.outfitter_addons_both', 'Both')) ?></option>
				</select>
			</div>
			<div class="bsim-row">
				<label for="bsimOfDir"><?= build_simulator_h(t_default('bsim.outfitter_direction', 'Direction')) ?></label>
				<select id="bsimOfDir" class="bsim-select">
					<option value="2" selected><?= build_simulator_h(t_default('bsim.outfitter_dir_south', 'South')) ?></option>
					<option value="0"><?= build_simulator_h(t_default('bsim.outfitter_dir_north', 'North')) ?></option>
					<option value="1"><?= build_simulator_h(t_default('bsim.outfitter_dir_east', 'East')) ?></option>
					<option value="3"><?= build_simulator_h(t_default('bsim.outfitter_dir_west', 'West')) ?></option>
				</select>
			</div>
			<div class="bsim-row">
				<label style="flex:0 0 auto;"><input type="checkbox" id="bsimOfAnim"> <?= build_simulator_h(t_default('bsim.outfitter_animate', 'Animate (turn on the spot - mount included, if shown)')) ?></label>
			</div>

			<div class="bsim-section-title"><?= build_simulator_h(t_default('bsim.outfitter_colors', 'Colors (0-132)')) ?></div>
			<?php foreach (array('head' => 78, 'body' => 68, 'legs' => 58, 'feet' => 76) as $channel => $default): ?>
				<div class="bsim-row">
					<label for="bsimOf<?= build_simulator_h(ucfirst($channel)) ?>"><?= build_simulator_h(t_default('bsim.outfitter_' . $channel, ucfirst($channel))) ?></label>
					<input type="range" id="bsimOf<?= build_simulator_h(ucfirst($channel)) ?>" min="0" max="132" value="<?= (int) $default ?>" data-bsim-color="<?= build_simulator_h($channel) ?>">
					<span class="bsim-range-val" id="bsimOf<?= build_simulator_h(ucfirst($channel)) ?>Val"><?= (int) $default ?></span>
				</div>
			<?php endforeach; ?>

			<div class="bsim-section-title"><?= build_simulator_h(t_default('bsim.outfitter_mount', 'Mount')) ?></div>
			<div class="bsim-row">
				<label style="flex:0 0 auto;"><input type="checkbox" id="bsimOfMountToggle"> <?= build_simulator_h(t_default('bsim.outfitter_show_mount', 'Show mount')) ?></label>
			</div>
			<div class="bsim-row">
				<label for="bsimOfMount"><?= build_simulator_h(t_default('bsim.outfitter_mount_id', 'Mount ID')) ?></label>
				<?php if ($bsimMountsList): ?>
					<select id="bsimOfMount" class="bsim-select" disabled>
						<?php foreach ($bsimMountsList as $m): ?>
							<option value="<?= (int) $m['id'] ?>"><?= build_simulator_h($m['name']) ?> (<?= (int) $m['id'] ?>)</option>
						<?php endforeach; ?>
					</select>
				<?php else: ?>
					<input type="number" id="bsimOfMount" min="0" value="0" disabled>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<script>
(function () {
	var server = <?= json_encode($outfitterServer) ?>;

	var img = document.getElementById('bsimOutfitImg');
	var idInput = document.getElementById('bsimOfId');
	var addonsSelect = document.getElementById('bsimOfAddons');
	var dirSelect = document.getElementById('bsimOfDir');
	var mountToggle = document.getElementById('bsimOfMountToggle');
	var mountInput = document.getElementById('bsimOfMount');
	var colorInputs = Array.prototype.slice.call(document.querySelectorAll('[data-bsim-color]'));

	function build() {
		var id = parseInt(idInput.value, 10) || 0;
		var url = server + '?id=' + encodeURIComponent(id)
			+ '&addons=' + encodeURIComponent(addonsSelect.value)
			+ '&direction=' + encodeURIComponent(dirSelect.value);

		colorInputs.forEach(function (input) {
			url += '&' + input.getAttribute('data-bsim-color') + '=' + encodeURIComponent(input.value);
			var valEl = document.getElementById(input.id + 'Val');
			if (valEl) valEl.textContent = input.value;
		});

		if (mountToggle.checked) {
			var mountId = parseInt(mountInput.value, 10) || 0;
			if (mountId > 0) url += '&mount=' + encodeURIComponent(mountId);
		}

		img.src = url;
		img.alt = 'Outfit ' + id;
	}

	[idInput, addonsSelect, dirSelect, mountInput].forEach(function (el) {
		el.addEventListener('input', build);
		el.addEventListener('change', build);
	});
	colorInputs.forEach(function (el) {
		el.addEventListener('input', build);
	});
	mountToggle.addEventListener('change', function () {
		mountInput.disabled = !mountToggle.checked;
		build();
	});

	// Animation: no walk-frame API on the image service, so this fakes
	// "moving" the same way turning on the spot in-game does - stepping
	// through the four directions on a timer. Covers the mount too, since
	// it is baked into the very same image whenever "Show mount" is on.
	var animTimer = null;
	var animDirs = ['2', '3', '0', '1'];
	var animStep = 0;
	var animCheckbox = document.getElementById('bsimOfAnim');
	if (animCheckbox) {
		animCheckbox.addEventListener('change', function () {
			if (animTimer) { clearInterval(animTimer); animTimer = null; }
			if (animCheckbox.checked) {
				animTimer = setInterval(function () {
					animStep = (animStep + 1) % animDirs.length;
					dirSelect.value = animDirs[animStep];
					build();
				}, 450);
			}
		});
	}

	// Zoom: mouse wheel over the preview scales the image in place, clamped
	// so it can't shrink away or blow up into a pixel mess.
	var preview = img.closest('.bsim-preview');
	var zoom = 1;
	if (preview) {
		preview.addEventListener('wheel', function (e) {
			e.preventDefault();
			zoom += (e.deltaY < 0 ? 0.2 : -0.2);
			zoom = Math.max(1, Math.min(6, zoom));
			img.style.transform = 'scale(' + zoom.toFixed(2) + ')';
		}, { passive: false });
	}

	build();
})();
</script>
