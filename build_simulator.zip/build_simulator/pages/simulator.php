<?php
/**
 * Public page: page.php?plugin=build_simulator&p=simulator
 *
 * Every equipable item is embedded once, with its already-computed stats, so
 * picking a different helmet or weapon recalculates instantly client-side -
 * no round trip per selection. There is no real character here, so a
 * storage-backed bonus (see the Armory) has nothing to read from - this page
 * only ever shows what items.xml itself defines.
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

if (!build_simulator_enabled()) {
	echo '<p>' . build_simulator_h(t_default('bsim.disabled', 'The build simulator is currently disabled.')) . '</p>';
	return;
}

$bsimSlots = build_simulator_slots();
$bsimItemsBySlot = build_simulator_items_by_slot();

$bsimPayload = array();
foreach ($bsimItemsBySlot as $slotKey => $items) {
	$bsimPayload[$slotKey] = array();
	foreach ($items as $item) {
		$bsimPayload[$slotKey][] = array(
			'id'      => $item['id'],
			'name'    => $item['name'],
			'image'   => $item['image'],
			'stats'   => build_simulator_item_stats($item),
		);
	}
}

$bsimHasItems = false;
foreach ($bsimItemsBySlot as $items) {
	if ($items) { $bsimHasItems = true; break; }
}
?>
<style>
.bsim-wrap{--bsim-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--bsim-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bsim-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--bsim-accent:var(--accent,var(--link,#f4c542));color:var(--bsim-text)}
<?= build_simulator_color_style() ?>
.bsim-wrap *{box-sizing:border-box}
.bsim-wrap h1{font-size:26px;margin:0 0 4px}
.bsim-lead{opacity:.8;margin:0 0 20px}
.bsim-doll{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;margin-bottom:22px}
.bsim-slot{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);padding:10px;text-align:center}
.bsim-slot-icon{width:48px;height:48px;margin:0 auto 8px;border:1px dashed var(--bsim-border);border-radius:8px;display:flex;align-items:center;justify-content:center;opacity:.6}
.bsim-slot-icon img{max-width:40px;max-height:40px}
.bsim-slot-label{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.05em;opacity:.7;margin-bottom:6px}
.bsim-select{width:100%;font-size:12.5px;padding:5px;border-radius:6px;border:1px solid var(--bsim-border);background:var(--bsim-surface);color:var(--bsim-text)}
.bsim-stats{border:1px solid var(--bsim-border);border-radius:10px;background:var(--bsim-surface);padding:16px}
.bsim-stats h2{margin:0 0 10px;font-size:17px}
.bsim-stats h3{margin:16px 0 8px;font-size:13px;opacity:.8}
.bsim-stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px}
.bsim-stat{display:flex;justify-content:space-between;gap:8px;padding:6px 10px;border:1px solid var(--bsim-border);border-radius:6px;font-size:13px}
.bsim-stat-val{color:var(--bsim-accent);font-weight:700;font-variant-numeric:tabular-nums}
.bsim-empty{opacity:.6;margin:0}
</style>

<div class="bsim-wrap">
	<h1><?= build_simulator_h(t_default('bsim.title', 'Build Simulator')) ?></h1>
	<p class="bsim-lead"><?= build_simulator_h(t_default('bsim.lead', 'Pick a piece for each slot and see the combined stats update live.')) ?></p>

	<?php if (!$bsimHasItems): ?>
		<p><?= build_simulator_h(t_default('bsim.no_items', 'No equipable items are loaded yet - upload items.xml under Admin Panel > Server Info.')) ?></p>
	<?php else: ?>
		<div class="bsim-doll">
			<?php foreach ($bsimSlots as $slotKey => $slot): ?>
				<div class="bsim-slot">
					<div class="bsim-slot-icon" id="bsimIcon_<?= build_simulator_h($slotKey) ?>">
						<?php if (!empty($slot['icon'])): ?>
							<img src="<?= build_simulator_h($slot['icon']) ?>" alt="">
						<?php else: ?>
							<i class="fa fa-plus"></i>
						<?php endif; ?>
					</div>
					<label class="bsim-slot-label" for="bsimSelect_<?= build_simulator_h($slotKey) ?>"><?= build_simulator_h(t_default('bsim.slot_' . $slotKey, $slot['label'])) ?></label>
					<select class="bsim-select" id="bsimSelect_<?= build_simulator_h($slotKey) ?>" data-bsim-slot="<?= build_simulator_h($slotKey) ?>">
						<option value="0"><?= build_simulator_h(t_default('bsim.none', '-- none --')) ?></option>
						<?php foreach (($bsimItemsBySlot[$slotKey] ?? array()) as $item): ?>
							<option value="<?= (int) $item['id'] ?>"><?= build_simulator_h($item['name']) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="bsim-stats">
			<h2><?= build_simulator_h(t_default('bsim.stats_title', 'Combined stats')) ?></h2>
			<div id="bsimStatsBody" class="bsim-stats-grid">
				<p class="bsim-empty"><?= build_simulator_h(t_default('bsim.stats_empty', 'Pick some items to see combined stats.')) ?></p>
			</div>
		</div>

		<script>
		(function () {
			var DATA = <?= json_encode($bsimPayload, JSON_UNESCAPED_UNICODE) ?>;
			var slots = Object.keys(DATA);
			var selected = {};

			function esc(s) {
				var d = document.createElement('div');
				d.textContent = String(s == null ? '' : s);
				return d.innerHTML;
			}

			function itemById(slotKey, id) {
				id = parseInt(id, 10);
				var list = DATA[slotKey] || [];
				for (var i = 0; i < list.length; i++) {
					if (list[i].id === id) return list[i];
				}
				return null;
			}

			// Each slot's placeholder (the admin-chosen icon, or the generic "+")
			// is whatever the server already rendered - captured once so an
			// emptied slot restores it exactly instead of a hardcoded icon.
			var emptyIconHtml = {};
			slots.forEach(function (slotKey) {
				var el = document.getElementById('bsimIcon_' + slotKey);
				if (el) emptyIconHtml[slotKey] = el.innerHTML;
			});

			function recalc() {
				var totals = {};

				slots.forEach(function (slotKey) {
					var item = selected[slotKey];
					var iconEl = document.getElementById('bsimIcon_' + slotKey);
					if (!item) {
						if (iconEl) iconEl.innerHTML = emptyIconHtml[slotKey] || '<i class="fa fa-plus"></i>';
						return;
					}
					if (iconEl) iconEl.innerHTML = '<img src="' + esc(item.image) + '" alt="' + esc(item.name) + '" title="' + esc(item.name) + '">';

					Object.keys(item.stats || {}).forEach(function (label) {
						var s = item.stats[label];
						if (!totals[label]) totals[label] = { value: 0, suffix: s.suffix };
						totals[label].value += Number(s.value) || 0;
					});
				});

				var statsBody = document.getElementById('bsimStatsBody');
				var labels = Object.keys(totals).sort();
				if (!labels.length) {
					statsBody.innerHTML = '<p class="bsim-empty"><?= build_simulator_h(t_default('bsim.stats_empty', 'Pick some items to see combined stats.')) ?></p>';
				} else {
					statsBody.innerHTML = labels.map(function (label) {
						var t = totals[label];
						var val = Math.round(t.value * 100) / 100;
						var sign = val > 0 ? '+' : '';
						return '<div class="bsim-stat"><span>' + esc(label) + '</span><span class="bsim-stat-val">' + sign + val + esc(t.suffix) + '</span></div>';
					}).join('');
				}
			}

			slots.forEach(function (slotKey) {
				var sel = document.getElementById('bsimSelect_' + slotKey);
				if (!sel) return;
				sel.addEventListener('change', function () {
					selected[slotKey] = sel.value !== '0' ? itemById(slotKey, sel.value) : null;
					recalc();
				});
			});

			recalc();
		})();
		</script>
	<?php endif; ?>
</div>
