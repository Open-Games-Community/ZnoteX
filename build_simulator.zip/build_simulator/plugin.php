<?php
/**
 * Build Simulator - a public equipment planner, plus the Armory.
 *
 * Item data comes straight from the same items.xml cache Admin Panel >
 * Server Info already parses for items.php (serverdata_load('items')) - this
 * plugin adds no XML parsing of its own, it only reads and aggregates.
 *
 * A bonus that never appears in items.xml at all - granted by a Lua script
 * that reacts to a player_storage key instead - cannot be tied to an item id
 * at all, since it lives on the PLAYER, not the item type (and the same item
 * id can behave differently per player - a rolled/rarity system, say). The
 * Armory (not the Simulator, which has no real player to read from) can
 * still show it: Admin Panel > Installed Plugins > Build Simulator Storage
 * Stats lets an admin name a storage key and how to format its value: read
 * live from the loaded character's own player_storage, shown next to the
 * normal item stats whenever it is greater than 0.
 */
if (!function_exists('build_simulator_h')) {

function build_simulator_h($v): string {
	return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8');
}
function build_simulator_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('plugin:build_simulator:setting:' . $key, $default) : $default;
}
function build_simulator_enabled(): bool {
	return build_simulator_setting('enabled', '1') === '1';
}

/**
 * The default CSS pulls its colors from a long var() fallback chain so it
 * reads reasonably on any theme without configuration - but "reasonably" is
 * not "well" on every theme, so Admin Panel > Installed Plugins > Build
 * Simulator lets an admin pin exact colors instead. Blank means "keep
 * reading from the theme", so this only ever emits overrides for the colors
 * actually set.
 */
function build_simulator_color_style(): string {
	$map = array(
		'color_surface' => '--bsim-surface',
		'color_text'    => '--bsim-text',
		'color_border'  => '--bsim-border',
		'color_accent'  => '--bsim-accent',
	);

	$decls = array();
	foreach ($map as $settingKey => $cssVar) {
		$value = trim(build_simulator_setting($settingKey, ''));
		if ($value !== '' && preg_match('/^#[0-9a-f]{6}$/i', $value)) {
			$decls[] = $cssVar . ':' . $value;
		}
	}

	return $decls ? '.bsim-wrap{' . implode(';', $decls) . '}' : '';
}

/**
 * Outfits.xml / mounts.xml aren't served on the website (they live on the
 * game server, not in the web root) - an admin uploads them once from
 * Admin Panel > Installed Plugins > Build Simulator Outfitter Data, and this
 * parses whatever <outfit>/<mount> elements it finds (lenient - schemas vary
 * a little by engine, but they all carry a looktype/clientid + name pair
 * somewhere) into a flat, deduplicated {id, name} list, stored as JSON in a
 * plugin setting. Nothing here reads data/XML directly - only what an admin
 * hands it through the upload form.
 */
function build_simulator_parse_outfits_xml(string $xml): array {
	$prev = libxml_use_internal_errors(true);
	$doc = simplexml_load_string($xml);
	libxml_use_internal_errors($prev);
	if ($doc === false) {
		return array();
	}

	// Player outfits (type="1") sit as <list looktype="..." name="..."/>
	// children of <outfit type="1">; type 2/3 are NPC/monster groups, so
	// scoped to type=1 first - some exports omit the type attribute
	// entirely, so a plain //list is the fallback rather than coming back
	// empty.
	$nodes = $doc->xpath('//outfit[@type="1"]/list');
	if (!$nodes) {
		$nodes = $doc->xpath('//list[@looktype]') ?: $doc->xpath('//outfit[@looktype]');
	}

	$out = array();
	foreach (($nodes ?: array()) as $node) {
		$attrs = $node->attributes();
		$id = (int) ($attrs['looktype'] ?? $attrs['id'] ?? 0);
		$name = trim((string) ($attrs['name'] ?? ''));
		if ($id > 0 && $name !== '' && !isset($out[$id])) {
			$out[$id] = $name;
		}
	}

	asort($out, SORT_NATURAL | SORT_FLAG_CASE);
	$list = array();
	foreach ($out as $id => $name) {
		$list[] = array('id' => $id, 'name' => $name);
	}
	return $list;
}

function build_simulator_parse_mounts_xml(string $xml): array {
	$prev = libxml_use_internal_errors(true);
	$doc = simplexml_load_string($xml);
	libxml_use_internal_errors($prev);
	if ($doc === false) {
		return array();
	}

	$out = array();
	foreach ($doc->xpath('//mount') as $node) {
		$attrs = $node->attributes();
		$id = (int) ($attrs['clientid'] ?? $attrs['looktype'] ?? $attrs['id'] ?? 0);
		$name = trim((string) ($attrs['name'] ?? ''));
		if ($id > 0 && $name !== '' && !isset($out[$id])) {
			$out[$id] = $name;
		}
	}

	asort($out, SORT_NATURAL | SORT_FLAG_CASE);
	$list = array();
	foreach ($out as $id => $name) {
		$list[] = array('id' => $id, 'name' => $name);
	}
	return $list;
}

function build_simulator_outfits_list(): array {
	$json = build_simulator_setting('outfits_json', '');
	if ($json === '') {
		return array();
	}
	$data = json_decode($json, true);
	return is_array($data) ? $data : array();
}

function build_simulator_mounts_list(): array {
	$json = build_simulator_setting('mounts_json', '');
	if ($json === '') {
		return array();
	}
	$data = json_decode($json, true);
	return is_array($data) ? $data : array();
}

/**
 * The ONE place that decides whether an item belongs in a given slot, used
 * by every caller that needs it (item-by-slot indexing, the Armory's
 * pre-selection) - so the two can never quietly disagree.
 *
 * Not every server engine agrees on which attribute carries an item's
 * category, and - confirmed against real items.xml samples from several
 * engines - an item can legitimately carry BOTH at once: a two-handed axe is
 * commonly weaponType="axe" *and* slotType="two-handed" on the very same
 * entry (TFS 1.x, Canary/OTServBR-Global and its forks - BlackTek, Crystal
 * Server - all share this items.xml format; OTHire and OTX inherit the same
 * TFS-derived schema). Checking only one attribute and discarding the other
 * would silently drop that item from a slot configured to match on
 * whichever attribute lost - so both are checked independently, and either
 * one matching is enough.
 */
function build_simulator_item_matches_slot(array $attributes, array $matchValues): bool {
	foreach (array('weaponType', 'slotType') as $attr) {
		if (isset($attributes[$attr]) && in_array($attributes[$attr], $matchValues, true)) {
			return true;
		}
	}
	return false;
}

/**
 * The paperdoll slots, in display order. Admin-editable (Admin Panel >
 * Installed Plugins > Build Simulator Slots) - not hardcoded, because
 * different engines/configs use different slotType/weaponType vocabularies
 * (Canary with "classic equipment slots" off uses "right-hand"/"two-handed"
 * instead of listing weapon classes, for instance), and some servers add
 * extra slots a fixed 9-slot list could never cover (a second ring, etc).
 *
 * 'values' is checked against both slotType and weaponType, independently -
 * see build_simulator_item_matches_slot().
 *
 * Falls back to the classic 9-slot TFS/Canary scheme only if the table is
 * empty or missing (a plugin update landing before install.sql has run).
 */
function build_simulator_slots(): array {
	$fallback = array(
		'head'      => array('label' => 'Head', 'values' => array('head'), 'icon' => ''),
		'necklace'  => array('label' => 'Necklace', 'values' => array('necklace'), 'icon' => ''),
		'armor'     => array('label' => 'Armor', 'values' => array('body'), 'icon' => ''),
		'shield'    => array('label' => 'Shield', 'values' => array('shield'), 'icon' => ''),
		'weapon'    => array('label' => 'Weapon', 'values' => array('sword', 'axe', 'club', 'distance', 'wand'), 'icon' => ''),
		'legs'      => array('label' => 'Legs', 'values' => array('legs'), 'icon' => ''),
		'feet'      => array('label' => 'Boots', 'values' => array('feet'), 'icon' => ''),
		'ring'      => array('label' => 'Ring', 'values' => array('ring'), 'icon' => ''),
		'ammo'      => array('label' => 'Ammo', 'values' => array('ammunition'), 'icon' => ''),
	);

	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_build_sim_slots')) {
		return $fallback;
	}

	$rows = db()->fetchAll("
		SELECT `slot_key`, `label`, `match_values`, `icon`
		FROM `znote_build_sim_slots`
		WHERE `active` = 1
		ORDER BY `sort_order` ASC, `id` ASC;
	");
	if (!is_array($rows) || !$rows) {
		return $fallback;
	}

	$slots = array();
	foreach ($rows as $row) {
		$key = (string) $row['slot_key'];
		if ($key === '') {
			continue;
		}
		$values = array_values(array_filter(array_map('trim', explode(',', (string) $row['match_values']))));
		if (!$values) {
			continue;
		}
		$slots[$key] = array(
			'label' => (string) $row['label'] !== '' ? (string) $row['label'] : ucfirst($key),
			'values' => $values,
			'icon' => (string) $row['icon'],
		);
	}

	return $slots ?: $fallback;
}

/**
 * All equipable items grouped by simulator slot, each as
 * [id, name, image]. Reads the same serverdata('items') cache items.php
 * uses - rebuilds it once if the cache is cold but the XML is on disk.
 */
function build_simulator_items_by_slot(): array {
	if (!function_exists('serverdata_load')) {
		return array();
	}

	$raw = serverdata_load('items');
	if ($raw === false && function_exists('serverdata_file') && is_file(serverdata_file('items.xml'))) {
		serverdata_rebuild('items');
		$raw = serverdata_load('items');
	}
	if (!is_array($raw) || empty($raw['item'])) {
		return array();
	}

	$slots = build_simulator_slots();
	$out = array();
	foreach (array_keys($slots) as $slotKey) {
		$out[$slotKey] = array();
	}

	foreach ($raw['item'] as $entry) {
		$attributes = (array) ($entry['attributes'] ?? array());
		if (!isset($attributes['weaponType']) && !isset($attributes['slotType'])) {
			continue;
		}

		foreach ($slots as $slotKey => $slot) {
			if (!build_simulator_item_matches_slot($attributes, $slot['values'])) {
				continue;
			}

			$id = (int) ($entry['id'] ?? $entry['fromid'] ?? 0);
			if ($id <= 0) {
				continue;
			}

			$out[$slotKey][] = array(
				'id' => $id,
				'name' => ucwords((string) ($entry['name'] ?? ('#' . $id))),
				'image' => function_exists('znote_item_image_url') ? znote_item_image_url($id, 'gif') : '',
				'attributes' => $attributes,
			);
		}
	}

	foreach ($out as $slotKey => $items) {
		usort($out[$slotKey], static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name']));
	}

	return $out;
}

/** Every equipable item, id => [name, attributes] - for looking up an item by id directly (the Armory). */
function build_simulator_flat_items(): array {
	if (!function_exists('serverdata_load')) {
		return array();
	}

	$raw = serverdata_load('items');
	if ($raw === false && function_exists('serverdata_file') && is_file(serverdata_file('items.xml'))) {
		serverdata_rebuild('items');
		$raw = serverdata_load('items');
	}
	if (!is_array($raw) || empty($raw['item'])) {
		return array();
	}

	$out = array();
	foreach ($raw['item'] as $entry) {
		$id = (int) ($entry['id'] ?? $entry['fromid'] ?? 0);
		if ($id <= 0) {
			continue;
		}
		$out[$id] = array(
			'name' => ucwords((string) ($entry['name'] ?? ('#' . $id))),
			'attributes' => (array) ($entry['attributes'] ?? array()),
		);
	}
	return $out;
}

/**
 * Standard TFS-family equip slot ids (players.pid on player_items), in
 * paperdoll display order. Consistent across TFS 0.x/1.x/OTHire/Canary.
 */
function build_simulator_equip_slots(): array {
	return array(
		1 => 'Head', 2 => 'Necklace', 4 => 'Armor', 5 => 'Weapon',
		6 => 'Shield', 7 => 'Legs', 8 => 'Boots', 9 => 'Ring', 10 => 'Ammo',
	);
}

/**
 * A character's currently equipped items (right now, from player_items) with
 * stats attached - the Armory's starting point before the visitor starts
 * swapping slots to test something else.
 */
function build_simulator_character_equipment(string $name): ?array {
	$name = trim($name);
	if ($name === '' || !function_exists('user_character_exist') || !user_character_exist($name)) {
		return null;
	}

	// lookmount is newer than some supported schemas (TFS 0.x/some 1.x installs
	// do not have it at all) - only select it when the column actually exists,
	// same guard the engine itself uses elsewhere for optional columns.
	$hasMount = function_exists('znote_column_exists') && znote_column_exists('players', 'lookmount');
	$player = db()->fetchOne("
		SELECT `id`, `name`, `level`, `vocation`, `sex`, `looktype`, `lookhead`, `lookbody`, `looklegs`, `lookfeet`, `lookaddons`" . ($hasMount ? ', `lookmount`' : '') . "
		FROM `players`
		WHERE `name` = ?
		LIMIT 1;
	", [$name]);
	if (!is_array($player)) {
		return null;
	}
	if (!$hasMount) {
		$player['lookmount'] = 0;
	}

	$equipped = db()->fetchAll("
		SELECT `pid`, `itemtype`
		FROM `player_items`
		WHERE `player_id` = ? AND `pid` IN (1, 2, 4, 5, 6, 7, 8, 9, 10);
	", [(int) $player['id']]);
	$equipped = is_array($equipped) ? $equipped : array();

	$flatItems = build_simulator_flat_items();
	$slotNames = build_simulator_equip_slots();

	$gear = array();
	foreach ($equipped as $row) {
		$pid = (int) $row['pid'];
		$itemId = (int) $row['itemtype'];
		if (!isset($slotNames[$pid])) {
			continue;
		}
		$item = $flatItems[$itemId] ?? array('name' => '#' . $itemId, 'attributes' => array());
		$gear[$pid] = array(
			'slot' => $slotNames[$pid],
			'id' => $itemId,
			'name' => $item['name'],
			'image' => function_exists('znote_item_image_url') ? znote_item_image_url($itemId, 'gif') : '',
			'stats' => build_simulator_item_stats($item),
			'attributes' => $item['attributes'] ?? array(),
		);
	}

	return array('player' => $player, 'gear' => $gear);
}

/** Configured storage-backed stats, in display order. */
function build_simulator_storage_stats_config(): array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_build_sim_storage_stats')) {
		return array();
	}
	$rows = db()->fetchAll("
		SELECT `storage_key`, `label`, `format`
		FROM `znote_build_sim_storage_stats`
		WHERE `active` = 1
		ORDER BY `sort_order` ASC, `id` ASC;
	");
	return is_array($rows) ? $rows : array();
}

/** One stored number, formatted per its configured representation. */
function build_simulator_storage_stat_format(string $format, int $value): string {
	switch ($format) {
		case 'percent': return $value . '%';
		case 'plus': return '+' . $value;
		case 'minus': return '-' . abs($value);
		default: return (string) $value;
	}
}

/**
 * Every configured storage stat that is actually set (> 0) on this
 * character, ready to display - label => formatted value. This is the only
 * way a Lua-storage-driven bonus (a rolled rarity stat, an enchant, anything
 * that lives on the player rather than the item) can appear on the Armory:
 * it is read from the player, not guessed from an item id.
 */
function build_simulator_character_storage_stats(int $playerId): array {
	if ($playerId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('player_storage')) {
		return array();
	}

	$config = build_simulator_storage_stats_config();
	if (!$config) {
		return array();
	}

	$keys = array_map(static fn($row) => (int) $row['storage_key'], $config);
	$placeholders = implode(',', array_fill(0, count($keys), '?'));
	$rows = db()->fetchAll("
		SELECT `key`, `value`
		FROM `player_storage`
		WHERE `player_id` = ? AND `key` IN ({$placeholders});
	", array_merge([$playerId], $keys));
	$rows = is_array($rows) ? $rows : array();

	$values = array();
	foreach ($rows as $row) {
		$values[(int) $row['key']] = (int) $row['value'];
	}

	$out = array();
	foreach ($config as $row) {
		$key = (int) $row['storage_key'];
		$value = $values[$key] ?? 0;
		if ($value <= 0) {
			continue;
		}
		$out[] = array(
			'label' => (string) $row['label'],
			'value' => build_simulator_storage_stat_format((string) $row['format'], $value),
		);
	}

	return $out;
}

/**
 * One friendly [label, formatted value] pair for a raw items.xml attribute,
 * or null for attributes that are not meaningful stats (weight, charges on
 * consumables, etc). Mirrors the label set items.php already shows, so a
 * value here reads the same way it does on the item's own equipment-browser
 * entry - same words, same units.
 */
function build_simulator_attribute_label(string $key, $value): ?array {
	$percent = array(
		'absorbPercentEnergy' => 'Energy protection', 'absorbPercentFire' => 'Fire protection',
		'absorbPercentEarth' => 'Earth protection', 'absorbPercentPoison' => 'Earth protection (poison)',
		'absorbPercentIce' => 'Ice protection', 'absorbPercentHoly' => 'Holy protection',
		'absorbPercentDeath' => 'Death protection', 'absorbPercentLifeDrain' => 'Life drain protection',
		'absorbPercentManaDrain' => 'Mana drain protection', 'absorbPercentDrown' => 'Drown protection',
		'absorbPercentPhysical' => 'Physical protection',
	);
	if (isset($percent[$key])) {
		return array($percent[$key], (float) $value, '%');
	}

	$skills = array(
		'skillFist' => 'Fist fighting', 'skillClub' => 'Club fighting', 'skillSword' => 'Sword fighting',
		'skillAxe' => 'Axe fighting', 'skillDist' => 'Distance fighting', 'skillShield' => 'Shielding',
	);
	if (isset($skills[$key])) {
		return array($skills[$key], (float) $value, '');
	}

	switch ($key) {
		case 'armor': return array('Armor', (float) $value, '');
		case 'attack': return array('Attack', (float) $value, '');
		case 'defense': return array('Defense', (float) $value, '');
		case 'extradefense': return array('Extra defense', (float) $value, '');
		case 'hitChance': return array('Hit chance', (float) $value, '%');
		case 'range': return array('Range', (float) $value, '');
		case 'magiclevelpoints': return array('Magic level', (float) $value, '');
		case 'speed': return array('Speed', ((float) $value) / 2, '');
		default: return null;
	}
}

/** Every stat an item contributes, as label => [value, suffix] - value is a plain number, ready to sum. */
function build_simulator_item_stats(array $item): array {
	$stats = array();
	foreach ((array) ($item['attributes'] ?? array()) as $key => $value) {
		$pair = build_simulator_attribute_label((string) $key, $value);
		if ($pair !== null) {
			$stats[$pair[0]] = array('value' => $pair[1], 'suffix' => $pair[2]);
		}
	}
	return $stats;
}

}
