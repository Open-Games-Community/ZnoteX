<?php
/**
 * Title: Build Simulator Outfitter Data
 * Icon: fa-magic
 * Group: Installed Plugins
 * Order: 40
 * Description: Upload data/XML/outfits.xml and data/XML/mounts.xml from your game server so the Outfitter page can offer a searchable name dropdown instead of a bare ID field.
 */

if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

const BSIM_OUTFITTER_MAX_XML = 8388608; // 8 MB - outfits.xml/mounts.xml are always small text files

function bsim_outfitter_data_read_upload(string $field): ?string {
	$file = $_FILES[$field] ?? null;
	if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
		return null;
	}
	if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
		acp_flash_error(t_default('acp.bsimof.upload_error', 'Upload failed (error code {code}).', ['code' => (string) $file['error']]));
		return null;
	}
	if (!is_uploaded_file((string) $file['tmp_name'])) {
		acp_flash_error(t_default('acp.bsimof.upload_invalid', 'That did not look like a real upload.'));
		return null;
	}
	if ((int) $file['size'] > BSIM_OUTFITTER_MAX_XML) {
		acp_flash_error(t_default('acp.bsimof.upload_too_big', 'That file is larger than expected for {file} - is it the right file?', ['file' => $field]));
		return null;
	}

	$content = file_get_contents((string) $file['tmp_name']);
	return $content !== false ? $content : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!acp_verify_csrf()) {
		acp_flash_error(t_default('acp.csrf_failed', 'Your session expired, please try again.'));
		acp_redirect('build_simulator__outfitter_data');
	}

	$do = (string) ($_POST['do'] ?? '');

	if ($do === 'clear_outfits') {
		setting_set('plugin:build_simulator:setting:outfits_json', '');
		acp_log('build_simulator.outfits_clear', '');
		acp_flash_success(t_default('acp.bsimof.outfits_cleared', 'Outfit list cleared - the Outfitter falls back to a plain ID field.'));
		acp_redirect('build_simulator__outfitter_data');
	}
	if ($do === 'clear_mounts') {
		setting_set('plugin:build_simulator:setting:mounts_json', '');
		acp_log('build_simulator.mounts_clear', '');
		acp_flash_success(t_default('acp.bsimof.mounts_cleared', 'Mount list cleared - the Outfitter falls back to a plain ID field.'));
		acp_redirect('build_simulator__outfitter_data');
	}

	$outfitsXml = bsim_outfitter_data_read_upload('outfits_xml');
	if ($outfitsXml !== null) {
		$parsed = build_simulator_parse_outfits_xml($outfitsXml);
		if (!$parsed) {
			acp_flash_error(t_default('acp.bsimof.outfits_empty', 'No <list looktype="..." name="..."> entries were found in that file - is it really outfits.xml?'));
		} else {
			setting_set('plugin:build_simulator:setting:outfits_json', json_encode($parsed));
			acp_log('build_simulator.outfits_upload', count($parsed) . ' outfits');
			acp_flash_success(t_default('acp.bsimof.outfits_saved', '{count} outfits loaded.', ['count' => (string) count($parsed)]));
		}
	}

	$mountsXml = bsim_outfitter_data_read_upload('mounts_xml');
	if ($mountsXml !== null) {
		$parsed = build_simulator_parse_mounts_xml($mountsXml);
		if (!$parsed) {
			acp_flash_error(t_default('acp.bsimof.mounts_empty', 'No <mount clientid="..." name="..."> entries were found in that file - is it really mounts.xml?'));
		} else {
			setting_set('plugin:build_simulator:setting:mounts_json', json_encode($parsed));
			acp_log('build_simulator.mounts_upload', count($parsed) . ' mounts');
			acp_flash_success(t_default('acp.bsimof.mounts_saved', '{count} mounts loaded.', ['count' => (string) count($parsed)]));
		}
	}

	acp_redirect('build_simulator__outfitter_data');
}

$outfits = build_simulator_outfits_list();
$mounts = build_simulator_mounts_list();
?>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimof.info_title', 'How this works') ?></h2>
	</header>
	<div class="acp-card-body">
		<p><?= t_default('acp.bsimof.info_body', "outfits.xml and mounts.xml live on the game server (data/XML/), not on the website, so there is nothing to auto-detect - upload a copy of each below. The Outfitter page then offers a proper name dropdown instead of a bare ID field. Leave either one un-uploaded (or clear it) and that field falls back to a plain number input, so the page still works without this.") ?></p>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimof.outfits_title', 'Outfits') ?> <span class="is-muted"><?= $outfits ? count($outfits) . ' ' . t_default('acp.bsimof.loaded', 'loaded') : t_default('acp.bsimof.none_loaded', 'none loaded') ?></span></h2>
	</header>
	<div class="acp-card-body">
		<form method="post" enctype="multipart/form-data">
			<?= acp_csrf_field() ?>
			<div class="acp-field">
				<label class="acp-label" for="bsimof_outfits"><?= t_default('acp.bsimof.outfits_label', 'data/XML/outfits.xml') ?></label>
				<input class="acp-input" type="file" id="bsimof_outfits" name="outfits_xml" accept=".xml">
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-upload"></i> <?= t_default('acp.bsimof.upload_btn', 'Upload') ?></button>
				<?php if ($outfits): ?>
					<button class="acp-btn acp-btn--ghost" type="submit" name="do" value="clear_outfits" formnovalidate><i class="fa fa-trash"></i> <?= t_default('acp.bsimof.clear_btn', 'Clear') ?></button>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimof.mounts_title', 'Mounts') ?> <span class="is-muted"><?= $mounts ? count($mounts) . ' ' . t_default('acp.bsimof.loaded', 'loaded') : t_default('acp.bsimof.none_loaded', 'none loaded') ?></span></h2>
	</header>
	<div class="acp-card-body">
		<form method="post" enctype="multipart/form-data">
			<?= acp_csrf_field() ?>
			<div class="acp-field">
				<label class="acp-label" for="bsimof_mounts"><?= t_default('acp.bsimof.mounts_label', 'data/XML/mounts.xml') ?></label>
				<input class="acp-input" type="file" id="bsimof_mounts" name="mounts_xml" accept=".xml">
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-upload"></i> <?= t_default('acp.bsimof.upload_btn', 'Upload') ?></button>
				<?php if ($mounts): ?>
					<button class="acp-btn acp-btn--ghost" type="submit" name="do" value="clear_mounts" formnovalidate><i class="fa fa-trash"></i> <?= t_default('acp.bsimof.clear_btn', 'Clear') ?></button>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>
