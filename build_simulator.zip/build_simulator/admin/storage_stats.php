<?php
/**
 * Title: Build Simulator Storage Stats
 * Icon: fa-database
 * Group: Installed Plugins
 * Order: 39
 * Description: Custom stats the Armory reads live from a character's own player_storage - for bonuses that live on the PLAYER, not an item (a rarity roll, a quest reward), and so can never be represented by an item's own stats.
 */

if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

if (!function_exists('znote_table_exists') || !znote_table_exists('znote_build_sim_storage_stats')) {
	acp_flash_error(t_default('acp.bsimstat.not_installed', 'Install the Build Simulator plugin first (Admin Panel > Plugins).'));
	acp_redirect('plugins');
}

$bsimFormats = array(
	'value'   => t_default('acp.bsimstat.fmt_value', 'Simple value (e.g. 5)'),
	'percent' => t_default('acp.bsimstat.fmt_percent', 'Percent (e.g. 5%)'),
	'plus'    => t_default('acp.bsimstat.fmt_plus', 'Plus sign (e.g. +5)'),
	'minus'   => t_default('acp.bsimstat.fmt_minus', 'Minus sign (e.g. -5)'),
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!acp_verify_csrf()) {
		acp_flash_error(t_default('acp.csrf_failed', 'Your session expired, please try again.'));
		acp_redirect('build_simulator__storage_stats');
	}

	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_build_sim_storage_stats` WHERE `id` = ? LIMIT 1;", [$id]);
		acp_log('build_simulator.storage_stat_delete', '#' . $id);
		acp_flash_success(t_default('acp.bsimstat.deleted', 'Storage stat removed.'));
		acp_redirect('build_simulator__storage_stats');
	}

	if ($do === 'move' && $id > 0) {
		$ids = db()->fetchAll("SELECT `id` FROM `znote_build_sim_storage_stats` ORDER BY `sort_order` ASC, `id` ASC;");
		$ids = is_array($ids) ? array_map('intval', array_column($ids, 'id')) : array();
		$pos = array_search($id, $ids, true);
		$swap = ((string) ($_POST['dir'] ?? '') === 'up') ? ((int) $pos - 1) : ((int) $pos + 1);

		if ($pos !== false && isset($ids[$swap])) {
			$ids[$pos] = $ids[$swap];
			$ids[$swap] = $id;
			foreach ($ids as $index => $rowId) {
				db()->execute("UPDATE `znote_build_sim_storage_stats` SET `sort_order` = ? WHERE `id` = ? LIMIT 1;", [($index + 1) * 10, $rowId]);
			}
		}
		acp_redirect('build_simulator__storage_stats');
	}

	if ($do === 'save') {
		$storageKey = intv($_POST['storage_key'] ?? 0);
		$label = substr(trim((string) ($_POST['label'] ?? '')), 0, 100);
		$format = (string) ($_POST['format'] ?? 'value');
		$active = !empty($_POST['active']) ? 1 : 0;

		if (!isset($bsimFormats[$format])) {
			$format = 'value';
		}

		if ($storageKey <= 0 || $label === '') {
			acp_flash_error(t_default('acp.bsimstat.missing_fields', 'Give the stat a storage key and a label.'));
			acp_redirect('build_simulator__storage_stats');
		}

		if ($id > 0) {
			db()->execute("
				UPDATE `znote_build_sim_storage_stats`
				SET `storage_key` = ?, `label` = ?, `format` = ?, `active` = ?
				WHERE `id` = ?
				LIMIT 1;
			", [$storageKey, $label, $format, $active, $id]);
			acp_log('build_simulator.storage_stat_update', '#' . $id);
			acp_flash_success(t_default('acp.bsimstat.updated', 'Storage stat updated.'));
		} else {
			$nextOrder = db()->fetchOne("SELECT COALESCE(MAX(`sort_order`), 0) + 10 AS `n` FROM `znote_build_sim_storage_stats`;");
			db()->execute("
				INSERT INTO `znote_build_sim_storage_stats` (`storage_key`, `label`, `format`, `active`, `sort_order`, `created_at`)
				VALUES (?, ?, ?, ?, ?, ?);
			", [$storageKey, $label, $format, $active, (int) ($nextOrder['n'] ?? 10), time()]);
			acp_log('build_simulator.storage_stat_create', (string) $storageKey);
			acp_flash_success(t_default('acp.bsimstat.created', 'Storage stat added.'));
		}

		acp_redirect('build_simulator__storage_stats');
	}
}

$stats = db()->fetchAll("SELECT * FROM `znote_build_sim_storage_stats` ORDER BY `sort_order` ASC, `id` ASC;");
$stats = is_array($stats) ? $stats : array();

$editId = intv($_GET['edit'] ?? 0);
$editing = null;
if ($editId > 0) {
	foreach ($stats as $s) {
		if ((int) $s['id'] === $editId) { $editing = $s; break; }
	}
}
?>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimstat.info_title', 'How this works') ?></h2>
	</header>
	<div class="acp-card-body">
		<p><?= t_default('acp.bsimstat.info_body', 'Some bonuses do not live on an item - a Lua script sets a number directly on the player instead (player_storage), so the same item id can behave differently per character (a rarity roll, a quest reward, and so on). Add a row below for each storage key you want the Armory to show: give it a label and pick how its number should be displayed. The Armory then reads that key live from whichever character is loaded, and only shows the row when the value is greater than 0.') ?></p>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimstat.form_title', 'Add / edit a storage stat') ?></h2>
	</header>
	<div class="acp-card-body">
		<form method="post">
			<?= acp_csrf_field() ?>
			<input type="hidden" name="do" value="save">
			<input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="bsimstat_key"><?= t_default('acp.bsimstat.key_label', 'Storage key') ?></label>
					<input class="acp-input" type="number" id="bsimstat_key" name="storage_key" value="<?= (int) ($editing['storage_key'] ?? 0) ?>" placeholder="<?= h(t_default('acp.bsimstat.key_placeholder', 'e.g. 45001')) ?>" required>
					<p class="acp-hint"><?= t_default('acp.bsimstat.key_help', 'The player_storage key your scripts write this value to.') ?></p>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="bsimstat_label"><?= t_default('acp.bsimstat.label_label', 'Display label') ?></label>
					<input class="acp-input" id="bsimstat_label" name="label" value="<?= h((string) ($editing['label'] ?? '')) ?>" placeholder="<?= h(t_default('acp.bsimstat.label_placeholder', 'e.g. Extra Fire Resistance')) ?>" maxlength="100" required>
				</div>
			</div>
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="bsimstat_format"><?= t_default('acp.bsimstat.format_label', 'Value representation') ?></label>
					<select class="acp-input" id="bsimstat_format" name="format">
						<?php foreach ($bsimFormats as $value => $label): ?>
							<option value="<?= h($value) ?>" <?= ((string) ($editing['format'] ?? 'value') === $value) ? 'selected' : '' ?>><?= h($label) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="bsimstat_active"><?= t('acp.settings.enabled') ?></label>
					<label style="display:flex;align-items:center;gap:8px;font-weight:400;min-height:34px;">
						<input type="checkbox" id="bsimstat_active" name="active" value="1" <?= empty($editing) || !empty($editing['active']) ? 'checked' : '' ?>>
						<span class="is-muted"><?= t('acp.settings.enabled') ?></span>
					</label>
				</div>
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? t_default('acp.bsimstat.save_btn', 'Save') : t_default('acp.bsimstat.add_btn', 'Add stat') ?></button>
				<?php if ($editing): ?>
					<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url('build_simulator__storage_stats')) ?>"><?= t_default('acp.bsimstat.cancel_btn', 'Cancel') ?></a>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimstat.list_title', 'Storage stats') ?></h2>
	</header>
	<div class="acp-card-body is-flush">
		<?php if ($stats): ?>
			<div class="acp-table-wrap">
				<table class="acp-table">
					<thead>
						<tr>
							<th></th>
							<th><?= t_default('acp.bsimstat.col_label', 'Label') ?></th>
							<th><?= t_default('acp.bsimstat.col_key', 'Storage key') ?></th>
							<th><?= t_default('acp.bsimstat.col_format', 'Format') ?></th>
							<th><?= t_default('acp.bsimstat.col_status', 'Status') ?></th>
							<th class="is-num"><?= t_default('acp.bsimstat.col_actions', 'Actions') ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($stats as $i => $s): ?>
							<tr>
								<td class="is-nowrap">
									<?php foreach (array('up' => 'fa-arrow-up', 'down' => 'fa-arrow-down') as $dir => $icon): ?>
										<?php if (($dir === 'up' && $i > 0) || ($dir === 'down' && $i < count($stats) - 1)): ?>
											<form class="acp-inline-form" method="post">
												<?= acp_csrf_field() ?>
												<input type="hidden" name="do" value="move">
												<input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
												<input type="hidden" name="dir" value="<?= $dir ?>">
												<button class="acp-btn acp-btn--ghost acp-btn--sm" type="submit"><i class="fa <?= $icon ?>"></i></button>
											</form>
										<?php endif; ?>
									<?php endforeach; ?>
								</td>
								<td><?= h((string) $s['label']) ?></td>
								<td><code><?= (int) $s['storage_key'] ?></code></td>
								<td class="is-muted"><?= h($bsimFormats[$s['format']] ?? (string) $s['format']) ?></td>
								<td>
									<span class="acp-pill acp-pill--<?= $s['active'] ? 'green' : 'grey' ?>">
										<?= $s['active'] ? t('acp.settings.enabled') : t_default('acp.bsimstat.status_off', 'Off') ?>
									</span>
								</td>
								<td class="is-nowrap is-num">
									<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url('build_simulator__storage_stats', ['edit' => (int) $s['id']])) ?>"><i class="fa fa-pencil"></i></a>
									<form class="acp-inline-form" method="post" data-confirm="<?= h(t_default('acp.bsimstat.confirm_delete', 'Remove this stat?')) ?>">
										<?= acp_csrf_field() ?>
										<input type="hidden" name="do" value="delete">
										<input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
										<button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<?php acp_empty(t_default('acp.bsimstat.empty', 'No storage stats configured.'), 'fa-database'); ?>
		<?php endif; ?>
	</div>
</section>
