<?php
/**
 * Title: Build Simulator Slots
 * Icon: fa-th-large
 * Group: Installed Plugins
 * Order: 38
 * Description: Which paperdoll slots the Build Simulator and Armory show, and what items.xml value(s) fill each one - add slots, reorder them, or fix the match values if your server engine uses a different vocabulary than the classic TFS/Canary one.
 */

if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

if (!function_exists('znote_table_exists') || !znote_table_exists('znote_build_sim_slots')) {
	acp_flash_error(t_default('acp.bsimslot.not_installed', 'Install the Build Simulator plugin first (Admin Panel > Plugins).'));
	acp_redirect('plugins');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!acp_verify_csrf()) {
		acp_flash_error(t_default('acp.csrf_failed', 'Your session expired, please try again.'));
		acp_redirect('build_simulator__slots');
	}

	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_build_sim_slots` WHERE `id` = ? LIMIT 1;", [$id]);
		acp_log('build_simulator.slot_delete', '#' . $id);
		acp_flash_success(t_default('acp.bsimslot.deleted', 'Slot removed.'));
		acp_redirect('build_simulator__slots');
	}

	if ($do === 'move' && $id > 0) {
		$ids = db()->fetchAll("SELECT `id` FROM `znote_build_sim_slots` ORDER BY `sort_order` ASC, `id` ASC;");
		$ids = is_array($ids) ? array_map('intval', array_column($ids, 'id')) : array();
		$pos = array_search($id, $ids, true);
		$swap = ((string) ($_POST['dir'] ?? '') === 'up') ? ((int) $pos - 1) : ((int) $pos + 1);

		if ($pos !== false && isset($ids[$swap])) {
			$ids[$pos] = $ids[$swap];
			$ids[$swap] = $id;
			foreach ($ids as $index => $rowId) {
				db()->execute("UPDATE `znote_build_sim_slots` SET `sort_order` = ? WHERE `id` = ? LIMIT 1;", [($index + 1) * 10, $rowId]);
			}
		}
		acp_redirect('build_simulator__slots');
	}

	if ($do === 'save') {
		$slotKey = strtolower(preg_replace('/[^a-z0-9_]/i', '', trim((string) ($_POST['slot_key'] ?? ''))));
		$label = substr(trim((string) ($_POST['label'] ?? '')), 0, 50);
		$matchValues = substr(trim((string) ($_POST['match_values'] ?? '')), 0, 255);
		$icon = substr(trim((string) ($_POST['icon'] ?? '')), 0, 255);
		$active = !empty($_POST['active']) ? 1 : 0;

		if ($slotKey === '' || $label === '' || $matchValues === '') {
			acp_flash_error(t_default('acp.bsimslot.missing_fields', 'Give the slot a key, a label and at least one match value.'));
			acp_redirect('build_simulator__slots');
		}

		if ($id > 0) {
			db()->execute("
				UPDATE `znote_build_sim_slots`
				SET `slot_key` = ?, `label` = ?, `match_values` = ?, `icon` = ?, `active` = ?
				WHERE `id` = ?
				LIMIT 1;
			", [$slotKey, $label, $matchValues, $icon, $active, $id]);
			acp_log('build_simulator.slot_update', '#' . $id);
			acp_flash_success(t_default('acp.bsimslot.updated', 'Slot updated.'));
		} else {
			$exists = db()->fetchOne("SELECT `id` FROM `znote_build_sim_slots` WHERE `slot_key` = ? LIMIT 1;", [$slotKey]);
			if (is_array($exists)) {
				acp_flash_error(t_default('acp.bsimslot.duplicate_key', 'A slot with that key already exists.'));
				acp_redirect('build_simulator__slots');
			}
			$nextOrder = db()->fetchOne("SELECT COALESCE(MAX(`sort_order`), 0) + 10 AS `n` FROM `znote_build_sim_slots`;");
			db()->execute("
				INSERT INTO `znote_build_sim_slots` (`slot_key`, `label`, `match_values`, `icon`, `active`, `sort_order`)
				VALUES (?, ?, ?, ?, ?, ?);
			", [$slotKey, $label, $matchValues, $icon, $active, (int) ($nextOrder['n'] ?? 10)]);
			acp_log('build_simulator.slot_create', $slotKey);
			acp_flash_success(t_default('acp.bsimslot.created', 'Slot added.'));
		}

		acp_redirect('build_simulator__slots');
	}
}

$slots = db()->fetchAll("SELECT * FROM `znote_build_sim_slots` ORDER BY `sort_order` ASC, `id` ASC;");
$slots = is_array($slots) ? $slots : array();

$editId = intv($_GET['edit'] ?? 0);
$editing = null;
if ($editId > 0) {
	foreach ($slots as $s) {
		if ((int) $s['id'] === $editId) { $editing = $s; break; }
	}
}
?>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimslot.form_title', 'Add / edit a slot') ?></h2>
		<p><?= t_default('acp.bsimslot.form_sub', 'match_values is a comma-separated list of items.xml slotType/weaponType values. Icon can point at an existing item image (e.g. ?znote_item_img=2643) or any other image URL - leave empty for the default "+" placeholder.') ?></p>
	</header>
	<div class="acp-card-body">
		<form method="post">
			<?= acp_csrf_field() ?>
			<input type="hidden" name="do" value="save">
			<input type="hidden" name="id" value="<?= (int) ($editing['id'] ?? 0) ?>">
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="bsimslot_key"><?= t_default('acp.bsimslot.key_label', 'Slot key') ?></label>
					<input class="acp-input" id="bsimslot_key" name="slot_key" value="<?= h((string) ($editing['slot_key'] ?? '')) ?>" placeholder="<?= h(t_default('acp.bsimslot.key_placeholder', 'e.g. ring2')) ?>" maxlength="32" <?= $editing ? 'readonly' : '' ?> required>
					<p class="acp-hint"><?= t_default('acp.bsimslot.key_help', 'Letters, digits and underscore only. Cannot be changed once created.') ?></p>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="bsimslot_label"><?= t_default('acp.bsimslot.label_label', 'Display label') ?></label>
					<input class="acp-input" id="bsimslot_label" name="label" value="<?= h((string) ($editing['label'] ?? '')) ?>" placeholder="<?= h(t_default('acp.bsimslot.label_placeholder', 'e.g. Second Ring')) ?>" maxlength="50" required>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="bsimslot_active"><?= t('acp.settings.enabled') ?></label>
					<label style="display:flex;align-items:center;gap:8px;font-weight:400;min-height:34px;">
						<input type="checkbox" id="bsimslot_active" name="active" value="1" <?= empty($editing) || !empty($editing['active']) ? 'checked' : '' ?>>
						<span class="is-muted"><?= t('acp.settings.enabled') ?></span>
					</label>
				</div>
			</div>
			<div class="acp-row">
				<div class="acp-field">
					<label class="acp-label" for="bsimslot_match"><?= t_default('acp.bsimslot.match_label', 'Match values') ?></label>
					<input class="acp-input" id="bsimslot_match" name="match_values" value="<?= h((string) ($editing['match_values'] ?? '')) ?>" placeholder="<?= h(t_default('acp.bsimslot.match_placeholder', 'e.g. ring')) ?>" maxlength="255" required>
				</div>
				<div class="acp-field">
					<label class="acp-label" for="bsimslot_icon"><?= t_default('acp.bsimslot.icon_label', 'Placeholder icon (optional)') ?></label>
					<input class="acp-input" id="bsimslot_icon" name="icon" value="<?= h((string) ($editing['icon'] ?? '')) ?>" placeholder="<?= h(t_default('acp.bsimslot.icon_placeholder', 'index.php?znote_item_img=2643')) ?>" maxlength="255">
				</div>
			</div>
			<div class="acp-actions">
				<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? t_default('acp.bsimslot.save_btn', 'Save') : t_default('acp.bsimslot.add_btn', 'Add slot') ?></button>
				<?php if ($editing): ?>
					<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url('build_simulator__slots')) ?>"><?= t_default('acp.bsimslot.cancel_btn', 'Cancel') ?></a>
				<?php endif; ?>
			</div>
		</form>
	</div>
</section>

<section class="acp-card">
	<header class="acp-card-head">
		<h2><?= t_default('acp.bsimslot.list_title', 'Slots') ?></h2>
	</header>
	<div class="acp-card-body is-flush">
		<?php if ($slots): ?>
			<div class="acp-table-wrap">
				<table class="acp-table">
					<thead>
						<tr>
							<th></th>
							<th><?= t_default('acp.bsimslot.col_label', 'Label') ?></th>
							<th><?= t_default('acp.bsimslot.col_key', 'Key') ?></th>
							<th><?= t_default('acp.bsimslot.col_match', 'Match values') ?></th>
							<th><?= t_default('acp.bsimslot.col_status', 'Status') ?></th>
							<th class="is-num"><?= t_default('acp.bsimslot.col_actions', 'Actions') ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($slots as $i => $s): ?>
							<tr>
								<td class="is-nowrap">
									<?php foreach (array('up' => 'fa-arrow-up', 'down' => 'fa-arrow-down') as $dir => $icon): ?>
										<?php if (($dir === 'up' && $i > 0) || ($dir === 'down' && $i < count($slots) - 1)): ?>
											<form class="acp-inline-form" method="post">
												<?= acp_csrf_field() ?>
												<input type="hidden" name="do" value="move">
												<input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
												<input type="hidden" name="dir" value="<?= $dir ?>">
												<button class="acp-btn acp-btn--ghost acp-btn--sm" type="submit"><i class="fa <?= $icon ?>"></i></button>
											</form>
										<?php endif; ?>
									<?php endforeach; ?>
								</td>
								<td><?= h((string) $s['label']) ?></td>
								<td><code><?= h((string) $s['slot_key']) ?></code></td>
								<td class="is-muted"><?= h((string) $s['match_values']) ?></td>
								<td>
									<span class="acp-pill acp-pill--<?= $s['active'] ? 'green' : 'grey' ?>">
										<?= $s['active'] ? t('acp.settings.enabled') : t_default('acp.bsimslot.status_off', 'Off') ?>
									</span>
								</td>
								<td class="is-nowrap is-num">
									<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url('build_simulator__slots', ['edit' => (int) $s['id']])) ?>"><i class="fa fa-pencil"></i></a>
									<form class="acp-inline-form" method="post" data-confirm="<?= h(t_default('acp.bsimslot.confirm_delete', 'Remove this slot?')) ?>">
										<?= acp_csrf_field() ?>
										<input type="hidden" name="do" value="delete">
										<input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
										<button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<?php acp_empty(t_default('acp.bsimslot.empty', 'No slots configured.'), 'fa-th-large'); ?>
		<?php endif; ?>
	</div>
</section>
