(function(){
	var card = document.querySelector('.ss-online');
	if (!card) return;
	var key = 'server_statistics_online_collapsed';
	var saved = null;
	try { saved = localStorage.getItem(key); } catch (e) {}
	if (saved === '0') card.classList.remove('ss-collapsed');
	var btn = card.querySelector('.ss-collapse');
	if (btn) btn.addEventListener('click', function(){
		var collapsed = card.classList.toggle('ss-collapsed');
		try { localStorage.setItem(key, collapsed ? '1' : '0'); } catch (e) {}
	});
})();
