<?php
if (!function_exists('server_statistics_setting')) {

function server_statistics_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('server_statistics:' . $key, $default) : $default;
}
function server_statistics_enabled(): bool { return server_statistics_setting('enabled', '1') === '1'; }
function server_statistics_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function server_statistics_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string) $v, $text);
	return $text;
}
function server_statistics_icon(string $name): string {
	$name = preg_replace('/^fa\s+/', '', trim($name));
	$name = preg_replace('/^fa-/', '', $name);
	$icons = array(
		'bar-chart' => '<path d="M4 19V9"/><path d="M9 19V5"/><path d="M14 19v-7"/><path d="M19 19V7"/><path d="M3 19h18"/>',
		'signal' => '<path d="M4 19v-3"/><path d="M8 19v-6"/><path d="M12 19v-9"/><path d="M16 19V7"/><path d="M20 19V4"/>',
		'line-chart' => '<path d="M3 17h18"/><path d="M5 14l4-4 4 3 6-7"/><path d="M15 6h4v4"/>',
		'users' => '<path d="M16 19c0-2-1.8-3.5-4-3.5S8 17 8 19"/><circle cx="12" cy="9" r="3"/><path d="M5.5 18c0-1.4 1.1-2.6 2.7-3.1"/><path d="M18.5 18c0-1.4-1.1-2.6-2.7-3.1"/><circle cx="6.5" cy="10" r="2"/><circle cx="17.5" cy="10" r="2"/>',
		'shield' => '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z"/>',
		'user-plus' => '<path d="M15 19c0-2.2-2.2-4-5-4s-5 1.8-5 4"/><circle cx="10" cy="8" r="3"/><path d="M18 8v6"/><path d="M15 11h6"/>',
		'calendar' => '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4"/><path d="M16 3v4"/><path d="M4 10h16"/>',
		'ban' => '<circle cx="12" cy="12" r="8"/><path d="M7 7l10 10"/>',
		'server' => '<rect x="4" y="5" width="16" height="5" rx="1"/><rect x="4" y="14" width="16" height="5" rx="1"/><path d="M8 7.5h.01"/><path d="M8 16.5h.01"/><path d="M12 7.5h4"/><path d="M12 16.5h4"/>',
		'chevron-up' => '<path d="M6 15l6-6 6 6"/>',
		'clock' => '<circle cx="12" cy="12" r="8"/><path d="M12 8v5l3 2"/>',
		'database' => '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
		'trophy' => '<path d="M8 4h8v4c0 3-1.8 5-4 5s-4-2-4-5V4z"/><path d="M8 6H5c0 3 1.2 5 4 5"/><path d="M16 6h3c0 3-1.2 5-4 5"/><path d="M12 13v4"/><path d="M8 21h8"/><path d="M9 17h6"/>',
		'map' => '<path d="M8 5l-4 2v13l4-2 8 2 4-2V5l-4 2-8-2z"/><path d="M8 5v13"/><path d="M16 7v13"/>',
		'refresh' => '<path d="M20 12a8 8 0 0 1-14 5"/><path d="M6 17H3v4"/><path d="M4 12a8 8 0 0 1 14-5"/><path d="M18 7h3V3"/>',
		'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
	);
	$body = $icons[$name] ?? $icons['user'];
	return '<svg class="ss-svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $body . '</svg>';
}
function server_statistics_ident(string $v): string {
	$v = trim($v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}
function server_statistics_int(string $key, int $default): int {
	$v = server_statistics_setting($key, '');
	return $v === '' ? $default : (int) $v;
}
function server_statistics_css_value(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function server_statistics_url(string $v): string {
	$v = trim($v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v) || preg_match('#^[a-zA-Z0-9_./-]+$#', $v)) ? $v : '';
}
function server_statistics_image_ref(string $v): string {
	$v = server_statistics_url($v);
	if ($v === '') return '';
	if (preg_match('#^(https?:)?//#i', $v) || $v[0] === '/') return $v;
	return server_statistics_asset($v) ?: $v;
}
function server_statistics_asset(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$path = __DIR__ . '/assets/img/' . $file;
	return is_file($path) ? znote_plugin_asset('server_statistics', 'img/' . $file) : '';
}
function server_statistics_img(string $setting, string $local): string {
	$url = server_statistics_image_ref(server_statistics_setting($setting, ''));
	return $url !== '' ? $url : server_statistics_asset($local);
}
function server_statistics_table(string $key, string $default): string { return server_statistics_ident(server_statistics_setting($key, '')) ?: $default; }
function server_statistics_col(string $table, string $key, array $candidates): string {
	$custom = server_statistics_ident(server_statistics_setting($key, ''));
	if ($custom !== '') return $custom;
	foreach ($candidates as $candidate) {
		if (function_exists('znote_column_exists') && znote_column_exists($table, $candidate)) return $candidate;
	}
	return $candidates[0] ?? '';
}
function server_statistics_table_ok(string $table): bool {
	return function_exists('znote_table_exists') && server_statistics_ident($table) !== '' && znote_table_exists($table);
}
function server_statistics_col_ok(string $table, string $col): bool {
	return function_exists('znote_column_exists') && server_statistics_ident($table) !== '' && server_statistics_ident($col) !== '' && znote_column_exists($table, $col);
}
function server_statistics_one(string $sql, int $fallback = 0): int {
	$row = function_exists('mysql_select_single') ? mysql_select_single($sql) : false;
	return is_array($row) ? (int) ($row['v'] ?? $fallback) : $fallback;
}
function server_statistics_rows(string $sql): array {
	$rows = function_exists('mysql_select_multi') ? mysql_select_multi($sql) : false;
	return is_array($rows) ? $rows : array();
}
function server_statistics_col_type(string $table, string $col): string {
	static $types = array();
	$key = $table . '.' . $col;
	if (isset($types[$key])) return $types[$key];
	if (!server_statistics_col_ok($table, $col)) return $types[$key] = '';
	$row = mysql_select_single("SHOW COLUMNS FROM `{$table}` LIKE '" . mysql_znote_escape_string($col) . "';");
	return $types[$key] = is_array($row) ? strtolower((string) ($row['Type'] ?? '')) : '';
}
function server_statistics_time_expr(string $table, string $col): string {
	$type = server_statistics_col_type($table, $col);
	return (strpos($type, 'int') !== false || strpos($type, 'decimal') !== false) ? "`{$col}`" : "UNIX_TIMESTAMP(`{$col}`)";
}
function server_statistics_json(string $key, array $default): array {
	$raw = trim(server_statistics_setting($key, ''));
	if ($raw === '') return $default;
	$data = json_decode($raw, true);
	return is_array($data) ? $data : $default;
}
function server_statistics_defaults_classes(): array {
	global $config;
	if (!empty($config['vocations']) && is_array($config['vocations'])) {
		$roots = array();
		foreach ($config['vocations'] as $id => $voc) {
			$id = (int) $id;
			if ($id <= 0) continue;
			$from = isset($voc['fromVoc']) && $voc['fromVoc'] !== false ? (int) $voc['fromVoc'] : $id;
			if (!isset($roots[$from])) $roots[$from] = array('ids' => array(), 'subs' => array());
			$roots[$from]['ids'][] = $id;
			$roots[$from]['subs'][(string) $id] = (string) ($voc['name'] ?? ('Vocation ' . $id));
		}
		$style = array(
			1 => array('name' => 'Sorcerer', 'color' => '#5b8dee', 'icon' => 'sorcerer.png', 'fa' => 'fa-magic'),
			2 => array('name' => 'Druid', 'color' => '#2ecc71', 'icon' => 'druid.png', 'fa' => 'fa-leaf'),
			3 => array('name' => 'Paladin', 'color' => '#f5c542', 'icon' => 'paladin.webp', 'fa' => 'fa-crosshairs'),
			4 => array('name' => 'Knight', 'color' => '#e74c3c', 'icon' => 'knight.webp', 'fa' => 'fa-shield'),
			9 => array('name' => 'Monk', 'color' => '#a855f7', 'icon' => 'monk.webp', 'fa' => 'fa-hand-rock-o'),
		);
		$out = array();
		foreach ($roots as $root => $group) {
			$base = $style[$root] ?? array('name' => (string) ($config['vocations'][$root]['name'] ?? ('Vocation ' . $root)), 'color' => '#4d8fff', 'icon' => '', 'fa' => 'fa-user');
			$out[] = $base + array('ids' => array_values(array_unique(array_map('intval', $group['ids']))), 'subs' => $group['subs']);
		}
		if ($out) return $out;
	}
	return array(
		array('name' => 'Sorcerer', 'ids' => array(1, 5), 'color' => '#5b8dee', 'icon' => 'sorcerer.png', 'fa' => 'fa-magic', 'subs' => array('1' => 'Sorcerer', '5' => 'Master Sorcerer')),
		array('name' => 'Druid', 'ids' => array(2, 6), 'color' => '#2ecc71', 'icon' => 'druid.png', 'fa' => 'fa-leaf', 'subs' => array('2' => 'Druid', '6' => 'Elder Druid')),
		array('name' => 'Paladin', 'ids' => array(3, 7), 'color' => '#f5c542', 'icon' => 'paladin.webp', 'fa' => 'fa-crosshairs', 'subs' => array('3' => 'Paladin', '7' => 'Royal Paladin')),
		array('name' => 'Knight', 'ids' => array(4, 8), 'color' => '#e74c3c', 'icon' => 'knight.webp', 'fa' => 'fa-shield', 'subs' => array('4' => 'Knight', '8' => 'Elite Knight')),
	);
}
function server_statistics_default_towns(): array {
	global $config;
	$towns = array();
	foreach ((array) ($config['towns'] ?? array()) as $id => $name) {
		$towns[] = array('id' => (int) $id, 'name' => (string) $name);
	}
	return $towns;
}
function server_statistics_player_meta(array $row): array {
	$voc = (int) ($row['vocation'] ?? 0);
	foreach (server_statistics_json('classes_json', server_statistics_defaults_classes()) as $class) {
		if (in_array($voc, array_map('intval', (array) ($class['ids'] ?? array())), true)) {
			return array('name' => (string) ($class['name'] ?? 'Adventurer'), 'color' => (string) ($class['color'] ?? '#4d8fff'), 'fa' => (string) ($class['fa'] ?? 'fa-user'));
		}
	}
	return array('name' => 'Adventurer', 'color' => '#4d8fff', 'fa' => 'fa-user');
}
function server_statistics_rank(int $rank): string {
	if ($rank === 1) return '1';
	if ($rank === 2) return '2';
	if ($rank === 3) return '3';
	return (string) $rank;
}
function server_statistics_start_time(): int {
	$date = trim(server_statistics_setting('launched_at', ''));
	if ($date === '' || $date === '2026-07-03 19:00:00') return 0;
	$t = strtotime($date);
	return $t !== false ? $t : 0;
}
function server_statistics_duration(int $seconds): string {
	$seconds = max(0, $seconds);
	$days = intdiv($seconds, 86400);
	$hours = intdiv($seconds % 86400, 3600);
	$minutes = intdiv($seconds % 3600, 60);
	return ($days > 0 ? $days . 'd ' : '') . $hours . 'h ' . $minutes . 'm';
}
function server_statistics_player_where(string $alias = ''): string {
	$pt = server_statistics_table('players_table', 'players');
	$groupCol = server_statistics_col($pt, 'players_group_col', array('group_id', 'group'));
	$prefix = $alias !== '' ? "`{$alias}`." : '';
	if (server_statistics_col_ok($pt, $groupCol)) return $prefix . "`{$groupCol}` < " . max(2, server_statistics_int('staff_group_min', 3));
	return '1=1';
}
function server_statistics_top_players(string $column, int $limit): array {
	$pt = server_statistics_table('players_table', 'players');
	if (!server_statistics_table_ok($pt) || !server_statistics_col_ok($pt, $column)) return array();
	$name = server_statistics_col($pt, 'players_name_col', array('name'));
	$level = server_statistics_col($pt, 'players_level_col', array('level'));
	$voc = server_statistics_col($pt, 'players_vocation_col', array('vocation'));
	$resets = server_statistics_col($pt, 'players_resets_col', array('resets', 'reset', 'rebirths'));
	$selectResets = server_statistics_col_ok($pt, $resets) ? "`{$resets}` AS resets" : "0 AS resets";
	$where = server_statistics_player_where();
	return server_statistics_rows("SELECT `{$name}` AS name, `{$level}` AS level, `{$voc}` AS vocation, {$selectResets}, `{$column}` AS v FROM `{$pt}` WHERE {$where} ORDER BY `{$column}` DESC, `{$level}` DESC LIMIT {$limit};");
}
function server_statistics_class_distribution(): array {
	$pt = server_statistics_table('players_table', 'players');
	$vc = server_statistics_col($pt, 'players_vocation_col', array('vocation'));
	if (!server_statistics_table_ok($pt) || !server_statistics_col_ok($pt, $vc)) return array();
	$where = server_statistics_player_where();
	$total = max(1, server_statistics_one("SELECT COUNT(*) AS v FROM `{$pt}` WHERE {$where}", 1));
	$counts = array();
	foreach (server_statistics_rows("SELECT `{$vc}` AS vocation, COUNT(*) AS v FROM `{$pt}` WHERE {$where} GROUP BY `{$vc}`") as $row) {
		$counts[(string) (int) $row['vocation']] = (int) $row['v'];
	}
	$out = array();
	foreach (server_statistics_json('classes_json', server_statistics_defaults_classes()) as $class) {
		$count = 0; $subs = array();
		foreach ((array) ($class['ids'] ?? array()) as $id) {
			$id = (string) (int) $id;
			$c = $counts[$id] ?? 0;
			$count += $c;
			$label = (string) (($class['subs'][$id] ?? '') ?: ('Vocation ' . $id));
			if ($c > 0 || server_statistics_setting('show_empty_classes', '1') === '1') $subs[] = array('name' => $label, 'value' => $c);
		}
		if ($count > 0 || server_statistics_setting('show_empty_classes', '1') === '1') {
			$out[] = array('name' => (string) ($class['name'] ?? 'Class'), 'count' => $count, 'pct' => round(($count / $total) * 100, 1), 'color' => (string) ($class['color'] ?? '#4d8fff'), 'icon' => server_statistics_img('icon_' . strtolower(preg_replace('/[^a-z0-9]+/i', '_', (string) ($class['name'] ?? 'class'))), (string) ($class['icon'] ?? '')), 'fa' => (string) ($class['fa'] ?? 'fa-user'), 'subs' => $subs);
		}
	}
	usort($out, static fn($a, $b) => $b['count'] <=> $a['count']);
	return $out;
}
function server_statistics_registrations(): array {
	$at = server_statistics_table('accounts_table', 'accounts');
	$created = server_statistics_col($at, 'accounts_created_col', array('creation', 'created', 'created_at'));
	$days = max(7, min(60, server_statistics_int('chart_days', 14)));
	$out = array(); $total = 0;
	for ($i = $days - 1; $i >= 0; $i--) {
		$start = strtotime("-{$i} days 00:00:00");
		$end = $start + 86400;
		$v = 0;
		if (server_statistics_table_ok($at) && server_statistics_col_ok($at, $created)) {
			$expr = server_statistics_time_expr($at, $created);
			$v = server_statistics_one("SELECT COUNT(*) AS v FROM `{$at}` WHERE {$expr} >= {$start} AND {$expr} < {$end}", 0);
		}
		$total += $v;
		$out[] = array('label' => date('d.m', $start), 'value' => $v, 'today' => $i === 0);
	}
	return array('items' => $out, 'total' => $total, 'max' => max(1, max(array_map(static fn($r) => (int) $r['value'], $out))));
}
function server_statistics_online_count(): int {
	$pt = server_statistics_table('players_table', 'players');
	$onlineTable = server_statistics_table('online_table', 'players_online');
	$onlineCol = server_statistics_col($pt, 'players_online_col', array('online'));
	if (server_statistics_table_ok($onlineTable)) {
		$idCol = server_statistics_col($pt, 'players_id_col', array('id'));
		if (server_statistics_table_ok($pt) && server_statistics_col_ok($pt, $idCol) && server_statistics_col_ok($onlineTable, 'player_id')) {
			return server_statistics_one("SELECT COUNT(*) AS v FROM `{$onlineTable}` `o` INNER JOIN `{$pt}` `p` ON `p`.`{$idCol}` = `o`.`player_id` WHERE " . server_statistics_player_where('p'), 0);
		}
		return server_statistics_one("SELECT COUNT(*) AS v FROM `{$onlineTable}`", 0);
	}
	if (server_statistics_table_ok($pt) && server_statistics_col_ok($pt, $onlineCol)) return server_statistics_one("SELECT COUNT(*) AS v FROM `{$pt}` WHERE `{$onlineCol}` > 0", 0);
	return 0;
}
function server_statistics_server_online(int $online): bool {
	global $config;
	if ($online > 0) return true;
	$enabled = !empty($config['status']['status_check']) || server_statistics_setting('status_check', '0') === '1';
	if (!$enabled) return false;
	$host = trim(server_statistics_setting('status_host', (string) ($config['status']['status_ip'] ?? $config['gameserver']['ip'] ?? '127.0.0.1')));
	$port = (int) server_statistics_setting('status_port', (string) ($config['status']['status_port'] ?? $config['port'] ?? 7171));
	if ($host === '' || $port <= 0 || !function_exists('fsockopen')) return false;
	$errno = 0; $errstr = '';
	$fp = @fsockopen($host, $port, $errno, $errstr, 1.0);
	if (!$fp) return false;
	fclose($fp);
	return true;
}
function server_statistics_banned_count(): int {
	$now = time();
	if (server_statistics_table_ok('account_bans')) {
		if (server_statistics_col_ok('account_bans', 'expires_at')) return server_statistics_one("SELECT COUNT(*) AS v FROM `account_bans` WHERE `expires_at` = 0 OR `expires_at` > {$now}", 0);
		return server_statistics_one("SELECT COUNT(*) AS v FROM `account_bans`", 0);
	}
	if (server_statistics_table_ok('bans')) {
		$where = server_statistics_col_ok('bans', 'active') ? "`active` = 1" : '1=1';
		if (server_statistics_col_ok('bans', 'expires')) $where .= " AND (`expires` = 0 OR `expires` > {$now})";
		return server_statistics_one("SELECT COUNT(*) AS v FROM `bans` WHERE {$where}", 0);
	}
	if (server_statistics_table_ok('player_bans')) return server_statistics_one("SELECT COUNT(*) AS v FROM `player_bans`", 0);
	return 0;
}
function server_statistics_selected_towns(): array {
	$pt = server_statistics_table('players_table', 'players');
	$townCol = server_statistics_col($pt, 'players_town_col', array('town_id', 'townid'));
	if (!server_statistics_table_ok($pt) || !server_statistics_col_ok($pt, $townCol)) return array();
	$towns = server_statistics_json('towns_json', server_statistics_default_towns());
	$names = array();
	foreach ($towns as $town) {
		$id = (int) ($town['id'] ?? 0);
		if ($id > 0) $names[$id] = (string) ($town['name'] ?? ('Town ' . $id));
	}
	$where = server_statistics_player_where();
	$rows = server_statistics_rows("SELECT `{$townCol}` AS town_id, COUNT(*) AS v FROM `{$pt}` WHERE {$where} GROUP BY `{$townCol}` ORDER BY v DESC;");
	$counts = array();
	foreach ($rows as $row) $counts[(int) $row['town_id']] = (int) $row['v'];
	$total = max(1, array_sum($counts));
	$out = array();
	foreach ($names as $id => $name) {
		$value = $counts[$id] ?? 0;
		$out[] = array('name' => $name, 'value' => $value, 'pct' => round(($value / $total) * 100));
	}
	usort($out, static fn($a, $b) => ($b['value'] <=> $a['value']) ?: strcmp($a['name'], $b['name']));
	return $out;
}
function server_statistics_richest(): array {
	$pt = server_statistics_table('players_table', 'players');
	$balanceCol = server_statistics_col($pt, 'players_balance_col', array('balance'));
	if (!server_statistics_table_ok($pt) || !server_statistics_col_ok($pt, $balanceCol)) return array('name' => '', 'value' => 0);
	$name = server_statistics_col($pt, 'players_name_col', array('name'));
	$where = server_statistics_player_where();
	$row = mysql_select_single("SELECT `{$name}` AS name, `{$balanceCol}` AS v FROM `{$pt}` WHERE {$where} ORDER BY `{$balanceCol}` DESC LIMIT 1;");
	return is_array($row) ? array('name' => (string) $row['name'], 'value' => (int) $row['v']) : array('name' => '', 'value' => 0);
}
function server_statistics_total_balance(): int {
	$pt = server_statistics_table('players_table', 'players');
	$balanceCol = server_statistics_col($pt, 'players_balance_col', array('balance'));
	if (!server_statistics_table_ok($pt) || !server_statistics_col_ok($pt, $balanceCol)) return 0;
	return server_statistics_one("SELECT COALESCE(SUM(`{$balanceCol}`),0) AS v FROM `{$pt}` WHERE " . server_statistics_player_where(), 0);
}
function server_statistics_top_guild(): array {
	$gt = server_statistics_table('guilds_table', 'guilds');
	if (!server_statistics_table_ok($gt)) return array('name' => '', 'score' => 0);
	$name = server_statistics_col($gt, 'guilds_name_col', array('name'));
	$score = server_statistics_col($gt, 'guilds_score_col', array('guild_level', 'guild_experience', 'balance'));
	if (server_statistics_col_ok($gt, $score)) {
		$row = mysql_select_single("SELECT `{$name}` AS name, `{$score}` AS score FROM `{$gt}` ORDER BY `{$score}` DESC LIMIT 1;");
		return is_array($row) ? array('name' => (string) $row['name'], 'score' => (int) $row['score']) : array('name' => '', 'score' => 0);
	}
	return array('name' => '', 'score' => 0);
}
function server_statistics_guild_member_stats(int $guilds): array {
	if (!server_statistics_table_ok('guild_membership')) return array('members' => 0, 'avg' => 0);
	$members = server_statistics_one("SELECT COUNT(*) AS v FROM `guild_membership`", 0);
	return array('members' => $members, 'avg' => $guilds > 0 ? (int) floor($members / max(1, $guilds)) : 0);
}
function server_statistics_data(): array {
	$pt = server_statistics_table('players_table', 'players');
	$at = server_statistics_table('accounts_table', 'accounts');
	$gt = server_statistics_table('guilds_table', 'guilds');
	$levelCol = server_statistics_col($pt, 'players_level_col', array('level'));
	$resetsCol = server_statistics_col($pt, 'players_resets_col', array('resets', 'reset', 'rebirths'));
	$createdCol = server_statistics_col($at, 'accounts_created_col', array('creation', 'created', 'created_at'));
	$online = server_statistics_online_count();
	if (function_exists('znote_record_update')) znote_record_update($online);
	$accounts = server_statistics_table_ok($at) ? server_statistics_one("SELECT COUNT(*) AS v FROM `{$at}`", 0) : server_statistics_int('fallback_accounts', 1802);
	$chars = server_statistics_table_ok($pt) ? server_statistics_one("SELECT COUNT(*) AS v FROM `{$pt}` WHERE " . server_statistics_player_where(), 0) : server_statistics_int('fallback_characters', 474);
	$guilds = server_statistics_table_ok($gt) ? server_statistics_one("SELECT COUNT(*) AS v FROM `{$gt}`", 0) : server_statistics_int('fallback_guilds', 12);
	$createdExpr = server_statistics_table_ok($at) && server_statistics_col_ok($at, $createdCol) ? server_statistics_time_expr($at, $createdCol) : '';
	$today = $createdExpr !== '' ? server_statistics_one("SELECT COUNT(*) AS v FROM `{$at}` WHERE {$createdExpr} >= " . strtotime('today'), 0) : server_statistics_int('fallback_new_today', 1);
	$week = $createdExpr !== '' ? server_statistics_one("SELECT COUNT(*) AS v FROM `{$at}` WHERE {$createdExpr} >= " . strtotime('-7 days'), 0) : server_statistics_int('fallback_new_week', 9);
	$banned = server_statistics_banned_count();
	$record = function_exists('znote_record_get') ? znote_record_get() : array('players' => 0, 'time' => 0);
	$peak = max($online, (int) ($record['players'] ?? 0));
	$topLevel = server_statistics_top_players($levelCol, max(3, min(20, server_statistics_int('ranking_limit', 5))));
	$topResets = server_statistics_col_ok($pt, $resetsCol) ? server_statistics_top_players($resetsCol, max(3, min(20, server_statistics_int('ranking_limit', 5)))) : array();
	$towns = server_statistics_selected_towns();
	$richest = server_statistics_richest();
	$topGuild = server_statistics_top_guild();
	$guildStats = server_statistics_guild_member_stats($guilds);
	return array(
		'online' => $online, 'peak' => $peak, 'accounts' => $accounts, 'characters' => $chars, 'guilds' => $guilds, 'new_today' => $today, 'new_week' => $week, 'banned' => $banned,
		'classes' => server_statistics_class_distribution(), 'registrations' => server_statistics_registrations(), 'top_level' => $topLevel, 'top_resets' => $topResets,
		'towns' => $towns, 'richest' => $richest, 'total_balance' => server_statistics_total_balance(), 'top_guild' => $topGuild, 'guild_members' => $guildStats['members'], 'guild_avg' => $guildStats['avg'],
		'started' => server_statistics_start_time(),
		'server_online' => server_statistics_server_online($online),
		'engine' => (string) ($GLOBALS['config']['ServerEngineReal'] ?? $GLOBALS['config']['ServerEngine'] ?? ''),
	);
}
function server_statistics_style_attr(): string {
	$map = array('panel_bg' => '--ss-panel', 'card_bg' => '--ss-card', 'inner_bg' => '--ss-inner', 'border' => '--ss-border', 'text' => '--ss-text', 'muted' => '--ss-muted', 'title' => '--ss-title', 'accent' => '--ss-accent', 'green' => '--ss-green', 'blue' => '--ss-blue', 'purple' => '--ss-purple', 'orange' => '--ss-orange', 'red' => '--ss-red');
	$css = '';
	foreach ($map as $key => $var) { $v = server_statistics_css_value(server_statistics_setting('style_' . $key, '')); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	$bg = server_statistics_img('background_img', 'server-statistics-bg.jpg');
	if ($bg !== '') $css .= '--ss-bg:url("' . server_statistics_h($bg) . '");';
	$radius = max(0, min(30, server_statistics_int('style_radius', 14)));
	$css .= '--ss-radius:' . $radius . 'px;';
	return $css !== '' ? ' style="' . server_statistics_h($css) . '"' : '';
}
function server_statistics_page_title($title, array $data = array()) {
	if (($data['plugin'] ?? '') === 'server_statistics') {
		$custom = trim(server_statistics_setting('page_title', ''));
		return $custom !== '' ? $custom : server_statistics_t('server_statistics.title', 'Server Statistics');
	}
	return $title;
}
function server_statistics_sync_menu(): void {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_menu')) return;
	mysql_delete("DELETE FROM `znote_menu` WHERE `url` = 'page.php?plugin=server_statistics&p=index';");
	if (!server_statistics_enabled() || server_statistics_setting('show_in_menu', '1') !== '1') return;
	$p = mysql_select_single("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` LIKE '%communit%' ORDER BY `id` ASC LIMIT 1;");
	$parent = is_array($p) ? (int) $p['id'] : 0;
	if ($parent > 0) {
		$mx = mysql_select_single("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = {$parent};");
		$sort = is_array($mx) ? (int) $mx['s'] + 1 : 1;
	} else {
		$sort = 58;
	}
	mysql_insert("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',{$parent},'Server Statistics','page.php?plugin=server_statistics&p=index','fa-bar-chart','all',{$sort},1);");
}
function server_statistics_ensure_menu(): void {
	static $done = false;
	if ($done || !function_exists('setting')) return;
	$done = true;
	$state = 'v2:' . (server_statistics_enabled() ? '1' : '0') . (server_statistics_setting('show_in_menu', '1') === '1' ? '1' : '0');
	if (setting('server_statistics:menu_v', '') === $state) return;
	server_statistics_sync_menu();
	if (function_exists('setting_set')) setting_set('server_statistics:menu_v', $state);
}
if (function_exists('znote_hook_register')) znote_hook_register('page.title', 'server_statistics_page_title');

}

server_statistics_ensure_menu();
