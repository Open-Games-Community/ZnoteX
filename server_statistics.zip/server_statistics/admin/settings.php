<?php
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'server_statistics__settings';
function ss_admin_color($v): string { return server_statistics_css_value((string) $v); }
function ss_admin_ident($v): string { return server_statistics_ident((string) $v); }
function ss_admin_url($v): string { return server_statistics_url((string) $v); }
function ss_admin_json($v, array $fallback): string {
	$v = trim((string) $v);
	if ($v === '') return json_encode($fallback, JSON_PRETTY_PRINT);
	json_decode($v, true);
	return json_last_error() === JSON_ERROR_NONE ? $v : json_encode($fallback, JSON_PRETTY_PRINT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	setting_set('server_statistics:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('server_statistics:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
	setting_set('server_statistics:status_check', !empty($_POST['status_check']) ? '1' : '0');
	foreach (array('page_title','live_badge','country_name','country_flag','background_img','launched_at','top_guild_name','top_guild_score','richest_player','status_host','status_port') as $key) {
		setting_set('server_statistics:' . $key, trim((string) ($_POST[$key] ?? '')));
	}
	foreach (array('fallback_accounts','fallback_characters','fallback_guilds','fallback_new_today','fallback_new_week','chart_days','ranking_limit','staff_group_min','style_radius') as $key) {
		setting_set('server_statistics:' . $key, (string) max(0, intv($_POST[$key] ?? 0)));
	}
	foreach (array('players_table','players_id_col','players_name_col','players_level_col','players_vocation_col','players_online_col','players_resets_col','players_group_col','players_town_col','players_balance_col','online_table','accounts_table','accounts_created_col','guilds_table','guilds_name_col','guilds_score_col') as $key) {
		setting_set('server_statistics:' . $key, ss_admin_ident($_POST[$key] ?? ''));
	}
	foreach (array('sorcerer','druid','paladin','knight','monk') as $key) {
		setting_set('server_statistics:icon_' . $key, ss_admin_url($_POST['icon_' . $key] ?? ''));
	}
	foreach (array('panel_bg','card_bg','inner_bg','border','text','muted','title','accent','green','blue','purple','orange','red') as $key) {
		setting_set('server_statistics:style_' . $key, ss_admin_color($_POST['style_' . $key] ?? ''));
	}
	setting_set('server_statistics:classes_json', ss_admin_json($_POST['classes_json'] ?? '', server_statistics_defaults_classes()));
	setting_set('server_statistics:towns_json', ss_admin_json($_POST['towns_json'] ?? '', server_statistics_default_towns()));
	setting_set('server_statistics:show_empty_classes', !empty($_POST['show_empty_classes']) ? '1' : '0');
	if (function_exists('acp_log')) acp_log('server_statistics.save', 'settings');
	acp_flash_success('Server Statistics settings saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('server_statistics:' . $k, $d);
$classesJson = $get('classes_json', json_encode(server_statistics_defaults_classes(), JSON_PRETTY_PRINT));
$townsJson = $get('towns_json', json_encode(server_statistics_default_towns(), JSON_PRETTY_PRINT));
?>

<?php acp_card_open('Server Statistics', 'Server statistics page. Public URL: page.php?plugin=server_statistics&p=index'); ?>
<form method="post">
	<?= acp_csrf_field() ?>

	<h3>General</h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Show under Community menu</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="status_check" value="1" <?= $get('status_check', '0') === '1' ? 'checked' : '' ?>> Check server port when online list is empty</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_empty_classes" value="1" <?= $get('show_empty_classes', '1') === '1' ? 'checked' : '' ?>> Show empty classes</label></div>
		<div class="acp-field"><label class="acp-label">Page title</label><input class="acp-input" name="page_title" value="<?= h($get('page_title', 'Server Statistics')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Live badge text</label><input class="acp-input" name="live_badge" value="<?= h($get('live_badge', 'LIVE - Updated on load')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Country / region name</label><input class="acp-input" name="country_name" value="<?= h($get('country_name', 'Europe')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Country / region flag URL</label><input class="acp-input" name="country_flag" value="<?= h($get('country_flag', 'https://flagcdn.com/eu.svg')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Background image URL or plugin file</label><input class="acp-input" name="background_img" value="<?= h($get('background_img', '')) ?>" placeholder="server-statistics-bg.jpg"></div>
		<div class="acp-field"><label class="acp-label">Launched at</label><input class="acp-input" name="launched_at" value="<?= h($get('launched_at', '')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Status host</label><input class="acp-input" name="status_host" value="<?= h($get('status_host', '127.0.0.1')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Status port</label><input class="acp-input" name="status_port" value="<?= h($get('status_port', '7171')) ?>"></div>
	</div>

	<h3>Fallback and Display Values</h3>
	<div class="acp-grid acp-grid--3">
		<?php foreach (array('fallback_accounts' => 0, 'fallback_characters' => 0, 'fallback_guilds' => 0, 'fallback_new_today' => 0, 'fallback_new_week' => 0, 'chart_days' => 14, 'ranking_limit' => 5, 'staff_group_min' => 3) as $key => $default): ?>
			<?php $label = ucwords(str_replace('_', ' ', $key)); ?>
			<div class="acp-field"><label class="acp-label"><?= h($label) ?></label><input class="acp-input" type="number" name="<?= h($key) ?>" value="<?= (int) $get($key, (string) $default) ?>"></div>
		<?php endforeach; ?>
		<div class="acp-field"><label class="acp-label">Richest player</label><input class="acp-input" name="richest_player" value="<?= h($get('richest_player', 'Knightmare')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Top guild name</label><input class="acp-input" name="top_guild_name" value="<?= h($get('top_guild_name', 'Exodus')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Top guild score</label><input class="acp-input" name="top_guild_score" value="<?= h($get('top_guild_score', '2')) ?>"></div>
	</div>

	<h3>Database Mapping</h3>
	<div class="acp-grid acp-grid--3">
		<?php foreach (array('players_table' => 'players', 'players_id_col' => 'id', 'players_name_col' => 'name', 'players_level_col' => 'level', 'players_vocation_col' => 'vocation', 'players_online_col' => 'online', 'players_resets_col' => 'resets', 'players_group_col' => 'group_id', 'players_town_col' => 'town_id', 'players_balance_col' => 'balance', 'online_table' => 'players_online', 'accounts_table' => 'accounts', 'accounts_created_col' => 'creation', 'guilds_table' => 'guilds', 'guilds_name_col' => 'name', 'guilds_score_col' => 'guild_level') as $key => $default): ?>
			<div class="acp-field"><label class="acp-label"><?= h(ucwords(str_replace('_', ' ', $key))) ?></label><input class="acp-input" name="<?= h($key) ?>" value="<?= h($get($key, $default)) ?>"></div>
		<?php endforeach; ?>
	</div>

	<h3>Vocation Images</h3>
	<div class="acp-grid acp-grid--3">
		<?php foreach (array('sorcerer' => 'sorcerer.png', 'druid' => 'druid.png', 'paladin' => 'paladin.webp', 'knight' => 'knight.webp', 'monk' => 'monk.webp') as $key => $default): ?>
			<div class="acp-field"><label class="acp-label"><?= h(ucfirst($key)) ?> image</label><input class="acp-input" name="icon_<?= h($key) ?>" value="<?= h($get('icon_' . $key, $default)) ?>"></div>
		<?php endforeach; ?>
	</div>

	<h3>Style</h3>
	<div class="acp-grid acp-grid--3">
		<?php foreach (array('panel_bg'=>'rgba(17,24,39,.9)','card_bg'=>'rgba(17,24,39,.9)','inner_bg'=>'rgba(13,17,23,.92)','border'=>'rgba(100,160,210,.2)','text'=>'#d9e2ef','muted'=>'#71829a','title'=>'#9fd3ff','accent'=>'#8ab4d6','green'=>'#22d47a','blue'=>'#4d8fff','purple'=>'#a855f7','orange'=>'#f97316','red'=>'#f04455') as $key => $default): ?>
			<div class="acp-field"><label class="acp-label"><?= h(ucwords(str_replace('_', ' ', $key))) ?></label><input class="acp-input" name="style_<?= h($key) ?>" value="<?= h($get('style_' . $key, $default)) ?>"></div>
		<?php endforeach; ?>
		<div class="acp-field"><label class="acp-label">Border radius</label><input class="acp-input" type="number" name="style_radius" value="<?= (int) $get('style_radius', '14') ?>"></div>
	</div>

	<h3>Classes / Vocations JSON</h3>
	<div class="acp-field"><textarea class="acp-textarea" name="classes_json" rows="16" spellcheck="false"><?= h($classesJson) ?></textarea></div>

	<h3>Town Names JSON</h3>
	<div class="acp-field"><textarea class="acp-textarea" name="towns_json" rows="12" spellcheck="false"><?= h($townsJson) ?></textarea></div>

	<div class="acp-actions">
		<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save settings</button>
		<a class="acp-btn acp-btn--ghost" href="../page.php?plugin=server_statistics&p=index" target="_blank">Open page</a>
	</div>
</form>
<?php acp_card_close(); ?>
