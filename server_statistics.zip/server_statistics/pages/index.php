<?php
/**
 * Public page: page.php?plugin=server_statistics&p=index
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }
if (!server_statistics_enabled()) { echo '<p>' . server_statistics_h(server_statistics_t('server_statistics.disabled', 'Server statistics are disabled.')) . '</p>'; return; }

$h = 'server_statistics_h';
$data = server_statistics_data();
$stats = array(
	array('key' => 'online', 'icon' => 'fa-signal', 'color' => 'var(--ss-green)', 'label' => server_statistics_t('server_statistics.online_now', 'Online Now')),
	array('key' => 'peak', 'icon' => 'fa-line-chart', 'color' => 'var(--ss-blue)', 'label' => server_statistics_t('server_statistics.peak_online', 'Peak Online')),
	array('key' => 'accounts', 'icon' => 'fa-users', 'color' => '#8ab4d6', 'label' => server_statistics_t('server_statistics.accounts', 'Accounts')),
	array('key' => 'characters', 'icon' => 'fa-users', 'color' => 'var(--ss-purple)', 'label' => server_statistics_t('server_statistics.characters', 'Characters')),
	array('key' => 'guilds', 'icon' => 'fa-shield', 'color' => 'var(--ss-orange)', 'label' => server_statistics_t('server_statistics.guilds', 'Guilds')),
	array('key' => 'new_today', 'icon' => 'fa-user-plus', 'color' => 'var(--ss-green)', 'label' => server_statistics_t('server_statistics.new_today', 'New Today')),
	array('key' => 'new_week', 'icon' => 'fa-calendar', 'color' => 'var(--ss-blue)', 'label' => server_statistics_t('server_statistics.new_week', 'New This Week')),
	array('key' => 'banned', 'icon' => 'fa-ban', 'color' => 'var(--ss-red)', 'label' => server_statistics_t('server_statistics.banned', 'Banned')),
);
$country = trim(server_statistics_setting('country_name', 'Europe'));
$flag = trim(server_statistics_setting('country_flag', 'https://flagcdn.com/eu.svg'));
$pageTitle = trim(server_statistics_setting('page_title', ''));
$liveBadge = trim(server_statistics_setting('live_badge', ''));
$topGuild = $data['top_guild']['name'] !== '' ? $data['top_guild']['name'] : trim(server_statistics_setting('top_guild_name', ''));
$topGuildScore = $data['top_guild']['score'] > 0 ? (string) $data['top_guild']['score'] : trim(server_statistics_setting('top_guild_score', '0'));
$goldTotal = (int) $data['total_balance'];
$richestName = $data['richest']['name'] !== '' ? $data['richest']['name'] : trim(server_statistics_setting('richest_player', ''));
$richestValue = (int) $data['richest']['value'];
?>
<link rel="stylesheet" href="<?= $h(znote_plugin_asset('server_statistics', 'css/server-statistics.css')) ?>">

<div class="ss-wrap" <?= server_statistics_style_attr() ?>>
	<div class="ss-hero">
		<div class="ss-container">
			<div class="ss-titlebar">
				<div>
					<div class="ss-kicker"><?= $h(server_statistics_t('server_statistics.live_data', 'Live Data')) ?></div>
					<h1><span><?= server_statistics_icon('bar-chart') ?></span><?= $h($pageTitle !== '' ? $pageTitle : server_statistics_t('server_statistics.title', 'Server Statistics')) ?></h1>
				</div>
				<div class="ss-live<?= $data['server_online'] ? '' : ' is-offline' ?>"><i></i><?= $h($data['server_online'] ? ($liveBadge !== '' ? $liveBadge : server_statistics_t('server_statistics.live_updated', 'LIVE - Updated on load')) : server_statistics_t('server_statistics.offline', 'OFFLINE - no online players')) ?></div>
			</div>
			<div class="ss-statgrid">
				<?php foreach ($stats as $i => $stat): ?>
					<div class="ss-stat" style="--ss-stat:<?= $h($stat['color']) ?>;animation-delay:<?= number_format($i * .07, 2) ?>s">
						<div class="ss-stat-ico"><?= server_statistics_icon($stat['icon']) ?></div>
						<div class="ss-stat-num"><?= number_format((int) $data[$stat['key']]) ?></div>
						<div class="ss-stat-lbl"><?= $h($stat['label']) ?></div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="ss-container ss-main">
		<section class="ss-online ss-collapsed<?= $data['server_online'] ? '' : ' ss-offline' ?>">
			<div class="ss-online-hd">
				<div class="ss-online-title">
					<span><?= server_statistics_icon('server') ?></span>
					<div>
						<strong><?= $h(server_statistics_t($data['server_online'] ? 'server_statistics.server_online' : 'server_statistics.server_offline', $data['server_online'] ? 'Server Online' : 'Server Offline')) ?></strong>
						<small>
							<?php if ($data['server_online'] && $data['started'] > 0): ?><?= $h(server_statistics_t('server_statistics.since', 'Since {date}', array('date' => date('d M Y', $data['started'])))) ?><?php else: ?><?= $h(server_statistics_t('server_statistics.status_checked', 'Status checked on load')) ?><?php endif; ?>
							<?php if ($country !== ''): ?> <em></em> <?php if ($flag !== ''): ?><img src="<?= $h($flag) ?>" alt=""><?php endif; ?><?= $h($country) ?><?php endif; ?>
							<?php if ($data['engine'] !== ''): ?> <em></em> <?= $h($data['engine']) ?><?php endif; ?>
						</small>
					</div>
				</div>
				<button class="ss-collapse" type="button" title="<?= $h(server_statistics_t('server_statistics.toggle', 'Collapse / expand')) ?>"><?= server_statistics_icon('chevron-up') ?></button>
			</div>
			<div class="ss-online-body">
				<div class="ss-stability">
					<div class="ss-section-title"><?= server_statistics_icon('signal') ?><?= $h(server_statistics_t('server_statistics.server_stability', 'Server Stability')) ?><b><?= $h($data['server_online'] ? '100% - ' . server_statistics_t('server_statistics.fully_stable', 'Fully stable') : server_statistics_t('server_statistics.offline_short', 'Offline')) ?></b></div>
					<div class="ss-segments"><?php for ($i = 0; $i < 28; $i++): ?><span style="animation-delay:<?= number_format($i * .05, 2) ?>s"></span><?php endfor; ?></div>
					<div class="ss-stability-foot"><span>0% - <?= $h(server_statistics_t('server_statistics.just_launched', 'just launched')) ?></span><span>100% - <?= $h(server_statistics_t('server_statistics.proven_stable', '30d proven stable')) ?></span></div>
				</div>
				<div class="ss-online-foot">
					<span><?= server_statistics_icon('clock') ?> <?= $h(server_statistics_t('server_statistics.runtime', 'Runtime:')) ?> <b><?= $h($data['server_online'] ? ($data['started'] > 0 ? server_statistics_duration(time() - $data['started']) : server_statistics_t('server_statistics.not_available', 'N/A')) : server_statistics_t('server_statistics.offline_short', 'Offline')) ?></b></span>
					<span><?= server_statistics_icon('calendar') ?> <?= $h(server_statistics_t('server_statistics.launched', 'Launched:')) ?> <b><?= $h($data['server_online'] && $data['started'] > 0 ? date('d M Y, H:i', $data['started']) : server_statistics_t('server_statistics.not_available', 'N/A')) ?></b></span>
				</div>
			</div>
		</section>

		<div class="ss-columns">
			<div>
				<section class="ss-panel">
					<div class="ss-section-title"><i class="fa fa-users"></i><?= $h(server_statistics_t('server_statistics.class_distribution', 'Class Distribution')) ?></div>
					<?php foreach ($data['classes'] as $class): ?>
						<div class="ss-class" style="--cc:<?= $h($class['color']) ?>">
							<span class="ss-class-img"><?php if ($class['icon'] !== ''): ?><img src="<?= $h($class['icon']) ?>" alt=""><?php endif; ?></span>
							<div class="ss-class-mid">
								<div class="ss-class-top"><strong><?= $h($class['name']) ?></strong><span><?= number_format((int) $class['count']) ?> <b><?= $h($class['pct']) ?>%</b></span></div>
								<div class="ss-bar"><i style="width:<?= max(2, min(100, (float) $class['pct'])) ?>%"></i></div>
								<div class="ss-subs"><?php foreach ($class['subs'] as $sub): ?><span><i class="fa <?= $h($class['fa']) ?>"></i><?= $h($sub['name']) ?> <b><?= number_format((int) $sub['value']) ?></b></span><?php endforeach; ?></div>
							</div>
						</div>
					<?php endforeach; ?>
				</section>

				<?php server_statistics_rank_panel('top_resets', $data['top_resets'], server_statistics_t('server_statistics.top_resets', 'Top Resets'), 'fa-refresh', server_statistics_t('server_statistics.rst', 'RST'), 'resets'); ?>

				<section class="ss-panel">
					<div class="ss-section-title"><?= server_statistics_icon('database') ?><?= $h(server_statistics_t('server_statistics.economy', 'Economy')) ?></div>
					<div class="ss-economy">
						<div><strong><?= number_format($goldTotal) ?></strong><span><?= $h(server_statistics_t('server_statistics.wcoins', 'Gold in circulation')) ?></span></div>
						<div><strong><?= $richestName !== '' ? $h($richestName) : '-' ?></strong><b><?= number_format($richestValue) ?> gp</b><span><?= $h(server_statistics_t('server_statistics.richest_player', 'Richest Player')) ?></span></div>
					</div>
				</section>

				<section class="ss-panel">
					<div class="ss-section-title"><?= server_statistics_icon('shield') ?><?= $h(server_statistics_t('server_statistics.guilds', 'Guilds')) ?></div>
					<div class="ss-guild-stats">
						<div><strong><?= number_format((int) $data['guilds']) ?></strong><span><?= $h(server_statistics_t('server_statistics.total', 'Total')) ?></span></div>
						<div><strong><?= number_format((int) $data['guild_avg']) ?></strong><span><?= $h(server_statistics_t('server_statistics.avg_size', 'Avg Size')) ?></span></div>
						<div><strong><?= number_format((int) $data['guild_members']) ?></strong><span><?= $h(server_statistics_t('server_statistics.chars_guild', 'Guild Members')) ?></span></div>
					</div>
					<?php if ($topGuild !== ''): ?><div class="ss-topguild"><span><?= $h(strtoupper(substr($topGuild, 0, 2))) ?></span><div><strong><?= $h($topGuild) ?></strong><small><?= $h(server_statistics_t('server_statistics.top_guild', 'Top guild')) ?> - <?= $h($topGuildScore) ?> <?= $h(server_statistics_t('server_statistics.score', 'score')) ?></small></div><i class="fa fa-trophy"></i></div><?php endif; ?>
				</section>
			</div>

			<div>
				<section class="ss-panel">
					<div class="ss-section-title"><?= server_statistics_icon('line-chart') ?><?= $h(server_statistics_t('server_statistics.registrations', 'Registrations - Last {days} Days', array('days' => server_statistics_int('chart_days', 14)))) ?></div>
					<div class="ss-chart">
						<?php foreach ($data['registrations']['items'] as $bar): $height = max(3, round(((int) $bar['value'] / $data['registrations']['max']) * 92)); ?>
							<div title="<?= $h($bar['label'] . ': ' . $bar['value']) ?>"><b><?= (int) $bar['value'] > 0 ? (int) $bar['value'] : '' ?></b><i class="<?= $bar['today'] ? 'is-today' : '' ?>" style="height:<?= $height ?>px"></i><span><?= $h($bar['label']) ?></span></div>
						<?php endforeach; ?>
					</div>
					<p class="ss-chart-total"><?= server_statistics_icon('user-plus') ?> <b><?= number_format($data['registrations']['total']) ?></b> <?= $h(server_statistics_t('server_statistics.total_days', 'total - {days} days', array('days' => server_statistics_int('chart_days', 14)))) ?></p>
				</section>

				<?php server_statistics_rank_panel('top_level', $data['top_level'], server_statistics_t('server_statistics.highest_level', 'Highest Level'), 'fa-trophy', 'Lv', 'level'); ?>

				<section class="ss-panel">
					<div class="ss-section-title"><?= server_statistics_icon('map') ?><?= $h(server_statistics_t('server_statistics.selected_town', 'Most Selected Town')) ?></div>
					<?php foreach ($data['towns'] as $map): ?>
						<div class="ss-map"><span title="<?= $h($map['name']) ?>"><?= $h($map['name']) ?></span><div><i style="width:<?= (int) $map['value'] > 0 ? max(2, min(100, (int) $map['pct'])) : 0 ?>%"></i></div><b><?= number_format((int) $map['value']) ?> <em>(<?= (int) $map['pct'] ?>%)</em></b></div>
					<?php endforeach; ?>
				</section>
			</div>
		</div>
	</div>
</div>

<?php
function server_statistics_rank_panel(string $type, array $rows, string $title, string $icon, string $suffix, string $valueKey): void {
	$h = 'server_statistics_h';
	?>
	<section class="ss-panel">
		<div class="ss-section-title"><?= server_statistics_icon($icon) ?><?= $h($title) ?></div>
		<?php if (!$rows): ?>
			<p class="ss-empty"><?= $h(server_statistics_t('server_statistics.empty', 'No data yet.')) ?></p>
		<?php else: ?>
			<?php $rank = 0; foreach ($rows as $row): $rank++; $meta = server_statistics_player_meta($row); ?>
				<div class="ss-top-row" style="--cc:<?= $h($meta['color']) ?>">
					<div class="ss-rank"><?= $h(server_statistics_rank($rank)) ?></div>
					<div class="ss-top-name">
						<strong><a href="characterprofile.php?name=<?= $h(urlencode((string) $row['name'])) ?>"><?= $h($row['name']) ?></a></strong>
						<small><i class="fa <?= $h($meta['fa']) ?>"></i><?= $h($meta['name']) ?> - <?= $type === 'top_level' ? number_format((int) ($row['resets'] ?? 0)) . ' ' . server_statistics_t('server_statistics.rst', 'RST') : 'Lv ' . number_format((int) ($row['level'] ?? 0)) ?></small>
					</div>
					<div class="ss-pill"><?= $suffix === 'Lv' ? 'Lv ' : '' ?><?= number_format((int) ($row[$valueKey] ?? $row['v'] ?? 0)) ?><?= $suffix !== 'Lv' ? ' ' . $h($suffix) : '' ?></div>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</section>
	<?php
}
?>
<script src="<?= $h(znote_plugin_asset('server_statistics', 'js/server-statistics.js')) ?>"></script>
