<?php
if (!function_exists('bloodfang_menu_fallback')) {
function bloodfang_menu_fallback(string $downloadUrl): array {
	return array(
		array('label' => t('bloodfang.nav.home'), 'url' => 'index.php', 'children' => array()),
		array('label' => t('bloodfang.nav.registration'), 'url' => 'register.php', 'children' => array(
			array('label' => t('bloodfang.create_account'), 'url' => 'register.php', 'children' => array()),
			array('label' => t('bloodfang.recover_password'), 'url' => 'recovery.php', 'children' => array()),
		)),
		array('label' => t('bloodfang.nav.downloads'), 'url' => $downloadUrl, 'children' => array(
			array('label' => t('bloodfang.download_client'), 'url' => $downloadUrl, 'children' => array()),
		)),
		array('label' => t('bloodfang.nav.rankings'), 'url' => 'highscores.php', 'children' => array(
			array('label' => t('bloodfang.nav.rankings'), 'url' => 'highscores.php', 'children' => array()),
			array('label' => t('bloodfang.nav.who_online'), 'url' => 'onlinelist.php', 'children' => array()),
			array('label' => t('bloodfang.nav.latest_deaths'), 'url' => 'deaths.php', 'children' => array()),
		)),
		array('label' => t('bloodfang.nav.market'), 'url' => 'market.php', 'children' => array(
			array('label' => t('bloodfang.nav.market'), 'url' => 'market.php', 'children' => array()),
			array('label' => t('bloodfang.nav.shop'), 'url' => 'shop.php', 'children' => array()),
		)),
		array('label' => t('bloodfang.nav.guides'), 'url' => 'serverinfo.php', 'children' => array(
			array('label' => t('bloodfang.nav.server_info'), 'url' => 'serverinfo.php', 'children' => array()),
			array('label' => t('bloodfang.nav.rules'), 'url' => 'rules.php', 'children' => array()),
			array('label' => t('bloodfang.nav.wiki'), 'url' => 'wiki.php', 'children' => array()),
		)),
	);
}
}

if (!function_exists('bloodfang_menu_url')) {
function bloodfang_menu_url(array $item): string {
	return (string)($item['url'] ?? '#');
}
}

if (!function_exists('bloodfang_menu_label')) {
function bloodfang_menu_label(array $item): string {
	$label = (string)($item['label'] ?? '');
	return function_exists('theme_menu_label') ? theme_menu_label($label) : $label;
}
}

if (!function_exists('bloodfang_render_menu')) {
function bloodfang_render_menu(array $items, bool $separators = true): void {
	$count = count($items);
	foreach ($items as $index => $item) {
		$children = isset($item['children']) && is_array($item['children']) ? $item['children'] : array();
		$target = !empty($item['target']) ? ' target="' . h($item['target']) . '" rel="noopener"' : '';
		if ($children) {
			$label = h(bloodfang_menu_label($item));
			echo '<li class="bf-dropdown-wrap">';
			echo '<a href="' . h(bloodfang_menu_url($item)) . '"' . $target . '>' . $label . ' <i class="fa fa-chevron-down bf-caret"></i></a>';
			echo '<ul class="bf-dropdown"><span class="bf-dropdown-head">' . $label . '</span><div class="bf-dropdown-links">';
			foreach ($children as $child) {
				$childTarget = !empty($child['target']) ? ' target="' . h($child['target']) . '" rel="noopener"' : '';
				echo '<a href="' . h(bloodfang_menu_url($child)) . '"' . $childTarget . '>' . h(bloodfang_menu_label($child)) . '</a>';
			}
			echo '</div></ul></li>';
		} else {
			echo '<li><a href="' . h(bloodfang_menu_url($item)) . '"' . $target . '>' . h(bloodfang_menu_label($item)) . '</a></li>';
		}
		if ($separators && $index < $count - 1) {
			echo '<span>|</span>';
		}
	}
}
}

if (!function_exists('bloodfang_server_socket_online')) {
function bloodfang_server_socket_online(array $config): bool {
	$host = (string)($config['status']['status_ip'] ?? $config['gameserver']['ip'] ?? '127.0.0.1');
	$port = (int)($config['status']['status_port'] ?? $config['port'] ?? 7171);
	if ($host === '' || $port <= 0) {
		return false;
	}

	$errorNumber = 0;
	$errorString = '';
	$socket = @fsockopen($host, $port, $errorNumber, $errorString, 0.4);
	if (is_resource($socket)) {
		fclose($socket);
		return true;
	}

	return false;
}
}

if (!function_exists('bloodfang_outfit_url')) {
function bloodfang_outfit_url(array $player): string {
	if (!function_exists('znote_outfit_image_base')) {
		return '';
	}

	$base = znote_outfit_image_base();
	$type = (int)($player['looktype'] ?? $player['type'] ?? 0);
	if ($base === '' || $type <= 0) {
		return '';
	}

	return $base . '?id=' . $type
		. '&addons=' . (int)($player['lookaddons'] ?? $player['addons'] ?? 0)
		. '&head=' . (int)($player['lookhead'] ?? $player['head'] ?? 0)
		. '&body=' . (int)($player['lookbody'] ?? $player['body'] ?? 0)
		. '&legs=' . (int)($player['looklegs'] ?? $player['legs'] ?? 0)
		. '&feet=' . (int)($player['lookfeet'] ?? $player['feet'] ?? 0)
		. '&g=0&h=3&i=1';
}
}

$bfLang = function_exists('translate_active') ? translate_active() : 'en';
$bfLangShort = strtoupper(explode('_', $bfLang)[0]);
$bfSite = htmlspecialchars((string)($config['site_name'] ?? $config['site_title'] ?? 'Bloodfang'), ENT_QUOTES, 'UTF-8');
$bfPageTitle = !empty($GLOBALS['page_title'])
	? (string)$GLOBALS['page_title']
	: ucwords(str_replace(array('-', '_'), ' ', (string)($page_filename ?? 'index')));
$bfDiscord = function_exists('theme_option') ? theme_option('discord_url') : '';
$bfFacebook = function_exists('theme_option') ? theme_option('facebook_url') : '';
$bfDownload = function_exists('theme_option') ? theme_option('download_url', 'downloads.php') : 'downloads.php';
$bfDonate = function_exists('theme_option') ? theme_option('donate_url', 'buypoints.php') : 'buypoints.php';
$bfFooter = function_exists('theme_option') ? theme_option('footer_html') : '';
$bfIsLogged = function_exists('user_logged_in') && user_logged_in() === true;
$bfIsAdmin = $bfIsLogged && isset($user_data) && function_exists('is_admin') && is_admin($user_data);

/* Sidebar data (server status + top players + top guilds) is cached for ~40s
   so the TCP status probe and the count queries don't run on every request. */
$bfSidebar = null;
$bfSidebarCache = class_exists('Cache') ? new Cache('engine/cache/bloodfang_sidebar') : null;
if ($bfSidebarCache && !$bfSidebarCache->hasExpired()) {
	$bfSidebar = $bfSidebarCache->load();
}
if (!is_array($bfSidebar)) {
	$server = array('accounts' => 0, 'players' => 0, 'online' => 0);
	if (function_exists('db')) {
		if (function_exists('znote_table_exists') && znote_table_exists('players_online')) {
			$onlineSql = "(SELECT COUNT(`player_id`) FROM `players_online`)";
		} elseif (function_exists('znote_column_exists') && znote_column_exists('players', 'online')) {
			$onlineSql = "(SELECT COUNT(`id`) FROM `players` WHERE `online` = 1)";
		} else {
			$onlineSql = "0";
		}
		$row = db()->rawFetchOne("
			SELECT
				(SELECT COUNT(`id`) FROM `accounts`) AS `accounts`,
				(SELECT COUNT(`id`) FROM `players`) AS `players`,
				{$onlineSql} AS `online`
		");
		if (is_array($row)) {
			$server = array_merge($server, $row);
		}
	}
	$online = ((int)$server['online'] > 0) || bloodfang_server_socket_online($config);

	$players = array();
	if (function_exists('db')) {
		$rows = db()->fetchAll("
			SELECT `name`, `level`, `vocation`, `looktype`, `lookaddons`, `lookhead`, `lookbody`, `looklegs`, `lookfeet`
			FROM `players`
			WHERE `group_id` < 2
			ORDER BY `level` DESC, `experience` DESC
			LIMIT 5
		");
		if (is_array($rows)) {
			$players = $rows;
		}
	}

	$guilds = array();
	if (function_exists('db')) {
		$rows = db()->fetchAll("
			SELECT `g`.`name`,
				(SELECT COUNT(`gm`.`guild_id`) FROM `guild_membership` `gm` WHERE `gm`.`guild_id` = `g`.`id`) AS `members`
			FROM `guilds` `g`
			ORDER BY `members` DESC, `g`.`name` ASC
			LIMIT 5
		");
		if (is_array($rows)) {
			$guilds = $rows;
		}
	}

	$bfSidebar = array('server' => $server, 'online' => $online, 'players' => $players, 'guilds' => $guilds);
	if ($bfSidebarCache) {
		$bfSidebarCache->setContent($bfSidebar);
		$bfSidebarCache->save();
	}
}
$bfServer = $bfSidebar['server'];
$bfServerOnline = (bool)$bfSidebar['online'];
$bfTopPlayers = $bfSidebar['players'];
$bfTopGuilds = $bfSidebar['guilds'];

$bfMenu = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
if (!$bfMenu) {
	$bfMenu = bloodfang_menu_fallback($bfDownload);
}
?>
<!doctype html>
<html lang="<?= htmlspecialchars(explode('_', $bfLang)[0], ENT_QUOTES, 'UTF-8') ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= theme_title() ?></title>
	<link rel="shortcut icon" href="<?= theme_asset('img/favicon.ico') ?>">
	<link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= theme_asset('css/vendor/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/vendor/v1.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/vendor/ui.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/vendor/freemucms.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/vendor/modern.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/bloodfang.css') ?>">
</head>
<body class="<?= theme_body_class() ?> bg-light-dark">
<div id="exception"></div>

<header class="header-wrapper header-layout4">
	<div class="animate-line">
		<div class="bf-container">
			<div class="bmu-topbar">
				<div class="bmu-tb-side"></div>
				<p class="bmu-tb-center"><?= h(t('bloodfang.welcome_to')) ?> <span><?= $bfSite ?></span></p>
				<div class="bmu-tb-side bmu-tb-right">
					<span class="bmu-time"><i class="fa fa-clock-o"></i> <span id="bmu-srv-time-val">--:--:--</span></span>
					<div class="bmu-lang-wrap">
						<button type="button" class="bmu-lang-toggle"><i class="fa fa-globe"></i><strong><?= h($bfLangShort) ?></strong><i class="fa fa-caret-down"></i></button>
						<ul class="bmu-lang-menu">
							<?php foreach (function_exists('translate_enabled') ? translate_enabled() : array('en') as $code):
								$entry = translate_catalog()[$code] ?? array('native' => strtoupper($code));
							?>
								<li><a href="<?= translate_url($code) ?>" class="<?= $code === $bfLang ? 'is-active' : '' ?>"><span><?= h($entry['native']) ?></span><small><?= h($code) ?></small></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<?php if ($bfDiscord !== ''): ?><a class="bmu-soc" href="<?= htmlspecialchars($bfDiscord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" title="Discord"><i class="fa fa-comments"></i></a><?php endif; ?>
					<?php if ($bfFacebook !== ''): ?><a class="bmu-soc" href="<?= htmlspecialchars($bfFacebook, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" title="Facebook"><i class="fa fa-facebook"></i></a><?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="bf-nav-band">
		<div class="bf-container bf-main-nav">
			<a class="bf-mark" href="index.php"><img src="<?= theme_asset('img/b.webp') ?>" alt="<?= $bfSite ?>"></a>
			<nav class="main-menu menu-style3">
				<ul><?php bloodfang_render_menu($bfMenu); ?></ul>
			</nav>
			<div class="bf-actions">
				<a href="<?= htmlspecialchars($bfDonate, ENT_QUOTES, 'UTF-8') ?>" class="vs-btn style2 outline1"><i class="fa fa-heart"></i><strong><?= h(t('bloodfang.donate')) ?></strong></a>
			</div>
		</div>
	</div>
</header>

<div class="ls-bg">
	<a href="index.php" class="bmu-banner-link"><img src="<?= theme_asset('img/bloodfang.png') ?>" alt="<?= $bfSite ?>"></a>
</div>

<section class="vs-blog-wrapper blog-single-layout1">
	<div class="bf-container bf-layout">
		<aside class="sidebar-area left-sidebar">
			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-server"></i><?= h(t('bloodfang.server_status')) ?></h3>
				<div class="bf-side-body">
					<div class="bmu-ss-row <?= $bfServerOnline ? 'is-online' : 'is-offline' ?>">
						<span><i class="bf-dot"></i><?= $bfSite ?></span>
						<strong><?= (int)$bfServer['online'] ?></strong>
					</div>
					<div class="bmu-ss-detail">
						<div class="bmu-ss-grid">
							<div class="bmu-ss-kv"><span class="k"><?= h(t('bloodfang.accounts')) ?></span><span class="v"><?= (int)$bfServer['accounts'] ?></span></div>
							<div class="bmu-ss-kv"><span class="k"><?= h(t('bloodfang.players')) ?></span><span class="v"><?= (int)$bfServer['players'] ?></span></div>
							<div class="bmu-ss-kv"><span class="k"><?= h(t('bloodfang.status')) ?></span><span class="v <?= $bfServerOnline ? 'status-online' : 'status-offline' ?>"><?= h(t($bfServerOnline ? 'bloodfang.online' : 'bloodfang.offline')) ?></span></div>
						</div>
					</div>
				</div>
			</div>

			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-trophy"></i><?= h(t('bloodfang.top_players')) ?></h3>
				<div class="bmutp-list">
					<?php foreach ($bfTopPlayers as $rank => $player):
						$outfitUrl = bloodfang_outfit_url($player);
					?>
						<a class="bmutp-row" href="characterprofile.php?name=<?= urlencode((string)$player['name']) ?>">
							<span class="bmutp-rank rank-<?= min(3, $rank + 1) ?>"><?= $rank + 1 ?></span>
							<?php if ($outfitUrl !== ''): ?>
								<img class="bmutp-ic" src="<?= h($outfitUrl) ?>" alt="">
							<?php else: ?>
								<span class="bmutp-ic bmutp-ic-placeholder"><i class="fa fa-user"></i></span>
							<?php endif; ?>
							<span class="bmutp-mid">
								<span class="bmutp-name"><?= h($player['name']) ?></span>
								<span class="bmutp-cls"><?= h(function_exists('vocation_id_to_name') ? vocation_id_to_name((int)$player['vocation']) : t('bloodfang.level')) ?> - <?= h(t('bloodfang.level')) ?> <?= (int)$player['level'] ?></span>
							</span>
						</a>
					<?php endforeach; ?>
					<?php if (!$bfTopPlayers): ?><p class="bf-muted"><?= h(t('bloodfang.no_players')) ?></p><?php endif; ?>
				</div>
			</div>

			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-shield"></i><?= h(t('bloodfang.top_guilds')) ?></h3>
				<div class="bf-guilds">
					<?php foreach ($bfTopGuilds as $gi => $guild): ?>
						<a class="bf-guild-row" href="guilds.php?name=<?= urlencode((string)$guild['name']) ?>">
							<span class="bf-guild-rank"><?= $gi + 1 ?></span>
							<span class="bf-guild-name"><?= h($guild['name']) ?></span>
							<span class="bf-guild-count"><i class="fa fa-users"></i><?= (int)$guild['members'] ?></span>
						</a>
					<?php endforeach; ?>
					<?php if (!$bfTopGuilds): ?><p class="bf-muted"><?= h(t('bloodfang.no_guilds')) ?></p><?php endif; ?>
				</div>
			</div>

		</aside>

		<main class="bf-content">
			<div class="bf-content-head">
				<h1><?= h($bfPageTitle) ?></h1>
			</div>
			<div class="bf-content-body">
				<?php theme_content(); ?>
			</div>
		</main>

		<aside class="sidebar-area right-sidebar">
			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-user-circle"></i><?= h(t('bloodfang.account')) ?></h3>
				<?php if ($bfIsLogged): ?>
					<div class="bf-login-inline">
						<p class="bf-muted"><i class="fa fa-user"></i> <?= h($user_data['name'] ?? '') ?></p>
						<a class="bf-wide-btn" href="myaccount.php"><?= h(t('nav.account')) ?></a>
					</div>
					<div class="bf-acct-links">
						<?php if ($bfIsAdmin): ?><a class="bf-side-link bf-admin-link" href="admin/"><i class="fa fa-cog"></i><?= h(t('bloodfang.admin_panel')) ?></a><?php endif; ?>
						<a class="bf-side-link" href="logout.php"><i class="fa fa-sign-out"></i><?= h(t('nav.logout')) ?></a>
					</div>
				<?php else: ?>
					<form class="bf-login-inline" action="login.php" method="post">
						<input type="text" name="username" maxlength="32" autocomplete="username" placeholder="<?= h(t('login.username')) ?>">
						<input type="password" name="password" maxlength="64" autocomplete="current-password" placeholder="<?= h(t('login.password')) ?>">
						<?php if (!empty($config['twoFactorAuthenticator'])): ?><input type="password" name="authcode" placeholder="<?= h(t('widget.login.token')) ?>"><?php endif; ?>
						<?php if (class_exists('Token')) Token::create(); ?>
						<button type="submit" class="bf-wide-btn"><i class="fa fa-sign-in"></i> <?= h(t('bloodfang.login')) ?></button>
						<div class="bf-login-inline-links">
							<a href="register.php"><?= h(t('bloodfang.create_account')) ?></a>
							<a href="recovery.php"><?= h(t('bloodfang.recover_password')) ?></a>
						</div>
					</form>
				<?php endif; ?>
			</div>

			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-diamond"></i><?= h(t('bloodfang.vip_membership')) ?></h3>
				<div class="bf-vip-body">
					<ul class="bf-vip-list">
						<li><i class="fa fa-check"></i><?= h(t('bloodfang.vip_perk_1')) ?></li>
						<li><i class="fa fa-check"></i><?= h(t('bloodfang.vip_perk_2')) ?></li>
						<li><i class="fa fa-check"></i><?= h(t('bloodfang.vip_perk_3')) ?></li>
					</ul>
					<div class="bf-vip-actions">
						<a class="bf-btn-gold" href="<?= htmlspecialchars($bfDonate, ENT_QUOTES, 'UTF-8') ?>"><i class="fa fa-star"></i><?= h(t('bloodfang.buy_vip')) ?></a>
						<a class="bf-btn-blood" href="<?= htmlspecialchars($bfDonate, ENT_QUOTES, 'UTF-8') ?>"><i class="fa fa-heart"></i><?= h(t('bloodfang.donate')) ?></a>
					</div>
				</div>
			</div>

			<?php if ($bfDiscord !== ''): ?>
			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-comments"></i><?= h(t('bloodfang.discord')) ?></h3>
				<div class="bf-widget-body">
					<div class="bf-widget-line"><span class="dot is-green"></span><?= h(t('bloodfang.community_online')) ?></div>
					<div class="bf-widget-sub"><?= h(t('bloodfang.discord_sub')) ?></div>
					<a class="bf-wide-btn" href="<?= htmlspecialchars($bfDiscord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><i class="fa fa-comments"></i><?= h(t('bloodfang.join_discord')) ?></a>
				</div>
			</div>
			<?php endif; ?>

			<?php if ($bfFacebook !== ''): ?>
			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-facebook-official"></i><?= h(t('bloodfang.facebook')) ?></h3>
				<div class="bf-widget-body">
					<div class="bf-widget-line"><span class="dot is-blue"></span><?= h(t('bloodfang.facebook_sub')) ?></div>
					<a class="bf-wide-btn" href="<?= htmlspecialchars($bfFacebook, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><i class="fa fa-facebook"></i><?= h(t('bloodfang.follow_facebook')) ?></a>
				</div>
			</div>
			<?php endif; ?>

			<div class="vs-sidebox">
				<h3 class="sidebox-title"><i class="fa fa-download"></i><?= h(t('bloodfang.downloads')) ?></h3>
				<div class="bf-dl-body">
					<a class="bf-dl-link" href="<?= htmlspecialchars($bfDownload, ENT_QUOTES, 'UTF-8') ?>">
						<span class="bf-dl-icon"><i class="fa fa-download"></i></span>
						<span class="bf-dl-text"><?= h(t('bloodfang.download_client')) ?></span>
					</a>
				</div>
			</div>
		</aside>
	</div>
</section>

<footer class="footer-wrapper">
	<div class="bf-container bf-footer">
		<div>
			<?php if ($bfFooter !== ''): ?><div class="bf-footer-custom"><?= $bfFooter ?></div><?php endif; ?>
			<p>&copy; <?= date('Y') ?> <a href="index.php"><?= $bfSite ?></a>. <?= h(t('bloodfang.powered_by')) ?> <a href="credits.php">ZnoteX</a>.</p>
		</div>
		<a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
	</div>
</footer>

<script src="<?= theme_asset('js/bloodfang.js') ?>"></script>
</body>
</html>
