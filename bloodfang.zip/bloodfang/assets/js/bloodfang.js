(function () {
	var clock = document.getElementById("bmu-srv-time-val");
	function tick() {
		if (!clock) return;
		clock.textContent = new Intl.DateTimeFormat("en-GB", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hour12: false
		}).format(new Date());
	}
	tick();
	setInterval(tick, 1000);

	document.querySelectorAll(".bmu-lang-toggle").forEach(function (button) {
		button.addEventListener("click", function (event) {
			event.preventDefault();
			event.stopPropagation();
			button.closest(".bmu-lang-wrap").classList.toggle("is-open");
		});
	});
	document.addEventListener("click", function () {
		document.querySelectorAll(".bmu-lang-wrap.is-open").forEach(function (wrap) {
			wrap.classList.remove("is-open");
		});
		document.querySelectorAll(".bf-dropdown-wrap.is-open").forEach(function (wrap) {
			wrap.classList.remove("is-open");
		});
	});

	document.querySelectorAll(".bf-dropdown-wrap > a").forEach(function (link) {
		link.addEventListener("click", function (event) {
			var wrap = link.closest(".bf-dropdown-wrap");
			if (!wrap || window.matchMedia("(hover: hover)").matches) return;
			event.preventDefault();
			event.stopPropagation();
			document.querySelectorAll(".bf-dropdown-wrap.is-open").forEach(function (item) {
				if (item !== wrap) item.classList.remove("is-open");
			});
			wrap.classList.toggle("is-open");
		});
	});

	var modal = document.getElementById("bfLoginModal");
	document.querySelectorAll("[data-open-login]").forEach(function (button) {
		button.addEventListener("click", function () {
			if (!modal) return;
			modal.classList.add("is-open");
			modal.setAttribute("aria-hidden", "false");
			var input = modal.querySelector("input");
			if (input) input.focus();
		});
	});
	document.querySelectorAll("[data-close-login]").forEach(function (button) {
		button.addEventListener("click", function () {
			if (!modal) return;
			modal.classList.remove("is-open");
			modal.setAttribute("aria-hidden", "true");
		});
	});
	if (modal) {
		modal.addEventListener("click", function (event) {
			if (event.target === modal) {
				modal.classList.remove("is-open");
				modal.setAttribute("aria-hidden", "true");
			}
		});
	}
})();
