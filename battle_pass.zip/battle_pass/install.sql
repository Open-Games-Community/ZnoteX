﻿CREATE TABLE IF NOT EXISTS `znote_battle_pass_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `mission_key` varchar(64) NOT NULL,
  `period_key` varchar(32) NOT NULL,
  `progress` int NOT NULL DEFAULT '0',
  `claimed` tinyint NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_mission_period` (`account_id`,`mission_key`,`period_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
