<?php

return array(
	'battle_pass.title' => 'Battle Pass',
	'battle_pass.claim' => 'Abholen',
	'battle_pass.claimed' => 'Abgeholt',
	'battle_pass.not_complete' => 'Mission nicht abgeschlossen.',
	'battle_pass.already_claimed' => 'Bereits abgeholt.',
	'battle_pass.claimed_ok' => 'Missionsbelohnung abgeholt.',
	'battle_pass.unknown' => 'Unbekannte Mission.',
	'battle_pass.period.daily' => 'täglich',
	'battle_pass.period.weekly' => 'wöchentlich',
	'battle_pass.mission.create_character' => 'Charakter erstellen',
	'battle_pass.mission.reach_level_20' => 'Erreiche Level 20',
	'battle_pass.mission.shop_purchase' => 'Im Shop einkaufen',
	'battle_pass.mission.join_guild' => 'Einer Gilde beitreten',
);
