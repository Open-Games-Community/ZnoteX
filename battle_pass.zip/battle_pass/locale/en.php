<?php

return array(
	'battle_pass.title' => 'Battle Pass',
	'battle_pass.claim' => 'Claim',
	'battle_pass.claimed' => 'Claimed',
	'battle_pass.not_complete' => 'Mission not complete.',
	'battle_pass.already_claimed' => 'Already claimed.',
	'battle_pass.claimed_ok' => 'Mission reward claimed.',
	'battle_pass.unknown' => 'Unknown mission.',
	'battle_pass.period.daily' => 'daily',
	'battle_pass.period.weekly' => 'weekly',
	'battle_pass.mission.create_character' => 'Create a character',
	'battle_pass.mission.reach_level_20' => 'Reach level 20',
	'battle_pass.mission.shop_purchase' => 'Buy from the shop',
	'battle_pass.mission.join_guild' => 'Join a guild',
);
