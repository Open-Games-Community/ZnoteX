<?php

return array(
	'battle_pass.title' => 'Passe de Batalha',
	'battle_pass.claim' => 'Resgatar',
	'battle_pass.claimed' => 'Resgatado',
	'battle_pass.not_complete' => 'Missão não concluída.',
	'battle_pass.already_claimed' => 'Já resgatado.',
	'battle_pass.claimed_ok' => 'Recompensa da missão resgatada.',
	'battle_pass.unknown' => 'Missão desconhecida.',
	'battle_pass.period.daily' => 'diária',
	'battle_pass.period.weekly' => 'semanal',
	'battle_pass.mission.create_character' => 'Crie um personagem',
	'battle_pass.mission.reach_level_20' => 'Alcance o nível 20',
	'battle_pass.mission.shop_purchase' => 'Compre na loja',
	'battle_pass.mission.join_guild' => 'Entre em uma guild',
);
