<?php

return array(
	'battle_pass.title' => 'Pase de batalla',
	'battle_pass.claim' => 'Reclamar',
	'battle_pass.claimed' => 'Reclamado',
	'battle_pass.not_complete' => 'Misión no completada.',
	'battle_pass.already_claimed' => 'Ya reclamado.',
	'battle_pass.claimed_ok' => 'Recompensa de misión reclamada.',
	'battle_pass.unknown' => 'Misión desconocida.',
	'battle_pass.period.daily' => 'diaria',
	'battle_pass.period.weekly' => 'semanal',
	'battle_pass.mission.create_character' => 'Crea un personaje',
	'battle_pass.mission.reach_level_20' => 'Alcanza el nivel 20',
	'battle_pass.mission.shop_purchase' => 'Compra en la tienda',
	'battle_pass.mission.join_guild' => 'Únete a una guild',
);
