<?php

return array(
	'battle_pass.title' => 'Karnet bojowy',
	'battle_pass.claim' => 'Odbierz',
	'battle_pass.claimed' => 'Odebrano',
	'battle_pass.not_complete' => 'Misja nieukończona.',
	'battle_pass.already_claimed' => 'Już odebrano.',
	'battle_pass.claimed_ok' => 'Nagroda za misję odebrana.',
	'battle_pass.unknown' => 'Nieznana misja.',
	'battle_pass.period.daily' => 'dzienna',
	'battle_pass.period.weekly' => 'tygodniowa',
	'battle_pass.mission.create_character' => 'Stwórz postać',
	'battle_pass.mission.reach_level_20' => 'Osiągnij poziom 20',
	'battle_pass.mission.shop_purchase' => 'Kup coś w sklepie',
	'battle_pass.mission.join_guild' => 'Dołącz do gildii',
);
