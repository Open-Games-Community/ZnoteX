<?php
if (!function_exists('battle_pass_setting')) {
function battle_pass_setting(string $k,string $d): string { return function_exists('setting')?(string)setting('battle_pass:'.$k,$d):$d; }
function battle_pass_enabled(): bool { return battle_pass_setting('enabled','1')==='1'; }
function battle_pass_h($v): string { return htmlspecialchars((string)($v??''),ENT_QUOTES,'UTF-8'); }
function battle_pass_style_color(string $key): string { $value=trim(battle_pass_setting('style_'.$key,'')); return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$value)?$value:''; }
function battle_pass_style_attr(): string { $map=['box_bg'=>'--znx-plugin-surface','text'=>'--znx-plugin-text','border'=>'--znx-plugin-border','mission_bg'=>'--bp-mission-bg','bar_bg'=>'--bp-bar-bg','bar_fill'=>'--bp-bar-fill','check_bg'=>'--bp-check-bg','check_text'=>'--bp-check-text','button_bg'=>'--bp-button-bg','button_text'=>'--bp-button-text']; $css=''; foreach($map as $k=>$var){$v=battle_pass_style_color($k); if($v!=='')$css.=$var.':'.$v.';';} return $css!==''?' style="'.battle_pass_h($css).'"':''; }
function battle_pass_is_claimed(int $accountId,array $m): bool { if(!function_exists('znote_table_exists')||!znote_table_exists('znote_battle_pass_progress'))return false; $key=(string)($m['key']??''); $period=battle_pass_period($m); $row=db()->fetchOne("SELECT `claimed` FROM `znote_battle_pass_progress` WHERE `account_id` = ? AND `mission_key` = ? AND `period_key` = ? LIMIT 1;", [$accountId, $key, $period]); return is_array($row)&&!empty($row['claimed']); }
function battle_pass_default_missions(): array { return [['key'=>'create_character','title'=>'Create a character','type'=>'character_created','target'=>1,'period'=>'weekly','points'=>15,'premdays'=>0],['key'=>'reach_level_20','title'=>'Reach level 20','type'=>'level','target'=>20,'period'=>'weekly','points'=>25,'premdays'=>0],['key'=>'shop_purchase','title'=>'Buy from the shop','type'=>'shop_purchase','target'=>1,'period'=>'daily','points'=>10,'premdays'=>0],['key'=>'join_guild','title'=>'Join a guild','type'=>'guild','target'=>1,'period'=>'weekly','points'=>20,'premdays'=>0]]; }
function battle_pass_missions(): array { $m=json_decode(battle_pass_setting('missions',''),true); return is_array($m)?$m:battle_pass_default_missions(); }
function battle_pass_period(array $m): string { return ($m['period']??'daily')==='weekly' ? date('o-\WW') : date('Y-m-d'); }
function battle_pass_bump(int $accountId,string $type,int $amount=1): void {
	if (!battle_pass_enabled() || $accountId<=0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_battle_pass_progress')) return;
	foreach (battle_pass_missions() as $m) if (($m['type']??'')===$type) { $key=(string)$m['key']; $period=battle_pass_period($m); $now=time(); db()->execute("INSERT INTO `znote_battle_pass_progress` (`account_id`,`mission_key`,`period_key`,`progress`,`updated_at`) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE `progress`=GREATEST(`progress`,`progress`+?),`updated_at`=?;", [$accountId, $key, $period, $amount, $now, $amount, $now]); }
}
function battle_pass_account_progress(int $accountId,array $m): int {
	$type=$m['type']??''; $target=max(1,(int)($m['target']??1));
	if ($type==='level') { $row=db()->fetchOne("SELECT MAX(`level`) AS `v` FROM `players` WHERE `account_id` = ?;", [$accountId]); return is_array($row)?min($target,(int)$row['v']):0; }
	if ($type==='guild') { $col=function_exists('znote_column_exists')&&znote_column_exists('players','guild_id')?'guild_id':'rank_id'; $row=db()->fetchOne("SELECT COUNT(*) AS `v` FROM `players` WHERE `account_id` = ? AND `{$col}` > 0;", [$accountId]); return is_array($row)?min($target,(int)$row['v']):0; }
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_battle_pass_progress')) return 0;
	$key=(string)$m['key']; $period=battle_pass_period($m); $row=db()->fetchOne("SELECT `progress`,`claimed` FROM `znote_battle_pass_progress` WHERE `account_id` = ? AND `mission_key` = ? AND `period_key` = ? LIMIT 1;", [$accountId, $key, $period]);
	return is_array($row)?min($target,(int)$row['progress']):0;
}
function battle_pass_claim(int $accountId,string $key): string {
	foreach (battle_pass_missions() as $m) {
		if (($m['key']??'')!==$key) continue;

		$target=max(1,(int)($m['target']??1));
		if (battle_pass_account_progress($accountId,$m)<$target) return t_default('battle_pass.not_complete','Mission not complete.');

		$period=battle_pass_period($m);
		$pts=max(0,(int)($m['points']??0));
		$prem=max(0,(int)($m['premdays']??0));

		// Re-check "claimed" and credit inside one locked transaction, so a
		// double-submit cannot claim (and pay out) the same mission twice.
		$claimed=db()->transaction(function ($db) use ($accountId,$key,$period,$target,$pts) {
			$row=$db->fetchOne("SELECT `claimed` FROM `znote_battle_pass_progress` WHERE `account_id` = ? AND `mission_key` = ? AND `period_key` = ? LIMIT 1 FOR UPDATE;", [$accountId, $key, $period]);
			if (is_array($row)&&$row['claimed']) return false;

			$now=time();
			$db->execute("INSERT INTO `znote_battle_pass_progress` (`account_id`,`mission_key`,`period_key`,`progress`,`claimed`,`updated_at`) VALUES (?, ?, ?, ?, 1, ?) ON DUPLICATE KEY UPDATE `claimed`=1,`updated_at`=VALUES(`updated_at`);", [$accountId, $key, $period, $target, $now]);

			if ($pts>0) $db->execute("UPDATE `znote_accounts` SET `points`=COALESCE(`points`,0)+? WHERE `account_id` = ?;", [$pts, $accountId]);

			return true;
		});

		if (!$claimed) return t_default('battle_pass.already_claimed','Already claimed.');
		if ($prem>0&&function_exists('user_account_add_premdays')) user_account_add_premdays($accountId,$prem);
		return t_default('battle_pass.claimed_ok','Mission reward claimed.');
	}
	return t_default('battle_pass.unknown','Unknown mission.');
}
function battle_pass_footer(): string {
	if (!battle_pass_enabled() || basename((string)($_SERVER['SCRIPT_NAME']??''))!=='myaccount.php' || empty($GLOBALS['session_user_id'])) return '';
	$aid=(int)$GLOBALS['session_user_id']; if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['battle_pass_claim'])&&class_exists('Token')&&Token::isValid($_POST['token']??null)) $GLOBALS['battle_pass_msg']=battle_pass_claim($aid,(string)$_POST['battle_pass_claim']);
	$items=''; foreach(battle_pass_missions() as $m){$p=battle_pass_account_progress($aid,$m);$t=max(1,(int)($m['target']??1));$pct=min(100,(int)floor($p/$t*100));$claimed=battle_pass_is_claimed($aid,$m);$done=$p>=$t;$mk=(string)($m['key']??'');$pk=(string)($m['period']??'daily');$title=t_default('battle_pass.mission.'.$mk,(string)($m['title']??$mk));$period=t_default('battle_pass.period.'.$pk,$pk);if($claimed){$btn='<button class="bp-btn" type="button" disabled>'.battle_pass_h(t_default('battle_pass.claimed','Claimed')).'</button>';}elseif($done){ob_start();Token::create();$tok=ob_get_clean();$btn='<form method="post">'.$tok.'<button class="bp-btn" name="battle_pass_claim" value="'.battle_pass_h($mk).'">'.battle_pass_h(t_default('battle_pass.claim','Claim')).'</button></form>';}else{$btn='';}$check=$claimed?'<span class="bp-check" aria-hidden="true">&#10003;</span>':'';$items.='<div class="bp-m'.($claimed?' is-done':'').'">'.$check.'<div><b>'.battle_pass_h($title).'</b><span>'.battle_pass_h($period).' - '.$p.'/'.$t.'</span></div><div class="bp-bar"><i style="width:'.$pct.'%"></i></div>'.$btn.'</div>';}
	$css='.bp-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 18px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.96;overflow:hidden}.bp-box *{box-sizing:border-box}.bp-list{display:grid;gap:8px}.bp-m{position:relative;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;padding:10px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:var(--bp-mission-bg,var(--znx-plugin-surface));overflow-wrap:anywhere}.bp-m span{display:block;font-size:12px;opacity:.7}.bp-m.is-done{opacity:.55}.bp-m.is-done b{text-decoration:line-through}.bp-check{position:absolute;top:4px;right:6px;min-width:16px;height:16px;line-height:16px;padding:0 3px;text-align:center;font-size:11px;font-weight:800;border-radius:8px;background:var(--bp-check-bg,#2f9e5e);color:var(--bp-check-text,#fff)}.bp-btn:disabled,.bp-btn[disabled]{opacity:.5;cursor:default;filter:none}.bp-bar{grid-column:1/-1;height:8px;border-radius:99px;border:1px solid var(--znx-plugin-border);background:var(--bp-bar-bg,var(--znx-plugin-surface));overflow:hidden}.bp-bar i{display:block;height:100%;background:var(--bp-bar-fill,var(--znx-plugin-text));opacity:.45}.bp-btn{padding:7px 10px;border-radius:6px;border:1px solid var(--znx-plugin-border);background:var(--bp-button-bg,var(--znx-plugin-surface));color:var(--bp-button-text,var(--znx-plugin-text));cursor:pointer}.bp-btn:hover{filter:brightness(1.08)}@media(max-width:520px){.bp-m{grid-template-columns:1fr}.bp-m form{justify-self:start}}';
	$msg=!empty($GLOBALS['battle_pass_msg'])?'<p>'.battle_pass_h($GLOBALS['battle_pass_msg']).'</p>':''; $html='<div id="battlePassBox" class="bp-box"'.battle_pass_style_attr().'><strong>'.battle_pass_h(t_default('battle_pass.title','Battle Pass')).'</strong>'.$msg.'<div class="bp-list">'.$items.'</div></div>';
	return '<script>(function(){if(document.getElementById("battlePassBox"))return;var s=document.createElement("style");s.textContent='.json_encode($css).';document.head.appendChild(s);var root=document.getElementById("myaccount")||document.querySelector("main,#content,.content");if(!root)return;var w=document.createElement("div");w.innerHTML='.json_encode($html).';root.appendChild(w.firstChild);}());</script>';
}
function battle_pass_character_created(array $d): void { battle_pass_bump((int)($d['account_id']??0),'character_created',1); }
function battle_pass_shop_purchased(array $d): void { battle_pass_bump((int)($d['account_id']??0),'shop_purchase',1); }
}
if(function_exists('znote_hook_register')){znote_hook_register('page.footer','battle_pass_footer');znote_hook_register('character.created','battle_pass_character_created');znote_hook_register('shop.purchased','battle_pass_shop_purchased');}
