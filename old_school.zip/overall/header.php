<?php
if (!function_exists('old_school_escape')) {
	function old_school_escape($value): string {
		return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
	}
}

$oldSchoolAssets = theme_url() . '/assets';
$oldSchoolMenu = array_values(array_filter(
	theme_menu_items('main'),
	static fn(array $item): bool => !empty($item['children'])
));
$oldSchoolFacebook = theme_option('facebook_url', 'https://www.facebook.com/arkoniaonline');
$oldSchoolTopBarHtml = theme_option('top_bar_html');
$oldSchoolCountdownValue = theme_option('countdown_target');
$oldSchoolCountdownTimestamp = null;

if ($oldSchoolCountdownValue !== '') {
	$oldSchoolCountdownDate = DateTimeImmutable::createFromFormat('Y-m-d\\TH:i', $oldSchoolCountdownValue);
	$oldSchoolCountdownErrors = DateTimeImmutable::getLastErrors();

	if (
		$oldSchoolCountdownDate !== false
		&& ($oldSchoolCountdownErrors === false || ($oldSchoolCountdownErrors['warning_count'] === 0 && $oldSchoolCountdownErrors['error_count'] === 0))
	) {
		$oldSchoolCountdownTimestamp = $oldSchoolCountdownDate->getTimestamp();
	}
}

$oldSchoolCountdownActive = $oldSchoolCountdownTimestamp !== null && $oldSchoolCountdownTimestamp > time();
$oldSchoolCountdownStatus = $oldSchoolCountdownActive
	? '<span style="color: yellow;" id="old-school-countdown">loading...</span>'
	: '<span style="color: yellow;">' . old_school_escape(theme_option('countdown_finished_text', 'SERVER STARTED!')) . '</span>';

if (str_contains($oldSchoolTopBarHtml, '{COUNTDOWN}')) {
	$oldSchoolTopBarHtml = str_replace('{COUNTDOWN}', $oldSchoolCountdownStatus, $oldSchoolTopBarHtml);
} elseif ($oldSchoolCountdownValue !== '') {
	$oldSchoolTopBarHtml = preg_replace_callback(
		'/<span([^>]*)>\\s*SERVER STARTED!\\s*<\\/span>/i',
		static fn(): string => $oldSchoolCountdownStatus,
		$oldSchoolTopBarHtml,
		1
	) ?? $oldSchoolTopBarHtml;
}
?>
<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?= theme_title() ?></title>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans|Patua+One" media="print" onload="this.media='all'">
		<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans|Patua+One"></noscript>
		<link rel="stylesheet" type="text/css" href="<?= old_school_escape($oldSchoolAssets) ?>/style.css">
		<link rel="stylesheet" type="text/css" href="<?= old_school_escape($oldSchoolAssets) ?>/tibia.css">
		<script src="assets/js/jquery.js"></script>
		<script src="<?= old_school_escape($oldSchoolAssets) ?>/cufon-yui.js"></script>
		<script src="<?= old_school_escape($oldSchoolAssets) ?>/jquery.slides.min.js"></script>
		<script src="<?= old_school_escape($oldSchoolAssets) ?>/Trajan_Pro_400.font.js"></script>
		<script type="text/javascript">
		Cufon.replace('.cufon', {
				color: '-linear-gradient(#ffa800, #6a3c00)',
				textShadow: '#14110c 1px 1px, #14110c -1px 1px'
			});
		</script>
		<style>
.display-none {
	display: none !important;
}

.display-inline {
	display: inline !important;
}
		</style>
		<script>
			jQuery(function(){
				jQuery('.changelog_trigger').click(function(e){
					e.preventDefault();
				jQuery('.minus'+$(this).attr('targetid')).toggle();
				jQuery('.plus'+$(this).attr('targetid')).toggle();	 
				
						jQuery('.changelog_big'+$(this).attr('targetid')).toggleClass("display-inline");
					  
					  jQuery('.changelog_small'+$(this).attr('targetid')).toggleClass("display-none");
					
				});
			});
		</script>
		<script>
		   $(function() {
		   $('#slides').slidesjs({
			width: 207,
			height: 100,
			navigation: true,
			play: {
			active: false,
			auto: true,
			interval: 3000,
			swap: true,
			pauseOnHover: false,
			restartDelay: 2500
			  }
		   });
		   });
	  </script>
	</head>
	<body class="<?= theme_body_class() ?>">
	<?php
		function user_count_characters() {
			$result = mysql_select_single("SELECT COUNT(`id`) AS `id` from `players`;");
			return ($result !== false) ? $result['id'] : 0;
		}
	?>
	
<div id="fb-root"></div>
<script>(function(d, s, id) {
  window.addEventListener('load', function () {
    window.setTimeout(function () {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id; js.async = true; js.defer = true;
      js.src = "https://connect.facebook.net/en_EN/sdk.js#xfbml=1&version=v2.8";
      fjs.parentNode.insertBefore(js, fjs);
    }, 250);
  });
}(document, 'script', 'facebook-jssdk'));</script>
	<?= $oldSchoolTopBarHtml ?>
	<?php if ($oldSchoolCountdownActive): ?>
		<script>
		(function () {
			var target = <?= (int)$oldSchoolCountdownTimestamp ?> * 1000;
			var output = document.getElementById('old-school-countdown');
			if (!output) return;

			function updateCountdown() {
				var remaining = target - Date.now();
				if (remaining <= 0) {
					output.textContent = <?= json_encode(theme_option('countdown_finished_text', 'SERVER STARTED!'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
					return false;
				}

				var days = Math.floor(remaining / 86400000);
				var hours = Math.floor((remaining % 86400000) / 3600000);
				var minutes = Math.floor((remaining % 3600000) / 60000);
				var seconds = Math.floor((remaining % 60000) / 1000);
				output.textContent = (days ? days + ' DAYS ' : '') + hours + ' HOURS ' + minutes + ' MINUTES ' + seconds + ' SECONDS';
				return true;
			}

			if (updateCountdown()) {
				var countdownTimer = window.setInterval(function () {
					if (!updateCountdown()) window.clearInterval(countdownTimer);
				}, 1000);
			}
		}());
		</script>
	<?php endif; ?>
		<div class="container_main">
			<div class="old-school-custom-logo" aria-hidden="true"></div>
			<div class="container_left">
				<?php foreach ($oldSchoolMenu as $menuCategory): ?>
					<?php
					$menuStyle = match (strtolower($menuCategory['label'])) {
						'home', 'news' => 'news',
						'account' => 'account',
						'community' => 'community',
						'library' => 'library',
						'shop' => 'shop',
						default => '',
					};
					$menuPanelId = 'old-school-menu-' . (int)$menuCategory['id'];
					?>
					<div class="left_box">
						<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
						<button class="title old-school-menu-toggle" type="button" aria-expanded="false" aria-controls="<?= old_school_escape($menuPanelId) ?>" data-menu-id="<?= (int)$menuCategory['id'] ?>">
							<?php if ($menuStyle !== ''): ?>
								<img src="<?= old_school_escape($oldSchoolAssets) ?>/img/<?= old_school_escape($menuStyle) ?>.gif" alt="">
								<span style="background-image: url(<?= old_school_escape($oldSchoolAssets) ?>/widget_texts/<?= old_school_escape($menuStyle) ?>.png);"></span>
							<?php else: ?>
								<span class="cufon old-school-menu-title"><?= old_school_escape($menuCategory['label']) ?></span>
							<?php endif; ?>
						</button>
						<div class="content" id="<?= old_school_escape($menuPanelId) ?>" hidden>
							<div class="rise-up-content">
								<ul>
									<?php foreach ($menuCategory['children'] as $menuEntry): ?>
										<li><a href="<?= old_school_escape($menuEntry['url']) ?>"<?= $menuEntry['target'] === '_blank' ? ' target="_blank" rel="noopener"' : '' ?>><?= old_school_escape($menuEntry['label']) ?></a></li>
									<?php endforeach; ?>
									<li><a href="<?= old_school_escape($menuCategory['url']) ?>"<?= $menuCategory['target'] === '_blank' ? ' target="_blank" rel="noopener"' : '' ?>><?= old_school_escape($menuCategory['label']) ?></a></li>
								</ul>
							</div>
						</div>
						<div class="border_bottom"></div>
					</div>
				<?php endforeach; ?>
			</div>
			<script>
			(function () {
				var storageKey = 'old_school_open_menus';
				var openMenus = [];

				try {
					var savedMenus = JSON.parse(window.sessionStorage.getItem(storageKey) || '[]');
					if (Array.isArray(savedMenus)) {
						openMenus = savedMenus.map(String);
					}
				} catch (error) {
					openMenus = [];
				}

				document.querySelectorAll('.old-school-menu-toggle').forEach(function (button) {
					var menuId = String(button.getAttribute('data-menu-id'));
					var panel = document.getElementById(button.getAttribute('aria-controls'));
					if (!panel) return;

					function setOpen(isOpen) {
						button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
						panel.hidden = !isOpen;
					}

					setOpen(openMenus.indexOf(menuId) !== -1);
					button.addEventListener('click', function () {
						var isOpen = button.getAttribute('aria-expanded') !== 'true';
						setOpen(isOpen);

						if (isOpen) {
							if (openMenus.indexOf(menuId) === -1) openMenus.push(menuId);
						} else {
							openMenus = openMenus.filter(function (id) { return id !== menuId; });
						}

						try {
							window.sessionStorage.setItem(storageKey, JSON.stringify(openMenus));
						} catch (error) {
							// The menu still works when browser storage is unavailable.
						}
					});
				});
			}());
			</script>
			<div class="container_mid">
				<!-- FACEBOOK -->
				<div class="center_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><span style="background-image: url(layouts/old_school/assets/widget_texts/facebook.png);"></span></div>
					<div class="content_bg">
						<div class="content">
							<div class="rise-up-content" style="min-height: 150px;">
								<div class="fb-page" style="padding: 10px 47px;" data-href="<?= old_school_escape($oldSchoolFacebook) ?>" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="<?= old_school_escape($oldSchoolFacebook) ?>" class="fb-xfbml-parse-ignore"><a href="<?= old_school_escape($oldSchoolFacebook) ?>">Arkonia Online</a></blockquote></div>
							</div>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
				<!-- CHANGELOG SYSTEM -->
				<?php
					if ($config['UseChangelogTicker'] && basename($_SERVER["SCRIPT_FILENAME"], '.php') == 'index') {
						?>
						<div class="center_box">
							<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
							<div class="title"><span style="background-image: url(layouts/old_school/assets/widget_texts/changelog.png);"></span></div>
							<div class="content_bg">
								<div class="content">
									<div class="rise-up-content">
						<?php
						//////////////////////
						// Changelog ticker //
						// Load from cache
						$changelogCache = new Cache('engine/cache/changelognews');
						$changelogs = $changelogCache->load();

						if (isset($changelogs) && !empty($changelogs) && $changelogs !== false) {
							?>
							<table class="stripped" cellpadding="2" style="margin: 5px 0;">
								<?php
								for ($i = 0; $i < count($changelogs) && $i < 5; $i++) {
									?>
									<tr>
										<td><small><?php echo getClock($changelogs[$i]['time'], true, true); ?></small> - 
											<div class="changelog_small<?php echo $i; ?>"  style="display: inline-block;"><?php if(strlen($changelogs[$i]['text']) > 57) {echo substr($changelogs[$i]['text'], 0, 60) . '...';}else { echo $changelogs[$i]['text'];} ?></div>
											<div class="changelog_big<?php echo $i; ?>"  style="display: none;"><?php echo $changelogs[$i]['text']; ?></div>
										</td>
										<td width="5%" valign="top"><center><a href="#" targetid="<?php echo $i; ?>" class="changelog_trigger"><img class="plus<?php echo $i; ?>" src="layouts/old_school/assets/tibia_img/plus.gif"><img class="minus<?php echo $i; ?>" style="display: none;" src="layouts/old_school/assets/tibia_img/minus.gif"></a></center></td>
									</tr>
									<?php
								}
								?>
							</table>
							<?php
						} else echo "<center>No changelogs submitted.</center>";
						
						?>
									</div>
								</div>
							</div>
							<div class="border_bottom"></div>
						</div>
						<?php
					}
				?>
				<!-- MAIN CONTENT -->
				<div class="center_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><span class="cufon" style="text-transform: uppercase;text-align: center;line-height: 43px;font-size: 16px;"><?php echo basename($_SERVER["SCRIPT_FILENAME"], '.php'); ?></span></div>
					<div class="content_bg">
						<div class="content">
							<div class="rise-up-content" style="min-height: 565px;">
