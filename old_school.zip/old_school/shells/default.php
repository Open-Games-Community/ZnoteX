<?php theme_include('overall/header.php'); ?>
<?php theme_content(); ?>
<?php theme_include('overall/footer.php'); ?>
