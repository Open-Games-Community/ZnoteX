<?php
$oldSchoolGalleryImages = array(
	theme_option('gallery_image_1'),
	theme_option('gallery_image_2'),
	theme_option('gallery_image_3'),
	theme_option('gallery_image_4'),
);
?>
							</div>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
			</div>	
			<div class="container_right">
				<a class="download_client" href="<?= old_school_escape($config['client_download'] ?? 'downloads.php') ?>"></a>
				<div class="right_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><img src="layouts/old_school/assets/img/quick.gif"><span style="background-image: url(layouts/old_school/assets/widget_texts/quicklogin.png);"></span></div>
					<div class="content">
						<div class="rise-up-content">
								<?php if (user_logged_in() === false) { ?>
								<div class="login"></div>
										<form action="login.php" method="post" style="margin-bottom: 0;">
											<?php $oldSchoolAccPlaceholder = t('common.account_number'); $oldSchoolPassPlaceholder = t('login.password'); ?>
										<input type="text" name="username" value="<?= old_school_escape($oldSchoolAccPlaceholder) ?>" class="inputtext" onfocus="this.value=''" onblur="if(this.value=='') { this.value='<?= old_school_escape(addslashes($oldSchoolAccPlaceholder)) ?>'};">
											<input type="password" name="password" value="<?= old_school_escape($oldSchoolPassPlaceholder) ?>" class="inputtext" onfocus="this.value=''" onblur="if(this.value=='') { this.value='<?= old_school_escape(addslashes($oldSchoolPassPlaceholder)) ?>'};">
											<input type="submit" name="Submit" value="" class="loginbtn"> <a class="createbtn" href="register.php"></a>
											<?php
												/* Form file */
												Token::create();
											?>
											<center style="font-size: 12px;">
												<?= t('common.lost_acc_or_password') ?>
											</center>
										</form>
								<?php }else{ ?>
								<div class="acc_menu">
									<center>
										<?= t('widget.account.welcome', ['name' => h($user_data['name'])]) ?>
												<a href='myaccount.php' class="inputbtn"><?= h(t('common.manage_account')) ?></a>
												<a style="color: orange;" href='createcharacter.php' class="inputbtn"><?= h(t('widget.account.create_character')) ?></a>
												<a href='logout.php' class="inputbtn"><?= h(t('widget.account.logout')) ?></a>

										<?php if (is_admin($user_data)){ ?>
											<a href="admin/index.php" class="inputbtn"><font color="red"><?= h(t('widget.admin.panel')) ?></font></a>
										<?php } ?>
									</center>
								</div>
								<?php } ?>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
				<div class="right_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><img src="layouts/old_school/assets/img/gallery.gif"><span style="background-image: url(layouts/old_school/assets/widget_texts/gallery.png);"></span></div>
					<div class="content">
						<div class="rise-up-content">
							<div class="slider">
								<div class="sbox">
									<div id="slides">
										<?php foreach ($oldSchoolGalleryImages as $oldSchoolGalleryImage): ?>
											<?php if ($oldSchoolGalleryImage !== ''): ?>
												<img src="<?= old_school_escape($oldSchoolGalleryImage) ?>" alt="">
											<?php endif; ?>
										<?php endforeach; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
				<div class="right_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><img src="layouts/old_school/assets/img/info.gif"><span style="background-image: url(layouts/old_school/assets/widget_texts/serverinfo.png);"></span></div>
					<div class="content">
						<div class="rise-up-content">
								<table class="sinfotable" cellspacing="0">
								<?php
								$status = true;
								
					@$sock = fsockopen($config['status']['status_ip'], $config['status']['status_port'], $errno, $errstr, 0.15);
									if(!$sock) {
										echo '<tr><td><b>' . h(t('common.status')) . ':</b></td><td> <img style="vertical-align:middle;" src="layouts/old_school/assets/img/off.png"></td></tr>';
										$status = false;
									}
									else {
										$info = chr(6).chr(0).chr(255).chr(255).'info';
										fwrite($sock, $info);
										$data='';
										while (!feof($sock))$data .= fgets($sock, 1024);
										fclose($sock);
										echo '<tr><td><b>' . h(t('common.status')) . ':</b></td><td> <img style="vertical-align:middle;" src="layouts/old_school/assets/img/on.png"></td></tr>';
									}
								
								
									?>
									<tr><td><b><?= h(t('nav.online')) ?>: </b></td><td>
										<a href="onlinelist.php"><?php echo user_count_online(); ?></a></td></tr>
									<?php
								
								?>
								<tr><td><b><?= h(t('widget.serverinfo.title')) ?>: </b></td><td><?php echo user_count_accounts();?></td></tr>
								<tr><td><b><?= h(t('common.character')) ?>s: </b></td><td><?php echo user_count_characters();?></td></tr>
								</table>
								<center><a href="serverinfo.php">&raquo; Server information</a></center>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
				<div class="right_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><img src="layouts/old_school/assets/img/exp.gif"><span style="background-image: url(layouts/old_school/assets/widget_texts/powergamers.png);"></span></div>
					<div class="content">
						<div class="rise-up-content">
						<ul class="toplvl">
						<?php
							function coloured_value($valuein)
							{
								error_reporting(E_ALL ^ E_NOTICE);
								$value = '';
								$value2 = $valuein;
								while(strlen($value2) > 3)
								{
									$value .= '.'.substr($value2, -3, 3);
									$value2 = substr($value2, 0, strlen($value2)-3);
								}
								@$value = $value2.$value;
								if($valuein > 0)
									return '<b><font color="green">+'.$value.'</font></b>';
								elseif($valuein < 0)
									return '<font color="red">'.$value.'</font>';
								else
									return $value;
							}
							$cache = new Cache('engine/cache/topPowergamers');
							if ($cache->hasExpired()) {
								$znotePlayers = mysql_select_multi('SELECT * FROM players WHERE group_id < 2 ORDER BY  experience - exphist_lastexp DESC LIMIT 5;');
								$cache->setContent($znotePlayers);
								$cache->save();
							} else {
								$znotePlayers = $cache->load();
							}

							if($znotePlayers){
								foreach($znotePlayers as $player)
								{
									$nam = $player['name'];
									if (strlen($nam) > 15)
									{$nam = substr($nam, 0, 12) . '...';}
									echo '<li style="margin: 6px 0;"><div style="position:relative; left:-48px; top:-48px;"><div style="background-image: url(layouts/old_school/assets/outfitter/outfit.php?id='.$player['looktype'].'&head='.$player['lookhead'].'&body='.$player['lookbody'].'&legs='.$player['looklegs'].'&feet='.$player['lookfeet'].');width:64px;height:64px;position:absolute;background-repeat:no-repeat;background-position:right bottom;"></div></div>
									<a style="margin-left: 19px;" href="characterprofile.php?name=' .$player['name']. '">' .$nam. '</a>';
									
									echo '<span style="float: right;">'.coloured_value($player['experience']-$player['exphist_lastexp']).'</span></li>';
								}
							}
							?>
							</ul>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
				<div class="right_box">
					<div class="corner_lt"></div><div class="corner_rt"></div><div class="corner_lb"></div><div class="corner_rb"></div>
					<div class="title"><img src="layouts/old_school/assets/img/casts.gif"><span style="background-image: url(layouts/old_school/assets/widget_texts/casts.png);"></span></div>
					<div class="content">
						<div class="rise-up-content">
						<ul class="toplvl">
						<?php
							$cache = new Cache('engine/cache/topCasts');
							if ($cache->hasExpired()) {
								$znotePlayers = mysql_select_multi('SELECT * FROM players WHERE group_id < 2 AND broadcasting = 1 ORDER BY  viewers DESC LIMIT 5;');
								$cache->setContent($znotePlayers);
								$cache->save();
							} else {
								$znotePlayers = $cache->load();
							}
							if($znotePlayers){
								foreach($znotePlayers as $player)
								{
									$nam = $player['name'];
									if (strlen($nam) > 15)
									{$nam = substr($nam, 0, 12) . '...';}
									echo '<li style="margin: 6px 0;"><div style="position:relative; left:-48px; top:-48px;"><div style="background-image: url(layouts/old_school/assets/outfitter/outfit.php?id='.$player['looktype'].'&head='.$player['lookhead'].'&body='.$player['lookbody'].'&legs='.$player['looklegs'].'&feet='.$player['lookfeet'].');width:64px;height:64px;position:absolute;background-repeat:no-repeat;background-position:right bottom;"></div></div>
									<a style="margin-left: 19px;" href="characterprofile.php?name=' .$player['name']. '">' .$nam. '</a>';
									
									echo '<span style="float: right;">'.$player['viewers'].'</span></li>';
								}
								
							}
							else
							{
								echo '<center>' . h(t('common.nothing')) . '</center>';
							}
							?>
							</ul>
						</div>
					</div>
					<div class="border_bottom"></div>
				</div>
			</div>
			<div class="footer_cnt">
				<center>
					<?php if (theme_option_set('footer_html')): ?>
						<div><?= theme_option('footer_html') ?></div>
					<?php endif; ?>
					<?= t('credits.copyright', ['year' => date('Y', time()), 'site' => '<strong>Arkonia.eu</strong>']) ?><br><a target="_blank" href="https://otland.net/members/hemrenus321.88336/" style="color: #3d4654;font-size: 11px;">by Hemrenus321</a>
				</center>
			</div>
		</div>
	</body>
</html>
