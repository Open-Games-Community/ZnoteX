<div style="background-color: pink;">
	<h1><?= h(t('downloads.title')) ?></h1>
	<h2><?= h(t('downloads.demo_notice')) ?></h2>
	<p><?= h(t('downloads.intro')) ?></p>

	<p><?= t('downloads.ipchanger') ?> <a href="http://static0.otland.net/ipchanger.exe"><?= h(t('downloads.here')) ?></a>.</p>
	<p><?= t('downloads.win', ['version' => ($config['client'] / 100)]) ?> <a href="<?php echo $config['client_download']; ?>"><?= h(t('downloads.here')) ?></a>.</p>
	<p><?= t('downloads.linux', ['version' => ($config['client'] / 100)]) ?> <a href="<?php echo $config['client_download_linux']; ?>"><?= h(t('downloads.here')) ?></a>.</p>

	<h2><?= h(t('downloads.howto')) ?></h2>
	<ol>
		<li>
			<a href="<?php echo $config['client_download']; ?>"><?= h(t('downloads.download')) ?></a> <?= h(t('downloads.step1')) ?>
		</li>
		<li>
			<a href="http://static0.otland.net/ipchanger.exe"><?= h(t('downloads.download')) ?></a> <?= h(t('downloads.step2')) ?>
		</li>
		<li>
			<?= h(t('downloads.step4')) ?> <?php echo $_SERVER['SERVER_NAME']; ?>
		</li>
		<li>
			<?= t('downloads.os_step_settings') ?>
		</li>
		<li>
			<?= h(t('downloads.os_step_version')) ?>
		</li>
		<li>
			<?= t('downloads.os_step_browse') ?>
		</li>
		<li>
			<?= t('downloads.os_step_apply') ?><br>
			<?= h(t('downloads.step5b')) ?> <a href="register.php"><?= h(t('downloads.here')) ?></a>.
		</li>
	</ol>
</div>