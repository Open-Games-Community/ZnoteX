<h1><?= h(t('blank.title')) ?></h1>
<p><?= h(t('blank.text')) ?></p>