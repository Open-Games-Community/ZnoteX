
	<h2><?= h(t('widget.search.title')) ?></h2>
	<form type="submit" action="characterprofile.php" method="get">

	<table>
		<tr><th ><?= h(t('common.search_character')) ?></th></tr>
		<tr><td>
			<table style="width: auto;margin: 0;">


				<tr>
					<td><strong><?= h(t('online.label_name')) ?></strong></td><td><input size="29" type="text" name="name" class="search"></td>
					<td>
					<input type="Submit" value="" class="hover" style="background: url(layouts/old_school/assets/tibia_img/sbutton_submit.gif); width:120px;height:18px;border: 0 none;" border="0"></td>
				</tr>


			</table>
		</td></tr>
	</table>

	</form>