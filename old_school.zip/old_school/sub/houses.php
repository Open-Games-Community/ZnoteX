<form action="houses.php" method="post">
	<?= h(t('common.select_town')) ?><br>
	<select name="selected">
	<?php
	foreach ($config['towns'] as $id => $name) echo '<option value="'. $id .'">'. $name .'</option>';
	?>
	</select>
	<?php
		/* Form file */
		Token::create();
	?>
	<input type="submit" value="<?= h(t('widget.houses.submit')) ?>">
</form>