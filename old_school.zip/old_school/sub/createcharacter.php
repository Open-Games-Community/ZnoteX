<?php require_once 'engine/init.php';
protect_page();

if (empty($_POST) === false) {
	// $_POST['']
	$required_fields = array('name', 'selected_town');
	foreach($_POST as $key=>$value) {
		if (empty($value) && in_array($key, $required_fields) === true) {
			$errors[] = t('reg.fill_all');
			break 1;
		}
	}
	
	// check errors (= user exist, pass long enough
	if (empty($errors) === true) {
		if (!Token::isValid($_POST['token'])) {
			$errors[] = t('login.token_invalid');
		}
		$_POST['name'] = validate_name($_POST['name']);
		if ($_POST['name'] === false) {
			$errors[] = t('acc.name_max_words');
		} else {
			if (user_character_exist($_POST['name']) !== false) {
				$errors[] = t('acc.name_taken');
			}
			if (!preg_match("/^[a-zA-Z_ ]+$/", $_POST['name'])) {
				$errors[] = t('acc.name_letters');
			}
			if (strlen($_POST['name']) < $config['minL'] || strlen($_POST['name']) > $config['maxL']) {
				$errors[] = t('acc.name_length', ['min' => $config['minL'], 'max' => $config['maxL']]);
			}
			// name restriction
			$resname = explode(" ", $_POST['name']);
			foreach($resname as $res) {
				if(in_array(strtolower($res), $config['invalidNameTags'])) {
					$errors[] = t('reg.restricted_word2');
				}
				else if(strlen($res) == 1) {
					$errors[] = t('reg.words_too_short2');
				}
			}
			// Validate vocation id
			if (!in_array((int)$_POST['selected_vocation'], $config['available_vocations'])) {
				$errors[] = t('createchar.bad_vocation');
			}
			// Validate town id
			if (!in_array((int)$_POST['selected_town'], $config['available_towns'])) {
				$errors[] = t('createchar.bad_town');
			}
			// Validate gender id
			if (!in_array((int)$_POST['selected_gender'], array(0, 1))) {
				$errors[] = t('createchar.bad_gender');
			}
			if (vocation_id_to_name($_POST['selected_vocation']) === false) {
				$errors[] = t('createchar.no_vocation');
			}
			if (town_id_to_name($_POST['selected_town']) === false) {
				$errors[] = t('createchar.no_town');
			}
			if (gender_exist($_POST['selected_gender']) === false) {
				$errors[] = t('createchar.no_gender');
			}
			// Char count
			$char_count = user_character_list_count($session_user_id);
			if ($char_count >= $config['max_characters']) {
				$errors[] = t('createchar.max_chars', ['max' => $config['max_characters']]);
			}
			if (validate_ip(getIP()) === false && $config['validate_IP'] === true) {
				$errors[] = t('reg.bad_ip');
			}
		}
	}
}
?>
<?php
if (isset($_GET['success']) && empty($_GET['success'])) {
	echo h(t('createchar.success'));
} else {
	if (empty($_POST) === false && empty($errors) === true) {
		if ($config['log_ip']) {
			znote_visitor_insert_detailed_data(2);
		}
		//Register
		$character_data = array(
			'name'		=>	format_character_name($_POST['name']),
			'account_id'=>	$session_user_id,
			'vocation'	=>	$_POST['selected_vocation'],
			'town_id'	=>	$_POST['selected_town'],
			'sex'		=>	$_POST['selected_gender'],
			'lastip'	=>	getIPLong(),
			'created'	=>	time()
		);
		
		user_create_character($character_data);
		header('Location: createcharacter.php?success');
		exit();
		//End register
		
	} else if (empty($errors) === false){
		echo '<font color="red"><b>';
		echo output_errors($errors);
		echo '</b></font>';
	}
	?>
	
	<p style="margin: 5px 5px 10px 5px;">
	<?= t('createchar.instructions') ?></p>
		<form action="" method="post">
		
			<div class="RowsWithOverEffect" style="margin: 5px;">
				<div class="TableContainer"> 
				<div class="CaptionContainer">
					<div class="CaptionInnerContainer">
						<span class="CaptionEdgeLeftTop" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightTop" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-edge.gif);"></span>
						<span class="CaptionBorderTop" style="background-image:url(layouts/old_school/assets/tibia_img/table-headline-border.gif);"></span>
						<span class="CaptionVerticalLeft" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-vertical.gif);"></span>
							<div class="Text"><?= h(t('createchar.title')) ?></div>
						<span class="CaptionVerticalRight" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-vertical.gif);"></span>
						<span class="CaptionBorderBottom" style="background-image:url(layouts/old_school/assets/tibia_img/table-headline-border.gif);"></span>
						<span class="CaptionEdgeLeftBottom" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightBottom" style="background-image:url(layouts/old_school/assets/tibia_img/box-frame-edge.gif);"></span>
					</div>
				</div>
				<table class="Table3" cellspacing="1">
							<tr>
								<td>
					<div class="InnerTableContainer">

								   <div class="TableShadowContainerRightTop">
									  <div class="TableShadowRightTop" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-rt.gif);"></div>
								   </div>
								   <div class="TableContentAndRightShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-rm.gif);">
									  <div class="TableContentContainer">
										 <table class="TableContent" width="100%" style="border:1px solid #faf0d7;">

										<tr class="LabelH">
											<td colspan="2">
												<?= h(t('createchar.col_name')) ?>
											</td>
											<td>
												<?= h(t('common.sex')) ?>
											</td>
											<td>
												<?= h(t('common.town')) ?>
											</td>
										</tr>
										
										<tr>
											<td>
												<?= h(t('createchar.name')) ?> 
											</td>
											<td>
												<input type="text" name="name">
											</td>
											<td>
												<select name="selected_gender">
												<option value="1"><?= h(t('createchar.male')) ?></option>
												<option value="0"><?= h(t('createchar.female')) ?></option>
												</select>
											</td>
											<td>
												<?php
												$available_towns = $config['available_towns'];
												if (count($available_towns) > 1):
													?>
														<select name="selected_town">
															<?php 
															foreach ($available_towns as $tid): 
																?>
																<option value="<?php echo $tid; ?>"><?php echo town_id_to_name($tid); ?></option>
																<?php 
															endforeach; 
															?>
														</select>
													<?php
												else:
													?>
													<input type="hidden" name="selected_town" value="<?php echo end($available_towns); ?>">
													<?php 
												endif;
												?>
											</td>
										</tr>
										 </table>
										 
									  </div>
								   </div>
								   <div class="TableShadowContainer">
									  <div class="TableBottomShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-bm.gif);">
										 <div class="TableBottomLeftShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-bl.gif);"></div>
										 <div class="TableBottomRightShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-br.gif);"></div>
									  </div>
								   </div>
								   
								   <br>
								   
								   <div class="TableShadowContainerRightTop">
									  <div class="TableShadowRightTop" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-rt.gif);"></div>
								   </div>
								   <div class="TableContentAndRightShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-rm.gif);">
									  <div class="TableContentContainer">
										 <table class="TableContent" width="100%" style="border:1px solid #faf0d7;">

										<tr class="LabelH">
											<td colspan="2">
												<?= h(t('createchar.select_vocation')) ?>
											</td>
										</tr>
										
										<tr>
											<td>
												<?php foreach ($config['available_vocations'] as $id) { ?>
												
												<div style="width: 25%; padding: 20px 0;float: left;text-align: left;">
													<input type="radio" name="selected_vocation" id="<?php echo $id; ?>" value="<?php echo $id; ?>">
													<label for="<?php echo $id; ?>"><?php echo vocation_id_to_name($id); ?></label>
												</div>

												<?php } ?>

											</td>
										</tr>
										 </table>
										 
									  </div>
								   </div>
								   <div class="TableShadowContainer">
									  <div class="TableBottomShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-bm.gif);">
										 <div class="TableBottomLeftShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-bl.gif);"></div>
										 <div class="TableBottomRightShadow" style="background-image:url(layouts/old_school/assets/tibia_img/table-shadow-br.gif);"></div>
									  </div>
								   </div>
								   
								   <br>
								   <center>
											<input name="submit" class="BigButton btn" type="submit" style="margin: 0 5px;display: inline-block;" value="<?= h(t('createchar.title')) ?>">

										<a href="myaccount.php">
											<div class="BigButton btn" style="margin: 0 5px;display: inline-block;background-image:url(layouts/old_school/assets/tibia_img/sbutton.gif)">
												<?= h(t('common.back')) ?>
											</div>
										</a>
								   </center>
								   <br>

	
					 	</div> 

						
						</td>
						</tr>
						
						</table>
				


							
					</div>
				</div>

					
				

	<?php
			/* Form file */
			Token::create();
			?>

				

	</form>
	<?php
}
?>