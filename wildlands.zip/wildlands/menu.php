<?php
/**
 * Wildlands top navigation.
 *
 * Entries come from Admin Panel > Menus (theme_menu_items('main')). Without a
 * managed menu a sensible default set is drawn. Markup matches the losena
 * ".navbar-nav" / ".nav-dropdown" structure so the converted CSS and the
 * mercury-blob script work unchanged.
 */

$wlMenu    = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$wlHasMenu = function_exists('theme_menu_available') ? theme_menu_available() : (bool) $wlMenu;
$wlCur     = (string) ($page_filename ?? 'index');
$wlForum   = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$hh = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$ml = static function ($v): string {
	$label = function_exists('theme_menu_label') ? theme_menu_label((string) $v) : (string) $v;
	return htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
};
$wlActive = static function (string $url) use ($wlCur): bool {
	if ($url === '') return false;
	if ($wlCur === 'index') return $url === 'index.php' || $url === '/' || $url === '';
	return strpos($url, $wlCur . '.php') === 0;
};
$wlIcon = static function (string $icon, string $fallback) use ($hh): string {
	$icon = trim($icon);
	if ($icon === '') $icon = $fallback;
	if ($icon === '') return '';
	if (strpos($icon, 'fa-') === false) $icon = 'fa-' . $icon;
	return '<i class="fa ' . $hh($icon) . '"></i> ';
};
?>
<ul class="navbar-nav" id="mainNav">
	<li class="nav-goo-host" aria-hidden="true">
		<span class="nav-goo-layer"><span class="nav-goo-blob"></span><span class="nav-goo-drop"></span></span>
		<span class="nav-goo-shine"></span>
	</li>
<?php if ($wlHasMenu): ?>
	<?php foreach ($wlMenu as $item): ?>
		<?php
		$hasDrop = !empty($item['children']);
		$href    = $item['url'] !== '' ? $item['url'] : '#';
		$target  = $item['target'] !== '' ? ' target="' . $hh($item['target']) . '" rel="noopener"' : '';
		?>
		<?php if ($hasDrop): ?>
			<li class="nav-dropdown">
				<a href="<?= $hh($href) ?>" class="<?= $wlActive($item['url']) ? 'active' : '' ?>"<?= $target ?>>
					<?= $wlIcon((string) $item['icon'], 'fa-chevron-down') ?><?= $ml($item['label']) ?>
					<i class="fa fa-chevron-down" style="font-size:.65rem;margin-left:2px;"></i>
				</a>
				<div class="nav-dropdown-menu">
					<?php foreach ($item['children'] as $child): ?>
						<a href="<?= $hh($child['url'] !== '' ? $child['url'] : '#') ?>"<?= $child['target'] !== '' ? ' target="' . $hh($child['target']) . '" rel="noopener"' : '' ?>>
							<?= $wlIcon((string) $child['icon'], 'fa-angle-right') ?><?= $ml($child['label']) ?>
						</a>
					<?php endforeach; ?>
				</div>
			</li>
		<?php else: ?>
			<li>
				<a href="<?= $hh($href) ?>" class="<?= $wlActive($item['url']) ? 'active' : '' ?>"<?= $target ?>>
					<?= $wlIcon((string) $item['icon'], '') ?><?= $ml($item['label']) ?>
				</a>
			</li>
		<?php endif; ?>
	<?php endforeach; ?>
<?php else: ?>
	<li><a href="index.php" class="<?= $wlCur === 'index' ? 'active' : '' ?>"><i class="fa fa-home"></i> <?= $hh(t('nav.news')) ?></a></li>
	<li class="nav-dropdown">
		<a href="highscores.php" class="<?= in_array($wlCur, array('highscores', 'onlinelist', 'guilds', 'lastkills'), true) ? 'active' : '' ?>">
			<i class="fa fa-trophy"></i> <?= $hh(t('nav.highscores')) ?> <i class="fa fa-chevron-down" style="font-size:.65rem;margin-left:2px;"></i>
		</a>
		<div class="nav-dropdown-menu">
			<a href="highscores.php"><i class="fa fa-user"></i> <?= $hh(t('nav.highscores')) ?></a>
			<a href="onlinelist.php"><i class="fa fa-globe"></i> <?= $hh(t('wildlands.nav.online')) ?></a>
			<a href="guilds.php"><i class="fa fa-shield"></i> <?= $hh(t('nav.guilds')) ?></a>
			<a href="lastkills.php"><i class="fa fa-skull"></i> <?= $hh(t('wildlands.nav.lastkills')) ?></a>
		</div>
	</li>
	<li><a href="serverinfo.php" class="<?= $wlCur === 'serverinfo' ? 'active' : '' ?>"><i class="fa fa-circle-info"></i> <?= $hh(t('nav.serverinfo')) ?></a></li>
	<li><a href="downloads.php" class="<?= $wlCur === 'downloads' ? 'active' : '' ?>"><i class="fa fa-download"></i> <?= $hh(t('wildlands.nav.download')) ?></a></li>
	<li><a href="shop.php" class="<?= $wlCur === 'shop' ? 'active' : '' ?>"><i class="fa fa-gem"></i> <?= $hh(t('nav.shop')) ?></a></li>
	<?php if ($wlForum !== ''): ?>
		<li><a href="<?= $hh($wlForum) ?>" target="_blank" rel="noopener"><i class="fa fa-comments"></i> <?= $hh(t('wildlands.nav.forum')) ?></a></li>
	<?php endif; ?>
<?php endif; ?>
</ul>
