<?php
/**
 * Wildlands - default shell.
 *
 * Converted 1:1 from the 'losena' MU CMS front-end. Only the design was kept:
 * the original site API, Google analytics, staff widget data feed and the
 * language cookie are gone. Chrome lives here, the look in assets/css/wildlands.css.
 */

$wlOpt = static function (string $k, string $d = ''): string {
	if (!function_exists('theme_option')) return $d;
	$v = trim((string) theme_option($k));
	return $v !== '' ? $v : $d;
};
$wlBar     = function_exists('theme_image') ? theme_image('logo_bar', theme_asset('images/bar.png')) : theme_asset('images/bar.png');
$wlEmblem  = function_exists('theme_image') ? theme_image('logo_emblem', theme_asset('images/logo.png')) : theme_asset('images/logo.png');
$wlFavicon = function_exists('theme_image') ? theme_image('favicon') : '';
$wlDesc    = function_exists('theme_option') ? theme_option('footer_desc') : '';
$wlFootHtml= function_exists('theme_option') ? theme_option('footer_html') : '';
$wlForum   = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$wlDiscord = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$wlTelegram= function_exists('theme_option') ? trim(theme_option('telegram_url')) : '';
$wlYoutube = function_exists('theme_option') ? trim(theme_option('youtube_url')) : '';
$wlVk      = function_exists('theme_option') ? trim(theme_option('vk_url')) : '';
$wlLang    = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';
$wlOnline  = (int) (function_exists('user_count_online') ? user_count_online() : 0);
$wlLogged  = function_exists('user_logged_in')
	? user_logged_in()
	: (function_exists('getSession') && getSession('user_id') !== false);
$wlIsAdmin = $wlLogged && function_exists('is_admin') && is_admin($user_data ?? null);
$wlPage    = (string) ($page_filename ?? 'index');
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

/**
 * Server status. Same idea as the core themes: a short TCP probe to the login
 * port, cached ~60s so it is not run on every request. null = unknown (never
 * happens here, kept for safety), true = up, false = down.
 */
$wlServerOnline = null;
$wlStatusCfg = is_array($config['status'] ?? null) ? $config['status'] : array();
$wlStatusIp   = (string) ($wlStatusCfg['status_ip'] ?? ($config['ip'] ?? '127.0.0.1'));
$wlStatusPort = (int) ($wlStatusCfg['status_port'] ?? ($config['port'] ?? 7171));
if ($wlStatusIp !== '' && $wlStatusPort > 0 && class_exists('Cache')) {
	$wlStatusCache = new Cache('engine/cache/wildlands_status');
	if ($wlStatusCache->hasExpired()) {
		$wlSock = @fsockopen($wlStatusIp, $wlStatusPort, $wlErrNo, $wlErrStr, 0.7);
		$wlServerOnline = $wlSock ? true : false;
		if ($wlSock) @fclose($wlSock);
		$wlStatusCache->setContent($wlServerOnline ? 1 : 0);
		$wlStatusCache->save();
	} else {
		$wlServerOnline = ((int) $wlStatusCache->load()) === 1;
	}
} elseif ($wlStatusIp !== '' && $wlStatusPort > 0) {
	$wlSock = @fsockopen($wlStatusIp, $wlStatusPort, $wlErrNo, $wlErrStr, 0.7);
	$wlServerOnline = $wlSock ? true : false;
	if ($wlSock) @fclose($wlSock);
}

$wlLangSel = '';
if (function_exists('translate_selector')) {
	$wlLangSel = translate_selector();
}
?>
<!DOCTYPE html>
<html lang="<?= $h($wlLang) ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#080b10">
	<meta name="color-scheme" content="dark">
	<title><?= theme_title() ?></title>
	<?php if ($wlFavicon !== ''): ?><link rel="icon" href="<?= $wlFavicon ?>"><?php endif; ?>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="<?= theme_asset('css/wildlands.css') ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body class="<?= theme_body_class() ?>">

<div id="site-bg" aria-hidden="true"></div>

<div class="wl-shell">

	<div class="status-bar">
		<div class="container">
			<div class="status-bar-inner">
				<div style="display:flex;gap:20px;align-items:center;">
					<span class="status-item">
						<?php if ($wlServerOnline === null): ?>
							<span class="status-dot"></span>
							<span style="color:var(--text-muted);"><?= t('wildlands.status.unknown') ?></span>
						<?php elseif ($wlServerOnline): ?>
							<span class="status-dot online"></span>
							<span style="color:var(--green);"><?= t('wildlands.status.online') ?></span>
						<?php else: ?>
							<span class="status-dot offline"></span>
							<span style="color:#e74c3c;"><?= t('wildlands.status.offline') ?></span>
						<?php endif; ?>
					</span>
					<span class="status-item">
						<i class="fa fa-users" style="color:var(--gold);font-size:.75rem;"></i>
						<b style="color:var(--gold);"><?= $wlOnline ?></b>&nbsp;<?= t('wildlands.status.players') ?>
					</span>
					<?php if ($wlForum !== ''): ?>
					<span class="status-item">
						<i class="fa fa-comments" style="color:var(--gold);font-size:.72rem;"></i>
						<a href="<?= $h($wlForum) ?>" target="_blank" rel="noopener" style="color:var(--text-muted);"><?= t('wildlands.nav.forum') ?></a>
					</span>
					<?php endif; ?>
				</div>
				<div style="display:flex;align-items:center;gap:14px;">
					<?php if ($wlLangSel !== ''): ?>
						<div class="wl-lang"><?= $wlLangSel ?></div>
						<?php if (function_exists('translate_selector_assets')) echo translate_selector_assets(); ?>
						<?php if (function_exists('translate_selector_rendered')) translate_selector_rendered(true); ?>
					<?php endif; ?>
					<?php if (!$wlLogged): ?>
						<a href="login.php" class="lang-btn"><?= t('wildlands.header.login') ?></a>
					<?php else: ?>
						<a href="logout.php" class="lang-btn"><?= t('wildlands.header.logout') ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>

	<svg width="0" height="0" aria-hidden="true" focusable="false" style="position:absolute;width:0;height:0;overflow:hidden;">
		<defs>
			<filter id="navGoo">
				<feGaussianBlur in="SourceGraphic" stdDeviation="7" result="navGooBlur"/>
				<feColorMatrix in="navGooBlur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -9"/>
			</filter>
		</defs>
	</svg>

	<nav class="navbar">
		<div class="container">
			<div class="navbar-inner">
				<a href="index.php" class="navbar-logo">
					<img src="<?= $wlBar ?>" alt="<?= theme_title() ?>" class="navbar-logo-img" style="height:56px;">
				</a>

				<button class="navbar-toggle" id="navToggle" aria-label="<?= t('wildlands.header.menu') ?>"><i class="fa fa-bars"></i></button>

				<?php theme_menu(); ?>

				<div class="navbar-actions">
					<?php if ($wlDiscord !== ''): ?><a href="<?= $h($wlDiscord) ?>" target="_blank" rel="noopener" class="wl-social" title="Discord"><i class="fab fa-discord"></i></a><?php endif; ?>
					<?php if ($wlTelegram !== ''): ?><a href="<?= $h($wlTelegram) ?>" target="_blank" rel="noopener" class="wl-social" title="Telegram"><i class="fab fa-telegram"></i></a><?php endif; ?>
					<?php if (!$wlLogged): ?>
						<a href="login.php" class="btn btn-ghost btn-sm"><?= t('wildlands.header.login') ?></a>
						<a href="register.php" class="btn btn-primary btn-sm"><?= t('wildlands.header.register') ?></a>
					<?php else: ?>
						<?php $wlName = (string) ($user_data['name'] ?? t('wildlands.header.account')); ?>
						<div class="nav-dropdown" data-wl-dd-wrap style="position:relative;">
							<a href="myaccount.php" data-wl-dd class="btn btn-ghost btn-sm">
								<i class="fa fa-user"></i> <?= $h($wlName) ?> <i class="fa fa-chevron-down" style="font-size:.6rem;"></i>
							</a>
							<div class="nav-dropdown-menu" style="right:0;left:auto;">
								<a href="myaccount.php"><i class="fa fa-user"></i> <?= t('wildlands.header.account') ?></a>
								<?php if ($wlIsAdmin): ?><a href="admin/"><i class="fa fa-shield-halved"></i> <?= t('wildlands.header.admin') ?></a><?php endif; ?>
								<a href="shop.php"><i class="fa fa-gem"></i> <?= t('nav.shop') ?></a>
								<a href="logout.php"><i class="fa fa-right-from-bracket"></i> <?= t('wildlands.header.logout') ?></a>
							</div>
						</div>
						<a href="shop.php" class="btn btn-primary btn-sm"><i class="fa fa-gem"></i> <?= t('nav.shop') ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</nav>

	<?php
	$wlAuth = array(
		'login'               => array('wildlands.auth.login_title', 'wildlands.auth.login_sub'),
		'register'            => array('wildlands.auth.register_title', 'wildlands.auth.register_sub'),
		'lostaccount'         => array('wildlands.auth.recover_title', 'wildlands.auth.recover_sub'),
		'lostaccountpassword' => array('wildlands.auth.recover_title', 'wildlands.auth.recover_sub'),
		'changepassword'      => array('wildlands.auth.password_title', 'wildlands.auth.password_sub'),
	);
	$wlAcctPages = array('myaccount', 'characters', 'createcharacter', 'twofa', 'changepassword', 'accountsettings', 'settings', 'paymentlog', 'changename', 'changesex', 'changecharacter');
	?>

	<?php if ($wlPage === 'index' || in_array($wlPage, array('downloads'), true)): ?>
		<?php theme_content(); ?>

	<?php elseif (isset($wlAuth[$wlPage])): ?>
		<main class="wl-auth">
			<div class="wl-auth__card">
				<h1 class="wl-auth__title"><?= t($wlAuth[$wlPage][0]) ?></h1>
				<p class="wl-auth__sub"><?= t($wlAuth[$wlPage][1]) ?></p>
				<div class="wl-panel" style="padding:0;border:none;background:none;box-shadow:none;"><?php theme_content(); ?></div>
				<?php if ($wlPage === 'login'): ?>
					<p class="wl-auth__foot"><?= t('wildlands.auth.no_account') ?> <a href="register.php"><?= t('wildlands.header.register') ?></a></p>
				<?php elseif ($wlPage === 'register'): ?>
					<p class="wl-auth__foot"><?= t('wildlands.auth.have_account') ?> <a href="login.php"><?= t('wildlands.header.login') ?></a></p>
				<?php endif; ?>
			</div>
		</main>

	<?php elseif ($wlLogged && in_array($wlPage, $wlAcctPages, true)): ?>
		<?php
		$acc = is_array($user_data ?? null) ? $user_data : array();
		$accId = (int) ($acc['id'] ?? 0);
		$accName = (string) ($acc['name'] ?? t('wildlands.header.account'));
		$accEmail = (string) ($acc['email'] ?? '');
		$accZ = ($accId && function_exists('user_znote_account_data'))
			? user_znote_account_data($accId, 'points', 'created') : false;
		$accPoints = is_array($accZ) ? (int) ($accZ['points'] ?? 0) : 0;
		$accCreated = (is_array($accZ) && !empty($accZ['created'])) ? (int) $accZ['created'] : 0;
		$accPrem = !empty($acc['premdays']) ? (int) $acc['premdays']
			: (!empty($acc['premium_ends_at']) && $acc['premium_ends_at'] > time()
				? (int) ceil(($acc['premium_ends_at'] - time()) / 86400) : 0);
		$accChars = ($accId && function_exists('user_character_list_count')) ? (int) user_character_list_count($accId) : 0;
		$accLast = !empty($acc['lastday']) ? (int) $acc['lastday'] : 0;
		$accInitial = function_exists('mb_substr') ? mb_strtoupper(mb_substr($accName, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($accName, 0, 1));
		$accTopup = $wlOpt('account_topup_url', 'shop.php');
		$accVip   = $wlOpt('account_vip_url', 'shop.php');
		$accVipShow = is_file('shop.php');
		$accVersion = isset($config['client']) && (int) $config['client'] > 0 ? rtrim(rtrim(number_format($config['client'] / 100, 2, '.', ''), '0'), '.') : '';
		$accSrvIp = (string) ($config['server_ip'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost'));
		$accYourIp = function_exists('getIP') ? getIP() : (string) ($_SERVER['REMOTE_ADDR'] ?? '');
		$wlTabs = array(
			'myaccount'       => array('fa-user', t('wildlands.account.overview')),
			'characters'      => array('fa-users', t('wildlands.account.characters')),
			'createcharacter' => array('fa-plus', t('wildlands.account.create')),
			'twofa'           => array('fa-shield-halved', '2FA'),
			'changepassword'  => array('fa-key', t('wildlands.account.password')),
			'settings'        => array('fa-gear', t('wildlands.account.settings')),
			'paymentlog'      => array('fa-receipt', t('wildlands.account.payments')),
		);
		?>
		<main class="wl-acct">
			<div class="db-hero">
				<div class="container">
					<div class="db-profile">
						<div class="db-avatar"><?= $h($accInitial) ?></div>
						<div style="flex:1;min-width:0;">
							<div class="db-uname"><?= $h($accName) ?></div>
							<div class="db-badges">
								<span class="db-badge" style="background:<?= $accPrem > 0 ? 'rgba(200,150,0,.15);color:#e8c547;border:1px solid rgba(200,150,0,.35)' : 'rgba(255,255,255,.05);color:var(--text-muted)' ?>;">
									<?= $accPrem > 0 ? t('wildlands.account.premium_days', array('n' => $accPrem)) : t('wildlands.account.free') ?>
								</span>
								<?php if ($accChars > 0): ?><span class="db-badge" style="background:rgba(96,165,250,.1);color:#60a5fa;"><?= t('wildlands.account.n_chars', array('n' => $accChars)) ?></span><?php endif; ?>
							</div>
							<div class="db-meta">
								<?php if ($accCreated > 0): ?><span><i class="fa fa-calendar"></i><?= t('wildlands.account.member_since', array('d' => date('M Y', $accCreated))) ?></span><?php endif; ?>
								<?php if ($accLast > 0): ?><span><i class="fa fa-right-to-bracket"></i><?= t('wildlands.account.last_login', array('d' => date('d M, H:i', $accLast))) ?></span><?php endif; ?>
								<?php if ($accEmail !== ''): ?><span><i class="fa fa-envelope"></i><?= $h($accEmail) ?></span><?php endif; ?>
							</div>
						</div>
						<a href="<?= $h($accTopup) ?>" class="db-topup"><i class="fa fa-plus"></i> <?= t('wildlands.account.topup') ?></a>
					</div>

					<div class="db-stats">
						<div class="db-hs"><div class="db-hs-val" style="color:#60a5fa;"><?= number_format($accPoints) ?></div><div class="db-hs-lbl"><?= t('wildlands.account.points') ?></div></div>
						<div class="db-hs"><div class="db-hs-val" style="color:#8ab4d6;"><?= $accChars ?></div><div class="db-hs-lbl"><?= t('wildlands.account.characters') ?></div></div>
						<div class="db-hs"><div class="db-hs-val" style="color:<?= $accPrem > 0 ? '#e8c547' : '#4a5568' ?>;"><?= $accPrem > 0 ? t('wildlands.account.vip') : t('wildlands.account.free') ?></div><div class="db-hs-lbl"><?= t('wildlands.account.status') ?></div></div>
						<div class="db-hs"><div class="db-hs-val" style="color:#b06aff;"><?= $accPrem > 0 ? (int) $accPrem : '&mdash;' ?></div><div class="db-hs-lbl"><?= t('wildlands.account.premium') ?></div></div>
					</div>
				</div>
			</div>

			<div class="container">
				<div class="db-grid">
					<div>
						<nav class="wl-acct__tabs">
							<?php foreach ($wlTabs as $tk => $tm): if (!is_file($tk . '.php')) continue; ?>
								<a class="wl-acct__tab<?= $wlPage === $tk ? ' is-active' : '' ?>" href="<?= $h($tk) ?>.php"><i class="fa <?= $tm[0] ?>"></i> <?= $h($tm[1]) ?></a>
							<?php endforeach; ?>
							<a class="wl-acct__tab" href="logout.php"><i class="fa fa-right-from-bracket"></i> <?= t('wildlands.header.logout') ?></a>
						</nav>
						<div class="db-card" style="padding:20px 22px;">
							<?php theme_content(); ?>
						</div>
					</div>

					<div>
						<?php if ($accVipShow && $accPrem <= 0): ?>
						<div class="db-card" style="position:relative;overflow:hidden;">
							<div style="position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,rgba(200,150,0,.4),rgba(200,150,0,.1));"></div>
							<div style="padding:20px;text-align:center;">
								<i class="fa fa-crown" style="color:var(--gold);font-size:1.4rem;margin-bottom:7px;display:block;"></i>
								<div style="color:var(--text-primary);font-weight:600;font-size:.88rem;margin-bottom:4px;"><?= t('wildlands.account.vip_title') ?></div>
								<div style="color:var(--text-muted);font-size:.75rem;margin-bottom:11px;"><?= t('wildlands.account.vip_text') ?></div>
								<a href="<?= $h($accVip) ?>" class="db-vip-btn"><?= t('wildlands.account.vip_cta') ?></a>
							</div>
						</div>
						<?php endif; ?>

						<div class="db-card" style="overflow:hidden;">
							<div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;">
								<div style="width:28px;height:28px;border-radius:8px;background:rgba(212,168,67,.08);border:1px solid rgba(212,168,67,.2);display:flex;align-items:center;justify-content:center;"><i class="fa fa-bolt" style="color:var(--gold);font-size:.7rem;"></i></div>
								<span style="font-family:'Cinzel',serif;font-weight:700;font-size:.78rem;color:var(--text-primary);"><?= t('wildlands.account.quick_actions') ?></span>
							</div>
							<?php
							$qa = array(
								array('shop.php', 'fa-wallet', '#34d399', t('wildlands.account.qa_topup')),
								array('changepassword.php', 'fa-key', '#60a5fa', t('wildlands.account.password')),
								array('twofa.php', 'fa-shield-halved', '#a78bfa', '2FA'),
								array('createcharacter.php', 'fa-plus', '#8ab4d6', t('wildlands.account.create')),
								array('paymentlog.php', 'fa-receipt', '#8ab4d6', t('wildlands.account.payments')),
							);
							foreach ($qa as $a): if (!is_file($a[0])) continue; ?>
								<a href="<?= $h($a[0]) ?>" class="db-qa">
									<div class="db-qa-ico" style="background:<?= $a[2] ?>12;border:1px solid <?= $a[2] ?>25;"><i class="fa <?= $a[1] ?>" style="color:<?= $a[2] ?>;"></i></div>
									<?= $h($a[3]) ?><i class="fa fa-chevron-right"></i>
								</a>
							<?php endforeach; ?>
						</div>

						<div class="db-card" style="overflow:hidden;">
							<div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;">
								<div style="width:28px;height:28px;border-radius:8px;background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.2);display:flex;align-items:center;justify-content:center;"><i class="fa fa-server" style="color:#34d399;font-size:.7rem;"></i></div>
								<span style="font-family:'Cinzel',serif;font-weight:700;font-size:.78rem;color:var(--text-primary);"><?= t('wildlands.footer.game') ?></span>
							</div>
							<div style="padding:4px 20px 14px;">
								<?php if ($accVersion !== ''): ?><div class="db-srv-row"><span style="color:var(--text-muted);"><?= t('wildlands.account.version') ?></span><span style="font-weight:600;"><?= $h($accVersion) ?></span></div><?php endif; ?>
								<?php if (trim((string) $wlOpt('stat_a_value')) !== ''): ?><div class="db-srv-row"><span style="color:var(--text-muted);"><?= $h($wlOpt('stat_a_label', 'EXP Rate')) ?></span><span style="color:#55d98d;font-weight:600;"><?= $h($wlOpt('stat_a_value')) ?></span></div><?php endif; ?>
								<div class="db-srv-row"><span style="color:var(--text-muted);"><?= $wlServerOnline === false ? t('wildlands.status.offline') : t('wildlands.status.online') ?></span><span class="db-online-dot" style="background:<?= $wlServerOnline === false ? '#e74c3c' : '#22d47a' ?>;box-shadow:0 0 6px <?= $wlServerOnline === false ? '#e74c3c' : '#22d47a' ?>88;"></span></div>
								<div class="db-srv-row" style="padding-top:7px;border-top:1px solid var(--border);">
									<span style="color:var(--text-muted);"><?= t('wildlands.account.your_ip') ?></span>
									<span style="font-family:monospace;font-size:.72rem;color:var(--text-muted);"><?= $h($accYourIp) ?></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>

	<?php else: ?>
		<main class="wl-main">
			<div class="container">
				<div class="wl-head"><h1><?= $h(ucwords(str_replace(array('-', '_'), ' ', $GLOBALS['page_title'] ?? $wlPage))) ?></h1></div>
				<div class="wl-panel"><?php theme_content(); ?></div>
			</div>
		</main>
	<?php endif; ?>

	<footer>
		<div class="container">
			<div class="footer-grid">
				<div>
					<div class="footer-brand"><img src="<?= $wlEmblem ?>" alt="<?= theme_title() ?>" style="height:88px;width:auto;filter:drop-shadow(0 1px 4px rgba(0,0,0,.5));"></div>
					<?php if (trim(strip_tags($wlDesc)) !== ''): ?><p class="footer-desc"><?= $wlDesc ?></p><?php endif; ?>
					<div style="margin-top:16px;display:flex;gap:12px;">
						<?php if ($wlDiscord !== ''): ?><a href="<?= $h($wlDiscord) ?>" target="_blank" rel="noopener" class="wl-social" title="Discord"><i class="fab fa-discord"></i></a><?php endif; ?>
						<?php if ($wlTelegram !== ''): ?><a href="<?= $h($wlTelegram) ?>" target="_blank" rel="noopener" class="wl-social" title="Telegram"><i class="fab fa-telegram"></i></a><?php endif; ?>
						<?php if ($wlYoutube !== ''): ?><a href="<?= $h($wlYoutube) ?>" target="_blank" rel="noopener" class="wl-social" title="YouTube"><i class="fab fa-youtube"></i></a><?php endif; ?>
						<?php if ($wlVk !== ''): ?><a href="<?= $h($wlVk) ?>" target="_blank" rel="noopener" class="wl-social" title="VK"><i class="fab fa-vk"></i></a><?php endif; ?>
					</div>
				</div>
				<div>
					<div class="footer-heading"><?= t('wildlands.footer.navigation') ?></div>
					<ul class="footer-links">
						<li><a href="index.php"><?= t('nav.news') ?></a></li>
						<li><a href="highscores.php"><?= t('nav.highscores') ?></a></li>
						<li><a href="downloads.php"><?= t('wildlands.nav.download') ?></a></li>
						<li><a href="serverinfo.php"><?= t('nav.serverinfo') ?></a></li>
					</ul>
				</div>
				<div>
					<div class="footer-heading"><?= t('wildlands.footer.game') ?></div>
					<ul class="footer-links">
						<li><a href="guilds.php"><?= t('nav.guilds') ?></a></li>
						<li><a href="onlinelist.php"><?= t('wildlands.nav.online') ?></a></li>
						<li><a href="shop.php"><?= t('nav.shop') ?></a></li>
						<li><a href="lastkills.php"><?= t('wildlands.nav.lastkills') ?></a></li>
					</ul>
				</div>
				<div>
					<div class="footer-heading"><?= t('wildlands.footer.support') ?></div>
					<ul class="footer-links">
						<li><a href="register.php"><?= t('wildlands.header.register') ?></a></li>
						<li><a href="lostaccount.php"><?= t('wildlands.footer.lost') ?></a></li>
						<?php if ($wlForum !== ''): ?><li><a href="<?= $h($wlForum) ?>" target="_blank" rel="noopener"><?= t('wildlands.nav.forum') ?></a></li><?php endif; ?>
						<li><a href="credits.php"><?= t('wildlands.footer.credits') ?></a></li>
					</ul>
				</div>
			</div>
			<div class="footer-bottom">
				<span>&copy; <?= date('Y') ?> <?= theme_title() ?>. <?= t('wildlands.footer.rights') ?><?php if (trim(strip_tags($wlFootHtml)) !== ''): ?> &middot; <?= $wlFootHtml ?><?php endif; ?></span>
				<span><?= t('wildlands.footer.powered') ?> <a href="credits.php">ZnoteX</a> &middot; <?= function_exists('elapsedTime') ? elapsedTime() : '0' ?>s</span>
			</div>
		</div>
	</footer>

</div>

<script src="<?= theme_asset('js/wildlands.js') ?>" defer></script>
</body>
</html>
