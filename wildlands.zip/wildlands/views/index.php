<?php
/**
 * Wildlands - front page (and the single news article view).
 *
 * Converted from the losena home route. The hero emblem, eyebrow, tagline,
 * pill and the three right-hand stat boxes are Admin Panel > Layouts options;
 * Online and Accounts are live. News fills the "Latest News" card, the
 * changelog ticker fills the second card, and a players query fills "Top
 * Players". Prepared by index.php: $news, $changelogs, $page, $view.
 */

$h  = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$bb = static function ($v): string { return function_exists('znote_bbcode_raw') ? znote_bbcode_raw((string) $v) : (string) $v; };
$opt = static function (string $k, string $d = '') { return function_exists('theme_option') ? (theme_option($k) !== '' ? theme_option($k) : $d) : $d; };
$excerpt = static function ($text, int $len = 90) use ($bb): string {
	$plain = trim(preg_replace('~\s+~', ' ', strip_tags($bb((string) $text))));
	if (function_exists('mb_strimwidth')) return mb_strimwidth($plain, 0, $len, '…', 'UTF-8');
	return strlen($plain) > $len ? substr($plain, 0, $len - 1) . '…' : $plain;
};
$plainTitle = static function ($t) use ($bb): string { return trim(strip_tags($bb((string) $t))); };

$newsItems = is_array($news ?? null) ? array_values($news) : array();
$logItems  = is_array($changelogs ?? null) ? array_values($changelogs) : array();

// ---- single article -------------------------------------------------
if (($view ?? '') !== '') {
	$article = null;
	foreach ($newsItems as $row) {
		if ((ctype_digit((string) $view) && (int) $view === (int) $row['id']) || urlencode($row['title']) === $view) { $article = $row; break; }
	}
	?>
	<main class="wl-main">
		<div class="container">
			<div class="wl-head"><h1><i class="fa fa-newspaper"></i> <?= $article ? $h($plainTitle($article['title'])) : $h(t('news.not_found')) ?></h1></div>
			<div class="wl-panel">
				<?php if ($article): ?>
					<p class="text-muted" style="margin-bottom:14px;font-size:.85rem;">
						<?= $h(getClock((int) $article['date'], true)) ?> &middot; <?= t('news.by') ?>
						<a href="characterprofile.php?name=<?= $h(urlencode($article['name'])) ?>"><?= $h($article['name']) ?></a>
					</p>
					<div><?= $bb($article['text']) ?></div>
				<?php else: ?>
					<p><?= t('news.not_found_text') ?></p>
				<?php endif; ?>
				<p style="margin-top:20px;"><a class="btn btn-secondary btn-sm" href="index.php">&larr; <?= t('wildlands.news.back') ?></a></p>
			</div>
		</div>
	</main>
	<?php
	return;
}

// ---- live numbers --------------------------------------------------
$wlOnline = (int) (function_exists('user_count_online') ? user_count_online() : 0);

$wlAccounts = 0;
if (function_exists('mysql_select_single')) {
	$c = new Cache('engine/cache/wildlands_accounts');
	if ($c->hasExpired()) {
		$row = mysql_select_single("SELECT COUNT(*) AS c FROM `accounts`;");
		$wlAccounts = is_array($row) ? (int) $row['c'] : 0;
		$c->setContent($wlAccounts);
		$c->save();
	} else {
		$wlAccounts = (int) $c->load();
	}
}

$wlIgnore = (int) ($config['highscore']['ignoreGroupId'] ?? 2);
$wlTop = array();
if (function_exists('mysql_select_multi')) {
	$c = new Cache('engine/cache/wildlands_top');
	if ($c->hasExpired()) {
		$wlTop = mysql_select_multi("
			SELECT `p`.`name`, `p`.`level`, `p`.`experience`, `p`.`vocation`,
			       `p`.`looktype`, `p`.`lookhead`, `p`.`lookbody`, `p`.`looklegs`, `p`.`lookfeet`,
			       `g`.`name` AS `guild`
			FROM `players` `p`
			LEFT JOIN `guild_membership` `gm` ON `gm`.`player_id` = `p`.`id`
			LEFT JOIN `guilds` `g` ON `g`.`id` = `gm`.`guild_id`
			WHERE `p`.`group_id` < {$wlIgnore}
			ORDER BY `p`.`level` DESC, `p`.`experience` DESC
			LIMIT 5;
		");
		$wlTop = is_array($wlTop) ? $wlTop : array();
		$c->setContent($wlTop);
		$c->save();
	} else {
		$wlTop = is_array($c->load()) ? $c->load() : array();
	}
}
$wlMaxLevel = 0;
foreach ($wlTop as $p) $wlMaxLevel = max($wlMaxLevel, (int) $p['level']);
$wlMaxLevel = max($wlMaxLevel, 1);

$wlOutfitSrv = trim((string) ($config['show_outfits']['imageServer'] ?? ''));
$wlOutfit = static function (array $p) use ($wlOutfitSrv): string {
	if ($wlOutfitSrv === '' || (int) ($p['looktype'] ?? 0) <= 0) return '';
	return $wlOutfitSrv . '?' . http_build_query(array(
		'id' => (int) $p['looktype'], 'addons' => 3, 'direction' => 3,
		'head' => (int) ($p['lookhead'] ?? 0), 'body' => (int) ($p['lookbody'] ?? 0),
		'legs' => (int) ($p['looklegs'] ?? 0), 'feet' => (int) ($p['lookfeet'] ?? 0),
	));
};
$wlVoc = static function (int $v): string { return function_exists('vocation_id_to_name') ? (string) vocation_id_to_name($v) : ''; };

$wlDownload = $opt('hero_download_url', 'downloads.php');
$wlForum    = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$wlDiscord  = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$wlPill     = trim((string) $opt('hero_pill', 'No Pay2Win'));
$wlEyebrow  = trim((string) $opt('eyebrow_text'));
$wlTagline  = trim((string) $opt('hero_tagline'));
$wlEmblem   = function_exists('theme_image') ? theme_image('logo_emblem', theme_asset('images/logo.png')) : theme_asset('images/logo.png');
$rankColors = array('#d4a843', '#c0c8d4', '#cd7f47', '#8ab4d6', '#8ab4d6');
?>

<section class="ic-hero">
	<div class="ic-inner">
		<?php if ($wlEyebrow !== ''): ?><div class="ic-eyebrow"><span></span><?= $h($wlEyebrow) ?><span></span></div><?php endif; ?>
		<div class="ic-logo-wrap">
			<img src="<?= $wlEmblem ?>" alt="<?= theme_title() ?>" class="ic-logo-img" style="max-width:420px;">
		</div>
		<?php if ($wlTagline !== ''): ?><div class="ic-rule"><span><?= $h($wlTagline) ?></span></div><?php endif; ?>
		<?php if ($wlPill !== ''): ?><div class="ic-opill"><?= $h($wlPill) ?></div><?php endif; ?>

		<div class="ic-btns">
			<a href="<?= $h($wlDownload) ?>" class="ic-btn ic-btn-g"><i class="fa fa-download"></i> <?= t('wildlands.hero.download') ?></a>
			<a href="register.php" class="ic-btn ic-btn-o"><i class="fa fa-user-plus"></i> <?= t('wildlands.hero.register') ?></a>
		</div>

		<div class="ic-stats">
			<div class="ic-stat ic-live">
				<div class="ic-sn" id="ic-online"><?= number_format($wlOnline) ?></div>
				<div class="ic-sl"><?= t('wildlands.hero.ingame') ?></div>
				<div class="ic-tab" onclick="icTog(this)"><i class="fa fa-angle-down"></i><i class="fa fa-angle-down"></i></div>
				<div class="ic-pop">
					<div class="ic-pop-h"><span class="dot"></span><?= t('wildlands.hero.activity') ?></div>
					<div class="ic-pop-b">
						<div class="ic-pop-r"><span class="l"><i class="fa fa-gamepad"></i><?= t('wildlands.hero.ingame') ?></span><span class="v"><?= number_format($wlOnline) ?></span></div>
						<div class="ic-pop-r"><span class="l"><i class="fa fa-users"></i><?= t('wildlands.hero.accounts') ?></span><span class="v"><?= number_format($wlAccounts) ?></span></div>
						<a href="onlinelist.php" class="ic-pop-cta"><i class="fa fa-list"></i> <?= t('wildlands.hero.who_online') ?></a>
					</div>
				</div>
			</div>

			<div class="ic-stat ic-pop-host">
				<div class="ic-sn"><?= number_format($wlAccounts) ?></div>
				<div class="ic-sl"><?= t('wildlands.hero.accounts') ?></div>
				<div class="ic-tab" onclick="icTog(this)"><i class="fa fa-angle-down"></i><i class="fa fa-angle-down"></i></div>
				<div class="ic-pop">
					<div class="ic-pop-h gold"><i class="fa fa-user-group"></i> <?= t('wildlands.hero.accounts') ?></div>
					<div class="ic-pop-b">
						<div class="ic-pop-r"><span class="l"><i class="fa fa-database"></i><?= t('wildlands.hero.total_accounts') ?></span><span class="v"><?= number_format($wlAccounts) ?></span></div>
						<div class="ic-pop-note"><?= t('wildlands.hero.join_free') ?></div>
						<a href="register.php" class="ic-pop-cta"><i class="fa fa-user-plus"></i> <?= t('wildlands.hero.create_account') ?></a>
					</div>
				</div>
			</div>

			<?php
			$customStats = array(
				array($opt('stat_a_value', 'x50'), $opt('stat_a_label', 'EXP Rate')),
				array($opt('stat_b_value', ''),    $opt('stat_b_label', '')),
				array($opt('stat_c_value', ''),    $opt('stat_c_label', '')),
			);
			foreach ($customStats as $i => $s):
				if (trim((string) $s[0]) === '') continue;
				$isExp = $i === 0;
			?>
				<div class="ic-stat ic-pop-host">
					<div class="<?= $isExp ? 'ic-sn-exp' : 'ic-sn' ?>"><?= $h($s[0]) ?></div>
					<div class="<?= $isExp ? 'ic-sl-exp' : 'ic-sl' ?>"><?= $h($s[1]) ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<div class="container" style="padding-bottom:60px;">

	<div class="ic-sh">
		<div class="ic-st"><span class="ic-sb"></span><i class="fa fa-layer-group" style="color:#8ab4d6;font-size:.82rem;"></i> <?= t('wildlands.section.news') ?></div>
	</div>
	<div class="ic-gh">
		<div class="ic-card">
			<div class="ic-ch">
				<div class="ic-ct"><i class="fa fa-newspaper" style="color:#8ab4d6;"></i> <?= t('wildlands.section.latest_news') ?></div>
				<a href="index.php" class="ic-sl2"><?= t('wildlands.section.all_news') ?> &rarr;</a>
			</div>
			<?php if ($newsItems): foreach (array_slice($newsItems, 0, 5) as $n): ?>
				<a href="index.php?view=<?= (int) $n['id'] ?>" class="ic-nr">
					<div><div class="ic-nday"><?= date('d', (int) $n['date']) ?></div><div class="ic-nmo"><?= date('M', (int) $n['date']) ?></div></div>
					<div class="ic-nd"></div>
					<div>
						<span class="ic-nc" style="background:rgba(80,80,80,.9);"><?= t('nav.news') ?></span>
						<div class="ic-nt"><?= $h($plainTitle($n['title'])) ?></div>
						<div class="ic-ne"><?= $h($excerpt($n['text'])) ?></div>
					</div>
					<div class="ic-na"><i class="fa fa-chevron-right"></i></div>
				</a>
			<?php endforeach; else: ?>
				<div class="ic-empty"><i class="fa fa-newspaper"></i><?= t('news.none') ?></div>
			<?php endif; ?>
		</div>

		<div class="ic-card">
			<div class="ic-ch">
				<div class="ic-ct"><i class="fa fa-scroll" style="color:#8ab4d6;"></i> <?= t('wildlands.section.changelog') ?></div>
				<a href="changelog.php" class="ic-sl2"><?= t('wildlands.section.all_changes') ?> &rarr;</a>
			</div>
			<?php if ($logItems): foreach (array_slice($logItems, 0, 6) as $cl): ?>
				<div class="ic-gr" style="cursor:default;">
					<div class="ic-gi"><i class="fa fa-wrench" style="color:rgba(138,180,214,.6);"></i></div>
					<div class="ic-gb">
						<div class="ic-gm2"><i class="fa fa-clock"></i><?= $h(getClock((int) ($cl['time'] ?? 0), true, true)) ?></div>
						<div class="ic-gtt" style="font-weight:600;font-family:'Nunito',sans-serif;font-size:.78rem;"><?= $bb((string) ($cl['text'] ?? '')) ?></div>
					</div>
				</div>
			<?php endforeach; else: ?>
				<div class="ic-empty"><i class="fa fa-scroll"></i><?= t('news.no_changelogs') ?></div>
			<?php endif; ?>
		</div>
	</div>

	<div class="ic-sh">
		<div class="ic-st"><span class="ic-sb"></span><i class="fa fa-trophy" style="color:#8ab4d6;font-size:.82rem;"></i> <?= t('wildlands.section.top_players') ?></div>
		<a href="highscores.php" class="ic-sl2"><?= t('wildlands.section.full_rankings') ?> &rarr;</a>
	</div>
	<div class="ic-gm">
		<div class="ic-card">
			<div class="ic-ch">
				<div class="ic-ct"><i class="fa fa-trophy" style="color:#8ab4d6;"></i> <?= t('wildlands.section.by_level') ?></div>
				<a href="highscores.php" class="ic-sl2"><?= t('wildlands.section.view_all') ?> &rarr;</a>
			</div>
			<?php if ($wlTop): foreach ($wlTop as $i => $p): $rank = $i + 1; $pct = round(min(100, (int) $p['level'] / $wlMaxLevel * 100), 1); ?>
				<div class="tpc-row">
					<div class="tpc-rank" style="color:<?= $rankColors[$i] ?? '#8ab4d6' ?>;"><?= $rank ?></div>
					<div class="tpc-av">
						<?php $of = $wlOutfit($p); if ($of !== ''): ?>
							<img src="<?= $h($of) ?>" style="bottom:-4px;width:54px;height:54px;" loading="lazy" onerror="this.remove()">
						<?php else: ?>
							<i class="fa fa-user" style="color:#8ab4d6;font-size:1.1rem;position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);"></i>
						<?php endif; ?>
					</div>
					<div style="min-width:0;">
						<div class="tpc-name">
							<a href="characterprofile.php?name=<?= $h(urlencode($p['name'])) ?>" style="color:inherit;text-decoration:none;"><?= $h($p['name']) ?></a>
							<?php if (!empty($p['guild'])): ?>
								<span class="tpc-guild" title="<?= $h($p['guild']) ?>">
									<svg viewBox="0 0 24 24" width="9" height="9" fill="currentColor"><path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z"/></svg><?= $h($p['guild']) ?>
								</span>
							<?php endif; ?>
						</div>
						<div class="tpc-meta">
							<?php $vn = $wlVoc((int) $p['vocation']); if ($vn !== ''): ?>
								<span class="tpc-cls" style="background:rgba(138,180,214,.12);border:1px solid rgba(138,180,214,.25);color:#8ab4d6;"><?= $h($vn) ?></span>
							<?php endif; ?>
						</div>
						<div class="tpc-brow">
							<span class="tpc-blbl" style="color:#4d8fff;"><?= t('wildlands.section.lvl') ?></span>
							<div class="tpc-track"><div class="tpc-fill" data-w="<?= $pct ?>" style="background:linear-gradient(90deg,#1a3568,#3f78d4 60%,#7ea3df);"></div></div>
							<span class="tpc-bval"><span class="tpc-cnt" data-to="<?= (int) $p['level'] ?>" style="color:#a9c9ff;font-weight:800;">0</span></span>
						</div>
					</div>
				</div>
			<?php endforeach; else: ?>
				<div class="ic-empty"><i class="fa fa-trophy"></i><?= t('common.nothing') ?></div>
			<?php endif; ?>
		</div>

		<div class="ic-card" style="display:flex;flex-direction:column;">
			<div class="ic-ch"><div class="ic-ct"><i class="fa fa-star" style="color:#8ab4d6;"></i> <?= t('wildlands.section.community') ?></div></div>
			<div style="padding:16px 17px;flex:1;">
				<p class="ic-vd"><?= t('wildlands.section.community_text') ?></p>
				<?php if ($wlDiscord !== ''): ?><a href="<?= $h($wlDiscord) ?>" target="_blank" rel="noopener" class="ic-vb"><i class="fab fa-discord"></i> Discord</a><?php endif; ?>
				<?php if ($wlForum !== ''): ?><a href="<?= $h($wlForum) ?>" target="_blank" rel="noopener" class="ic-vb"><i class="fa fa-comments"></i> <?= t('wildlands.nav.forum') ?></a><?php endif; ?>
				<a href="serverinfo.php" class="ic-vb"><i class="fa fa-circle-info"></i> <?= t('nav.serverinfo') ?></a>
				<a href="highscores.php" class="ic-vb"><i class="fa fa-ranking-star"></i> <?= t('nav.highscores') ?></a>
			</div>
		</div>
	</div>

</div>
