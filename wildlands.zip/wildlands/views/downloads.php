<?php
/**
 * Wildlands - Download Center.
 *
 * Converted from losena/download.html (.dl-* components). Files come from the
 * "Download page - files" theme option (Label | URL | size | note | section
 * per line); when it is empty it falls back to $config['client_download'] and
 * $config['client_download_linux'].
 */

$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$opt = static function (string $k) { return function_exists('theme_option') ? trim((string) theme_option($k)) : ''; };

$version = isset($config['client']) && (int) $config['client'] > 0
	? rtrim(rtrim(number_format($config['client'] / 100, 2, '.', ''), '0'), '.')
	: '';
$serverIp = (string) ($config['server_ip'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost'));

$accents = array('#c89600', '#d4a843', '#8ab4d6', '#4774cf', '#22d47a', '#a78bfa');

$files = array();
foreach (preg_split('/\r\n|\r|\n/', $opt('download_links')) as $line) {
	$line = trim($line);
	if ($line === '' || strpos($line, '|') === false) continue;
	$parts = array_map('trim', explode('|', $line));
	$url = $parts[1] ?? '';
	if ($url === '' || !preg_match('~^https?://~i', $url)) continue;
	$files[] = array(
		'label'   => $parts[0] !== '' ? $parts[0] : 'Download',
		'url'     => $url,
		'size'    => $parts[2] ?? '',
		'note'    => $parts[3] ?? '',
		'section' => $parts[4] !== '' ? ($parts[4] ?? '') : t('wildlands.dl.section_client'),
	);
}
if (!$files) {
	$win = trim((string) ($config['client_download'] ?? ''));
	$lin = trim((string) ($config['client_download_linux'] ?? ''));
	if ($win !== '') $files[] = array('label' => t('wildlands.dl.windows'), 'url' => $win, 'size' => '', 'note' => $version !== '' ? 'v' . $version : '', 'section' => t('wildlands.dl.section_client'));
	if ($lin !== '') $files[] = array('label' => t('wildlands.dl.linux'), 'url' => $lin, 'size' => '', 'note' => $version !== '' ? 'v' . $version : '', 'section' => t('wildlands.dl.section_client'));
}
$files[] = array('label' => t('wildlands.dl.ipchanger'), 'url' => 'https://github.com/jo3bingham/tibia-ip-changer/releases/latest', 'size' => '', 'note' => '', 'section' => t('wildlands.dl.section_tools'));

$sections = array();
foreach ($files as $i => $f) {
	$f['_accent'] = $accents[$i % count($accents)];
	$sections[$f['section']][] = $f;
}
$intro = $opt('download_note');
if ($intro === '') $intro = t('wildlands.dl.intro');
?>

<div id="site-main">
<div class="container dl-wrap">

	<div style="position:relative;padding:36px 0 24px;overflow:hidden;">
		<div style="position:absolute;top:-80px;right:-80px;width:400px;height:400px;background:radial-gradient(circle,rgba(100,160,210,.06),transparent 65%);pointer-events:none;"></div>
		<div style="font-size:.52rem;letter-spacing:4px;text-transform:uppercase;color:rgba(100,160,210,.5);margin-bottom:10px;"><?= $h(t('wildlands.dl.eyebrow')) ?></div>
		<h1 style="display:flex;align-items:center;gap:14px;font-family:'Cinzel',serif;font-size:1.6rem;font-weight:900;letter-spacing:1.5px;text-transform:uppercase;margin:0 0 8px;">
			<div style="width:42px;height:42px;background:rgba(100,160,210,.1);border:1px solid rgba(100,160,210,.25);border-radius:10px;display:flex;align-items:center;justify-content:center;">
				<i class="fa fa-download" style="color:#8ab4d6;font-size:.9rem;"></i>
			</div><?= $h(t('wildlands.dl.title')) ?>
		</h1>
		<p style="color:var(--text-muted);font-size:.82rem;margin:0 0 0 56px;"><?= $h($intro) ?></p>
	</div>

	<div style="background:rgba(17,24,39,var(--op-cards));border:1px solid var(--border);border-radius:14px;">

		<div style="padding:18px 22px 0;">
			<div class="dl-stats">
				<?php if ($version !== ''): ?>
				<div class="dl-stat">
					<div class="dl-stat-icon" style="background:rgba(100,160,210,.1);border:1px solid rgba(100,160,210,.2);"><i class="fa fa-gamepad" style="color:#8ab4d6;"></i></div>
					<div><div class="dl-stat-val"><?= $h($version) ?></div><div class="dl-stat-lbl"><?= $h(t('wildlands.dl.stat_version')) ?></div></div>
				</div>
				<?php endif; ?>
				<div class="dl-stat">
					<div class="dl-stat-icon" style="background:rgba(34,212,122,.08);border:1px solid rgba(34,212,122,.15);"><i class="fa fa-file-arrow-down" style="color:#22d47a;"></i></div>
					<div><div class="dl-stat-val"><?= count($files) ?></div><div class="dl-stat-lbl"><?= $h(t('wildlands.dl.stat_files')) ?></div></div>
				</div>
				<div class="dl-stat">
					<div class="dl-stat-icon" style="background:rgba(77,143,255,.08);border:1px solid rgba(77,143,255,.15);"><i class="fa fa-server" style="color:#4d8fff;"></i></div>
					<div><div class="dl-stat-val" style="font-size:.95rem;"><?= $h($serverIp) ?></div><div class="dl-stat-lbl"><?= $h(t('wildlands.dl.stat_server')) ?></div></div>
				</div>
			</div>
		</div>

		<?php if (count($sections) > 1): ?>
		<div style="padding:14px 22px 0;">
			<div class="dl-cats">
				<span class="dl-cat-tab active" onclick="dlFilter('all', this)"><i class="fa fa-layer-group"></i> <?= $h(t('wildlands.dl.all')) ?> <span class="dl-cat-count"><?= count($files) ?></span></span>
				<?php $si = 0; foreach ($sections as $sname => $sfiles): $si++; ?>
					<span class="dl-cat-tab" onclick="dlFilter('sec<?= $si ?>', this)"><i class="fa fa-folder"></i> <?= $h($sname) ?> <span class="dl-cat-count"><?= count($sfiles) ?></span></span>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>

		<div style="padding:12px 22px 8px;"><div style="height:1px;background:linear-gradient(90deg,transparent,rgba(100,160,210,.2),transparent);"></div></div>

		<div style="padding:0 22px 22px;">
			<div class="dl-howto">
				<div class="dl-howto-ico"><i class="fa fa-circle-info"></i></div>
				<div>
					<div class="dl-howto-title"><?= $h(t('wildlands.dl.howto')) ?></div>
					<div class="dl-steps">
						<div class="dl-step"><div class="dl-step-num">1</div><?= $h(t('wildlands.dl.step1')) ?></div>
						<div class="dl-step"><div class="dl-step-num">2</div><?= $h(t('wildlands.dl.step2')) ?></div>
						<div class="dl-step"><div class="dl-step-num">3</div><?= $h(t('wildlands.dl.step3')) ?></div>
						<div class="dl-step"><div class="dl-step-num">4</div><?= $h(t('wildlands.dl.step4', array('ip' => $serverIp))) ?></div>
					</div>
				</div>
			</div>

			<?php $si = 0; foreach ($sections as $sname => $sfiles): $si++; ?>
				<div class="dl-cat-section" data-cat="sec<?= $si ?>" style="margin-bottom:24px;">
					<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
						<div style="width:30px;height:30px;background:#8ab4d618;border:1px solid #8ab4d630;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-folder-open" style="color:#8ab4d6;font-size:.75rem;"></i></div>
						<span style="font-size:.72rem;font-weight:800;text-transform:uppercase;letter-spacing:2px;color:#8ab4d6;"><?= $h($sname) ?></span>
						<div style="flex:1;height:1px;background:linear-gradient(90deg,#8ab4d630,transparent);"></div>
						<span style="font-size:.65rem;color:var(--text-muted);"><?= count($sfiles) ?> <?= $h(t('wildlands.dl.files_lc')) ?></span>
					</div>
					<div class="dl-grid">
						<?php foreach ($sfiles as $f): $host = parse_url($f['url'], PHP_URL_HOST) ?: ''; ?>
							<div class="dl-card" style="animation:fadeup .4s ease both;">
								<div class="dl-card-accent" style="background:linear-gradient(90deg,<?= $f['_accent'] ?>,transparent);"></div>
								<div class="dl-card-inner">
									<div class="dl-card-head">
										<div class="dl-card-ico" style="background:<?= $f['_accent'] ?>18;border:1px solid <?= $f['_accent'] ?>30;"><i class="fa fa-download" style="color:<?= $f['_accent'] ?>;"></i></div>
										<div style="flex:1;min-width:0;">
											<div class="dl-card-title"><?= $h($f['label']) ?></div>
											<div class="dl-card-desc"><?= $h($host) ?></div>
										</div>
									</div>
									<?php if ($f['size'] !== '' || $f['note'] !== ''): ?>
									<div class="dl-card-meta">
										<?php if ($f['size'] !== ''): ?><span><i class="fa fa-weight-hanging"></i><?= $h($f['size']) ?></span><?php endif; ?>
										<?php if ($f['note'] !== ''): ?><span><i class="fa fa-tag"></i><?= $h($f['note']) ?></span><?php endif; ?>
									</div>
									<?php endif; ?>
									<div class="dl-card-btns">
										<a href="<?= $h($f['url']) ?>" class="dl-btn dl-btn-primary" style="flex:1;justify-content:center;" target="_blank" rel="noopener"><i class="fa fa-download"></i> <?= $h(t('wildlands.dl.download')) ?></a>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>
</div>

<script>
function dlFilter(cat, el) {
	document.querySelectorAll('.dl-cat-tab').forEach(function (t) { t.classList.remove('active'); });
	el.classList.add('active');
	document.querySelectorAll('.dl-cat-section').forEach(function (s) {
		s.style.display = (cat === 'all' || s.dataset.cat === cat) ? '' : 'none';
	});
}
</script>
