/* Wildlands theme - front-end behaviour.
   Ported from the losena scrape: mobile nav, dropdown toggles, the hero
   stat popovers, the ranking count-up bars and the navbar "mercury" blob.
   The original online-count / language cookie code was removed - ZnoteX
   renders those server-side. */
(function () {
	'use strict';

	// ---- mobile nav -------------------------------------------------
	var toggle = document.getElementById('navToggle');
	var nav = document.getElementById('mainNav');
	if (toggle && nav) {
		toggle.addEventListener('click', function () { nav.classList.toggle('open'); });
	}

	// ---- dropdown open on tap (mobile) ----------------------------
	document.querySelectorAll('.nav-dropdown > a').forEach(function (a) {
		a.addEventListener('click', function (e) {
			if (window.innerWidth <= 768) {
				e.preventDefault();
				a.parentNode.classList.toggle('is-open');
				var m = a.parentNode.querySelector('.nav-dropdown-menu');
				if (m) {
					var open = a.parentNode.classList.contains('is-open');
					m.style.opacity = open ? '1' : '';
					m.style.visibility = open ? 'visible' : '';
					m.style.transform = open ? 'none' : '';
				}
			}
		});
	});

	// ---- account menu (status bar / actions) ---------------------
	document.querySelectorAll('[data-wl-dd]').forEach(function (btn) {
		btn.addEventListener('click', function (e) {
			e.stopPropagation();
			var wrap = btn.closest('[data-wl-dd-wrap]') || btn.parentNode;
			wrap.classList.toggle('is-open');
		});
	});
	document.addEventListener('click', function () {
		document.querySelectorAll('[data-wl-dd-wrap].is-open').forEach(function (w) { w.classList.remove('is-open'); });
	});

	// ---- hero stat popovers -------------------------------------
	window.icTog = function (el) {
		var st = el.closest('.ic-stat');
		if (!st) return;
		var wasOpen = st.classList.contains('open');
		st.closest('.ic-stats').querySelectorAll('.ic-stat.open').forEach(function (x) { x.classList.remove('open'); });
		if (!wasOpen) st.classList.add('open');
	};
	document.addEventListener('click', function (e) {
		if (!e.target.closest('.ic-tab') && !e.target.closest('.ic-pop')) {
			document.querySelectorAll('.ic-stat.open').forEach(function (x) { x.classList.remove('open'); });
		}
	});

	// ---- ranking count-up + bar fill ---------------------------
	function countUp() {
		document.querySelectorAll('.tpc-cnt').forEach(function (el, i) {
			var to = parseInt(el.getAttribute('data-to'), 10) || 0, dur = 1300, t0 = null;
			function step(ts) {
				t0 = t0 || ts;
				var k = Math.min((ts - t0) / dur, 1);
				el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString();
				if (k < 1) requestAnimationFrame(step);
			}
			setTimeout(function () { requestAnimationFrame(step); }, 150 + i * 40);
		});
		setTimeout(function () {
			document.querySelectorAll('.tpc-fill').forEach(function (el) {
				el.style.width = (el.getAttribute('data-w') || 0) + '%';
			});
		}, 120);
	}
	if (document.readyState !== 'loading') countUp();
	else document.addEventListener('DOMContentLoaded', countUp);

	// ---- navbar mercury blob ----------------------------------
	(function () {
		if (!nav) return;
		if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
		var host = nav.querySelector('.nav-goo-host');
		if (!host) return;
		var blob = host.querySelector('.nav-goo-blob'),
			drop = host.querySelector('.nav-goo-drop'),
			shine = host.querySelector('.nav-goo-shine');
		if (!blob || !drop || !shine) return;

		var links = [];
		[].forEach.call(nav.children, function (li) {
			var a = li.firstElementChild;
			if (a && a.tagName === 'A' && a.getAttribute('href') !== '#') links.push(a);
		});
		if (!links.length) return;
		nav.classList.add('nav-mercury');

		var active = null;
		links.forEach(function (a) { if (a.classList.contains('active')) active = a; });

		var current = null, dropTimer = null;
		var DROP = 7.5;

		function enabled() { return window.innerWidth > 768; }
		function box(a) {
			var r = a.getBoundingClientRect(), n = nav.getBoundingClientRect();
			return { x: r.left - n.left, y: r.top - n.top, w: r.width, h: r.height, c: r.left - n.left + r.width / 2 };
		}
		function paint(a) {
			links.forEach(function (l) { l.classList.remove('goo-on'); });
			if (a) a.classList.add('goo-on');
		}
		function moveTo(a, withDrop) {
			if (!a) { blob.style.opacity = shine.style.opacity = '0'; paint(null); return; }
			var b = box(a);
			blob.style.opacity = shine.style.opacity = '1';
			[blob, shine].forEach(function (el) {
				el.style.height = b.h + 'px';
				el.style.width = b.w + 'px';
				el.style.transform = 'translate(' + b.x + 'px,' + b.y + 'px)';
			});
			paint(a);
			if (withDrop) {
				drop.style.opacity = '1';
				drop.style.transform = 'translate(' + (b.c - DROP) + 'px,' + (b.y + b.h / 2 - DROP) + 'px)';
				clearTimeout(dropTimer);
				dropTimer = setTimeout(function () { drop.style.opacity = '0'; }, 260);
			}
		}
		function settle() { moveTo(active, false); }

		requestAnimationFrame(settle);
		links.forEach(function (a) {
			a.addEventListener('mouseenter', function () { if (enabled()) { current = a; moveTo(a, true); } });
		});
		nav.addEventListener('mouseleave', function () { if (enabled()) { current = null; settle(); } });
		window.addEventListener('resize', function () { (current || active) && moveTo(current || active, false); });
	})();
})();
