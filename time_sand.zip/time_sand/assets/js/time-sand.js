/**
 * Time Sand - front-end behaviour.
 *
 * Vanilla replacements for the Angular pieces that were removed: the header
 * (scroll state, mobile drawer, dropdowns), the 3D hero carousel and the
 * "how to start" slider. No analytics, no captcha, no external calls.
 */
(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') fn();
		else document.addEventListener('DOMContentLoaded', fn);
	}

	ready(function () {
		initHeader();
		initDropdowns();
		initMobileNav();
		initCarousel();
		initStartSlider();
		initNewsPager();
		initCopyButtons();
		initShop();
	});

	/* --------------------------------------------------------------- shop */
	function initShop() {
		var filter = document.querySelector('[data-shop-grid]');
		if (filter) {
			var cards = Array.prototype.slice.call(filter.querySelectorAll('[data-shop-item]'));
			document.querySelectorAll('[data-shop-cat]').forEach(function (btn) {
				btn.addEventListener('click', function () {
					var cat = btn.getAttribute('data-shop-cat');
					document.querySelectorAll('[data-shop-cat]').forEach(function (b) {
						b.classList.toggle('nz-segment__btn--active', b === btn);
					});
					cards.forEach(function (c) {
						c.hidden = (cat !== 'all' && c.getAttribute('data-shop-item') !== cat);
					});
				});
			});
		}
		document.querySelectorAll('.needconfirmation').forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				var name = btn.getAttribute('data-item-name') || '';
				var cost = btn.getAttribute('data-item-cost') || '';
				if (!window.confirm('Buy "' + name + '" for ' + cost + ' points?')) {
					e.preventDefault();
				}
			});
		});
	}

	/* ------------------------------------------------------- copy buttons */
	function initCopyButtons() {
		document.querySelectorAll('[data-copy]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var target = document.querySelector(btn.getAttribute('data-copy'));
				if (!target) return;
				var text = (target.textContent || '').trim();
				var done = function () {
					btn.classList.add('is-copied');
					setTimeout(function () { btn.classList.remove('is-copied'); }, 1600);
				};
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(text).then(done, function () {});
				} else {
					var r = document.createRange(); r.selectNode(target);
					var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
					try { document.execCommand('copy'); done(); } catch (e) {}
					s.removeAllRanges();
				}
			});
		});
	}

	/* ---------------------------------------------------------------- header */
	function initHeader() {
		var header = document.getElementById('ts-header');
		if (!header) return;
		var onScroll = function () {
			header.classList.toggle('header--scrolled', window.scrollY > 20);
		};
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
	}

	function initDropdowns() {
		var triggers = document.querySelectorAll('[data-ts-dropdown]');
		if (!triggers.length) return;
		triggers.forEach(function (btn) {
			var item = btn.closest('.dropdown');
			if (!item) return;
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var open = item.classList.contains('open');
				document.querySelectorAll('.dropdown.open').forEach(function (o) { o.classList.remove('open'); });
				if (!open) item.classList.add('open');
			});
		});
		document.addEventListener('click', function (e) {
			if (!e.target.closest('.dropdown')) {
				document.querySelectorAll('.dropdown.open').forEach(function (o) { o.classList.remove('open'); });
			}
		});
	}

	function initMobileNav() {
		var nav = document.getElementById('ts-nav');
		var openBtn = document.querySelector('[data-ts-nav-open]');
		var closeBtn = document.querySelector('[data-ts-nav-close]');
		if (!nav || !openBtn) return;
		var setOpen = function (on) {
			nav.classList.toggle('active', on);
			openBtn.classList.toggle('active', on);
			openBtn.setAttribute('aria-expanded', on ? 'true' : 'false');
			document.body.classList.toggle('nz-menu-open', on);
		};
		openBtn.addEventListener('click', function () { setOpen(!nav.classList.contains('active')); });
		if (closeBtn) closeBtn.addEventListener('click', function () { setOpen(false); });
		nav.querySelectorAll('a.nav__link').forEach(function (a) {
			a.addEventListener('click', function () { setOpen(false); });
		});
	}

	/* ------------------------------------------------------------- carousel */
	function initCarousel() {
		var root = document.querySelector('.carousel-3d');
		if (!root) return;
		var slides = Array.prototype.slice.call(root.querySelectorAll('.carousel-slide'));
		var dots = Array.prototype.slice.call(root.querySelectorAll('.carousel-dots .dot'));
		if (slides.length === 0) return;
		var current = 0;
		var n = slides.length;
		var timer = null;

		function render() {
			slides.forEach(function (s, i) {
				s.classList.remove('active', 'prev', 'next', 'hidden');
				if (i === current) s.classList.add('active');
				else if (n > 1 && i === (current - 1 + n) % n) s.classList.add('prev');
				else if (n > 2 && i === (current + 1) % n) s.classList.add('next');
				else s.classList.add('hidden');
			});
			dots.forEach(function (d, i) { d.classList.toggle('active', i === current); });
		}

		function go(i) { current = (i % n + n) % n; render(); }
		function next() { go(current + 1); }
		function prev() { go(current - 1); }

		function auto() {
			stop();
			if (n > 1) timer = setInterval(next, 6000);
		}
		function stop() { if (timer) { clearInterval(timer); timer = null; } }

		var left = root.querySelector('.carousel-arrow-left');
		var right = root.querySelector('.carousel-arrow-right');
		if (left) left.addEventListener('click', function () { prev(); auto(); });
		if (right) right.addEventListener('click', function () { next(); auto(); });
		dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); auto(); }); });
		slides.forEach(function (s, i) {
			s.addEventListener('click', function () {
				if (s.classList.contains('prev')) { prev(); auto(); }
				else if (s.classList.contains('next')) { next(); auto(); }
			});
		});
		root.addEventListener('mouseenter', stop);
		root.addEventListener('mouseleave', auto);

		render();
		auto();
	}

	/* ---------------------------------------------------- news grid pager */
	function initNewsPager() {
		var wrap = document.querySelector('[data-news-pages]');
		var pager = document.querySelector('[data-news-pager]');
		if (!wrap) return;
		var pages = Array.prototype.slice.call(wrap.querySelectorAll('[data-news-page]'));
		if (pages.length < 2) return;

		var current = 0;
		var cur = pager ? pager.querySelector('[data-news-cur]') : null;
		var btns = pager ? Array.prototype.slice.call(pager.querySelectorAll('[data-news-dir]')) : [];

		function render() {
			pages.forEach(function (p, i) { p.hidden = (i !== current); });
			if (cur) cur.textContent = String(current + 1);
			btns.forEach(function (b) {
				var dir = parseInt(b.getAttribute('data-news-dir'), 10);
				b.disabled = (dir < 0 && current === 0) || (dir > 0 && current === pages.length - 1);
			});
		}

		btns.forEach(function (b) {
			b.addEventListener('click', function () {
				var dir = parseInt(b.getAttribute('data-news-dir'), 10);
				current = Math.max(0, Math.min(pages.length - 1, current + dir));
				render();
			});
		});

		if (pager) pager.hidden = false;
		render();
	}

	/* --------------------------------------------------------- start slider */
	function initStartSlider() {
		var root = document.querySelector('.swiper-start');
		if (!root) return;
		var wrap = root.querySelector('.swiper-wrapper');
		var slides = wrap ? Array.prototype.slice.call(wrap.querySelectorAll('.swiper-slide')) : [];
		var pag = root.querySelector('.swiper-pagination');
		if (!wrap || slides.length === 0) return;

		var index = 0;
		var bullets = [];
		if (pag) {
			pag.innerHTML = '';
			slides.forEach(function (s, i) {
				var b = document.createElement('button');
				b.className = 'swiper-pagination-bullet' + (i === 0 ? ' swiper-pagination-bullet-active' : '');
				b.type = 'button';
				b.setAttribute('aria-label', 'Slide ' + (i + 1));
				b.addEventListener('click', function () { go(i); });
				pag.appendChild(b);
				bullets.push(b);
			});
		}

		function layout() {
			var single = window.matchMedia('(min-width: 900px)').matches;
			root.classList.toggle('is-static', single);
			if (single) {
				wrap.style.transform = '';
				slides.forEach(function (s) { s.style.width = ''; s.classList.add('swiper-slide-active'); });
			} else {
				slides.forEach(function (s) { s.style.width = '100%'; s.classList.remove('swiper-slide-active'); });
				go(index);
			}
		}

		function go(i) {
			index = Math.max(0, Math.min(slides.length - 1, i));
			wrap.style.transform = 'translate3d(-' + (index * 100) + '%,0,0)';
			slides.forEach(function (s, k) { s.classList.toggle('swiper-slide-active', k === index); });
			bullets.forEach(function (b, k) { b.classList.toggle('swiper-pagination-bullet-active', k === index); });
		}

		wrap.style.transition = 'transform .35s ease';
		// basic touch swipe
		var startX = null;
		wrap.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; }, { passive: true });
		wrap.addEventListener('touchend', function (e) {
			if (startX === null) return;
			var dx = e.changedTouches[0].clientX - startX;
			if (Math.abs(dx) > 40) go(index + (dx < 0 ? 1 : -1));
			startX = null;
		});

		layout();
		window.addEventListener('resize', layout);
	}
})();
