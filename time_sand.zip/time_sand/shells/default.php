<?php
/**
 * Time Sand - default shell.
 *
 * Converted from the Nozdor CMS front-end. Only the design was kept: the
 * original Google reCAPTCHA, analytics, tooltip widget and site API are gone.
 * The chrome lives here; the look lives in assets/css/time-sand.css.
 */

$tsLogo = function_exists('theme_image')
	? theme_image('logo_image', theme_asset('img/logo.png'))
	: theme_asset('img/logo.png');
$tsFavicon  = function_exists('theme_image') ? theme_image('favicon') : '';
$tsFooter   = function_exists('theme_option') ? theme_option('footer_html') : '';
$tsPromo    = function_exists('theme_option') ? trim(theme_option('promo_text')) : '';
$tsPromoUrl = function_exists('theme_option') ? trim(theme_option('promo_link')) : '';
$tsForum    = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$tsDiscord  = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$tsVk       = function_exists('theme_option') ? trim(theme_option('vk_url')) : '';
$tsTelegram = function_exists('theme_option') ? trim(theme_option('telegram_url')) : '';
$tsYoutube  = function_exists('theme_option') ? trim(theme_option('youtube_url')) : '';
$tsLang     = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';
$tsOnline   = (int) (function_exists('user_count_online') ? user_count_online() : 0);
$tsLoggedIn = function_exists('user_logged_in')
	? user_logged_in()
	: (function_exists('getSession') && getSession('user_id') !== false);
$tsIsAdmin = $tsLoggedIn && function_exists('is_admin') && is_admin($user_data ?? null);
$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>
<!DOCTYPE html>
<html lang="<?= $h($tsLang) ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#1B1815">
	<meta name="color-scheme" content="dark">
	<title><?= theme_title() ?></title>
	<?php if ($tsFavicon !== ''): ?><link rel="icon" href="<?= $tsFavicon ?>"><?php endif; ?>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Material+Icons&display=swap">
	<link rel="stylesheet" href="<?= theme_asset('css/time-sand.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/glue.css') ?>">
</head>
<body class="<?= theme_body_class() ?>">

<?php if ($tsPromo !== ''): ?>
	<?php if ($tsPromoUrl !== ''): ?>
	<a class="header__promo-banner" href="<?= $h($tsPromoUrl) ?>">
		<span class="header__promo-text"><?= $h($tsPromo) ?></span>
		<span class="header__promo-separator">&mdash;</span>
		<span class="header__promo-link"><?= t('time_sand.promo.more') ?></span>
	</a>
	<?php else: ?>
	<div class="header__promo-banner"><span class="header__promo-text"><?= $h($tsPromo) ?></span></div>
	<?php endif; ?>
	<style>:root{--nz-promo-h:32px}</style>
<?php else: ?>
	<style>:root{--nz-promo-h:0px}.header{top:0}</style>
<?php endif; ?>

<header class="header" id="ts-header">
	<div class="header__container">
		<div class="header__content">
			<a class="header__logo" href="index.php">
				<img src="<?= $tsLogo ?>" alt="<?= theme_title() ?>">
			</a>

			<nav class="header__nav" id="ts-nav">
				<button type="button" aria-label="Close menu" class="mobile-close-btn" data-ts-nav-close>
					<span class="material-icons">close</span>
				</button>

				<?php theme_menu(); ?>

				<div class="header__actions">
					<a class="header__action-item header__online" href="onlinelist.php" title="<?= t('time_sand.header.online') ?>">
						<span class="online-dot"></span>
						<span class="online-count"><?= $tsOnline ?></span>
						<span class="online-label"><?= t('time_sand.header.online') ?></span>
					</a>
					<?php
					if (function_exists('translate_selector')) {
						$sel = translate_selector();
						if ($sel !== '') {
							echo '<div class="ts-lang">' . $sel . '</div>' . translate_selector_assets();
							translate_selector_rendered(true);
						}
					}
					?>
					<?php if ($tsLoggedIn): ?>
						<?php $tsName = (string)($user_data['name'] ?? t('time_sand.header.account')); ?>
						<div class="dropdown header__account-menu">
							<button type="button" class="header__action-item header__account" data-ts-dropdown aria-haspopup="true" aria-expanded="false">
								<span class="material-icons">person</span>
								<span class="header__account-name"><?= $h($tsName) ?></span>
								<span class="material-icons dropdown__icon">expand_more</span>
							</button>
							<ul class="dropdown__menu">
								<li class="dropdown__item"><a class="nav__link" href="myaccount.php"><span class="material-icons">person</span> <?= t('time_sand.header.profile') ?></a></li>
								<?php if ($tsIsAdmin): ?>
									<li class="dropdown__item"><a class="nav__link" href="admin/"><span class="material-icons">security</span> <?= t('time_sand.header.admin') ?></a></li>
								<?php endif; ?>
								<li class="dropdown__item"><a class="nav__link" href="shop.php"><span class="material-icons">shopping_cart</span> <?= t('time_sand.header.shop') ?></a></li>
								<li class="dropdown__item"><a class="nav__link header__logout" href="logout.php"><span class="material-icons">logout</span> <?= t('time_sand.header.logout') ?></a></li>
							</ul>
						</div>
						<a class="nz-btn nz-btn--primary header__donate" href="shop.php"><?= t('time_sand.header.shop') ?></a>
					<?php else: ?>
						<a class="header__action-item header__account" href="login.php">
							<span class="material-icons">person</span>
							<span><?= t('time_sand.header.login') ?></span>
						</a>
						<a class="nz-btn nz-btn--primary header__donate" href="register.php"><?= t('time_sand.header.register') ?></a>
					<?php endif; ?>
				</div>
			</nav>

			<div class="mobile-menu-wrapper">
				<button class="mobile-menu-btn" aria-label="Open menu" data-ts-nav-open>
					<span class="mobile-menu-btn__line"></span>
					<span class="mobile-menu-btn__line"></span>
					<span class="mobile-menu-btn__line"></span>
				</button>
			</div>
		</div>
	</div>
</header>

<div class="wrapper">
	<app-particles-container>
		<div class="particles-container" aria-hidden="true">
			<?php for ($i = 0; $i < 22; $i++): ?><div class="particle"></div><?php endfor; ?>
		</div>
	</app-particles-container>

	<?php
	$tsPage = (string)($page_filename ?? 'index');
	$tsAuthPages = array(
		'login'           => array('time_sand.auth.login_title',    'time_sand.auth.login_subtitle'),
		'register'        => array('time_sand.auth.register_title', 'time_sand.auth.register_subtitle'),
		'lostaccount'     => array('time_sand.auth.recover_title',  'time_sand.auth.recover_subtitle'),
		'lostaccountpassword' => array('time_sand.auth.recover_title', 'time_sand.auth.recover_subtitle'),
		'changepassword'  => array('time_sand.auth.password_title', 'time_sand.auth.password_subtitle'),
	);
	?>
	<?php
	$tsAccountPages = array('myaccount', 'twofa', 'settings', 'createcharacter', 'accountsettings', 'paymentlog', 'changename', 'changesex', 'changecharacter');
	?>
	<?php if ($tsPage === 'index'): ?>
		<?php theme_content(); ?>
	<?php elseif ($tsLoggedIn && in_array($tsPage, $tsAccountPages, true)): ?>
		<?php
		$acc = is_array($user_data ?? null) ? $user_data : array();
		$accId = (int)($acc['id'] ?? 0);
		$accName = (string)($acc['name'] ?? '');
		$accZ = ($accId && function_exists('user_znote_account_data'))
			? user_znote_account_data($accId, 'points', 'created') : false;
		$accPoints = is_array($accZ) ? (int)($accZ['points'] ?? 0) : 0;
		$accSince = (is_array($accZ) && !empty($accZ['created']))
			? max(0, floor((time() - (int)$accZ['created']) / 86400)) : null;
		$accPrem = !empty($acc['premdays']) ? (int)$acc['premdays']
			: (!empty($acc['premium_ends_at']) && $acc['premium_ends_at'] > time()
				? (int)ceil(($acc['premium_ends_at'] - time()) / 86400) : 0);
		$accItems = array(
			'myaccount'      => array('person',        t('time_sand.account.nav_overview')),
			'characters'     => array('sports_kabaddi', t('time_sand.account.nav_characters')),
			'createcharacter'=> array('add_circle',    t('time_sand.account.nav_create')),
			'twofa'          => array('verified_user', t('time_sand.account.nav_2fa')),
			'changepassword' => array('vpn_key',       t('time_sand.account.nav_password')),
			'settings'       => array('settings',      t('time_sand.account.nav_settings')),
			'shop'           => array('shopping_cart', t('time_sand.header.shop')),
			'paymentlog'     => array('receipt_long',  t('time_sand.account.nav_payments')),
		);
		?>
		<main class="ts-page profile-page">
			<div class="container">
				<nav class="breadcrumb-nav">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a class="breadcrumb-link" href="index.php"><?= t('nav.news') ?></a></li>
						<li class="breadcrumb-item"><span class="breadcrumb-link"><?= t('time_sand.account.title') ?></span></li>
					</ol>
				</nav>

				<div class="nz-panel profile-hero">
					<div class="profile-hero__id">
						<div class="profile-avatar"><?= $h(function_exists('mb_substr') ? mb_strtoupper(mb_substr($accName, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($accName, 0, 1))) ?></div>
						<div class="profile-hero__lines">
							<div class="profile-hero__name"><?= $h($accName) ?><span class="profile-hero__tag">#<?= $accId ?></span></div>
							<div class="profile-hero__badges">
								<span class="profile-badge<?= $accPrem > 0 ? ' profile-badge--gold' : '' ?>">
									<span class="material-icons">workspace_premium</span>
									<?= $accPrem > 0 ? t('time_sand.account.premium_days', ['n' => $accPrem]) : t('time_sand.account.free') ?>
								</span>
								<?php if ($accSince !== null): ?>
									<span class="profile-badge"><span class="material-icons">schedule</span> <?= t('time_sand.account.since', ['n' => (int)$accSince]) ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="nz-strip profile-hero__stats">
						<div class="nz-stat">
							<span class="nz-stat__icon"><span class="material-icons">paid</span></span>
							<span class="nz-stat__body"><span class="nz-stat__value"><?= number_format($accPoints) ?></span><span class="nz-stat__label"><?= t('time_sand.account.points') ?></span></span>
						</div>
						<div class="nz-stat">
							<span class="nz-stat__icon"><span class="material-icons">workspace_premium</span></span>
							<span class="nz-stat__body"><span class="nz-stat__value"><?= $accPrem > 0 ? (int)$accPrem : '&mdash;' ?></span><span class="nz-stat__label"><?= t('time_sand.account.premium') ?></span></span>
						</div>
					</div>
				</div>

				<nav class="nz-segment profile-tabs" role="tablist" aria-label="<?= t('time_sand.account.group_manage') ?>">
					<?php foreach ($accItems as $accKey => $accMeta): ?>
						<?php if (!is_file($accKey . '.php')) continue; ?>
						<a class="nz-segment__btn profile-tabs__tab<?= $tsPage === $accKey ? ' nz-segment__btn--active' : '' ?>" href="<?= $h($accKey) ?>.php"<?= $tsPage === $accKey ? ' aria-selected="true"' : '' ?>>
							<span class="material-icons"><?= $accMeta[0] ?></span> <?= $h($accMeta[1]) ?>
						</a>
					<?php endforeach; ?>
					<a class="nz-segment__btn profile-tabs__tab profile-tabs__tab--logout" href="logout.php">
						<span class="material-icons">logout</span> <?= t('time_sand.header.logout') ?>
					</a>
				</nav>

				<div class="profile-content nz-panel">
					<div class="ts-inner"><?php theme_content(); ?></div>
				</div>
			</div>
		</main>
	<?php elseif (isset($tsAuthPages[$tsPage])): ?>
		<main class="ts-page nz-auth">
			<div class="container">
				<div class="nz-panel nz-auth__card">
					<header class="nz-auth__head">
						<h1 class="nz-auth__title"><?= t($tsAuthPages[$tsPage][0]) ?></h1>
						<p class="nz-auth__subtitle"><?= t($tsAuthPages[$tsPage][1]) ?></p>
					</header>
					<div class="ts-inner nz-auth__content"><?php theme_content(); ?></div>
					<?php if ($tsPage === 'login'): ?>
						<p class="nz-auth__foot"><?= t('time_sand.auth.no_account') ?><br>
							<a class="nz-auth__link" href="register.php"><?= t('time_sand.header.register') ?></a>
						</p>
					<?php elseif ($tsPage === 'register'): ?>
						<p class="nz-auth__foot"><?= t('time_sand.auth.have_account') ?><br>
							<a class="nz-auth__link" href="login.php"><?= t('time_sand.header.login') ?></a>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</main>
	<?php else: ?>
		<main class="ts-page">
			<div class="ts-inner container"><?php theme_content(); ?></div>
		</main>
	<?php endif; ?>
</div>

<footer class="footer">
	<div class="footer__back">
		<div class="container">
			<div class="footer__main">
				<div class="footer__column footer__column--brand">
					<img class="footer__logo" src="<?= $tsLogo ?>" alt="<?= theme_title() ?>">
					<?php if ($tsFooter !== ''): ?><p class="footer__brand-line"><?= $tsFooter ?></p><?php endif; ?>
				</div>

				<div class="footer__column footer__column--navigation">
					<h4 class="footer__column-title"><?= t('time_sand.footer.information') ?></h4>
					<ul class="footer__nav-list">
						<li><a href="index.php"><?= t('nav.news') ?></a></li>
						<li><a href="highscores.php"><?= t('nav.highscores') ?></a></li>
						<li><a href="serverinfo.php"><?= t('nav.serverinfo') ?></a></li>
						<li><a href="downloads.php"><?= t('time_sand.nav.download') ?></a></li>
						<?php if ($tsForum !== ''): ?><li><a href="<?= $h($tsForum) ?>" target="_blank" rel="noopener"><?= t('time_sand.nav.forum') ?></a></li><?php endif; ?>
					</ul>
				</div>

				<div class="footer__column footer__column--social">
					<h4 class="footer__column-title"><?= t('time_sand.footer.social') ?></h4>
					<div class="footer__social-networks">
						<?php if ($tsVk !== ''): ?><a class="footer__social-link" href="<?= $h($tsVk) ?>" target="_blank" rel="noopener" title="VK"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.864-.525-2.05-1.68-1.033-1.1-1.49-1.25-1.744-1.25-.356 0-.458.102-.458.593v1.526c0 .407-.135.66-1.253.66-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4.03 8.57 4.03 8.096c0-.254.102-.491.593-.491h1.744c.441 0 .61.203.78.677.915 2.423 2.441 4.548 3.067 4.548.237 0 .339-.11.339-.712V9.728c-.085-1.388-.813-1.509-.813-2.001 0-.204.169-.407.441-.407h2.712c.373 0 .508.203.508.677v3.625c0 .372.17.508.271.508.237 0 .438-.136.881-.576 1.356-1.507 2.322-3.84 2.322-3.84.127-.271.322-.491.763-.491h1.744c.525 0 .644.271.525.677-.254 1.017-2.644 4.548-2.644 4.548-.203.339-.271.491 0 .847.203.254.864.847 1.305 1.356.777.847 1.371 1.552 1.524 2.05.169.508-.085.779-.576.779z"/></svg></a><?php endif; ?>
						<?php if ($tsDiscord !== ''): ?><a class="footer__social-link" href="<?= $h($tsDiscord) ?>" target="_blank" rel="noopener" title="Discord"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg></a><?php endif; ?>
						<?php if ($tsTelegram !== ''): ?><a class="footer__social-link" href="<?= $h($tsTelegram) ?>" target="_blank" rel="noopener" title="Telegram"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg></a><?php endif; ?>
						<?php if ($tsYoutube !== ''): ?><a class="footer__social-link" href="<?= $h($tsYoutube) ?>" target="_blank" rel="noopener" title="YouTube"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a><?php endif; ?>
					</div>
				</div>
			</div>

			<div class="footer__bottom">
				<p class="footer__copyright">
					<?= t('time_sand.footer.copyright', ['year' => date('Y'), 'site' => $h((string)($config['site_name'] ?? theme_title()))]) ?>
				</p>
				<p class="footer__powered">
					<?= t('time_sand.footer.powered') ?> <a href="credits.php">ZnoteX</a> &middot; <?= elapsedTime() ?>s
				</p>
			</div>
		</div>
	</div>
</footer>

<script src="<?= theme_asset('js/time-sand.js') ?>" defer></script>
</body>
</html>
