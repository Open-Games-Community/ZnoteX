<?php
/**
 * Top navigation for Time Sand.
 *
 * Entries come from Admin Panel > Menus (theme_menu_items('main')). When no
 * managed menu exists yet, a sensible default set is rendered instead. The
 * markup matches the Nozdor ".nav__menu" / ".dropdown" structure so the
 * converted stylesheet styles it unchanged.
 */

$tsMenu    = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$tsHasMenu = function_exists('theme_menu_available') ? theme_menu_available() : (bool)$tsMenu;
$tsCurrent = (string)($page_filename ?? 'index');
$tsForumUrl = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$hh = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
// Managed menu labels are stored in the DB; theme_menu_label() maps common
// labels ("Home", "Community", …) onto the core nav.* locale keys.
$ml = static function ($v): string {
	$label = function_exists('theme_menu_label') ? theme_menu_label((string)$v) : (string)$v;
	return htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
};

$tsActive = static function (string $url) use ($tsCurrent): bool {
	return $url !== '' && strpos($url, $tsCurrent . '.php') === 0;
};
?>
<ul class="nav__menu">
<?php if ($tsHasMenu): ?>
	<?php foreach ($tsMenu as $item): ?>
		<?php
		$hasDrop = !empty($item['children']);
		$href    = $item['url'] !== '' ? $item['url'] : '#';
		$target  = $item['target'] !== '' ? ' target="' . $hh($item['target']) . '" rel="noopener"' : '';
		$cls     = 'nav__item' . ($hasDrop ? ' dropdown' : '') . ($tsActive($item['url']) ? ' is-active' : '');
		?>
		<li class="<?= $cls ?>">
			<?php if ($hasDrop): ?>
				<button type="button" class="nav__link dropdown__trigger" data-ts-dropdown>
					<span class="nav__link-text"><?= $ml($item["label"]) ?></span>
					<span class="material-icons dropdown__icon">expand_more</span>
				</button>
				<ul class="dropdown__menu">
					<?php foreach ($item['children'] as $child): ?>
						<li class="dropdown__item">
							<a class="nav__link" href="<?= $hh($child['url']) ?>"<?= $child['target'] !== '' ? ' target="' . $hh($child['target']) . '" rel="noopener"' : '' ?>>
								<?php if ($child['icon'] !== ''): ?><span class="material-icons">chevron_right</span><?php endif; ?>
								<?= $ml($child["label"]) ?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else: ?>
				<a class="nav__link" href="<?= $hh($href) ?>"<?= $target ?>>
					<span class="nav__link-text"><?= $ml($item["label"]) ?></span>
				</a>
			<?php endif; ?>
		</li>
	<?php endforeach; ?>
<?php else: ?>
	<li class="nav__item<?= $tsCurrent === 'index' ? ' is-active' : '' ?>">
		<a class="nav__link" href="index.php"><span class="nav__link-text"><?= $hh(t('nav.news')) ?></span></a>
	</li>
	<li class="nav__item dropdown">
		<button type="button" class="nav__link dropdown__trigger" data-ts-dropdown>
			<span class="nav__link-text"><?= $hh(t('time_sand.nav.statistics')) ?></span>
			<span class="material-icons dropdown__icon">expand_more</span>
		</button>
		<ul class="dropdown__menu">
			<li class="dropdown__item"><a class="nav__link" href="highscores.php"><span class="material-icons">emoji_events</span> <?= $hh(t('nav.highscores')) ?></a></li>
			<li class="dropdown__item"><a class="nav__link" href="onlinelist.php"><span class="material-icons">public</span> <?= $hh(t('time_sand.nav.online')) ?></a></li>
			<li class="dropdown__item"><a class="nav__link" href="guilds.php"><span class="material-icons">groups</span> <?= $hh(t('nav.guilds')) ?></a></li>
			<li class="dropdown__item"><a class="nav__link" href="lastkills.php"><span class="material-icons">sports_kabaddi</span> <?= $hh(t('time_sand.nav.lastkills')) ?></a></li>
		</ul>
	</li>
	<li class="nav__item"><a class="nav__link" href="serverinfo.php"><span class="nav__link-text"><?= $hh(t('nav.serverinfo')) ?></span></a></li>
	<li class="nav__item"><a class="nav__link" href="downloads.php"><span class="nav__link-text"><?= $hh(t('time_sand.nav.download')) ?></span></a></li>
	<li class="nav__item"><a class="nav__link" href="shop.php"><span class="nav__link-text"><?= $hh(t('nav.shop')) ?></span></a></li>
	<?php if ($tsForumUrl !== ''): ?>
	<li class="nav__item"><a class="nav__link" href="<?= $hh($tsForumUrl) ?>" target="_blank" rel="noopener"><span class="nav__link-text"><?= $hh(t('time_sand.nav.forum')) ?></span></a></li>
	<?php endif; ?>
<?php endif; ?>
</ul>
