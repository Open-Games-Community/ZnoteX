<?php
/**
 * Time Sand - guild wars, styled after the Nozdor raids ladder page.
 *
 * Called by guildwar.php as view('guildwar'). Handles the war list; a single
 * war (?warid=) falls back to the default theme's detailed view, wrapped in
 * the Time Sand panel.
 *
 * In scope: $config, $isOtx, plus get_guild_wars(), get_war_kills().
 */

$hb = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

// ---- single war: reuse the default detailed view -------------------------
if (!empty($_GET['warid'])) {
	echo '<div class="raids-panel"><div class="raids-head"><div class="raids-head__title">'
		. '<span class="material-icons">flag</span><div><h1>' . $hb(t('time_sand.guilds.wars')) . '</h1></div></div></div>';
	$default = theme_root() . '/default/views/guildwar.php';
	if (is_file($default)) {
		include $default;
	}
	echo '</div>';
	return;
}

// ---- war list -----------------------------------------------------------
$engine = $config['ServerEngine'];
$wars = ($engine === 'TFS_03') ? get_guild_wars03() : get_guild_wars();
$wars = is_array($wars) ? $wars : array();

$kills = array();
foreach ($wars as $w) {
	$kills[$w['id']] = ($engine === 'TFS_03') ? get_war_kills03($w['id']) : get_war_kills($w['id']);
}
?>
<div class="raids-panel">
	<div class="raids-head">
		<div class="raids-head__title">
			<span class="material-icons">flag</span>
			<div>
				<h1><?= $hb(t('time_sand.guilds.wars')) ?></h1>
				<span class="raids-head__meta"><?= $hb((string)($config['site_name'] ?? theme_title())) ?></span>
			</div>
		</div>
		<nav role="tablist" class="nz-segment raids-tabs">
			<a role="tab" href="guilds.php" class="nz-segment__btn raids-tabs__tab" aria-selected="false">
				<span class="material-icons">shield</span> <?= $hb(t('nav.guilds')) ?>
			</a>
			<a role="tab" href="guildwar.php" class="nz-segment__btn raids-tabs__tab nz-segment__btn--active" aria-selected="true">
				<span class="material-icons">flag</span> <?= $hb(t('time_sand.guilds.wars')) ?>
			</a>
		</nav>
	</div>

	<?php if (!$wars): ?>
		<p class="raids-muted raids-empty"><?= t('time_sand.guilds.no_wars') ?></p>
	<?php else: ?>
		<table class="raids-ladder">
			<thead>
				<tr>
					<th class="raids-ladder__rank">#</th>
					<th><?= $hb(t('guildwar.attacking')) ?></th>
					<th class="raids-ladder__num"><?= $hb(t('guildwar.deathcount')) ?></th>
					<th><?= $hb(t('guildwar.defending')) ?></th>
					<th class="raids-ladder__log"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($wars as $i => $w): ?>
					<?php
						$k1 = 0; $k2 = 0;
						foreach ((is_array($kills[$w['id']] ?? null) ? $kills[$w['id']] : array()) as $kill) {
							$isG1 = ($isOtx && ($kill['guild_id'] ?? null) == $w['guild1'])
								|| (!$isOtx && ($kill['killerguild'] ?? null) == $w['guild1']);
							$isG1 ? $k1++ : $k2++;
						}
						$warUrl = 'guildwar.php?warid=' . (int)$w['id'];
					?>
					<tr class="raids-ladder__row" onclick="window.location.href='<?= $hb($warUrl) ?>'">
						<td class="raids-ladder__rank"><?= $i + 1 ?></td>
						<td><a class="raids-guild raids-guild--link raids-ladder__strong" href="guilds.php?name=<?= $hb(urlencode((string)$w['name1'])) ?>"><?= $hb($w['name1']) ?></a></td>
						<td class="raids-ladder__num"><?= (int)$k1 ?> &ndash; <?= (int)$k2 ?></td>
						<td><a class="raids-guild raids-guild--link" href="guilds.php?name=<?= $hb(urlencode((string)$w['name2'])) ?>"><?= $hb($w['name2']) ?></a></td>
						<td class="raids-ladder__log"><a class="raids-details-link" href="<?= $hb($warUrl) ?>"><?= t('common.view') ?></a></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
