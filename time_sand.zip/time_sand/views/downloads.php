<?php
/**
 * Time Sand - Downloads.
 *
 * Same data as the default view ($config['client'], client_download,
 * client_download_linux, server name); reworked into a card layout with
 * proper download buttons and a "how to play" panel.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$version   = isset($config['client']) ? rtrim(rtrim(number_format($config['client'] / 100, 2, '.', ''), '0'), '.') : '';
$winUrl    = (string)($config['client_download'] ?? '');
$linuxUrl  = (string)($config['client_download_linux'] ?? '');
$ipcUrl    = 'https://github.com/jo3bingham/tibia-ip-changer/releases/latest';
$serverIp  = (string)($config['server_ip'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost'));
$siteName  = (string)($config['site_name'] ?? theme_title());

$cards = array();
if ($winUrl !== '') {
	$cards[] = array('icon' => 'desktop_windows', 'os' => t('time_sand.dl.windows'),
		'name' => t('time_sand.dl.client', ['version' => $version]), 'url' => $winUrl);
}
if ($linuxUrl !== '') {
	$cards[] = array('icon' => 'terminal', 'os' => t('time_sand.dl.linux'),
		'name' => t('time_sand.dl.client', ['version' => $version]), 'url' => $linuxUrl);
}
$cards[] = array('icon' => 'swap_horiz', 'os' => t('time_sand.dl.tool'),
	'name' => t('downloads.ipchanger'), 'url' => $ipcUrl);
?>
<div class="hero-header">
	<div class="hero-header__content">
		<h1 class="hero-header__title"><span class="material-icons">download</span> <?= $h(t('downloads.title')) ?></h1>
		<p class="hero-header__subtitle"><?= $h(t('downloads.intro')) ?></p>
	</div>
</div>

<div class="ts-dl-grid">
	<?php foreach ($cards as $c): ?>
		<div class="nz-panel ts-dl-card">
			<span class="ts-dl-card__icon"><span class="material-icons"><?= $c['icon'] ?></span></span>
			<span class="ts-dl-card__os"><?= $h($c['os']) ?></span>
			<span class="ts-dl-card__name"><?= $h($c['name']) ?></span>
			<a class="nz-btn nz-btn--primary ts-dl-card__btn" href="<?= $h($c['url']) ?>"<?= strpos($c['url'], 'http') === 0 ? ' target="_blank" rel="noopener"' : '' ?>>
				<span class="material-icons">download</span> <?= $h(t('downloads.download')) ?>
			</a>
		</div>
	<?php endforeach; ?>
</div>

<div class="nz-panel ts-dl-howto">
	<h2 class="ts-dl-howto__title"><?= $h(rtrim(t('downloads.howto'), ':')) ?></h2>

	<ol class="ts-dl-steps">
		<li><a href="<?= $h($winUrl ?: $ipcUrl) ?>"><?= t('downloads.download') ?></a> <?= t('downloads.step1') ?></li>
		<li><a href="<?= $h($ipcUrl) ?>" target="_blank" rel="noopener"><?= t('downloads.download') ?></a> <?= t('downloads.step2') ?></li>
		<li><?= t('downloads.step3') ?></li>
		<li><?= t('downloads.step4') ?> <code><?= $h($serverIp) ?></code></li>
		<li>
			<?= t('downloads.step5') ?> <strong>Apply</strong>.<br>
			<?= t('downloads.step5b') ?> <a href="register.php"><?= t('downloads.here') ?></a>.
		</li>
	</ol>
</div>
