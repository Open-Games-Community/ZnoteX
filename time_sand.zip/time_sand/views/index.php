<?php
/**
 * Time Sand - front page (and the single-news article view).
 *
 * Converted from the Nozdor home route. The hero carousel shows the images an
 * admin uploads in Admin Panel > Layouts > Time Sand ("Slider image 1..5").
 * Below the hero: a compact changelog box (if enabled) and the news grid.
 *
 * Prepared by index.php: $news (array|false), $changelogs (array|false),
 * $page, $view.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$bb = static function ($v): string { return function_exists('znote_bbcode_raw') ? znote_bbcode_raw((string)$v) : (string)$v; };
$siteName = (string)($config['site_name'] ?? theme_title());

/** First image URL found in a post body: [img]…[/img], [img=WxH]…[/img] or <img src>. */
$firstImage = static function (string $text): string {
	if (preg_match('~\[img[^\]]*\]\s*([^\[\s]+)\s*\[/img\]~i', $text, $m)) {
		return trim($m[1]);
	}
	if (preg_match('~<img[^>]+src\s*=\s*["\']?([^"\'\s>]+)~i', $text, $m)) {
		return trim($m[1]);
	}
	return '';
};

$mark = static function ($text) use ($h): string {
	$text = trim(strip_tags((string)$text));
	$c = function_exists('mb_substr') ? mb_substr($text, 0, 1, 'UTF-8') : substr($text, 0, 1);
	return $h($c);
};

$plainTitle = static function ($t) use ($h, $bb): string {
	return $h(trim(strip_tags($bb($t))));
};

$excerpt = static function ($text, int $len = 180) use ($bb): string {
	$plain = trim(preg_replace('~\s+~', ' ', strip_tags($bb($text))));
	if (function_exists('mb_strimwidth')) {
		return mb_strimwidth($plain, 0, $len, '…', 'UTF-8');
	}
	return (strlen($plain) > $len) ? substr($plain, 0, $len - 1) . '…' : $plain;
};

$newsItems = (is_array($news ?? null)) ? array_values($news) : array();

// -------------------------------------------------------------------------
// Single article: index.php?view=<id|title>  -> its own page, then stop.
// -------------------------------------------------------------------------
if (($view ?? '') !== '') {
	$article = null;
	foreach ($newsItems as $row) {
		if ((ctype_digit((string)$view) && (int)$view === (int)$row['id']) || urlencode($row['title']) === $view) {
			$article = $row;
			break;
		}
	}
	?>
	<main class="ts-page">
		<div class="container ts-article-wrap">
			<nav class="breadcrumb-nav">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a class="breadcrumb-link" href="index.php"><?= t('nav.news') ?></a></li>
					<li class="breadcrumb-item"><span class="breadcrumb-link"><?= $article ? $plainTitle($article['title']) : t('news.not_found') ?></span></li>
				</ol>
			</nav>

			<?php if ($article): ?>
				<article class="nz-panel ts-article">
					<header class="ts-article__head">
						<div class="ts-article__meta">
							<span class="news__date"><?= $h(getClock((int)$article['date'], true)) ?></span>
							<span class="news__author"><?= t('news.by') ?> <a href="characterprofile.php?name=<?= $h(urlencode($article['name'])) ?>"><?= $h($article['name']) ?></a></span>
						</div>
						<h1 class="ts-article__title"><?= $plainTitle($article['title']) ?></h1>
					</header>
					<div class="ts-article__body"><?= $bb($article['text']) ?></div>
					<a class="nz-btn ts-article__back" href="index.php">&larr; <?= t('time_sand.news.back') ?></a>
				</article>
			<?php else: ?>
				<div class="nz-panel ts-article">
					<h1 class="ts-article__title"><?= t('news.not_found') ?></h1>
					<p><?= t('news.not_found_text') ?></p>
					<a class="nz-btn ts-article__back" href="index.php">&larr; <?= t('time_sand.news.back') ?></a>
				</div>
			<?php endif; ?>
		</div>
	</main>
	<?php
	return;
}

// -------------------------------------------------------------------------
// Home page
// -------------------------------------------------------------------------
$tsSlides = array();
for ($i = 1; $i <= 5; $i++) {
	$img = function_exists('theme_image') ? theme_image('slider_image_' . $i) : '';
	if ($img === '') {
		continue;
	}
	$tsSlides[] = array(
		'img'  => $img,
		'link' => function_exists('theme_option') ? trim(theme_option('slider_link_' . $i)) : '',
	);
}
if (!$tsSlides) {
	$tsSlides[] = array(
		'img'  => function_exists('theme_image') ? theme_image('logo_image', theme_asset('img/logo.png')) : theme_asset('img/logo.png'),
		'link' => '',
	);
}

$arrowL = '<svg viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="var(--nz-gold)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
$arrowR = '<svg viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="var(--nz-gold)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

$changelogList = array();
if (!empty($config['UseChangelogTicker']) && is_array($changelogs ?? null)) {
	$changelogList = array_slice($changelogs, 0, 5);
}

$newsMedia = static function ($item) use ($firstImage, $mark): string {
	$src = $firstImage((string)$item['text']);
	if ($src !== '') {
		return '<div class="news__media"><img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="" loading="lazy"></div>';
	}
	return '<div class="news__media"><span class="news__media-mark">' . $mark($item['title']) . '</span></div>';
};
?>
<div id="home" class="home">
	<div class="magic-effects" aria-hidden="true">
		<?php for ($e = 1; $e <= 12; $e++): ?><div class="ember e<?= $e ?>"></div><?php endfor; ?>
		<div class="golden-aura"></div>
	</div>

	<div class="container">
		<h1 class="nz-sr-only"><?= $h($siteName) ?> &mdash; <?= t('time_sand.hero.h1') ?></h1>

		<div class="hero-intro">
			<p class="intro-tagline"><?= t('time_sand.hero.tagline') ?></p>
			<h2 class="intro-title"><?= t('time_sand.hero.title') ?> <span class="accent"><?= t('time_sand.hero.title_accent') ?></span></h2>
			<p class="intro-subtitle"><?= t('time_sand.hero.subtitle') ?></p>
		</div>

		<div class="hero-video-section">
			<div class="carousel-3d">
				<button type="button" aria-label="Previous" class="carousel-arrow carousel-arrow-left"><?= $arrowL ?></button>

				<div class="carousel-track">
					<?php foreach ($tsSlides as $idx => $slide): ?>
						<div class="carousel-slide<?= $idx === 0 ? ' active' : ' hidden' ?>">
							<div class="slide-frame">
								<?php if ($idx === 0): ?><span class="new-video-badge"><?= t('time_sand.hero.badge') ?></span><?php endif; ?>
								<?php $tag = $slide['link'] !== '' ? 'a' : 'span'; ?>
								<<?= $tag ?> <?= $slide['link'] !== '' ? 'href="' . $h($slide['link']) . '"' : '' ?> class="ts-slide-media">
									<img src="<?= $h($slide['img']) ?>" alt="<?= $h($siteName) ?>" loading="<?= $idx === 0 ? 'eager' : 'lazy' ?>">
								</<?= $tag ?>>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<button type="button" aria-label="Next" class="carousel-arrow carousel-arrow-right"><?= $arrowR ?></button>

				<?php if (count($tsSlides) > 1): ?>
					<div class="carousel-dots">
						<?php foreach ($tsSlides as $idx => $slide): ?>
							<button type="button" class="dot<?= $idx === 0 ? ' active' : '' ?>" aria-label="Slide <?= $idx + 1 ?>"></button>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div class="hero-cta-block">
			<a class="hero-btn-play" href="register.php"><?= t('time_sand.hero.cta_play') ?></a>
			<a class="hero-btn-transfer" href="downloads.php">
				<span class="transfer-tag"><?= t('time_sand.hero.cta_tag') ?></span>
				<span class="transfer-content">
					<span class="transfer-label"><?= t('time_sand.hero.cta_transfer_label') ?></span>
					<span class="transfer-sep">&mdash;</span>
					<span class="transfer-desc"><?= t('time_sand.hero.cta_transfer_desc') ?></span>
				</span>
			</a>
		</div>

		<div class="section-divider" aria-hidden="true">
			<div class="divider-line"></div>
			<div class="divider-ornament">
				<span class="ornament-wing left"></span>
				<span class="ornament-gem"></span>
				<span class="ornament-wing right"></span>
			</div>
			<div class="divider-line"></div>
		</div>

		<div id="news" class="news-section">
			<div class="container">

				<?php if ($changelogList): ?>
					<section class="nz-panel ts-changelog">
						<h2 class="ts-changelog__title"><?= t('time_sand.changelog.title') ?></h2>
						<ul class="ts-changelog__list">
							<?php foreach ($changelogList as $cl): ?>
								<?php
									$clFull = trim(strip_tags($bb($cl['text'])));
									$clShort = $excerpt($cl['text'], 90);
									$clLong = ($clFull !== '' && $clShort !== $clFull);
									$clDate = $h(getClock((int)$cl['time'], true, true));
								?>
								<li class="ts-changelog__item">
									<?php if ($clLong): ?>
										<details>
											<summary>
												<span class="ts-changelog__date"><?= $clDate ?></span>
												<span class="ts-changelog__text"><?= $h($clShort) ?></span>
											</summary>
											<div class="ts-changelog__more"><?= $bb($cl['text']) ?></div>
										</details>
									<?php else: ?>
										<div class="ts-changelog__row">
											<span class="ts-changelog__date"><?= $clDate ?></span>
											<span class="ts-changelog__text"><?= $h($clFull) ?></span>
										</div>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</section>
				<?php endif; ?>

				<?php if ($newsItems): ?>
					<?php
					$featured = $newsItems[0];
					// small cards: up to 8 per page, up to 6 pages (48 items)
					$rest = array_slice($newsItems, 1, 48);
					$perPage = 8;
					$pages = array_chunk($rest, $perPage);
					$pageCount = count($pages);
					?>
					<div class="news">
						<a class="news__item news__item-main" href="index.php?view=<?= (int)$featured['id'] ?>">
							<?= $newsMedia($featured) ?>
							<div class="news__body">
								<div class="news__meta">
									<span class="news__date"><?= $h(getClock((int)$featured['date'], true)) ?></span>
									<span class="news__author"><?= t('news.by') ?> <?= $h($featured['name']) ?></span>
								</div>
								<span class="news__title"><?= $plainTitle($featured['title']) ?></span>
								<span class="news__subtitle"><?= $h($excerpt($featured['text'])) ?></span>
								<span class="news__more"><?= t('time_sand.news.read_more') ?> &rarr;</span>
							</div>
						</a>

						<?php if ($rest): ?>
						<div class="news__pages" data-news-pages>
							<?php foreach ($pages as $p => $chunk): ?>
								<div class="news__grid" data-news-page="<?= $p + 1 ?>"<?= $p === 0 ? '' : ' hidden' ?>>
									<?php foreach ($chunk as $item): ?>
										<a class="news__item news__item-grid" href="index.php?view=<?= (int)$item['id'] ?>">
											<?= $newsMedia($item) ?>
											<div class="news__body">
												<span class="news__date"><?= $h(getClock((int)$item['date'], true)) ?></span>
												<span class="news__title"><?= $plainTitle($item['title']) ?></span>
											</div>
										</a>
									<?php endforeach; ?>
								</div>
							<?php endforeach; ?>
						</div>

						<?php if ($pageCount > 1): ?>
						<div class="news__pager" data-news-pager hidden>
							<button type="button" class="news__pager-btn" data-news-dir="-1" aria-label="Previous">&larr;</button>
							<span class="news__pager-info"><span data-news-cur>1</span> / <?= $pageCount ?></span>
							<button type="button" class="news__pager-btn" data-news-dir="1" aria-label="Next">&rarr;</button>
						</div>
						<?php endif; ?>
						<?php endif; ?>
					</div>
				<?php else: ?>
					<p class="section-subtitle"><?= t('news.none') ?></p>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<section class="start" id="start">
	<div class="start-gradient" aria-hidden="true"></div>
	<div class="container">
		<p class="section-title"><?= t('time_sand.start.title') ?></p>
		<p class="section-subtitle"><?= t('time_sand.start.subtitle') ?></p>

		<div class="start__slider">
			<div class="swiper swiper-start">
				<div class="swiper-wrapper">
					<div class="swiper-slide start__slide">
						<div class="step active">
							<div class="step__title"><p><?= t('time_sand.start.step1_kicker') ?></p></div>
							<div class="step__content">
								<p><?= t('time_sand.start.step1_title') ?></p>
								<span><?= t('time_sand.start.step1_text') ?></span>
								<a class="step__action" href="register.php"><?= t('time_sand.start.step1_action') ?></a>
							</div>
						</div>
					</div>
					<div class="swiper-slide start__slide">
						<div class="step">
							<div class="step__title"><p><?= t('time_sand.start.step2_kicker') ?></p></div>
							<div class="step__content">
								<p><?= t('time_sand.start.step2_title') ?></p>
								<span><?= t('time_sand.start.step2_text') ?></span>
							</div>
						</div>
					</div>
					<div class="swiper-slide start__slide">
						<div class="step">
							<div class="step__title"><p><?= t('time_sand.start.step3_kicker') ?></p></div>
							<div class="step__content">
								<p><?= t('time_sand.start.step3_title') ?></p>
								<span><?= t('time_sand.start.step3_text') ?></span>
								<a class="step__action" href="downloads.php"><?= t('time_sand.start.step3_action') ?></a>
							</div>
						</div>
					</div>
				</div>
				<div class="swiper-pagination"></div>
			</div>
		</div>
	</div>
</section>


