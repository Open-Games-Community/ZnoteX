<?php
/**
 * Time Sand - highscores, styled after the Nozdor arena ladder page.
 *
 * Same data and filter logic as the default theme's highscores view; only the
 * presentation changes (hero header, stat strip, .table markup).
 *
 * In scope from highscores.php: $vocGroups, $type, $vocation, $page,
 * $rowsPerPage, $highscore, $configVocations, $loadOutfits, $loadFlags,
 * plus skillName(), pageCheck(), vocation_id_to_name().
 */

if (!$vocGroups) {
	echo '<p class="hero-header__subtitle">' . t('common.nothing') . '</p>';
	return;
}

$vocGroup = is_array($vocGroups[$vocation]) ? $vocGroups[$vocation] : $vocGroups[$vocGroups[$vocation]];
$rows = ($vocGroup[$type] !== false) ? $vocGroup[$type] : array();

$totalPlayers = count($rows);
$topValue = $totalPlayers ? $rows[0]['value'] : 0;
$vocLabel = ($vocation === 'all') ? t('vocation.any_lower') : vocation_id_to_name($vocation);
$skillLabel = skillName($type);
$hb = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>
<div class="hero-header">
	<div class="hero-header__content">
		<h1 class="hero-header__title"><span class="material-icons">emoji_events</span> <?= $hb(t('nav.highscores')) ?></h1>
		<p class="hero-header__subtitle"><?= $hb($skillLabel) ?> &middot; <?= $hb($vocLabel) ?></p>
	</div>

	<form action="" method="GET" class="arena-filter">
		<span class="arena-filter__label"><?= t('common.view') ?>:</span>
		<select name="type">
			<?php foreach (array(7=>'skill.experience',8=>'skill.magic',5=>'skill.shield',2=>'skill.sword',1=>'skill.club',3=>'skill.axe',4=>'skill.distance',6=>'skill.fishing',9=>'skill.fist') as $tv => $tk): ?>
				<option value="<?= $tv ?>"<?= $type == $tv ? ' selected' : '' ?>><?= t($tk) ?></option>
			<?php endforeach; ?>
		</select>
		<select name="vocation">
			<option value="all"<?= !is_int($vocation) ? ' selected' : '' ?>><?= t('vocation.any') ?></option>
			<?php foreach ($configVocations as $vId => $vData): ?>
				<?php if ($vData['fromVoc'] === false): ?>
					<option value="<?= (int)$vId ?>"<?= (is_int($vocation) && $vocation == $vId) ? ' selected' : '' ?>><?= $hb($vData['name']) ?></option>
				<?php endif; ?>
			<?php endforeach; ?>
		</select>
		<select name="page">
			<?php
			$pages = ($vocGroup[$type] !== false)
				? ceil(min(($highscore['rows'] / $highscore['rowsPerPage']), (count($rows) / $highscore['rowsPerPage'])))
				: 1;
			for ($i = 1; $i <= max(1, $pages); $i++): ?>
				<option value="<?= $i ?>"<?= $i == $page ? ' selected' : '' ?>><?= t('highscores.page', ['n' => $i]) ?></option>
			<?php endfor; ?>
		</select>
		<input type="submit" value="<?= t('common.view') ?>">
	</form>
</div>

<div class="nz-strip stats-cards">
	<div class="nz-stat">
		<span class="nz-stat__icon"><span class="material-icons">groups</span></span>
		<span class="nz-stat__body">
			<span class="nz-stat__value"><?= number_format($totalPlayers) ?></span>
			<span class="nz-stat__label"><?= $hb(t('common.name')) ?></span>
		</span>
	</div>
	<div class="nz-stat">
		<span class="nz-stat__icon"><span class="material-icons">military_tech</span></span>
		<span class="nz-stat__body">
			<span class="nz-stat__value"><?= number_format($topValue) ?></span>
			<span class="nz-stat__label"><?= $hb($skillLabel) ?></span>
		</span>
	</div>
	<div class="nz-stat">
		<span class="nz-stat__icon"><span class="material-icons">shield</span></span>
		<span class="nz-stat__body">
			<span class="nz-stat__value"><?= $hb($vocLabel) ?></span>
			<span class="nz-stat__label"><?= $hb(t('common.vocation')) ?></span>
		</span>
	</div>
</div>

<div class="arena-table-wrapper">
	<table class="table">
		<thead>
			<tr>
				<?php if ($loadOutfits): ?><th class="table-header__cell"><div class="table-header__content"><span class="table-header__label"><?= t('common.outfit') ?></span></div></th><?php endif; ?>
				<th class="table-header__cell"><div class="table-header__content"><span class="table-header__label">#</span></div></th>
				<th class="table-header__cell"><div class="table-header__content"><span class="table-header__label"><?= t('common.name') ?></span></div></th>
				<th class="table-header__cell"><div class="table-header__content"><span class="table-header__label"><?= t('common.vocation') ?></span></div></th>
				<th class="table-header__cell"><div class="table-header__content"><span class="table-header__label"><?= t('common.level') ?></span></div></th>
				<?php if ($type === 7): ?><th class="table-header__cell"><div class="table-header__content"><span class="table-header__label"><?= t('common.points') ?></span></div></th><?php endif; ?>
			</tr>
		</thead>
		<tbody>
			<?php if (!$rows): ?>
				<tr><td colspan="6"><?= t('common.nothing') ?></td></tr>
			<?php else: ?>
				<?php for ($i = 0; $i < count($rows); $i++): ?>
					<?php if (!pageCheck($i, $page, $rowsPerPage)) continue; ?>
					<?php $r = $rows[$i];
						$flag = ($loadFlags && strlen((string)($r['flag'] ?? '')) > 1)
							? '<img class="hs-flag" src="' . $hb($config['country_flags']['server'] . '/' . $r['flag'] . '.png') . '" alt=""> ' : ''; ?>
					<tr>
						<?php if ($loadOutfits): ?>
							<td class="outfitColumn"><img src="<?= $hb($config['show_outfits']['imageServer'] . '?id=' . $r['type'] . '&addons=' . $r['addons'] . '&head=' . $r['head'] . '&body=' . $r['body'] . '&legs=' . $r['legs'] . '&feet=' . $r['feet']) ?>" alt=""></td>
						<?php endif; ?>
						<td><?= $i + 1 ?></td>
						<td><?= $flag ?><a href="characterprofile.php?name=<?= $hb(urlencode($r['name'])) ?>"><?= $hb($r['name']) ?></a></td>
						<td><?= $hb(vocation_id_to_name($r['vocation'])) ?></td>
						<td><?= number_format((int)$r['value']) ?></td>
						<?php if ($type === 7): ?><td><?= number_format((int)$r['experience']) ?></td><?php endif; ?>
					</tr>
				<?php endfor; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
