<?php
/**
 * Time Sand - Item Shop.
 *
 * Same data and purchase flow as the default view; reworked into a compact
 * card grid with a category filter. In scope from shop.php: $shop, $shop_list,
 * $loggedin, $user_znote_data, $config, $buy (on a POST).
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

if (empty($shop['enabled'])) {
	echo '<div class="nz-panel ts-inner" style="padding:26px 28px"><h1 class="section-title">' . $h(t('buypoints.disabled')) . '</h1><p>' . $h(t('buypoints.disabled_text')) . '</p></div>';
	return;
}

$points   = $loggedin ? (int)($user_znote_data['points'] ?? 0) : 0;
$imgSrv   = (string)($shop['imageServer'] ?? 'items.znote.eu');
$imgType  = (string)($shop['imageType'] ?? 'gif');
$outSrv   = (string)($config['show_outfits']['imageServer'] ?? '');
$showOut  = !empty($config['show_outfits']['shop']);
$confirm  = !empty($shop['enableShopConfirmation']);
$sess     = time();

$catNames = array(
	1 => t('shop.cat_items'), 2 => t('shop.cat_premium'), 3 => t('shop.cat_misc'),
	4 => t('shop.cat_misc'), 5 => t('shop.cat_outfits'), 6 => t('shop.cat_mounts'),
);
$catSlug = array(1 => 'items', 2 => 'premium', 3 => 'misc', 4 => 'misc', 5 => 'outfits', 6 => 'mounts');

// Build the item sprite URL the same way the admin panel does: honour an
// explicit scheme, otherwise http:// for a hostname, otherwise site-relative.
$itemImageUrl = static function (int $itemId) use ($imgSrv, $imgType): string {
	$server = rtrim($imgSrv, '/');
	$ext = ltrim($imgType, '.');
	if ($server === '' || $itemId <= 0) {
		return '';
	}
	if (preg_match('~^https?://~i', $server)) {
		return $server . '/' . $itemId . '.' . $ext;
	}
	if (strpos($server, '.') !== false) {
		return 'http://' . $server . '/' . $itemId . '.' . $ext;
	}
	return '/' . ltrim($server, '/') . '/' . $itemId . '.' . $ext;
};

$offerImage = static function (array $o) use ($itemImageUrl, $outSrv, $showOut): string {
	$id = $o['itemid'];
	if (is_array($id)) { $id = reset($id); }
	if ((int)$o['type'] === 5 && $showOut && $outSrv !== '') {
		return $outSrv . '?id=' . (int)$id . '&addons=' . (int)$o['count'] . '&head=0&body=0&legs=0&feet=0';
	}
	if ((int)$o['type'] === 6 && $outSrv !== '') {
		return $outSrv . '?id=128&addons=0&mount=' . (int)$id;
	}
	return $itemImageUrl((int)$id);
};

$offerCount = static function (array $o): string {
	$type = (int)$o['type'];
	if ($type === 2) { return t('shop.days', ['count' => (int)$o['count']]); }
	if ($type === 5 || $type === 6) { return ''; }
	return (int)$o['count'] . 'x';
};

// group + keep only categories that have offers
$grouped = array();
foreach (($shop_list ?? array()) as $key => $offer) {
	$type = (int)$offer['type'];
	$slug = $catSlug[$type] ?? 'misc';
	$grouped[$slug][$key] = $offer;
}
$usedCats = array();
foreach (array('items' => 'shop.cat_items', 'premium' => 'shop.cat_premium', 'outfits' => 'shop.cat_outfits', 'mounts' => 'shop.cat_mounts', 'misc' => 'shop.cat_misc') as $slug => $lk) {
	if (!empty($grouped[$slug])) { $usedCats[$slug] = t($lk); }
}
?>
<div class="hero-header">
	<div class="hero-header__content">
		<h1 class="hero-header__title"><span class="material-icons">storefront</span> <?= $h(t('time_sand.shop.title')) ?></h1>
		<p class="hero-header__subtitle"><?= $h(t('time_sand.shop.subtitle')) ?></p>
	</div>
	<?php if ($loggedin): ?>
		<div class="ts-shop-points">
			<span class="material-icons">paid</span>
			<span class="ts-shop-points__value"><?= number_format($points) ?></span>
			<span class="ts-shop-points__label"><?= $h(t('time_sand.shop.points')) ?></span>
			<a class="nz-btn ts-shop-points__buy" href="buypoints.php"><?= $h(t('time_sand.shop.buy_points')) ?></a>
		</div>
	<?php endif; ?>
</div>

<?php if (!$loggedin): ?>
	<p class="hero-header__subtitle" style="margin-bottom:16px"><?= $h(t('shop.need_login')) ?></p>
<?php endif; ?>

<?php if (count($usedCats) > 1): ?>
	<nav class="nz-segment ts-shop-filter" role="tablist">
		<button type="button" class="nz-segment__btn nz-segment__btn--active" data-shop-cat="all"><?= $h(t('shop.cat_all')) ?></button>
		<?php foreach ($usedCats as $slug => $label): ?>
			<button type="button" class="nz-segment__btn" data-shop-cat="<?= $h($slug) ?>"><?= $h($label) ?></button>
		<?php endforeach; ?>
	</nav>
<?php endif; ?>

<?php if (empty($shop_list)): ?>
	<p class="hero-header__subtitle"><?= $h(t('time_sand.shop.empty')) ?></p>
<?php else: ?>
	<div class="ts-shop-grid" data-shop-grid>
		<?php foreach ($grouped as $slug => $offers): ?>
			<?php foreach ($offers as $key => $o): ?>
				<?php $cost = (int)$o['points']; $count = $offerCount($o); ?>
				<article class="nz-panel ts-shop-card" data-shop-item="<?= $h($slug) ?>">
					<div class="ts-shop-card__img">
						<img src="<?= $h($offerImage($o)) ?>" alt="" loading="lazy">
						<?php if ($count !== ''): ?><span class="ts-shop-card__count"><?= $h($count) ?></span><?php endif; ?>
					</div>
					<div class="ts-shop-card__name"><?= $h(strip_tags((string)$o['description'])) ?></div>
					<div class="ts-shop-card__cost"><span class="material-icons">paid</span> <?= number_format($cost) ?></div>
					<?php if ($loggedin): ?>
						<form action="" method="POST" class="ts-shop-card__buy">
							<input type="hidden" name="buy" value="<?= (int)$key ?>">
							<input type="hidden" name="session" value="<?= $sess ?>">
							<button type="submit" class="nz-btn nz-btn--primary<?= $confirm ? ' needconfirmation' : '' ?>"
								<?= $points < $cost ? 'disabled' : '' ?>
								data-item-name="<?= $h(strip_tags((string)$o['description'])) ?>" data-item-cost="<?= $cost ?>">
								<?= $h(t('time_sand.shop.buy')) ?>
							</button>
						</form>
					<?php else: ?>
						<a class="nz-btn ts-shop-card__login" href="login.php"><?= $h(t('time_sand.shop.login')) ?></a>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php $_SESSION['shop_session'] = $sess; ?>
