<?php
/**
 * Time Sand - guild list, styled after the Nozdor raids ladder page.
 *
 * Called by guilds.php as view('guilds', ['guilds' => $guilds]) for the list
 * view (no ?name=). The single-guild view keeps the default markup.
 *
 * $guilds rows: id, name, creationdata, motd, total, level.
 */

$hb = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$list = (is_array($guilds ?? null)) ? $guilds : array();
$guildwarOn = !empty($config['guildwar_enabled']);
$totalMembers = 0;
foreach ($list as $g) { $totalMembers += (int)($g['total'] ?? 0); }
?>
<div class="raids-panel">
	<div class="raids-head">
		<div class="raids-head__title">
			<span class="material-icons">shield</span>
			<div>
				<h1><?= $hb(t('nav.guilds')) ?></h1>
				<span class="raids-head__meta"><?= $hb((string)($config['site_name'] ?? theme_title())) ?></span>
			</div>
		</div>
		<nav role="tablist" class="nz-segment raids-tabs">
			<a role="tab" href="guilds.php" class="nz-segment__btn raids-tabs__tab nz-segment__btn--active" aria-selected="true">
				<span class="material-icons">shield</span> <?= $hb(t('nav.guilds')) ?>
			</a>
			<?php if ($guildwarOn): ?>
				<a role="tab" href="guildwar.php" class="nz-segment__btn raids-tabs__tab" aria-selected="false">
					<span class="material-icons">flag</span> <?= $hb(t('time_sand.guilds.wars')) ?>
				</a>
			<?php endif; ?>
		</nav>
	</div>

	<div class="nz-strip stats-cards">
		<div class="nz-stat">
			<span class="nz-stat__icon"><span class="material-icons">shield</span></span>
			<span class="nz-stat__body">
				<span class="nz-stat__value"><?= number_format(count($list)) ?></span>
				<span class="nz-stat__label"><?= $hb(t('nav.guilds')) ?></span>
			</span>
		</div>
		<div class="nz-stat">
			<span class="nz-stat__icon"><span class="material-icons">groups</span></span>
			<span class="nz-stat__body">
				<span class="nz-stat__value"><?= number_format($totalMembers) ?></span>
				<span class="nz-stat__label"><?= $hb(t('online.label_name')) ?></span>
			</span>
		</div>
	</div>

	<?php if (!$list): ?>
		<p class="raids-muted raids-empty"><?= t('topguilds.no_frags') ?></p>
	<?php else: ?>
		<table class="raids-ladder">
			<thead>
				<tr>
					<th class="raids-ladder__rank">#</th>
					<th><?= $hb(t('online.label_name')) ?></th>
					<th class="raids-ladder__num"><?= $hb(t('guild.members')) ?></th>
					<th class="raids-ladder__value"><?= $hb(t('time_sand.guilds.created')) ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($list as $i => $g): ?>
					<?php $url = 'guilds.php?name=' . urlencode((string)$g['name']); ?>
					<tr class="raids-ladder__row" onclick="window.location.href='<?= $hb($url) ?>'">
						<td class="raids-ladder__rank"><?= $i + 1 ?></td>
						<td><a class="raids-guild raids-guild--link raids-ladder__strong" href="<?= $hb($url) ?>"><?= $hb($g['name']) ?></a></td>
						<td class="raids-ladder__num"><?= number_format((int)($g['total'] ?? 0)) ?></td>
						<td class="raids-ladder__value"><?= $hb(!empty($g['creationdata']) ? date('Y-m-d', (int)$g['creationdata']) : '-') ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
