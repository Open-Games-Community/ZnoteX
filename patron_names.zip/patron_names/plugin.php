<?php
/**
 * Patron Names - animated names for premium / VIP players.
 *
 * No core change: a page.footer script gets the {name: tier} map (built from the
 * accounts premium columns + a game storage key + a manual list, cached), finds
 * every <a href="characterprofile.php?name=..."> and adds the tier class + an
 * optional suffix. The animation CSS is generated from the admin settings.
 */
if (!function_exists('patron_names_setting')) {

function patron_names_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('patron_names:' . $k, $d) : $d;
}
function patron_names_int(string $k, int $d): int { $v = patron_names_setting($k, ''); return $v === '' ? $d : (int) $v; }
function patron_names_enabled(): bool { return patron_names_setting('enabled', '1') === '1'; }
function patron_names_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function patron_names_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function patron_names_ident(string $v): string { $v = trim($v); return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : ''; }

/** [dark, mid, light] gradient stops per colour name. */
function patron_names_palettes(): array {
	return array(
		'red'    => array('#c04040', '#fb7171', '#ffe5e5'),
		'green'  => array('#2f9e44', '#69db7c', '#ebfbee'),
		'blue'   => array('#1971c2', '#74c0fc', '#e7f5ff'),
		'yellow' => array('#e6a817', '#ffd43b', '#fff9db'),
		'purple' => array('#8b3fc7', '#b982f0', '#f3e8ff'),
		'orange' => array('#e8590c', '#ffa94d', '#fff4e6'),
	);
}
function patron_names_anims(): array {
	return array('shimmer', 'pulse', 'wave', 'glow', 'rainbow');
}

// --- the name -> tier map ------------------------------------------------
function patron_names_col_ok(string $table, string $col): bool {
	return function_exists('znote_column_exists') && znote_column_exists($table, $col);
}
function patron_names_premium_condition(): string {
	if (patron_names_col_ok('accounts', 'premium_ends_at')) return "`a`.`premium_ends_at` > UNIX_TIMESTAMP()";
	if (patron_names_col_ok('accounts', 'lastday') && patron_names_col_ok('accounts', 'premdays')) return "(`a`.`lastday` + `a`.`premdays` * 86400) > UNIX_TIMESTAMP()";
	if (patron_names_col_ok('accounts', 'premdays')) return "`a`.`premdays` > 0";
	return "0";
}
function patron_names_build_map(): array {
	if (!function_exists('db')) return array();
	$mode  = patron_names_setting('mode', 'both');
	$staff = max(0, patron_names_int('staff_group_min', 3));
	$staffWhere = patron_names_setting('exclude_staff', '1') === '1' ? " AND `p`.`group_id` < ?" : '';
	$out = array();

	if ($mode === 'both' || $mode === 'premium') {
		$cond = patron_names_premium_condition();
		if ($cond !== '0') {
			$params = $staffWhere !== '' ? [$staff] : [];
			$rows = db()->fetchAll("SELECT `p`.`name` FROM `players` `p` JOIN `accounts` `a` ON `a`.`id` = `p`.`account_id` WHERE {$cond}{$staffWhere} LIMIT 2000;", $params);
			if (is_array($rows)) foreach ($rows as $r) $out[strtolower(trim((string) $r['name']))] = 'premium';
		}
	}

	if ($mode === 'both' || $mode === 'vip') {
		$tbl = patron_names_ident(patron_names_setting('storage_table', '')) ?: 'player_storage';
		$pc  = patron_names_ident(patron_names_setting('storage_player_col', '')) ?: 'player_id';
		$kc  = patron_names_ident(patron_names_setting('storage_key_col', '')) ?: 'key';
		$vc  = patron_names_ident(patron_names_setting('storage_value_col', '')) ?: 'value';
		$key = patron_names_int('vip_key', 0);
		$min = patron_names_int('vip_min', 1);
		if ($key !== 0 && function_exists('znote_table_exists') && znote_table_exists($tbl)) {
			$params = [$key, $min];
			if ($staffWhere !== '') $params[] = $staff;
			$rows = db()->fetchAll("SELECT `p`.`name` FROM `players` `p` JOIN `{$tbl}` `s` ON `s`.`{$pc}` = `p`.`id` WHERE `s`.`{$kc}` = ? AND `s`.`{$vc}` >= ?{$staffWhere} LIMIT 2000;", $params);
			if (is_array($rows)) foreach ($rows as $r) $out[strtolower(trim((string) $r['name']))] = 'vip'; // vip wins over premium
		}
	}

	// manual list always wins
	$manualTier = patron_names_setting('manual_tier', 'vip') === 'premium' ? 'premium' : 'vip';
	foreach (preg_split('/[\r\n,]+/', patron_names_setting('manual_names', '')) as $n) {
		$n = strtolower(trim($n));
		if ($n !== '') $out[$n] = $manualTier;
	}

	return $out;
}
function patron_names_map(): array {
	static $map = null;
	if ($map !== null) return $map;
	$ttl = max(15, patron_names_int('cache_ttl', 90));
	$at  = patron_names_int('cache_at', 0);
	$raw = patron_names_setting('cache', '');
	if ($raw !== '' && (time() - $at) < $ttl) {
		$dec = json_decode($raw, true);
		if (is_array($dec)) return $map = $dec;
	}
	$map = patron_names_build_map();
	if (function_exists('setting_set')) {
		setting_set('patron_names:cache', (string) json_encode($map));
		setting_set('patron_names:cache_at', (string) time());
	}
	return $map;
}
function patron_names_clear_cache(): void {
	if (function_exists('setting_set')) { setting_set('patron_names:cache', ''); setting_set('patron_names:cache_at', '0'); }
}

// --- generated CSS -----------------------------------------------------
function patron_names_tier_css(string $tier): string {
	$pal = patron_names_palettes();
	$col = patron_names_setting($tier . '_color', $tier === 'premium' ? 'yellow' : 'red');
	if (!isset($pal[$col])) $col = 'red';
	[$d, $m, $l] = $pal[$col];
	$anim = patron_names_setting($tier . '_anim', 'shimmer');
	if (!in_array($anim, patron_names_anims(), true)) $anim = 'shimmer';
	$speed = max(600, patron_names_int($tier . '_speed', 2400));
	$sel = ".patron-name--{$tier}";
	$css = "{$sel}{font-weight:600;transition:filter .2s ease}";

	if ($anim === 'shimmer' || $anim === 'wave' || $anim === 'rainbow') {
		$deg  = $anim === 'wave' ? '20deg' : '100deg';
		$grad = $anim === 'rainbow'
			? "linear-gradient({$deg},#ff5252,#ffb142,#fff176,#69db7c,#4dd0e1,#7c9cff,#c77dff,#ff5252)"
			: "linear-gradient({$deg},{$d} 0%,{$d} 35%,{$m} 45%,{$l} 50%,{$m} 55%,{$d} 65%,{$d} 100%)";
		$css .= "{$sel}{background-image:{$grad};background-size:300% auto;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;filter:drop-shadow(0 0 1px " . patron_names_rgba($d, .3) . ");animation:patronShimmer {$speed}ms linear infinite}";
		$css .= "@keyframes patronShimmer{0%{background-position:0% 50%}100%{background-position:-150% 50%}}";
	} elseif ($anim === 'pulse') {
		$css .= "{$sel}{color:{$m};animation:patronPulse {$speed}ms ease-in-out infinite;text-shadow:0 0 6px " . patron_names_rgba($m, .0) . "}";
		$css .= "@keyframes patronPulse{0%,100%{opacity:1;text-shadow:0 0 2px " . patron_names_rgba($m, .0) . "}50%{opacity:.72;text-shadow:0 0 10px " . patron_names_rgba($l, .8) . "}}";
	} else { // glow
		$css .= "{$sel}{color:{$m};animation:patronGlow {$speed}ms ease-in-out infinite}";
		$css .= "@keyframes patronGlow{0%,100%{text-shadow:0 0 3px " . patron_names_rgba($d, .5) . "}50%{text-shadow:0 0 12px " . patron_names_rgba($l, .9) . ",0 0 4px " . patron_names_rgba($m, .7) . "}}";
	}

	$font = trim(patron_names_setting($tier . '_font', ''));
	if ($font !== '') $css .= "{$sel}{font-family:" . preg_replace('/[^A-Za-z0-9 ,"\'\-]/', '', $font) . "}";
	$fs = patron_names_int($tier . '_size', 0);
	if ($fs >= 8 && $fs <= 40) $css .= "{$sel}{font-size:{$fs}px}";

	$sfx = patron_names_setting($tier . '_suffix', '');
	if ($sfx !== '') {
		$css .= ".patron-suffix--{$tier}{color:{$m};margin-left:4px;font-size:.9em;-webkit-text-fill-color:{$m}}";
	}
	return $css;
}
function patron_names_rgba(string $hex, float $a): string {
	$hex = ltrim($hex, '#');
	if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	$r = hexdec(substr($hex, 0, 2)); $g = hexdec(substr($hex, 2, 2)); $b = hexdec(substr($hex, 4, 2));
	return "rgba({$r},{$g},{$b}," . rtrim(rtrim(number_format($a, 2, '.', ''), '0'), '.') . ")";
}

// --- footer hook -----------------------------------------------------
function patron_names_footer(): string {
	if (!patron_names_enabled()) return '';
	$pages = array_filter(array_map('trim', explode(',', patron_names_setting('pages', ''))));
	if ($pages) {
		$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
		if (!in_array($script, $pages, true)) return '';
	}
	$map = patron_names_map();
	if (!$map) return '';
	$mode = patron_names_setting('mode', 'both');

	$css = '';
	if ($mode === 'both' || $mode === 'premium') $css .= patron_names_tier_css('premium');
	if ($mode === 'both' || $mode === 'vip')     $css .= patron_names_tier_css('vip');

	$suffix = array(
		'premium' => patron_names_setting('premium_suffix', ''),
		'vip'     => patron_names_setting('vip_suffix', ''),
	);

	return '<style>' . $css . '</style>'
		. '<script>(function(){'
		. 'var M=' . json_encode($map) . ',S=' . json_encode($suffix) . ';'
		. 'function nameOf(a){try{var u=a.getAttribute("href")||"";var m=u.match(/[?&]name=([^&#]+)/);if(!m)return"";return decodeURIComponent(m[1].replace(/\\+/g," ")).trim().toLowerCase();}catch(e){return"";}}'
		. 'function run(){document.querySelectorAll(\'a[href*="characterprofile.php?name="]:not(.patron-done)\').forEach(function(a){'
		. 'a.classList.add("patron-done");var t=M[nameOf(a)];if(!t)return;'
		. 'a.classList.add("patron-name","patron-name--"+t);'
		. 'if(S[t]){var i=document.createElement("i");i.className="patron-suffix patron-suffix--"+t;i.textContent=S[t];i.setAttribute("aria-hidden","true");a.appendChild(i);}'
		. '});}'
		. 'if(document.readyState!=="loading")run();else document.addEventListener("DOMContentLoaded",run);'
		. 'setTimeout(run,600);'
		. '}());</script>';
}

function patron_names_ensure_menu(): void {}

}

if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'patron_names_footer');
}
