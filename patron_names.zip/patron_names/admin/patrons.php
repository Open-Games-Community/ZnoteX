<?php
/**
 * Title: Patron Names
 * Icon: fa-star
 * Group: Installed Plugins
 * Order: 41
 * Description: Which players get an animated name, and how it looks.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'patron_names__patrons';

$colors = array_keys(patron_names_palettes());
$anims  = patron_names_anims();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$pick = static function (string $v, array $allow, string $def): string { return in_array($v, $allow, true) ? $v : $def; };

	setting_set('patron_names:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('patron_names:mode', $pick((string) ($_POST['mode'] ?? 'both'), array('both', 'premium', 'vip'), 'both'));
	setting_set('patron_names:exclude_staff', !empty($_POST['exclude_staff']) ? '1' : '0');
	setting_set('patron_names:staff_group_min', (string) max(2, intv($_POST['staff_group_min'] ?? 3)));
	setting_set('patron_names:cache_ttl', (string) max(15, min(3600, intv($_POST['cache_ttl'] ?? 90))));
	setting_set('patron_names:pages', trim((string) ($_POST['pages'] ?? '')));

	setting_set('patron_names:vip_key', (string) intv($_POST['vip_key'] ?? 0));
	setting_set('patron_names:vip_min', (string) intv($_POST['vip_min'] ?? 1));
	foreach (array('storage_table', 'storage_player_col', 'storage_key_col', 'storage_value_col') as $k) {
		setting_set('patron_names:' . $k, patron_names_ident((string) ($_POST[$k] ?? '')));
	}
	setting_set('patron_names:manual_names', trim((string) ($_POST['manual_names'] ?? '')));
	setting_set('patron_names:manual_tier', $pick((string) ($_POST['manual_tier'] ?? 'vip'), array('vip', 'premium'), 'vip'));

	foreach (array('premium', 'vip') as $tier) {
		setting_set("patron_names:{$tier}_color", $pick((string) ($_POST[$tier . '_color'] ?? ''), $colors, $tier === 'premium' ? 'yellow' : 'red'));
		setting_set("patron_names:{$tier}_anim", $pick((string) ($_POST[$tier . '_anim'] ?? ''), $anims, 'shimmer'));
		setting_set("patron_names:{$tier}_speed", (string) max(600, min(12000, intv($_POST[$tier . '_speed'] ?? 2400))));
		setting_set("patron_names:{$tier}_suffix", substr(trim((string) ($_POST[$tier . '_suffix'] ?? '')), 0, 8));
		setting_set("patron_names:{$tier}_font", substr(trim((string) ($_POST[$tier . '_font'] ?? '')), 0, 80));
		setting_set("patron_names:{$tier}_size", (string) max(0, min(40, intv($_POST[$tier . '_size'] ?? 0))));
	}

	patron_names_clear_cache();
	if (function_exists('acp_log')) acp_log('patron_names.config', '');
	acp_flash_success(t_default('acp.patron.saved', 'Patron Names saved.'));
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('patron_names:' . $k, $d);

// live counts (also warms the cache)
patron_names_clear_cache();
$map = patron_names_build_map();
$nPrem = 0; $nVip = 0;
foreach ($map as $t) { if ($t === 'premium') $nPrem++; else $nVip++; }

$tierLabels = array(
	'premium' => t_default('acp.patron.tier_premium', 'Premium'),
	'vip'     => t_default('acp.patron.tier_vip', 'VIP'),
);

$tierBlock = static function (string $tier, $get, array $colors, array $anims) use ($tierLabels) {
	$def = $tier === 'premium' ? 'yellow' : 'red';
	$label = $tierLabels[$tier] ?? ucfirst($tier);
	?>
	<h3><?= h(t_default('acp.patron.tier_style_title', '{tier} name style', array('tier' => $label))) ?></h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.colour', 'Colour')) ?></label><select class="acp-select" name="<?= $tier ?>_color">
			<?php foreach ($colors as $c): ?><option value="<?= h($c) ?>" <?= $get($tier . '_color', $def) === $c ? 'selected' : '' ?>><?= h(ucfirst($c)) ?></option><?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.animation', 'Animation')) ?></label><select class="acp-select" name="<?= $tier ?>_anim">
			<?php foreach ($anims as $a): ?><option value="<?= h($a) ?>" <?= $get($tier . '_anim', 'shimmer') === $a ? 'selected' : '' ?>><?= h(ucfirst($a)) ?></option><?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.anim_speed', 'Animation speed (ms)')) ?></label><input class="acp-input" type="number" min="600" max="12000" step="100" name="<?= $tier ?>_speed" value="<?= (int) $get($tier . '_speed', '2400') ?>"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.suffix_icon', 'Suffix icon')) ?> <span class="acp-muted">(<?= t_default('acp.patron.suffix_icon_help', 'after the name, e.g. &hearts; &starf; &diams; - blank = none') ?>)</span></label><input class="acp-input" name="<?= $tier ?>_suffix" value="<?= h($get($tier . '_suffix')) ?>" maxlength="8"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.font_family', 'Font family')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.blank_inherit', 'blank = inherit')) ?>)</span></label><input class="acp-input" name="<?= $tier ?>_font" value="<?= h($get($tier . '_font')) ?>" placeholder="Philosopher, serif"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.font_size', 'Font size px')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.zero_inherit', '0 = inherit')) ?>)</span></label><input class="acp-input" type="number" min="0" max="40" name="<?= $tier ?>_size" value="<?= (int) $get($tier . '_size', '0') ?>"></div>
	</div>
	<?php
};
?>
<?php acp_card_open(t_default('acp.patron.title', 'Patron Names'), t_default('acp.patron.sub', 'Premium and VIP players get an animated name everywhere a character link appears (highscores, online list, guild rosters, profiles). VIP = any player whose game storage key is &ge; a value you set - grant it in-game or in the DB. No engine change; a <code>page.footer</code> script restyles the links.')); ?>

<p class="acp-muted" style="margin:-6px 0 14px">
	<?= h(t_default('acp.patron.matched_now', 'Matched right now:')) ?> <b><?= (int) $nPrem ?></b> <?= h(t_default('acp.patron.tier_premium', 'Premium')) ?> &middot; <b><?= (int) $nVip ?></b> <?= h(t_default('acp.patron.tier_vip', 'VIP')) ?>.
	<?php if ($nPrem === 0 && $nVip === 0): ?> &mdash; <?= h(t_default('acp.patron.nothing_yet', 'nothing to show yet (no premium accounts, and no VIP storage set below).')) ?><?php endif; ?>
</p>

<form method="post">
	<?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> <?= h(t_default('acp.patron.enabled', 'Enabled')) ?></label></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.who_gets', 'Who gets a patron name')) ?></label><select class="acp-select" name="mode">
			<option value="both"    <?= $get('mode', 'both') === 'both' ? 'selected' : '' ?>><?= h(t_default('acp.patron.mode_both', 'Premium & VIP')) ?></option>
			<option value="premium" <?= $get('mode') === 'premium' ? 'selected' : '' ?>><?= h(t_default('acp.patron.mode_premium', 'Premium only')) ?></option>
			<option value="vip"     <?= $get('mode') === 'vip' ? 'selected' : '' ?>><?= h(t_default('acp.patron.mode_vip', 'VIP only')) ?></option>
		</select></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="exclude_staff" value="1" <?= $get('exclude_staff', '1') === '1' ? 'checked' : '' ?>> <?= h(t_default('acp.patron.skip_staff', 'Skip staff characters')) ?></label></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.staff_group_min', 'Staff group id from')) ?></label><input class="acp-input" type="number" min="2" name="staff_group_min" value="<?= (int) $get('staff_group_min', '3') ?>"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.recheck_interval', 'Recheck interval (seconds)')) ?></label><input class="acp-input" type="number" min="15" max="3600" name="cache_ttl" value="<?= (int) $get('cache_ttl', '90') ?>"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.only_pages', 'Only on pages')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.only_pages_help', 'comma list of files, blank = everywhere')) ?>)</span></label><input class="acp-input" name="pages" value="<?= h($get('pages')) ?>" placeholder="highscores.php, online.php"></div>
	</div>

	<h3><?= h(t_default('acp.patron.vip_detection', 'VIP detection')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.vip_detection_help', 'a game storage key on the player')) ?>)</span></h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.storage_key', 'Storage key')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.storage_key_help', '0 = VIP off')) ?>)</span></label><input class="acp-input" type="number" name="vip_key" value="<?= (int) $get('vip_key', '0') ?>"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.min_value', 'Minimum value')) ?></label><input class="acp-input" type="number" name="vip_min" value="<?= (int) $get('vip_min', '1') ?>"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.storage_table', 'Storage table')) ?></label><input class="acp-input" name="storage_table" value="<?= h($get('storage_table')) ?>" placeholder="player_storage"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.col_player_id', 'player id column')) ?></label><input class="acp-input" name="storage_player_col" value="<?= h($get('storage_player_col')) ?>" placeholder="player_id"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.col_key', 'key column')) ?></label><input class="acp-input" name="storage_key_col" value="<?= h($get('storage_key_col')) ?>" placeholder="key"></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.col_value', 'value column')) ?></label><input class="acp-input" name="storage_value_col" value="<?= h($get('storage_value_col')) ?>" placeholder="value"></div>
	</div>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.manual_names', 'Manual names')) ?> <span class="acp-muted">(<?= h(t_default('acp.patron.manual_names_help', 'one per line - always shown')) ?>)</span></label><textarea class="acp-textarea" name="manual_names" rows="3"><?= h($get('manual_names')) ?></textarea></div>
		<div class="acp-field"><label class="acp-label"><?= h(t_default('acp.patron.manual_style', 'Manual names use the style of')) ?></label><select class="acp-select" name="manual_tier">
			<option value="vip"     <?= $get('manual_tier', 'vip') === 'vip' ? 'selected' : '' ?>><?= h(t_default('acp.patron.tier_vip', 'VIP')) ?></option>
			<option value="premium" <?= $get('manual_tier') === 'premium' ? 'selected' : '' ?>><?= h(t_default('acp.patron.tier_premium', 'Premium')) ?></option>
		</select></div>
	</div>

	<?php $tierBlock('premium', $get, $colors, $anims); ?>
	<?php $tierBlock('vip', $get, $colors, $anims); ?>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= h(t_default('acp.patron.save_btn', 'Save')) ?></button></div>
</form>
