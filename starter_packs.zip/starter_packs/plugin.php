<?php
if (!function_exists('starter_packs_setting')) {
function starter_packs_setting(string $key, string $default = ''): string { return function_exists('setting') ? (string)setting('starter_packs:' . $key, $default) : $default; }
function starter_packs_enabled(): bool { return starter_packs_setting('enabled', '1') === '1'; }
function starter_packs_h($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function starter_packs_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string)$v, $text);
	return $text;
}
function starter_packs_css_value(string $value): string {
	$value = trim($value);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value)) return $value;
	return preg_match('/^linear-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $value) ? $value : '';
}
function starter_packs_color(string $key): string { return starter_packs_css_value(starter_packs_setting('style_' . $key, '')); }
function starter_packs_css_position(string $value): string {
	$value = trim($value);
	return preg_match('/^(-?[0-9.]+%?|left|center|right)\s+(-?[0-9.]+%?|top|center|bottom)$/', $value) ? $value : '';
}
function starter_packs_css_size(string $value): string {
	$value = trim($value);
	return preg_match('/^(auto|cover|contain|[0-9.]+%(\s+(auto|[0-9.]+%))?)$/', $value) ? $value : '';
}
function starter_packs_style_attr(array $map): string {
	$css = '';
	foreach ($map as $key => $var) {
		$value = starter_packs_color($key);
		if ($value !== '') $css .= $var . ':' . $value . ';';
	}
	return $css !== '' ? ' style="' . starter_packs_h($css) . '"' : '';
}
function starter_packs_asset_image(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.-]/', '', $file);
	if ($file === '') return '';
	$path = __DIR__ . '/assets/img/' . $file;
	return is_file($path) ? znote_plugin_asset('starter_packs', 'img/' . $file) : '';
}
function starter_packs_ensure_schema(): void {
	if (!function_exists('znote_table_exists') || !function_exists('znote_column_exists') || !znote_table_exists('znote_starter_pack_transactions')) return;
	if (!znote_column_exists('znote_starter_pack_transactions', 'player_id')) mysql_update("ALTER TABLE `znote_starter_pack_transactions` ADD COLUMN `player_id` int NOT NULL DEFAULT '0' AFTER `account_id`;");
	if (!znote_column_exists('znote_starter_pack_transactions', 'points')) mysql_update("ALTER TABLE `znote_starter_pack_transactions` ADD COLUMN `points` int NOT NULL DEFAULT '0' AFTER `currency`;");
	if (znote_table_exists('znote_starter_pack_orders') && !znote_column_exists('znote_starter_pack_orders', 'player_id')) mysql_update("ALTER TABLE `znote_starter_pack_orders` ADD COLUMN `player_id` int NOT NULL DEFAULT '0' AFTER `account_id`;");
}
function starter_packs_currency_for(string $provider = ''): string {
	global $config;
	$providers = $provider !== '' ? array($provider) : array('paypal', 'stripe', 'mercadopago', 'pagseguro', 'paygol');
	foreach ($providers as $p) {
		$currency = strtoupper(trim((string)($config[$p]['currency'] ?? '')));
		if ($currency !== '') return $currency;
	}
	return 'EUR';
}
function starter_packs_default_packs(): array {
	return array(
		array('key'=>'starter','title'=>'Starter Pack','subtitle'=>'A solid beginning','price'=>20,'image'=>'pack_1.png','image_pos'=>'center center','image_size'=>'contain','accent'=>'#2fdd72','card_bg'=>'linear-gradient(180deg,rgba(16,70,44,.96),rgba(7,26,19,.96))','border'=>'#48d977','button_bg'=>'#1c7e3a','button_text'=>'#f2ffe8','rewards'=>array(array('kind'=>'premium_days','value'=>7,'icon_pos'=>'0% 43%'),array('kind'=>'premium_points','value'=>100,'icon_pos'=>'60% 43%'),array('kind'=>'outfit','male'=>128,'female'=>136,'addons'=>3,'icon_pos'=>'0% 60%'),array('kind'=>'storage','key'=>90020,'value'=>1,'icon_pos'=>'100% 43%'))),
		array('key'=>'adventurer','title'=>'Adventurer Pack','subtitle'=>'Explore further','price'=>50,'image'=>'pack_2.png','image_pos'=>'center center','image_size'=>'contain','accent'=>'#4ba8ff','card_bg'=>'linear-gradient(180deg,rgba(12,61,108,.96),rgba(5,25,48,.96))','border'=>'#4ba8ff','button_bg'=>'#165a9b','button_text'=>'#eef7ff','rewards'=>array(array('kind'=>'premium_days','value'=>15,'icon_pos'=>'20% 43%'),array('kind'=>'premium_points','value'=>300,'icon_pos'=>'60% 43%'),array('kind'=>'outfit','male'=>129,'female'=>137,'addons'=>3,'icon_pos'=>'0% 60%'),array('kind'=>'mount','mount'=>1,'icon_pos'=>'20% 60%'),array('kind'=>'storage','key'=>90050,'value'=>1,'icon_pos'=>'100% 43%'))),
		array('key'=>'hero','title'=>'Hero Pack','subtitle'=>'Rise above','price'=>100,'image'=>'pack_3.png','image_pos'=>'center center','image_size'=>'contain','accent'=>'#c34dff','card_bg'=>'linear-gradient(180deg,rgba(74,20,110,.96),rgba(29,8,49,.96))','border'=>'#c34dff','button_bg'=>'#7420a0','button_text'=>'#fff1ff','rewards'=>array(array('kind'=>'premium_days','value'=>30,'icon_pos'=>'40% 43%'),array('kind'=>'premium_points','value'=>700,'icon_pos'=>'60% 43%'),array('kind'=>'outfit','male'=>130,'female'=>138,'addons'=>3,'icon_pos'=>'40% 60%'),array('kind'=>'mount','mount'=>2,'icon_pos'=>'60% 60%'),array('kind'=>'item','itemid'=>2160,'count'=>25,'icon_pos'=>'80% 60%'),array('kind'=>'storage','key'=>90100,'value'=>1,'icon_pos'=>'100% 43%'))),
		array('key'=>'epic','title'=>'Epic Pack','subtitle'=>'For true heroes','price'=>200,'image'=>'pack_4.png','image_pos'=>'center center','image_size'=>'contain','accent'=>'#f0b84a','card_bg'=>'linear-gradient(180deg,rgba(111,68,14,.96),rgba(43,24,6,.96))','border'=>'#f0b84a','button_bg'=>'#9c6614','button_text'=>'#fff6d8','rewards'=>array(array('kind'=>'premium_days','value'=>60,'icon_pos'=>'80% 43%'),array('kind'=>'premium_points','value'=>1600,'icon_pos'=>'60% 43%'),array('kind'=>'outfit','male'=>131,'female'=>139,'addons'=>3,'icon_pos'=>'90% 60%'),array('kind'=>'mount','mount'=>3,'icon_pos'=>'0% 75%'),array('kind'=>'item','itemid'=>2472,'count'=>1,'icon_pos'=>'20% 75%'),array('kind'=>'storage','key'=>90200,'value'=>1,'icon_pos'=>'100% 43%'))),
		array('key'=>'legend','title'=>'Legend Pack','subtitle'=>'Become a legend','price'=>300,'image'=>'pack_5.png','image_pos'=>'center center','image_size'=>'contain','accent'=>'#ff4d35','card_bg'=>'linear-gradient(180deg,rgba(130,26,16,.96),rgba(53,8,5,.96))','border'=>'#ff654f','button_bg'=>'#a52519','button_text'=>'#fff4ec','rewards'=>array(array('kind'=>'premium_days','value'=>90,'icon_pos'=>'80% 43%'),array('kind'=>'premium_points','value'=>3000,'icon_pos'=>'60% 43%'),array('kind'=>'outfit','male'=>132,'female'=>140,'addons'=>3,'icon_pos'=>'60% 75%'),array('kind'=>'mount','mount'=>4,'icon_pos'=>'80% 75%'),array('kind'=>'item','itemid'=>2472,'count'=>2,'icon_pos'=>'20% 75%'),array('kind'=>'storage','key'=>90300,'value'=>1,'icon_pos'=>'100% 75%'))),
	);
}
function starter_packs_reward_kind(array $reward): string {
	$kind = (string)($reward['kind'] ?? 'item');
	if ($kind === 'premium') return 'premium_days';
	if ($kind === 'points') return 'premium_points';
	return $kind;
}
function starter_packs_pack_rewards(array $pack): array {
	if (isset($pack['rewards']) && is_array($pack['rewards'])) return array_slice($pack['rewards'], 0, 10);
	return array();
}
function starter_packs_default_icon_file(string $kind): string {
	if ($kind === 'premium_days') return 'vip.png';
	if ($kind === 'premium_points') return 'points.png';
	if ($kind === 'outfit') return 'armor.png';
	if ($kind === 'mount') return 'mount.png';
	if ($kind === 'storage') return 'key.png';
	if ($kind === 'house') return 'storage.png';
	return 'storage.png';
}
function starter_packs_item_image_url(int $itemid): string {
	global $config;
	if ($itemid <= 0 || empty($config['shop']['showImage'])) return '';
	$server = trim((string)($config['shop']['imageServer'] ?? ''));
	$type = preg_replace('/[^a-zA-Z0-9]/', '', (string)($config['shop']['imageType'] ?? 'gif'));
	if ($server === '' || $type === '') return '';
	$path = rtrim($server, '/') . '/' . $itemid . '.' . $type;
	if (preg_match('/^https?:\/\//i', $path)) return $path;
	return (strpos($path, '/') === 0 ? '' : 'http://') . $path;
}
function starter_packs_outfit_image_url(int $outfitId, int $addons = 3, int $mountId = 0): string {
	global $config;
	if ($outfitId <= 0 || empty($config['show_outfits']['shop'])) return '';
	$server = trim((string)($config['show_outfits']['imageServer'] ?? ''));
	if ($server === '') return '';
	$url = $server . '?id=' . $outfitId . '&addons=' . max(0, min(3, $addons)) . '&head=94&body=79&legs=114&feet=114';
	if ($mountId > 0) $url .= '&mount=' . $mountId . '&direction=2';
	return $url;
}
function starter_packs_reward_quantity(array $reward): int {
	$kind = starter_packs_reward_kind($reward);
	if ($kind === 'item') return max(1, (int)($reward['count'] ?? 1));
	if ($kind === 'outfit' || $kind === 'mount') return max(1, (int)($reward['quantity'] ?? 1));
	return 0;
}
function starter_packs_reward_image_url(array $reward): string {
	$kind = starter_packs_reward_kind($reward);
	if ($kind === 'item') return starter_packs_item_image_url((int)($reward['itemid'] ?? 0));
	if ($kind === 'outfit') return starter_packs_outfit_image_url((int)($reward['male'] ?? $reward['itemid'] ?? 0), (int)($reward['addons'] ?? 3));
	if ($kind === 'mount') return starter_packs_outfit_image_url(128, 0, (int)($reward['mount'] ?? $reward['itemid'] ?? 0));
	return '';
}
function starter_packs_normalize_pack(array $pack, int $index): array {
	if (($pack['image'] ?? '') === '' || ($pack['image'] ?? '') === 'packs.png' || ($pack['image'] ?? '') === 'assets.png') {
		$pack['image'] = 'pack_' . ($index + 1) . '.png';
		$pack['image_pos'] = 'center center';
		$pack['image_size'] = 'contain';
	}
	if (empty($pack['image_pos'])) $pack['image_pos'] = 'center center';
	if (empty($pack['image_size'])) $pack['image_size'] = 'contain';
	$rewards = array();
	foreach (starter_packs_pack_rewards($pack) as $reward) {
		$kind = starter_packs_reward_kind($reward);
		if (empty($reward['icon_file'])) $reward['icon_file'] = starter_packs_default_icon_file($kind);
		if ($kind === 'premium_days' && ($reward['icon_file'] ?? '') === 'empty_calendar.png') $reward['icon_file'] = 'vip.png';
		$rewards[] = $reward;
	}
	$pack['rewards'] = array_slice($rewards, 0, 10);
	return $pack;
}
function starter_packs_packs(): array {
	$packs = json_decode(starter_packs_setting('packs', ''), true);
	$packs = is_array($packs) && $packs ? array_slice($packs, 0, 5) : starter_packs_default_packs();
	foreach ($packs as $i => $pack) $packs[$i] = starter_packs_normalize_pack((array)$pack, $i);
	return $packs;
}
function starter_packs_pack(string $key): ?array {
	foreach (starter_packs_packs() as $pack) if ((string)($pack['key'] ?? '') === $key) return $pack;
	return null;
}
function starter_packs_points_total(array $pack): int {
	$total = 0;
	foreach (starter_packs_pack_rewards($pack) as $reward) if (starter_packs_reward_kind($reward) === 'premium_points') $total += max(0, (int)($reward['value'] ?? 0));
	return $total;
}
function starter_packs_requires_character(array $pack): bool {
	foreach (starter_packs_pack_rewards($pack) as $reward) if (starter_packs_reward_kind($reward) === 'house') return true;
	return false;
}
function starter_packs_valid_character(int $accountId, int $playerId): bool {
	return $playerId > 0 && mysql_select_single("SELECT `id` FROM `players` WHERE `id`={$playerId} AND `account_id`={$accountId} LIMIT 1;") !== false;
}
function starter_packs_character_options(int $accountId): string {
	$rows = function_exists('user_character_list') ? user_character_list($accountId) : mysql_select_multi("SELECT `id`,`name` FROM `players` WHERE `account_id`={$accountId} ORDER BY `level` DESC;");
	if (!is_array($rows)) return '';
	$html = '';
	foreach ($rows as $row) {
		$id = (int)($row['id'] ?? 0);
		if ($id > 0) $html .= '<option value="' . $id . '">' . starter_packs_h($row['name'] ?? ('#' . $id)) . '</option>';
	}
	return $html;
}
function starter_packs_ref(string $provider): string { return 'sp_' . preg_replace('/[^a-z0-9_]/', '', strtolower($provider)) . '_' . bin2hex(random_bytes(12)); }
function starter_packs_create_tx(string $provider, int $accountId, array $pack, int $playerId = 0): string {
	starter_packs_ensure_schema();
	$ref = starter_packs_ref($provider);
	$now = time();
	$key = mysql_znote_escape_string((string)$pack['key']);
	$p = mysql_znote_escape_string($provider);
	$currency = mysql_znote_escape_string(starter_packs_currency_for($provider));
	$price = number_format((float)($pack['price'] ?? 0), 2, '.', '');
	$points = starter_packs_points_total($pack);
	mysql_insert("INSERT INTO `znote_starter_pack_transactions` (`reference`,`provider`,`account_id`,`player_id`,`pack_key`,`price`,`currency`,`points`,`status`,`created_at`,`updated_at`) VALUES ('{$ref}','{$p}',{$accountId},{$playerId},'{$key}','{$price}','{$currency}',{$points},'pending',{$now},{$now});");
	return $ref;
}
function starter_packs_provider_enabled(string $provider): bool { return !empty($GLOBALS['config'][$provider]['enabled']); }
function starter_packs_link_payment_reference(string $starterRef, string $provider, string $paymentRef): void {
	$r = mysql_znote_escape_string($starterRef);
	$p = mysql_znote_escape_string($provider);
	$pr = mysql_znote_escape_string($paymentRef);
	mysql_update("UPDATE `znote_starter_pack_transactions` SET `provider_reference`='{$pr}',`updated_at`=" . time() . " WHERE `reference`='{$r}' AND `provider`='{$p}' LIMIT 1;");
}
function starter_packs_begin_checkout(string $provider, int $accountId, string $packKey, int $playerId = 0): array {
	$provider = strtolower($provider);
	$pack = starter_packs_pack($packKey);
	if (!$pack || $accountId <= 0) return array('ok'=>false,'message'=>starter_packs_t('starter_packs.invalid', 'Invalid starter pack.'));
	if (!in_array($provider, array('stripe','mercadopago','paypal','pagseguro','paygol'), true) || !starter_packs_provider_enabled($provider)) return array('ok'=>false,'message'=>starter_packs_t('starter_packs.provider_disabled', 'Payment provider is disabled.'));
	if (starter_packs_requires_character($pack) && !starter_packs_valid_character($accountId, $playerId)) return array('ok'=>false,'message'=>starter_packs_t('starter_packs.character_required', 'Select one of your characters for this pack.'));
	$ref = starter_packs_create_tx($provider, $accountId, $pack, $playerId);
	if (in_array($provider, array('stripe','mercadopago'), true) && function_exists('payment_gateway_create_checkout')) {
		$old = $GLOBALS['config']['paypal_prices'] ?? array();
		$GLOBALS['config']['paypal_prices'] = array((string)$pack['price'] => max(1, starter_packs_points_total($pack)));
		try {
			$result = payment_gateway_create_checkout($provider, $accountId, $pack['price']);
			starter_packs_link_payment_reference($ref, $provider, (string)($result['reference'] ?? ''));
			$GLOBALS['config']['paypal_prices'] = $old;
			return array('ok'=>true,'redirect'=>(string)$result['url']);
		} catch (Throwable $e) {
			$GLOBALS['config']['paypal_prices'] = $old;
			mysql_update("UPDATE `znote_starter_pack_transactions` SET `status`='create_failed',`updated_at`=" . time() . " WHERE `reference`='" . mysql_znote_escape_string($ref) . "' LIMIT 1;");
			return array('ok'=>false,'message'=>$e->getMessage());
		}
	}
	return array('ok'=>true,'reference'=>$ref,'provider'=>$provider,'pack'=>$pack);
}
function starter_packs_find_for_payment(array $data): ?array {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_starter_pack_transactions')) return null;
	$provider = mysql_znote_escape_string((string)($data['provider'] ?? ''));
	$reference = mysql_znote_escape_string((string)($data['reference'] ?? ''));
	$custom = mysql_znote_escape_string((string)($data['custom'] ?? ''));
	$where = array();
	if ($reference !== '') $where[] = "(`provider`='{$provider}' AND `provider_reference`='{$reference}')";
	if ($custom !== '' && substr($custom, 0, 3) === 'sp_') $where[] = "`reference`='{$custom}'";
	if (!$where) return null;
	$row = mysql_select_single("SELECT * FROM `znote_starter_pack_transactions` WHERE (" . implode(' OR ', $where) . ") AND `status` IN ('pending','paid') LIMIT 1;");
	return is_array($row) ? $row : null;
}
function starter_packs_payment_resolve($payment, array $context = array()): array {
	if (!is_array($payment) || !starter_packs_enabled()) return is_array($payment) ? $payment : array();
	$custom = (string)($payment['custom'] ?? '');
	if ($custom === '' || substr($custom, 0, 3) !== 'sp_') return $payment;
	$provider = mysql_znote_escape_string((string)($payment['provider'] ?? ''));
	$ref = mysql_znote_escape_string($custom);
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_starter_pack_transactions')) return $payment;
	$tx = mysql_select_single("SELECT * FROM `znote_starter_pack_transactions` WHERE `reference`='{$ref}' AND `provider`='{$provider}' LIMIT 1;");
	if (!is_array($tx)) return $payment;
	$payment['resolved'] = true;
	$payment['account_id'] = (int)$tx['account_id'];
	$payment['price'] = $tx['price'];
	$payment['currency'] = $tx['currency'];
	$payment['points'] = (int)$tx['points'];
	$payment['starter_reference'] = $custom;
	return $payment;
}
function starter_packs_mark_paid_and_deliver(array $data): void {
	$tx = starter_packs_find_for_payment($data);
	if (!$tx) return;
	$price = number_format((float)($data['price'] ?? $tx['price']), 2, '.', '');
	$currency = strtoupper((string)($data['currency'] ?? $tx['currency']));
	if ($price !== number_format((float)$tx['price'], 2, '.', '') || $currency !== strtoupper((string)$tx['currency'])) return;
	$id = (int)$tx['id'];
	$providerReference = mysql_znote_escape_string((string)($data['reference'] ?? $tx['provider_reference']));
	mysql_update("UPDATE `znote_starter_pack_transactions` SET `status`='paid',`provider_reference`=IF(`provider_reference`='', '{$providerReference}', `provider_reference`),`updated_at`=" . time() . " WHERE `id`={$id} LIMIT 1;");
	$tx['status'] = 'paid';
	starter_packs_deliver_tx($tx);
}
function starter_packs_deliver_tx(array $tx): void {
	if ((int)($tx['delivered'] ?? 0) === 1 || (string)($tx['status'] ?? '') !== 'paid') return;
	$pack = starter_packs_pack((string)$tx['pack_key']);
	if (!$pack) return;
	$accountId = (int)$tx['account_id'];
	$playerId = (int)($tx['player_id'] ?? 0);
	if ($accountId <= 0) return;
	$now = time();
	$txid = (int)$tx['id'];
	foreach (starter_packs_pack_rewards($pack) as $reward) {
		$kind = starter_packs_reward_kind($reward);
		if ($kind === 'premium_days') {
			$days = max(0, (int)($reward['value'] ?? 0));
			if ($days > 0 && function_exists('user_account_add_premdays')) user_account_add_premdays($accountId, $days);
			if ($days > 0) mysql_insert("INSERT INTO `znote_starter_pack_orders` (`pack_tx_id`,`account_id`,`reward_type`,`count`,`created_at`) VALUES ({$txid},{$accountId},'premium_days',{$days},{$now});");
			continue;
		}
		if ($kind === 'premium_points') {
			$points = max(0, (int)($reward['value'] ?? 0));
			if ($points > 0 && (int)($tx['points'] ?? 0) <= 0) mysql_update("UPDATE `znote_accounts` SET `points`=COALESCE(`points`,0)+{$points} WHERE `account_id`={$accountId};");
			if ($points > 0) mysql_insert("INSERT INTO `znote_starter_pack_orders` (`pack_tx_id`,`account_id`,`reward_type`,`count`,`created_at`) VALUES ({$txid},{$accountId},'premium_points',{$points},{$now});");
			continue;
		}
		if ($kind === 'storage') {
			$key = (int)($reward['key'] ?? 0);
			$value = (int)($reward['value'] ?? 0);
			if ($key > 0) {
				mysql_insert("INSERT INTO `account_storage` (`account_id`,`key`,`value`) VALUES ({$accountId},{$key},{$value}) ON DUPLICATE KEY UPDATE `value`={$value};");
				mysql_insert("INSERT INTO `znote_starter_pack_orders` (`pack_tx_id`,`account_id`,`reward_type`,`storage_key`,`storage_value`,`created_at`) VALUES ({$txid},{$accountId},'storage',{$key},{$value},{$now});");
			}
			continue;
		}
		if ($kind === 'house') {
			$houseId = (int)($reward['house_id'] ?? 0);
			if ($houseId > 0 && $playerId > 0 && starter_packs_valid_character($accountId, $playerId) && function_exists('znote_table_exists') && znote_table_exists('houses')) {
				mysql_update("UPDATE `houses` SET `owner`={$playerId} WHERE `id`={$houseId} AND (`owner`=0 OR `owner` IS NULL) LIMIT 1;");
				mysql_insert("INSERT INTO `znote_starter_pack_orders` (`pack_tx_id`,`account_id`,`player_id`,`reward_type`,`itemid`,`created_at`) VALUES ({$txid},{$accountId},{$playerId},'house',{$houseId},{$now});");
			}
			continue;
		}
		$type = $kind === 'outfit' ? 5 : ($kind === 'mount' ? 6 : 1);
		$itemid = $kind === 'outfit' ? max(0, (int)($reward['male'] ?? $reward['itemid'] ?? 0)) : ($kind === 'mount' ? max(0, (int)($reward['mount'] ?? $reward['itemid'] ?? 0)) : max(0, (int)($reward['itemid'] ?? 0)));
		$count = $kind === 'outfit' ? max(0, (int)($reward['female'] ?? $reward['count'] ?? 0)) : ($kind === 'mount' ? 1 : max(0, (int)($reward['count'] ?? 0)));
		if ($itemid > 0 && $count > 0) {
			mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$accountId},{$type},{$itemid},{$count},{$now});");
			mysql_insert("INSERT INTO `znote_starter_pack_orders` (`pack_tx_id`,`account_id`,`reward_type`,`itemid`,`count`,`created_at`) VALUES ({$txid},{$accountId},'{$kind}',{$itemid},{$count},{$now});");
		}
	}
	mysql_update("UPDATE `znote_starter_pack_transactions` SET `delivered`=1,`delivered_at`={$now},`updated_at`={$now} WHERE `id`={$txid} LIMIT 1;");
}
function starter_packs_reward_text(array $reward): string {
	$label = trim((string)($reward['label'] ?? ''));
	if ($label !== '') {
		$qty = starter_packs_reward_quantity($reward);
		return $qty > 0 ? $qty . 'x ' . $label : $label;
	}
	$kind = starter_packs_reward_kind($reward);
	if ($kind === 'premium_days') return starter_packs_t('starter_packs.premium_days', '{n} Premium Days', array('n'=>(int)($reward['value'] ?? 0)));
	if ($kind === 'premium_points') return starter_packs_t('starter_packs.premium_points', '{n} Points', array('n'=>(int)($reward['value'] ?? 0)));
	if ($kind === 'outfit') return starter_packs_t('starter_packs.outfit', '{count}x Outfit', array('count'=>starter_packs_reward_quantity($reward)));
	if ($kind === 'mount') return starter_packs_t('starter_packs.mount', '{count}x Mount', array('count'=>starter_packs_reward_quantity($reward)));
	if ($kind === 'storage') return starter_packs_t('starter_packs.storage_label', 'Storage Key', array('key'=>(int)($reward['key'] ?? 0),'value'=>(int)($reward['value'] ?? 0)));
	if ($kind === 'house') return starter_packs_t('starter_packs.house', 'House {id}', array('id'=>(int)($reward['house_id'] ?? 0)));
	return starter_packs_t('starter_packs.reward_item', '{count}x Item', array('count'=>starter_packs_reward_quantity($reward),'kind'=>'item','itemid'=>(int)($reward['itemid'] ?? 0)));
}
function starter_packs_footer(): string {
	if (!starter_packs_enabled() || basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'buypoints.php' || empty($GLOBALS['session_user_id'])) return '';
	$providers = array();
	foreach (array('stripe'=>'Stripe','mercadopago'=>'Mercado Pago','paypal'=>'PayPal','pagseguro'=>'PagSeguro','paygol'=>'PayGol') as $key=>$label) if (starter_packs_provider_enabled($key)) $providers[$key] = $label;
	if (!$providers) return '';
	$cards = '';
	foreach (starter_packs_packs() as $i => $pack) {
		$rewards = '';
		foreach (starter_packs_pack_rewards($pack) as $reward) {
			$iconPos = starter_packs_css_position((string)($reward['icon_pos'] ?? '')) ?: '50% 50%';
			$iconFile = starter_packs_asset_image((string)($reward['icon_file'] ?? ''));
			$iconStyle = '--sp-icon-pos:' . $iconPos . ';' . ($iconFile !== '' ? '--sp-icon-url:url(' . $iconFile . ');--sp-icon-size:contain;' : '');
			$rewardImage = starter_packs_reward_image_url($reward);
			$visual = $rewardImage !== ''
				? '<img class="sp-reward-img" src="' . starter_packs_h($rewardImage) . '" alt="">'
				: '<span class="sp-icon" style="' . starter_packs_h($iconStyle) . '"></span>';
			$rewards .= '<li>' . $visual . '<span>' . starter_packs_h(starter_packs_reward_text($reward)) . '</span></li>';
		}
		$options = '';
		foreach ($providers as $key=>$label) $options .= '<option value="' . starter_packs_h($key) . '">' . starter_packs_h($label) . '</option>';
		$character = starter_packs_requires_character($pack) ? '<select name="player_id" class="sp-character" required><option value="">' . starter_packs_h(starter_packs_t('starter_packs.select_character', 'Select character')) . '</option>' . starter_packs_character_options((int)$GLOBALS['session_user_id']) . '</select>' : '';
		$image = trim((string)($pack['image'] ?? ''));
		$image = $image !== '' && !preg_match('/^https?:\/\//i', $image) ? starter_packs_asset_image($image) : $image;
		$imagePos = starter_packs_css_position((string)($pack['image_pos'] ?? '')) ?: '50% 0%';
		$imageSize = starter_packs_css_size((string)($pack['image_size'] ?? '')) ?: '330% auto';
		$media = $image !== '' ? '<div class="sp-media" style="background-image:url(' . starter_packs_h($image) . ');background-position:' . starter_packs_h($imagePos) . ';background-size:' . starter_packs_h($imageSize) . '"></div>' : '<div class="sp-media sp-media--empty"><i class="fa fa-gift"></i></div>';
		$style = '';
		foreach (array('accent'=>'--sp-pack-accent','card_bg'=>'--sp-pack-bg','border'=>'--sp-pack-border','title_color'=>'--sp-pack-title','price_color'=>'--sp-pack-price','button_bg'=>'--sp-pack-button','button_text'=>'--sp-pack-button-text') as $key=>$var) {
			$value = starter_packs_css_value((string)($pack[$key] ?? ''));
			if ($value !== '') $style .= $var . ':' . $value . ';';
		}
		ob_start(); if (class_exists('Token')) Token::create(); $token = ob_get_clean();
		$cards .= '<article class="sp-pack sp-pack-' . (int)$i . '"' . ($style !== '' ? ' style="' . starter_packs_h($style) . '"' : '') . '>' . $media . '<div class="sp-pack-body"><h3>' . starter_packs_h($pack['title'] ?? $pack['key']) . '</h3><p class="sp-sub">' . starter_packs_h($pack['subtitle'] ?? $pack['description'] ?? '') . '</p><strong class="sp-price">' . starter_packs_h(number_format((float)($pack['price'] ?? 0), 2)) . ' ' . starter_packs_h(starter_packs_currency_for()) . '</strong><ul>' . $rewards . '</ul><form action="' . starter_packs_h(znote_plugin_url('starter_packs', 'checkout')) . '" method="post">' . $token . '<input type="hidden" name="pack" value="' . starter_packs_h($pack['key'] ?? '') . '"><select name="provider">' . $options . '</select>' . $character . '<button type="submit"><i class="fa fa-shopping-cart"></i> ' . starter_packs_h(starter_packs_t('starter_packs.get_pack', 'Get Pack')) . '</button></form></div></article>';
	}
	$css = '.sp-box{--znx-plugin-sprite:url("' . starter_packs_h(starter_packs_asset_image('assets.png')) . '");--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));display:block;clear:both;width:100%;max-width:100%;margin:0 0 22px;padding:16px;border:1px solid var(--znx-plugin-border);border-radius:10px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);overflow:hidden}.sp-box *{box-sizing:border-box}.sp-kicker{display:flex;flex-wrap:wrap;justify-content:center;gap:26px;margin:0 0 16px;opacity:.86;text-transform:uppercase;letter-spacing:.08em;font-size:12px}.sp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(190px,100%),1fr));gap:14px;align-items:stretch}.sp-pack{position:relative;min-width:0;border:1px solid var(--sp-pack-border,var(--znx-plugin-border));border-radius:10px;background:var(--sp-pack-bg,var(--znx-plugin-surface));color:var(--znx-plugin-text);box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--sp-pack-accent,currentColor) 30%,transparent);overflow:hidden}.sp-pack:before{content:"";position:absolute;inset:0;border-top:3px solid var(--sp-pack-accent,currentColor);pointer-events:none}.sp-media{height:150px;background-repeat:no-repeat;border-bottom:1px solid var(--sp-pack-border,var(--znx-plugin-border));display:grid;place-items:center;color:var(--sp-pack-accent,currentColor);font-size:42px;background-color:rgba(0,0,0,.18)}.sp-pack-body{padding:14px}.sp-pack h3{margin:0;text-align:center;color:var(--sp-pack-title,var(--znx-plugin-text));font-size:20px;text-transform:uppercase;letter-spacing:.05em}.sp-sub{text-align:center;margin:2px 0 10px;opacity:.75;text-transform:uppercase;font-size:11px;letter-spacing:.08em}.sp-price{display:block;text-align:center;margin:8px 0 12px;padding:8px;border-top:1px solid var(--sp-pack-border,var(--znx-plugin-border));border-bottom:1px solid var(--sp-pack-border,var(--znx-plugin-border));color:var(--sp-pack-price,var(--sp-pack-accent,currentColor));font-size:24px}.sp-pack ul{margin:0 0 14px;padding:0;list-style:none}.sp-pack li{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid color-mix(in srgb,var(--sp-pack-border,var(--znx-plugin-border)) 55%,transparent);overflow-wrap:anywhere}.sp-icon,.sp-reward-img{width:42px;height:42px;object-fit:contain;object-position:center;flex:0 0 auto;filter:drop-shadow(0 2px 4px rgba(0,0,0,.45));image-rendering:auto}.sp-icon{background-image:var(--sp-icon-url,var(--znx-plugin-sprite));background-size:var(--sp-icon-size,560% auto);background-position:var(--sp-icon-pos,50% 50%);background-repeat:no-repeat}.sp-pack form{display:flex;flex-direction:column;gap:8px}.sp-pack select,.sp-pack button{width:100%;min-height:36px;border:1px solid var(--sp-pack-border,var(--znx-plugin-border));border-radius:999px;background:var(--sp-input-bg,var(--znx-plugin-surface));color:var(--znx-plugin-text);padding:7px 10px}.sp-pack button{background:var(--sp-pack-button,var(--sp-button-bg,var(--znx-plugin-surface)));color:var(--sp-pack-button-text,var(--sp-button-text,var(--znx-plugin-text)));font-weight:800;text-transform:uppercase;letter-spacing:.06em;cursor:pointer}@media(max-width:680px){.sp-box{padding:10px}.sp-media{height:120px}.sp-price{font-size:20px}}';
	$html = '<section id="starterPacksBox" class="sp-box"' . starter_packs_style_attr(array('box_bg'=>'--znx-plugin-surface','text'=>'--znx-plugin-text','border'=>'--znx-plugin-border','input_bg'=>'--sp-input-bg','button_bg'=>'--sp-button-bg','button_text'=>'--sp-button-text')) . '><div class="sp-kicker"><span><i class="fa fa-heart"></i> ' . starter_packs_h(starter_packs_t('starter_packs.kicker_support', 'Support the server')) . '</span><span><i class="fa fa-gift"></i> ' . starter_packs_h(starter_packs_t('starter_packs.kicker_items', 'Get exclusive items')) . '</span><span><i class="fa fa-crown"></i> ' . starter_packs_h(starter_packs_t('starter_packs.kicker_future', 'A stronger tomorrow')) . '</span></div><div class="sp-grid">' . $cards . '</div></section>';
	return '<script>(function(){if(document.getElementById("starterPacksBox"))return;var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);function a(){var t=document.getElementById("buypointsTable")||document.querySelector("table");if(t)return t;var f=document.querySelector("form");if(!f)return document.querySelector("main,#content,.content")||document.body;var g=f.closest(".payment-grid,.points-grid,.buypoints-grid,.buy-points-grid,.donation-grid,.price-grid,.pricing-grid,.cards,.cards-grid,.grid,[class*=grid],[class*=cards],[class*=packages],[class*=pricing]");if(g&&g.querySelectorAll("form").length>1)return g;var n=f.parentElement;while(n&&n.parentElement&&n!==document.body){if(n.parentElement.querySelectorAll("form").length>1)return n.parentElement;n=n.parentElement;}return f;}var target=a();if(!target||!target.parentNode)return;var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';target.parentNode.insertBefore(w.firstChild,target);}());</script>';
}
}
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'starter_packs_footer');
	znote_hook_register('payment.resolve', 'starter_packs_payment_resolve');
	znote_hook_register('payment.completed', 'starter_packs_mark_paid_and_deliver');
}
