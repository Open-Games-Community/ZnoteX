<?php
protect_page();

if (!starter_packs_enabled()) {
	echo '<p>' . starter_packs_h(starter_packs_t('starter_packs.disabled', 'Starter packs are disabled.')) . '</p>';
	return;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || (class_exists('Token') && !Token::isValid($_POST['token'] ?? null))) {
	http_response_code(400);
	echo '<h1>Invalid request</h1><p>Reload the buy points page and try again.</p>';
	return;
}

$provider = strtolower(trim((string)($_POST['provider'] ?? '')));
$packKey = (string)($_POST['pack'] ?? '');
$playerId = (int)($_POST['player_id'] ?? 0);
$accountId = (int)$GLOBALS['session_user_id'];
$result = starter_packs_begin_checkout($provider, $accountId, $packKey, $playerId);

if (empty($result['ok'])) {
	echo '<h1>' . starter_packs_h(starter_packs_t('starter_packs.title', 'Starter Packs')) . '</h1>';
	echo '<p>' . starter_packs_h($result['message'] ?? 'Payment unavailable.') . '</p>';
	return;
}

if (!empty($result['redirect'])) {
	header('Location: ' . $result['redirect']);
	exit;
}

$ref = (string)($result['reference'] ?? '');
$pack = $result['pack'] ?? starter_packs_pack($packKey);
$price = number_format((float)($pack['price'] ?? 0), 2, '.', '');
$currency = starter_packs_currency_for($provider);

if ($provider === 'paypal') {
	$paypal = $GLOBALS['config']['paypal'];
	?>
	<h1><?= starter_packs_h(starter_packs_t('starter_packs.title', 'Starter Packs')) ?></h1>
	<p><?= starter_packs_h(starter_packs_t('starter_packs.redirecting', 'Redirecting to payment...')) ?></p>
	<form id="starterPackPaymentForm" action="https://www.paypal.com/cgi-bin/webscr" method="POST">
		<input type="hidden" name="cmd" value="_xclick">
		<input type="hidden" name="business" value="<?= starter_packs_h($paypal['email'] ?? '') ?>">
		<input type="hidden" name="item_name" value="<?= starter_packs_h(($pack['title'] ?? 'Starter Pack') . ' on ' . ($GLOBALS['config']['site_title'] ?? 'ZnoteX')) ?>">
		<input type="hidden" name="item_number" value="starter_pack">
		<input type="hidden" name="amount" value="<?= starter_packs_h($price) ?>">
		<input type="hidden" name="no_shipping" value="1">
		<input type="hidden" name="no_note" value="1">
		<input type="hidden" name="currency_code" value="<?= starter_packs_h($currency) ?>">
		<input type="hidden" name="lc" value="GB">
		<input type="hidden" name="bn" value="PP-BuyNowBF">
		<input type="hidden" name="return" value="<?= starter_packs_h($paypal['success'] ?? '') ?>">
		<input type="hidden" name="cancel_return" value="<?= starter_packs_h($paypal['failed'] ?? '') ?>">
		<input type="hidden" name="rm" value="2">
		<input type="hidden" name="notify_url" value="<?= starter_packs_h($paypal['ipn'] ?? '') ?>">
		<input type="hidden" name="custom" value="<?= starter_packs_h($ref) ?>">
		<input type="submit" value="<?= starter_packs_h(starter_packs_t('starter_packs.purchase', 'Purchase')) ?>">
	</form>
	<script>document.getElementById('starterPackPaymentForm').submit();</script>
	<?php
	return;
}

if ($provider === 'pagseguro') {
	$pagseguro = $GLOBALS['config']['pagseguro'];
	?>
	<h1><?= starter_packs_h(starter_packs_t('starter_packs.title', 'Starter Packs')) ?></h1>
	<p><?= starter_packs_h(starter_packs_t('starter_packs.redirecting', 'Redirecting to payment...')) ?></p>
	<form id="starterPackPaymentForm" target="pagseguro" action="https://<?= starter_packs_h($pagseguro['urls']['www'] ?? 'pagseguro.uol.com.br') ?>/checkout/checkout.jhtml" method="post">
		<input type="hidden" name="email_cobranca" value="<?= starter_packs_h($pagseguro['email'] ?? '') ?>">
		<input type="hidden" name="tipo" value="CP">
		<input type="hidden" name="moeda" value="<?= starter_packs_h($currency) ?>">
		<input type="hidden" name="ref_transacao" value="<?= starter_packs_h($ref) ?>">
		<input type="hidden" name="item_id_1" value="starter_pack">
		<input type="hidden" name="item_descr_1" value="<?= starter_packs_h($pack['title'] ?? 'Starter Pack') ?>">
		<input type="hidden" name="item_quant_1" value="1">
		<input type="hidden" name="item_peso_1" value="0">
		<input type="hidden" name="item_valor_1" value="<?= starter_packs_h($price) ?>">
		<input type="submit" value="<?= starter_packs_h(starter_packs_t('starter_packs.purchase', 'Purchase')) ?>">
	</form>
	<script>document.getElementById('starterPackPaymentForm').submit();</script>
	<?php
	return;
}

if ($provider === 'paygol') {
	$paygol = $GLOBALS['config']['paygol'];
	?>
	<h1><?= starter_packs_h(starter_packs_t('starter_packs.title', 'Starter Packs')) ?></h1>
	<p><?= starter_packs_h(starter_packs_t('starter_packs.redirecting', 'Redirecting to payment...')) ?></p>
	<form id="starterPackPaymentForm" method="post" action="http://www.paygol.com/micropayment/paynow">
		<input type="hidden" name="pg_serviceid" value="<?= starter_packs_h($paygol['serviceID'] ?? '') ?>">
		<input type="hidden" name="pg_currency" value="<?= starter_packs_h($currency) ?>">
		<input type="hidden" name="pg_name" value="<?= starter_packs_h($pack['title'] ?? ($paygol['name'] ?? 'Starter Pack')) ?>">
		<input type="hidden" name="pg_custom" value="<?= starter_packs_h($ref) ?>">
		<input type="hidden" name="pg_price" value="<?= starter_packs_h($price) ?>">
		<input type="hidden" name="pg_return_url" value="<?= starter_packs_h($paygol['returnURL'] ?? '') ?>">
		<input type="hidden" name="pg_cancel_url" value="<?= starter_packs_h($paygol['cancelURL'] ?? '') ?>">
		<input type="submit" value="<?= starter_packs_h(starter_packs_t('starter_packs.purchase', 'Purchase')) ?>">
	</form>
	<script>document.getElementById('starterPackPaymentForm').submit();</script>
	<?php
	return;
}

echo '<p>Payment provider is unavailable.</p>';
