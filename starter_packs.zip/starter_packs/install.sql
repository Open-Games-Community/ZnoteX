CREATE TABLE IF NOT EXISTS `znote_starter_pack_transactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `reference` varchar(128) NOT NULL,
  `provider` varchar(32) NOT NULL,
  `provider_reference` varchar(128) DEFAULT NULL,
  `account_id` int NOT NULL,
  `player_id` int NOT NULL DEFAULT '0',
  `pack_key` varchar(64) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `currency` varchar(8) NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `delivered` tinyint NOT NULL DEFAULT '0',
  `created_at` int NOT NULL,
  `updated_at` int NOT NULL,
  `delivered_at` int DEFAULT NULL,
  `payload` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `provider_reference` (`provider`, `provider_reference`),
  KEY `account_status` (`account_id`, `status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_starter_pack_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pack_tx_id` bigint NOT NULL,
  `account_id` int NOT NULL,
  `player_id` int NOT NULL DEFAULT '0',
  `reward_type` varchar(24) NOT NULL,
  `itemid` int NOT NULL DEFAULT '0',
  `count` int NOT NULL DEFAULT '0',
  `storage_key` int NOT NULL DEFAULT '0',
  `storage_value` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pack_tx_id` (`pack_tx_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `account_storage` (
  `account_id` int NOT NULL,
  `key` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`account_id`, `key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
