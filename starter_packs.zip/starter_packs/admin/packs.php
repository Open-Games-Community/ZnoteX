<?php
/**
 * Title: Starter Packs
 * Icon: fa-gift
 * Group: Installed Plugins
 * Order: 70
 * Description: Configure up to 5 starter packs with up to 10 reward lines each.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

function starter_packs_admin_color($value): string {
	$value = trim((string)$value);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value)) return $value;
	return preg_match('/^linear-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $value) ? $value : '';
}

function starter_packs_admin_position($value): string {
	$value = trim((string)$value);
	return preg_match('/^(-?[0-9.]+%?|left|center|right)\s+(-?[0-9.]+%?|top|center|bottom)$/', $value) ? $value : '';
}

function starter_packs_admin_size($value): string {
	$value = trim((string)$value);
	return preg_match('/^(auto|cover|contain|[0-9.]+%(\s+(auto|[0-9.]+%))?)$/', $value) ? $value : '';
}

function starter_packs_admin_key(string $value, int $fallback): string {
	$key = preg_replace('/[^a-z0-9_]/', '', strtolower($value));
	return $key !== '' ? $key : 'pack_' . $fallback;
}

function starter_packs_admin_rewards(int $packIndex): array {
	$rewards = array();
	$kinds = $_POST['reward_kind'][$packIndex] ?? array();
	for ($i = 0; $i < 10; $i++) {
		$kind = (string)($kinds[$i] ?? '');
		if (!in_array($kind, array('premium_days', 'premium_points', 'item', 'outfit', 'mount', 'storage', 'house'), true)) continue;
		$reward = array(
			'kind' => $kind,
			'label' => trim((string)($_POST['reward_label'][$packIndex][$i] ?? '')),
			'icon_file' => preg_replace('/[^a-zA-Z0-9_.-]/', '', (string)($_POST['reward_icon_file'][$packIndex][$i] ?? '')),
			'icon_pos' => starter_packs_admin_position($_POST['reward_icon_pos'][$packIndex][$i] ?? ''),
		);
		if ($kind === 'premium_days' || $kind === 'premium_points') {
			$value = max(0, (int)($_POST['reward_value'][$packIndex][$i] ?? 0));
			if ($value > 0) $rewards[] = $reward + array('value' => $value);
			continue;
		}
		if ($kind === 'storage') {
			$key = (int)($_POST['reward_storage_key'][$packIndex][$i] ?? 0);
			$value = (int)($_POST['reward_storage_value'][$packIndex][$i] ?? 0);
			if ($key > 0) $rewards[] = $reward + array('key' => $key, 'value' => $value);
			continue;
		}
		if ($kind === 'outfit') {
			$male = max(0, (int)($_POST['reward_male'][$packIndex][$i] ?? 0));
			$female = max(0, (int)($_POST['reward_female'][$packIndex][$i] ?? 0));
			$addons = max(0, min(3, (int)($_POST['reward_addons'][$packIndex][$i] ?? 3)));
			if ($male > 0 && $female > 0) $rewards[] = $reward + array('male' => $male, 'female' => $female, 'addons' => $addons);
			continue;
		}
		if ($kind === 'mount') {
			$mount = max(0, (int)($_POST['reward_mount'][$packIndex][$i] ?? 0));
			if ($mount > 0) $rewards[] = $reward + array('mount' => $mount);
			continue;
		}
		if ($kind === 'house') {
			$houseId = max(0, (int)($_POST['reward_house'][$packIndex][$i] ?? 0));
			if ($houseId > 0) $rewards[] = $reward + array('house_id' => $houseId);
			continue;
		}
		$itemid = max(0, (int)($_POST['reward_itemid'][$packIndex][$i] ?? 0));
		$count = max(0, (int)($_POST['reward_count'][$packIndex][$i] ?? 0));
		if ($itemid > 0 && $count > 0) $rewards[] = $reward + array('itemid' => $itemid, 'count' => $count);
	}
	return array_slice($rewards, 0, 10);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	setting_set('starter_packs:enabled', !empty($_POST['enabled']) ? '1' : '0');
	$packs = array();
	for ($i = 0; $i < 5; $i++) {
		$title = trim((string)($_POST['title'][$i] ?? ''));
		$price = max(0, (float)($_POST['price'][$i] ?? 0));
		if ($title === '' || $price <= 0) continue;
		$packs[] = array(
			'key' => starter_packs_admin_key((string)($_POST['pack_key'][$i] ?? ''), $i + 1),
			'title' => $title,
			'subtitle' => trim((string)($_POST['subtitle'][$i] ?? '')),
			'price' => $price,
			'image' => trim((string)($_POST['image'][$i] ?? 'assets.png')),
			'image_pos' => starter_packs_admin_position($_POST['image_pos'][$i] ?? ''),
			'image_size' => starter_packs_admin_size($_POST['image_size'][$i] ?? ''),
			'accent' => starter_packs_admin_color($_POST['accent'][$i] ?? ''),
			'card_bg' => starter_packs_admin_color($_POST['card_bg'][$i] ?? ''),
			'border' => starter_packs_admin_color($_POST['border'][$i] ?? ''),
			'title_color' => starter_packs_admin_color($_POST['title_color'][$i] ?? ''),
			'price_color' => starter_packs_admin_color($_POST['price_color'][$i] ?? ''),
			'button_bg' => starter_packs_admin_color($_POST['pack_button_bg'][$i] ?? ''),
			'button_text' => starter_packs_admin_color($_POST['pack_button_text'][$i] ?? ''),
			'rewards' => starter_packs_admin_rewards($i),
		);
	}
	setting_set('starter_packs:packs', json_encode(array_slice($packs, 0, 5), JSON_UNESCAPED_SLASHES));
	foreach (array('box_bg','text','border','input_bg','button_bg','button_text') as $key) {
		setting_set('starter_packs:style_' . $key, starter_packs_admin_color($_POST['style_' . $key] ?? ''));
	}
	acp_flash_success('Starter packs saved.');
	acp_redirect('starter_packs__packs');
}

$packs = starter_packs_packs();
while (count($packs) < 5) $packs[] = array('key'=>'','title'=>'','subtitle'=>'','price'=>0,'image'=>'pack_' . (count($packs) + 1) . '.png','image_pos'=>'center center','image_size'=>'contain','rewards'=>array());
$currency = starter_packs_currency_for();
$styleKeys = array('box_bg'=>'Box background','text'=>'Text color','border'=>'Border color','input_bg'=>'Input background','button_bg'=>'Default button background','button_text'=>'Default button text');
$rewardKinds = array('premium_days'=>'Premium Days','premium_points'=>'Premium Points','item'=>'Item','outfit'=>'Outfit male/female','mount'=>'Mount ID','storage'=>'Storage Key','house'=>'House ID');
?>
<?php acp_card_open('Starter Packs', 'Configure up to 5 packs. Each pack can contain up to 10 reward lines. Prices display in config.php currency: ' . h($currency)); ?>
<form method="post" id="starterPacksAdmin">
	<?= acp_csrf_field() ?>
	<div class="acp-field"><label><input type="checkbox" name="enabled" value="1" <?= setting('starter_packs:enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
	<h3>Global style</h3>
	<p class="acp-muted">Leave empty to inherit the theme, with default theme fallback. Sprite default: assets/img/assets.png.</p>
	<div class="acp-grid acp-grid--2">
		<?php foreach ($styleKeys as $key => $label): ?>
			<div class="acp-field"><label class="acp-label"><?= h($label) ?></label><input class="acp-input" name="style_<?= h($key) ?>" value="<?= h(setting('starter_packs:style_' . $key, '')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)"></div>
		<?php endforeach; ?>
	</div>
	<h3>Packs</h3>
	<div id="starterPackList">
		<?php foreach ($packs as $i => $pack): $rewards = starter_packs_pack_rewards($pack); while (count($rewards) < 10) $rewards[] = array('kind'=>'','label'=>'','icon_file'=>'','icon_pos'=>'','value'=>0,'itemid'=>0,'count'=>0,'male'=>0,'female'=>0,'addons'=>3,'mount'=>0,'key'=>0,'house_id'=>0); ?>
			<section class="acp-card starter-pack-admin-card" data-pack-index="<?= $i ?>" <?= ($i > 0 && trim((string)$pack['title']) === '') ? 'hidden' : '' ?>>
				<h4>Pack <?= $i + 1 ?></h4>
				<div class="acp-grid acp-grid--2">
					<div class="acp-field"><label class="acp-label">Internal key</label><input class="acp-input" name="pack_key[<?= $i ?>]" value="<?= h($pack['key'] ?? '') ?>" placeholder="starter"></div>
					<div class="acp-field"><label class="acp-label">Title</label><input class="acp-input" name="title[<?= $i ?>]" value="<?= h($pack['title'] ?? '') ?>" placeholder="Starter Pack"></div>
					<div class="acp-field"><label class="acp-label">Subtitle</label><input class="acp-input" name="subtitle[<?= $i ?>]" value="<?= h($pack['subtitle'] ?? '') ?>" placeholder="A solid beginning"></div>
					<div class="acp-field"><label class="acp-label">Price (<?= h($currency) ?>)</label><input class="acp-input" type="number" step="0.01" min="0" name="price[<?= $i ?>]" value="<?= h((string)($pack['price'] ?? 0)) ?>"></div>
					<div class="acp-field"><label class="acp-label">Header image file</label><input class="acp-input" name="image[<?= $i ?>]" value="<?= h($pack['image'] ?? ('pack_' . ($i + 1) . '.png')) ?>" placeholder="pack_1.png or https://..."></div>
					<div class="acp-field"><label class="acp-label">Image position</label><input class="acp-input" name="image_pos[<?= $i ?>]" value="<?= h($pack['image_pos'] ?? 'center center') ?>" placeholder="center center"></div>
					<div class="acp-field"><label class="acp-label">Image size</label><input class="acp-input" name="image_size[<?= $i ?>]" value="<?= h($pack['image_size'] ?? 'contain') ?>" placeholder="contain"></div>
					<div class="acp-field"><label class="acp-label">Accent</label><input class="acp-input" name="accent[<?= $i ?>]" value="<?= h($pack['accent'] ?? '') ?>" placeholder="#2fdd72"></div>
					<div class="acp-field"><label class="acp-label">Card background</label><input class="acp-input" name="card_bg[<?= $i ?>]" value="<?= h($pack['card_bg'] ?? '') ?>" placeholder="linear-gradient(...)"></div>
					<div class="acp-field"><label class="acp-label">Border</label><input class="acp-input" name="border[<?= $i ?>]" value="<?= h($pack['border'] ?? '') ?>"></div>
					<div class="acp-field"><label class="acp-label">Title color</label><input class="acp-input" name="title_color[<?= $i ?>]" value="<?= h($pack['title_color'] ?? '') ?>"></div>
					<div class="acp-field"><label class="acp-label">Price color</label><input class="acp-input" name="price_color[<?= $i ?>]" value="<?= h($pack['price_color'] ?? '') ?>"></div>
					<div class="acp-field"><label class="acp-label">Button background</label><input class="acp-input" name="pack_button_bg[<?= $i ?>]" value="<?= h($pack['button_bg'] ?? '') ?>"></div>
					<div class="acp-field"><label class="acp-label">Button text</label><input class="acp-input" name="pack_button_text[<?= $i ?>]" value="<?= h($pack['button_text'] ?? '') ?>"></div>
				</div>
				<div class="acp-table-wrap">
					<table class="acp-table starter-reward-table">
						<thead><tr><th>Type</th><th>Icon file</th><th>Icon pos</th><th>Value</th><th>Item ID</th><th>Count</th><th>Male</th><th>Female</th><th>Addons</th><th>Mount</th><th>Storage key</th><th>Storage value</th><th>Display text</th><th>House ID</th><th></th></tr></thead>
						<tbody>
						<?php foreach ($rewards as $r => $reward): $kind = starter_packs_reward_kind($reward); if (($reward['kind'] ?? '') === '') $kind = ''; ?>
							<tr <?= ($r > 0 && $kind === '') ? 'hidden' : '' ?>>
								<td><select class="acp-input" name="reward_kind[<?= $i ?>][]"><option value="">Empty</option><?php foreach ($rewardKinds as $value => $label): ?><option value="<?= h($value) ?>" <?= $kind === $value ? 'selected' : '' ?>><?= h($label) ?></option><?php endforeach; ?></select></td>
								<td><input class="acp-input" name="reward_icon_file[<?= $i ?>][]" value="<?= h($reward['icon_file'] ?? '') ?>" placeholder="premium.png"></td>
								<td><input class="acp-input" name="reward_icon_pos[<?= $i ?>][]" value="<?= h($reward['icon_pos'] ?? '') ?>" placeholder="60% 43%"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_value[<?= $i ?>][]" value="<?= (int)($reward['value'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_itemid[<?= $i ?>][]" value="<?= (int)($reward['itemid'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_count[<?= $i ?>][]" value="<?= (int)($reward['count'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_male[<?= $i ?>][]" value="<?= (int)($reward['male'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_female[<?= $i ?>][]" value="<?= (int)($reward['female'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" min="0" max="3" name="reward_addons[<?= $i ?>][]" value="<?= (int)($reward['addons'] ?? 3) ?>"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_mount[<?= $i ?>][]" value="<?= (int)($reward['mount'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" name="reward_storage_key[<?= $i ?>][]" value="<?= (int)($reward['key'] ?? 0) ?>"></td>
								<td><input class="acp-input" type="number" name="reward_storage_value[<?= $i ?>][]" value="<?= (int)($reward['value'] ?? 0) ?>"></td>
								<td><input class="acp-input" name="reward_label[<?= $i ?>][]" value="<?= h($reward['label'] ?? '') ?>" placeholder="Access Isle"></td>
								<td><input class="acp-input" type="number" min="0" name="reward_house[<?= $i ?>][]" value="<?= (int)($reward['house_id'] ?? 0) ?>"></td>
								<td><button class="acp-btn acp-btn--red acp-btn--sm" type="button" data-remove-reward>-</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<div class="acp-actions"><button class="acp-btn acp-btn--blue acp-btn--sm" type="button" data-add-reward>+ Add reward</button><button class="acp-btn acp-btn--red acp-btn--sm" type="button" data-remove-pack>- Remove pack</button></div>
			</section>
		<?php endforeach; ?>
	</div>
	<div class="acp-actions"><button class="acp-btn acp-btn--blue" type="button" id="starterPackAdd">+ Add pack</button><button class="acp-btn acp-btn--green" type="submit">Save</button></div>
</form>
<script>
(function(){
	var form = document.getElementById('starterPacksAdmin');
	if (!form) return;
	document.getElementById('starterPackAdd').addEventListener('click', function(){
		var hidden = form.querySelector('.starter-pack-admin-card[hidden]');
		if (hidden) hidden.hidden = false;
	});
	form.addEventListener('click', function(e){
		var addReward = e.target.closest('[data-add-reward]');
		if (addReward) {
			var card = addReward.closest('.starter-pack-admin-card');
			var row = card && card.querySelector('.starter-reward-table tbody tr[hidden]');
			if (row) row.hidden = false;
			return;
		}
		var removeReward = e.target.closest('[data-remove-reward]');
		if (removeReward) {
			var row = removeReward.closest('tr');
			if (!row) return;
			row.querySelectorAll('input').forEach(function(input){ input.value = input.type === 'number' ? 0 : ''; });
			var select = row.querySelector('select');
			if (select) select.value = '';
			row.hidden = true;
			return;
		}
		var removePack = e.target.closest('[data-remove-pack]');
		if (removePack) {
			var card = removePack.closest('.starter-pack-admin-card');
			if (!card) return;
			card.querySelectorAll('input').forEach(function(input){ input.value = input.type === 'number' ? 0 : ''; });
			card.querySelectorAll('select').forEach(function(select){ select.value = ''; });
			card.hidden = true;
		}
	});
})();
</script>
<?php acp_card_close(); ?>
