<?php

return array(
	'starter_packs.title' => 'Starter Packs',
	'starter_packs.purchase' => 'Purchase',
	'starter_packs.invalid' => 'Invalid starter pack.',
	'starter_packs.provider_disabled' => 'Payment provider is disabled.',
	'starter_packs.prepared' => 'Starter pack checkout prepared.',
	'starter_packs.premium_days' => '{n} premium days',
	'starter_packs.premium_points' => '{n} Points',
	'starter_packs.outfit' => '{count}x Outfit',
	'starter_packs.mount' => '{count}x Mount',
	'starter_packs.house' => 'House {id}',
	'starter_packs.storage_label' => 'Storage Key',
	'starter_packs.select_character' => 'Select character',
	'starter_packs.character_required' => 'Select one of your characters for this pack.',
	'starter_packs.redirecting' => 'Redirecting to payment...',
	'starter_packs.get_pack' => 'Get Pack',
	'starter_packs.kicker_support' => 'Support the server',
	'starter_packs.kicker_items' => 'Get exclusive items',
	'starter_packs.kicker_future' => 'A stronger tomorrow',
	'starter_packs.storage' => 'Storage {key} = {value}',
	'starter_packs.reward_item' => '{count}x Item',
);
