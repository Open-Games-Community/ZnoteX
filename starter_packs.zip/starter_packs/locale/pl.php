<?php

return array(
	'starter_packs.title' => 'Pakiety startowe',
	'starter_packs.purchase' => 'Kup',
	'starter_packs.invalid' => 'Nieprawidlowy pakiet startowy.',
	'starter_packs.provider_disabled' => 'Operator platnosci jest wylaczony.',
	'starter_packs.prepared' => 'Platnosc za pakiet startowy przygotowana.',
	'starter_packs.premium_days' => '{n} dni premium',
	'starter_packs.premium_points' => '{n} punktow',
	'starter_packs.outfit' => '{count}x Outfit',
	'starter_packs.mount' => '{count}x Mount',
	'starter_packs.house' => 'Dom {id}',
	'starter_packs.storage_label' => 'Storage Key',
	'starter_packs.select_character' => 'Wybierz postac',
	'starter_packs.character_required' => 'Wybierz jedna ze swoich postaci dla tego pakietu.',
	'starter_packs.redirecting' => 'Przekierowanie do platnosci...',
	'starter_packs.get_pack' => 'Odbierz pakiet',
	'starter_packs.kicker_support' => 'Wesprzyj serwer',
	'starter_packs.kicker_items' => 'Zdobadz ekskluzywne itemy',
	'starter_packs.kicker_future' => 'Silniejsze jutro',
	'starter_packs.storage' => 'Storage {key} = {value}',
	'starter_packs.reward_item' => '{count}x Item',
);
