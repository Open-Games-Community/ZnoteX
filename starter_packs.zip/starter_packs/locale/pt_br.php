<?php

return array(
	'starter_packs.title' => 'Pacotes iniciais',
	'starter_packs.purchase' => 'Comprar',
	'starter_packs.invalid' => 'Pacote inicial invalido.',
	'starter_packs.provider_disabled' => 'Provedor de pagamento desativado.',
	'starter_packs.prepared' => 'Pagamento do pacote inicial preparado.',
	'starter_packs.premium_days' => '{n} dias premium',
	'starter_packs.premium_points' => '{n} pontos',
	'starter_packs.outfit' => '{count}x Outfit',
	'starter_packs.mount' => '{count}x Montaria',
	'starter_packs.house' => 'Casa {id}',
	'starter_packs.storage_label' => 'Storage Key',
	'starter_packs.select_character' => 'Selecione personagem',
	'starter_packs.character_required' => 'Selecione um dos seus personagens para este pacote.',
	'starter_packs.redirecting' => 'Redirecionando para pagamento...',
	'starter_packs.get_pack' => 'Obter pacote',
	'starter_packs.kicker_support' => 'Apoie o servidor',
	'starter_packs.kicker_items' => 'Receba itens exclusivos',
	'starter_packs.kicker_future' => 'Um futuro mais forte',
	'starter_packs.storage' => 'Storage {key} = {value}',
	'starter_packs.reward_item' => '{count}x Item',
);
