<?php

return array(
	'starter_packs.title' => 'Starter-Pakete',
	'starter_packs.purchase' => 'Kaufen',
	'starter_packs.invalid' => 'Ungultiges Starter-Paket.',
	'starter_packs.provider_disabled' => 'Zahlungsanbieter ist deaktiviert.',
	'starter_packs.prepared' => 'Starter-Paket Zahlung vorbereitet.',
	'starter_packs.premium_days' => '{n} Premium-Tage',
	'starter_packs.premium_points' => '{n} Punkte',
	'starter_packs.outfit' => '{count}x Outfit',
	'starter_packs.mount' => '{count}x Mount',
	'starter_packs.house' => 'Haus {id}',
	'starter_packs.storage_label' => 'Storage Key',
	'starter_packs.select_character' => 'Charakter auswahlen',
	'starter_packs.character_required' => 'Wahle einen deiner Charaktere fur dieses Paket.',
	'starter_packs.redirecting' => 'Weiterleitung zur Zahlung...',
	'starter_packs.get_pack' => 'Paket holen',
	'starter_packs.kicker_support' => 'Server unterstutzen',
	'starter_packs.kicker_items' => 'Exklusive Items erhalten',
	'starter_packs.kicker_future' => 'Eine starkere Zukunft',
	'starter_packs.storage' => 'Storage {key} = {value}',
	'starter_packs.reward_item' => '{count}x Item',
);
