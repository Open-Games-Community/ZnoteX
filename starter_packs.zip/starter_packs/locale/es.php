<?php

return array(
	'starter_packs.title' => 'Packs iniciales',
	'starter_packs.purchase' => 'Comprar',
	'starter_packs.invalid' => 'Pack inicial invalido.',
	'starter_packs.provider_disabled' => 'Proveedor de pago desactivado.',
	'starter_packs.prepared' => 'Pago del pack inicial preparado.',
	'starter_packs.premium_days' => '{n} dias premium',
	'starter_packs.premium_points' => '{n} puntos',
	'starter_packs.outfit' => '{count}x Outfit',
	'starter_packs.mount' => '{count}x Montura',
	'starter_packs.house' => 'Casa {id}',
	'starter_packs.storage_label' => 'Storage Key',
	'starter_packs.select_character' => 'Selecciona personaje',
	'starter_packs.character_required' => 'Selecciona uno de tus personajes para este pack.',
	'starter_packs.redirecting' => 'Redirigiendo al pago...',
	'starter_packs.get_pack' => 'Obtener pack',
	'starter_packs.kicker_support' => 'Apoya el servidor',
	'starter_packs.kicker_items' => 'Consigue items exclusivos',
	'starter_packs.kicker_future' => 'Un futuro mas fuerte',
	'starter_packs.storage' => 'Storage {key} = {value}',
	'starter_packs.reward_item' => '{count}x Item',
);
