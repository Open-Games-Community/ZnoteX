(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var glow = document.querySelector('.cursor-glow');
  var embersHost = document.querySelector('.embers');
  var glowSize = 160;

  function onReady(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  onReady(function () {
    document.documentElement.classList.add('theme-ready');

    if (!reduceMotion && glow) {
      var half = glowSize / 2;
      var gx = window.innerWidth / 2;
      var gy = window.innerHeight / 3;
      var tx = gx;
      var ty = gy;
      var ticking = false;

      window.addEventListener('pointermove', function (e) {
        tx = e.clientX;
        ty = e.clientY;
        if (!ticking) {
          ticking = true;
          requestAnimationFrame(function () {
            gx += (tx - gx) * 0.12;
            gy += (ty - gy) * 0.12;
            glow.style.transform = 'translate(' + (gx - half) + 'px,' + (gy - half) + 'px)';
            ticking = false;
          });
        }
      }, { passive: true });
    }

    if (!reduceMotion && embersHost) {
      var count = window.innerWidth < 900 ? 8 : 14;
      for (var i = 0; i < count; i++) {
        var ember = document.createElement('span');
        ember.className = 'ember';
        ember.style.left = (Math.random() * 100) + '%';
        ember.style.animationDelay = (Math.random() * 12) + 's';
        ember.style.animationDuration = (12 + Math.random() * 10) + 's';
        ember.style.setProperty('--sway', ((Math.random() * 28) - 14) + 'px');
        ember.style.opacity = String(0.1 + Math.random() * 0.22);
        embersHost.appendChild(ember);
      }
    }

    var menu = document.querySelector('.blackM_menu');
    if (menu) {
      var onScroll = function () {
        if (window.scrollY > 18) menu.classList.add('is-compact');
        else menu.classList.remove('is-compact');
      };
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll();
    }

    var onlineEl = document.querySelector('.online-now .odometer[data-online-base], .online-now [data-online-base]');
    if (onlineEl) {
      var base = parseInt(onlineEl.getAttribute('data-online-base'), 10) || 0;
      var current = base;
      var digitH = 0;
      var busy = false;
      var COPIES = 4;
      var ORIGIN = 10;

      function measure() {
        var d = onlineEl.querySelector('.odo-digit');
        digitH = d ? d.offsetHeight : 48;
      }

      function buildMeter(value) {
        onlineEl.textContent = '';
        onlineEl.classList.add('odometer');
        var str = String(Math.max(0, value | 0));
        for (var i = 0; i < str.length; i++) {
          var win = document.createElement('span');
          win.className = 'odo-digit';
          var reel = document.createElement('span');
          reel.className = 'odo-reel';
          for (var n = 0; n < COPIES * 10; n++) {
            var num = document.createElement('span');
            num.textContent = String(n % 10);
            reel.appendChild(num);
          }
          reel._idx = ORIGIN + (parseInt(str.charAt(i), 10) || 0);
          win.appendChild(reel);
          onlineEl.appendChild(win);
        }
        measure();
        paint(false, 1);
      }

      function paint(animate, dir) {
        var digits = onlineEl.querySelectorAll('.odo-digit');
        var str = String(Math.max(0, current | 0));
        if (!digits.length || str.length !== digits.length) {
          buildMeter(current);
          return 0;
        }
        if (!digitH) measure();
        var len = digits.length;
        var maxDur = 0;
        for (var i = 0; i < len; i++) {
          var reel = digits[i].querySelector('.odo-reel');
          var target = parseInt(str.charAt(i), 10) || 0;
          if (!animate) {
            reel._idx = ORIGIN + target;
            reel.style.transition = 'none';
            reel.style.transform = 'translate3d(0,' + (-reel._idx * digitH) + 'px,0)';
            continue;
          }
          var idx = typeof reel._idx === 'number' ? reel._idx : ORIGIN + target;
          var curDigit = ((idx % 10) + 10) % 10;
          var steps = dir >= 0
            ? (target - curDigit + 10) % 10
            : (curDigit - target + 10) % 10;
          reel._idx = dir >= 0 ? idx + steps : idx - steps;
          var delay = (len - 1 - i) * 120;
          var duration = 720 + steps * 210;
          reel.style.transition = steps
            ? 'transform ' + duration + 'ms linear ' + delay + 'ms'
            : 'none';
          reel.style.transform = 'translate3d(0,' + (-reel._idx * digitH) + 'px,0)';
          if (steps) maxDur = Math.max(maxDur, duration + delay);
        }
        return maxDur;
      }

      function settle() {
        var reels = onlineEl.querySelectorAll('.odo-reel');
        for (var i = 0; i < reels.length; i++) {
          var reel = reels[i];
          var digit = ((reel._idx % 10) + 10) % 10;
          if (reel._idx < ORIGIN || reel._idx >= ORIGIN + 20) {
            reel._idx = ORIGIN + digit;
            reel.style.transition = 'none';
            reel.style.transform = 'translate3d(0,' + (-reel._idx * digitH) + 'px,0)';
          }
        }
      }

      var wander = [];
      var hop = 0;

      function randInt(min, max) {
        return min + Math.floor(Math.random() * (max - min + 1));
      }

      function planWander() {
        var up1 = randInt(3, 12);
        var down1 = randInt(2, 8);
        var up2 = randInt(3, 11);
        var mid = Math.max(0, base + up1 - down1);
        var peak = mid + up2;
        wander = [base + up1, mid, peak, base];
        hop = 0;
      }

      function finishRoll() {
        settle();
        onlineEl.classList.remove('is-up', 'is-down');
        var host = onlineEl.closest('.online-now');
        if (host) host.classList.remove('is-rolling');
        busy = false;
        if (reduceMotion) return;
        var pause = current === base
          ? 3200 + Math.random() * 2600
          : 700 + Math.random() * 900;
        setTimeout(playNext, pause);
      }

      function rollTo(target) {
        target = Math.max(0, target | 0);
        if (target === current || busy) return;
        busy = true;
        var dir = target > current ? 1 : -1;
        current = target;
        if (reduceMotion) {
          paint(false, dir);
          finishRoll();
          return;
        }
        onlineEl.classList.add(dir > 0 ? 'is-up' : 'is-down');
        var host = onlineEl.closest('.online-now');
        if (host) host.classList.add('is-rolling');
        var dur = paint(true, dir) || 900;
        setTimeout(finishRoll, dur + 60);
      }

      function playNext() {
        if (reduceMotion || busy) return;
        if (hop >= wander.length) {
          planWander();
        }
        var next = wander[hop++];
        if (typeof next !== 'number' || next === current) {
          if (current !== base) {
            rollTo(base);
            hop = wander.length;
            return;
          }
          planWander();
          next = wander[hop++];
        }
        rollTo(next);
      }

      buildMeter(base);
      if (!reduceMotion) {
        setTimeout(playNext, 2200);
      }
    }

    document.querySelectorAll('.blogroll .post .post_toggle').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var post = btn.closest('.post');
        if (!post) return;
        var open = post.classList.toggle('is-open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    });

    // Soft parallax tilt on glass panels (desktop only)
    if (!reduceMotion && window.matchMedia('(pointer:fine)').matches) {
      var panels = document.querySelectorAll(
        '.blackM_main_left .panel, .blackM_main_right .panel, .blackM_main_box_middle'
      );
      panels.forEach(function (panel) {
        panel.addEventListener('pointermove', function (e) {
          var r = panel.getBoundingClientRect();
          var x = (e.clientX - r.left) / r.width - 0.5;
          var y = (e.clientY - r.top) / r.height - 0.5;
          panel.style.transform =
            'perspective(900px) rotateY(' + (x * 3) + 'deg) rotateX(' + (-y * 2.4) + 'deg)';
        });
        panel.addEventListener('pointerleave', function () {
          panel.style.transform = '';
        });
      });
    }
  });
})();