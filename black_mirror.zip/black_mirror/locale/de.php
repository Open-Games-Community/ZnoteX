<?php

return array(
	'black_mirror.footer.copyright' => '&copy; {year} {site}',
	'black_mirror.footer.powered_by' => 'Betrieben mit',
	'black_mirror.aside.top_players' => 'Top-Spieler',
	'black_mirror.aside.top_guilds' => 'Top-Gilden',
	'black_mirror.aside.vocation' => 'Klasse',
	'black_mirror.aside.members' => 'Mitglieder',
	'black_mirror.aside.view_all' => 'Alle ansehen',
	'black_mirror.user.panel' => 'Benutzerbereich',
	'black_mirror.stats.title' => 'Statistiken',
	'black_mirror.stats.players_online' => 'Spieler online',
	'black_mirror.stats.server_offline' => 'Server offline',
	'black_mirror.stats.accounts' => 'Erstellte Konten:',
	'black_mirror.stats.characters' => 'Charaktere:',
);
