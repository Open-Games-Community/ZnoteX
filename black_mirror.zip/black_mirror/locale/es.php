<?php

return array(
	'black_mirror.footer.copyright' => '&copy; {year} {site}',
	'black_mirror.footer.powered_by' => 'Desarrollado con',
	'black_mirror.aside.top_players' => 'Mejores jugadores',
	'black_mirror.aside.top_guilds' => 'Mejores guilds',
	'black_mirror.aside.vocation' => 'Clase',
	'black_mirror.aside.members' => 'Miembros',
	'black_mirror.aside.view_all' => 'Ver todo',
	'black_mirror.user.panel' => 'Panel de usuario',
	'black_mirror.stats.title' => 'Estadísticas',
	'black_mirror.stats.players_online' => 'Jugadores en línea',
	'black_mirror.stats.server_offline' => 'Servidor desconectado',
	'black_mirror.stats.accounts' => 'Cuentas creadas:',
	'black_mirror.stats.characters' => 'Personajes:',
);
