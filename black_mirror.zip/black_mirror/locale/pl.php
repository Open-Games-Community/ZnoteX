<?php

return array(
	'black_mirror.footer.copyright' => '&copy; {year} {site}',
	'black_mirror.footer.powered_by' => 'Napędzane przez',
	'black_mirror.aside.top_players' => 'Najlepsi gracze',
	'black_mirror.aside.top_guilds' => 'Najlepsze gildie',
	'black_mirror.aside.vocation' => 'Klasa',
	'black_mirror.aside.members' => 'Członkowie',
	'black_mirror.aside.view_all' => 'Zobacz wszystko',
	'black_mirror.user.panel' => 'Panel użytkownika',
	'black_mirror.stats.title' => 'Statystyki',
	'black_mirror.stats.players_online' => 'Gracze online',
	'black_mirror.stats.server_offline' => 'Serwer offline',
	'black_mirror.stats.accounts' => 'Utworzone konta:',
	'black_mirror.stats.characters' => 'Postacie:',
);
