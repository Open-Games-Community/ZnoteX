<?php

return array(
	'black_mirror.footer.copyright' => '&copy; {year} {site}',
	'black_mirror.footer.powered_by' => 'Powered by',
	'black_mirror.aside.top_players' => 'Top Players',
	'black_mirror.aside.top_guilds' => 'Top Guilds',
	'black_mirror.aside.vocation' => 'Class',
	'black_mirror.aside.members' => 'Members',
	'black_mirror.aside.view_all' => 'View all',
	'black_mirror.user.panel' => 'User Panel',
	'black_mirror.stats.title' => 'Statistics',
	'black_mirror.stats.players_online' => 'Players online',
	'black_mirror.stats.server_offline' => 'Server offline',
	'black_mirror.stats.accounts' => 'Accounts created:',
	'black_mirror.stats.characters' => 'Characters:',
);
