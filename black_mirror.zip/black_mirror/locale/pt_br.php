<?php

return array(
	'black_mirror.footer.copyright' => '&copy; {year} {site}',
	'black_mirror.footer.powered_by' => 'Desenvolvido com',
	'black_mirror.aside.top_players' => 'Melhores jogadores',
	'black_mirror.aside.top_guilds' => 'Melhores guildas',
	'black_mirror.aside.vocation' => 'Classe',
	'black_mirror.aside.members' => 'Membros',
	'black_mirror.aside.view_all' => 'Ver tudo',
	'black_mirror.user.panel' => 'Painel do usuário',
	'black_mirror.stats.title' => 'Estatísticas',
	'black_mirror.stats.players_online' => 'Jogadores online',
	'black_mirror.stats.server_offline' => 'Servidor offline',
	'black_mirror.stats.accounts' => 'Contas criadas:',
	'black_mirror.stats.characters' => 'Personagens:',
);
