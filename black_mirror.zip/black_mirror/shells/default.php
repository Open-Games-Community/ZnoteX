<?php
/**
 * Black Mirror - default shell.
 *
 * Plain HTML around theme_content(). The look lives entirely in the
 * stylesheets under assets/css/; this file only lays out the frame:
 * a fixed background, a logo, the managed navigation, and a three
 * column body (rankings / page / account + stats).
 */

$bmVideo    = function_exists('theme_option') ? theme_option('background_video') : '';
$bmLogo     = function_exists('theme_image')
	? theme_image('logo_image', theme_asset('img/logo1.png'))
	: theme_asset('img/logo1.png');
$bmDiscord  = function_exists('theme_option') ? theme_option('discord_url') : '';
$bmFooter   = function_exists('theme_option') ? theme_option('footer_html') : '';
$bmHeadline = !empty($GLOBALS['page_title'])
	? (string)$GLOBALS['page_title']
	: ucwords(str_replace(array('-', '_'), ' ', (string)($page_filename ?? 'index')));
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(function_exists('translate_active') ? explode('_', translate_active())[0] : 'en', ENT_QUOTES, 'UTF-8') ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?= theme_title() ?></title>
	<link rel="stylesheet" href="<?= theme_asset('css/normalize.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap.css') ?>">
	<link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= theme_asset('css/main.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/reference-cms.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/nav-cta.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/contract.css') ?>">
</head>
<body class="<?= theme_body_class() ?>">

<?php if ($bmVideo !== ''): ?>
	<video autoplay muted loop playsinline id="video-background">
		<source src="<?= htmlspecialchars($bmVideo, ENT_QUOTES, 'UTF-8') ?>" type="video/mp4">
	</video>
<?php endif; ?>
<div class="page-atmosphere" aria-hidden="true"></div>
<div class="page-vignette" aria-hidden="true"></div>
<div class="cursor-glow" aria-hidden="true"></div>
<div class="embers" aria-hidden="true"></div>

<div id="blackM">

	<?php
	if (function_exists('translate_selector')) {
		$bmLang = translate_selector();
		if ($bmLang !== '') {
			echo '<div class="black-mirror-lang">' . $bmLang . '</div>' . translate_selector_assets();
			translate_selector_rendered(true);
		}
	}
	?>

	<div class="blackM_logo_bg" style="background-image:url('<?= $bmLogo ?>')">
		<a href="index.php" aria-label="<?= theme_title() ?>"></a>
	</div>

	<div class="blackM_menu">
		<i class="blackM_menu_sheen" aria-hidden="true"></i>
		<?php theme_menu(); ?>
	</div>

	<div class="blackM_main clearfix">

		<div class="blackM_main_left col-md-3">
			<?php theme_sidebar(); ?>
		</div>

		<div class="blackM_main_middle col-md-6">
			<div class="blackM_main_box_middle">
				<div class="panel panel-default">
					<div class="blackM2-c-l">
						<div class="page-hd">
							<div class="bd-c">
								<h2 class="pre-social"><?= htmlspecialchars($bmHeadline, ENT_QUOTES, 'UTF-8') ?></h2>
							</div>
						</div>
						<div class="padding-container">
							<div class="bd-c">
								<?php theme_content(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="blackM_main_right col-md-3">
			<?php
			if (user_logged_in() === true) {
				widget('account');
				if (isset($user_data) && is_admin($user_data)) {
					widget('admin');
				}
			} else {
				widget('login');
			}
			widget('statistics');
			?>
		</div>

	</div>
</div>

<div id="social_networks">
	<div class="footer-nav">
		<div class="social">
			<?php if ($bmDiscord !== ''): ?>
				<a href="<?= htmlspecialchars($bmDiscord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" title="Discord" class="discord"><i class="fa fa-discord"></i></a>
			<?php endif; ?>
		</div>
	</div>
</div>
<div id="footer_other_infos">
	<?php if ($bmFooter !== ''): ?>
		<p><?= $bmFooter ?></p>
	<?php endif; ?>
	<p><?= t('black_mirror.footer.copyright', ['year' => date('Y'), 'site' => htmlspecialchars((string)($config['site_name'] ?? theme_title()), ENT_QUOTES, 'UTF-8')]) ?>
		&middot; <?= t('black_mirror.footer.powered_by') ?> <a href="credits.php">ZnoteX</a>
		&middot; <?= elapsedTime() ?>s</p>
</div>

<script src="<?= theme_asset('js/jquery-2.2.4.min.js') ?>"></script>
<script src="<?= theme_asset('js/tether.min.js') ?>"></script>
<script src="<?= theme_asset('js/bootstrap.min.js') ?>"></script>
<script src="<?= theme_asset('js/theme-wow.js') ?>"></script>
</body>
</html>
