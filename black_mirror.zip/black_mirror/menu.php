<?php
/**
 * Top navigation. Entries come from Admin Panel > Menus
 * (theme_menu_items('main')); this file only renders them.
 */

$bmMenu = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$bmMenuLive = function_exists('theme_menu_available') ? theme_menu_available() : (bool)$bmMenu;
$bmMenuLabel = static function ($value): string {
	return htmlspecialchars(function_exists('theme_menu_label') ? theme_menu_label((string)$value) : (string)$value, ENT_QUOTES, 'UTF-8');
};
?>
<ul class="blackM_menu_content">
	<?php if ($bmMenuLive): ?>
		<?php foreach ($bmMenu as $item): ?>
			<li class="<?= $item['children'] ? 'dropdown' : '' ?>">
				<?php if ($item['url'] === '' && $item['children']): ?>
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<?php if ($item['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i> <?php endif; ?>
						<?= $bmMenuLabel($item['label']) ?> <span class="caret"></span>
					</a>
				<?php else: ?>
					<a href="<?= htmlspecialchars($item['url'] !== '' ? $item['url'] : '#', ENT_QUOTES, 'UTF-8') ?>"<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
						<?php if ($item['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i> <?php endif; ?>
						<?= $bmMenuLabel($item['label']) ?>
					</a>
				<?php endif; ?>

				<?php if ($item['children']): ?>
					<ul class="dropdown-menu">
						<?php foreach ($item['children'] as $child): ?>
							<li>
								<a href="<?= htmlspecialchars($child['url'], ENT_QUOTES, 'UTF-8') ?>"<?= $child['target'] !== '' ? ' target="' . htmlspecialchars($child['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
									<?= $bmMenuLabel($child['label']) ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	<?php else: ?>
		<li><a href="index.php"><i class="fa fa-home"></i> <?= h(t('nav.home')) ?></a></li>
		<li><a href="highscores.php"><i class="fa fa-trophy"></i> <?= h(t('nav.highscores')) ?></a></li>
		<li><a href="onlinelist.php"><i class="fa fa-users"></i> <?= h(t('nav.community')) ?></a></li>
		<li><a href="guilds.php"><i class="fa fa-shield"></i> <?= h(t('nav.guilds')) ?></a></li>
		<li><a href="shop.php"><i class="fa fa-shopping-cart"></i> <?= h(t('nav.shop')) ?></a></li>
		<li class="btn-download"><a href="register.php"><?= h(t('nav.register')) ?></a></li>
		<li>
			<?php if (user_logged_in() === true): ?>
				<a href="myaccount.php"><i class="fa fa-user"></i> <?= h(t('nav.account')) ?></a>
			<?php else: ?>
				<a href="login.php"><i class="fa fa-sign-in"></i> <?= h(t('nav.login')) ?></a>
			<?php endif; ?>
		</li>
	<?php endif; ?>
</ul>
