<?php
/**
 * Left column - server rankings. Read-only queries, cached, same pattern the
 * default theme's widgets use.
 */

$bmIgnoreGroup = (int)($config['highscore']['ignoreGroupId'] ?? 2);

$bmTopCache = new Cache('engine/cache/blackMirrorTopPlayers');
if ($bmTopCache->hasExpired()) {
	$bmTopPlayers = mysql_select_multi("
		SELECT `name`, `level`, `vocation`
		FROM `players`
		WHERE `group_id` < {$bmIgnoreGroup}
		ORDER BY `level` DESC, `experience` DESC
		LIMIT 5;
	");
	$bmTopCache->setContent($bmTopPlayers);
	$bmTopCache->save();
} else {
	$bmTopPlayers = $bmTopCache->load();
}

$bmGuildCache = new Cache('engine/cache/blackMirrorTopGuilds');
if ($bmGuildCache->hasExpired()) {
	$bmTopGuilds = mysql_select_multi("
		SELECT `g`.`name` AS `name`, COUNT(`gm`.`player_id`) AS `members`
		FROM `guilds` `g`
		LEFT JOIN `guild_membership` `gm` ON `gm`.`guild_id` = `g`.`id`
		GROUP BY `g`.`id`
		ORDER BY `members` DESC, `g`.`name` ASC
		LIMIT 5;
	");
	$bmGuildCache->setContent($bmTopGuilds);
	$bmGuildCache->save();
} else {
	$bmTopGuilds = $bmGuildCache->load();
}
?>
<div class="panel panel-default">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('black_mirror.aside.top_players') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<table class="table table-sm table-hover sidebar-top-table">
			<thead>
				<tr class="yellow">
					<th class="stt-rank">#</th>
					<th class="stt-name"><?= t('common.name') ?></th>
					<th class="stt-class"><?= t('black_mirror.aside.vocation') ?></th>
					<th class="stt-level"><?= t('common.level') ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ($bmTopPlayers): foreach ($bmTopPlayers as $i => $p): ?>
					<tr class="stt-row--<?= $i + 1 ?>">
						<th scope="row" class="stt-rank stt-rank--<?= $i + 1 ?>"><?php if ($i < 3): ?><img src="<?= theme_asset('img/top' . ($i + 1) . 'icon.png') ?>" alt="<?= $i + 1 ?>" class="stt-rank-icon"><?php else: ?><?= $i + 1 ?><?php endif; ?></th>
						<td class="stt-name">
							<a href="characterprofile.php?name=<?= urlencode((string)$p['name']) ?>"><?= htmlspecialchars((string)$p['name'], ENT_QUOTES, 'UTF-8') ?></a>
						</td>
						<td class="stt-class"><?= htmlspecialchars(vocation_id_to_name((int)$p['vocation']), ENT_QUOTES, 'UTF-8') ?></td>
						<td class="stt-level"><span class="lvl-badge"><?= (int)$p['level'] ?></span></td>
					</tr>
				<?php endforeach; else: ?>
					<tr><td colspan="4"><?= t('common.nothing') ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
		<div class="center"><a href="highscores.php"><?= t('black_mirror.aside.view_all') ?> &raquo;</a></div>
	</div>
</div>

<div class="panel panel-default">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('black_mirror.aside.top_guilds') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<table class="table table-sm table-hover sidebar-top-table">
			<thead>
				<tr class="yellow">
					<th class="stt-rank">#</th>
					<th class="stt-name"><?= t('common.name') ?></th>
					<th class="stt-level"><?= t('black_mirror.aside.members') ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ($bmTopGuilds): foreach ($bmTopGuilds as $i => $g): ?>
					<tr class="stt-row--<?= $i + 1 ?>">
						<th scope="row" class="stt-rank stt-rank--<?= $i + 1 ?>"><?php if ($i < 3): ?><img src="<?= theme_asset('img/top' . ($i + 1) . 'icon.png') ?>" alt="<?= $i + 1 ?>" class="stt-rank-icon"><?php else: ?><?= $i + 1 ?><?php endif; ?></th>
						<td class="stt-name">
							<a href="guilds.php?name=<?= urlencode((string)$g['name']) ?>"><?= htmlspecialchars((string)$g['name'], ENT_QUOTES, 'UTF-8') ?></a>
						</td>
						<td class="stt-level"><span class="lvl-badge"><?= (int)$g['members'] ?></span></td>
					</tr>
				<?php endforeach; else: ?>
					<tr><td colspan="3"><?= t('common.nothing') ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
		<div class="center"><a href="topguilds.php"><?= t('black_mirror.aside.view_all') ?> &raquo;</a></div>
	</div>
</div>
