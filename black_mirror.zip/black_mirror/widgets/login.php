<div class="panel panel-default" id="loginContainer">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('black_mirror.user.panel') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<form class="form loginForm" role="form" method="post" action="login.php">
			<label for="login_username" class="blackM_main_box_middle_content_label">
				<i class="fa fa-user"></i> <?= t('widget.login.username') ?>
			</label>
			<input id="login_username" class="blackM_main_box_middle_content_input form-control" name="username" type="text" maxlength="64">

			<label for="login_password" class="blackM_main_box_middle_content_label">
				<i class="fa fa-key"></i> <?= t('widget.login.password') ?>
			</label>
			<input id="login_password" class="blackM_main_box_middle_content_input form-control" name="password" type="password" maxlength="64">

			<?php if (!empty($config['twoFactorAuthenticator'])): ?>
				<label for="login_authcode" class="blackM_main_box_middle_content_label">
					<i class="fa fa-shield"></i> <?= t('widget.login.token') ?>
				</label>
				<input id="login_authcode" class="blackM_main_box_middle_content_input form-control" name="authcode" type="password">
			<?php endif; ?>

			<?php Token::create(); ?>

			<button class="btn btn-primary blackM_main_content_button login-btn" name="submit" type="submit">
				<i class="fa fa-sign-in"></i> <?= t('widget.login.submit') ?>
			</button>

			<div class="center">
				<a href="register.php"><?= t('widget.login.new_account') ?></a><br>
				<a href="recovery.php"><?= t('widget.login.lost') ?></a>
			</div>
		</form>
	</div>
</div>
