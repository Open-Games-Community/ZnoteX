<?php
$blackMFeedbackNew = 0;
$blackMFeedbackCache = new Cache('engine/cache/asideFeedbackCount');
if ($blackMFeedbackCache->hasExpired()) {
	$cat = 4;
	$threads = mysql_select_multi("SELECT `id`, `player_id` FROM `znote_forum_threads` WHERE `forum_id`='$cat' AND `closed`='0';");
	if ($threads !== false) {
		$staffs = mysql_select_multi("SELECT `id` FROM `players` WHERE `group_id` > '1';");
		foreach ($threads as $thread) {
			$response = false;
			$posts = mysql_select_multi("SELECT `id`, `player_id` FROM `znote_forum_posts` WHERE `thread_id`='" . $thread['id'] . "';");
			if ($posts !== false && is_array($staffs)) {
				foreach ($posts as $post) {
					foreach ($staffs as $staff) {
						if ($post['player_id'] == $staff['id']) {
							$response = true;
						}
					}
				}
			}
			if (!$response) {
				$blackMFeedbackNew++;
			}
		}
	}
	$blackMFeedbackCache->setContent($blackMFeedbackNew);
	$blackMFeedbackCache->save();
} else {
	$blackMFeedbackNew = (int)$blackMFeedbackCache->load();
}
?>
<div class="panel panel-default">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('widget.admin.title') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<a class="btn btn-primary blackM_main_content_button" href="admin/index.php">
			<i class="fa fa-sliders"></i> <?= t('widget.admin.panel') ?>
		</a>
		<a class="btn blackM_main_content_button" href="forum.php?cat=4">
			<i class="fa fa-comments"></i> <?= t('widget.admin.feedback', ['count' => $blackMFeedbackNew]) ?>
		</a>
	</div>
</div>
