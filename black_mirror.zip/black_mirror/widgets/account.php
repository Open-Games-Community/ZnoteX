<div class="panel panel-default">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('black_mirror.user.panel') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<p class="center"><?= t('widget.account.welcome', ['name' => htmlspecialchars((string)($user_data['name'] ?? ''), ENT_QUOTES, 'UTF-8')]) ?></p>
		<a class="btn btn-primary blackM_main_content_button" href="myaccount.php"><i class="fa fa-user"></i> <?= t('widget.account.my_account') ?></a>
		<a class="btn blackM_main_content_button" href="createcharacter.php"><i class="fa fa-plus"></i> <?= t('widget.account.create_character') ?></a>
		<a class="btn blackM_main_content_button" href="changepassword.php"><i class="fa fa-key"></i> <?= t('widget.account.change_password') ?></a>
		<a class="btn blackM_main_content_button" href="settings.php"><i class="fa fa-cog"></i> <?= t('widget.account.settings') ?></a>
		<a class="btn btn-danger blackM_main_content_button" href="logout.php"><i class="fa fa-sign-out"></i> <?= t('widget.account.logout') ?></a>
	</div>
</div>
