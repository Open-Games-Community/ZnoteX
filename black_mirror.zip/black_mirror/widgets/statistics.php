<?php
$bmStatCache = new Cache('engine/cache/blackMirrorStats');
if ($bmStatCache->hasExpired()) {
	$bmStats = mysql_select_single("
		SELECT
			(SELECT COUNT(`id`) FROM `accounts`) AS `accounts`,
			(SELECT COUNT(`id`) FROM `players`) AS `players`,
			(SELECT COUNT(`player_id`) FROM `players_online`) AS `online`
	");
	$bmStatCache->setContent($bmStats);
	$bmStatCache->save();
} else {
	$bmStats = $bmStatCache->load();
}
$bmStats = is_array($bmStats) ? $bmStats : array('accounts' => 0, 'players' => 0, 'online' => 0);

/**
 * Server status. Green unless the status probe is enabled in config.php AND the
 * game server does not answer. Same check the other themes use, cached so the
 * socket call does not run on every page load.
 */
$bmServerOnline = true;
if (!empty($config['status']['status_check'])) {
	$bmStatusCache = new Cache('engine/cache/blackMirrorServerStatus');
	$bmStatusCache->setExpiration(30);
	if ($bmStatusCache->hasExpired()) {
		$bmSock = @fsockopen(
			(string)$config['status']['status_ip'],
			(int)$config['status']['status_port'],
			$bmErrNo,
			$bmErrStr,
			1
		);
		$bmServerOnline = ($bmSock !== false);
		if ($bmSock !== false) {
			fclose($bmSock);
		}
		$bmStatusCache->setContent(array('online' => $bmServerOnline ? 1 : 0));
		$bmStatusCache->save();
	} else {
		$loaded = $bmStatusCache->load();
		$bmServerOnline = !is_array($loaded) || !empty($loaded['online']);
	}
}
?>
<div class="panel panel-default">
	<div class="panel-heading blackM_main_left_panel_header"><?= t('black_mirror.stats.title') ?></div>
	<div class="panel-body blackM_main_left_panel_body">
		<div class="online-now<?= $bmServerOnline ? '' : ' is-offline' ?>">
			<div class="odometer" aria-live="polite"><?= (int)$bmStats['online'] ?></div>
			<h3 class="center online-now-label">
				<?= $bmServerOnline ? t('black_mirror.stats.players_online') : t('black_mirror.stats.server_offline') ?>
			</h3>
		</div>
		<div class="stats">
			<div>
				<?= t('black_mirror.stats.accounts') ?>
				<div class="stats-value"><?= number_format((int)$bmStats['accounts']) ?></div>
			</div>
			<div>
				<?= t('black_mirror.stats.characters') ?>
				<div class="stats-value"><?= number_format((int)$bmStats['players']) ?></div>
			</div>
		</div>
		<div class="center"><a href="serverinfo.php"><?= t('black_mirror.aside.view_all') ?> &raquo;</a></div>
	</div>
</div>
