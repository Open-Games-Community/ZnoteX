<?php

return array(
	'boosted_creatures.panel_title' => 'Server boosts',
	'boosted_creatures.creature_title' => 'Boosted Creature',
	'boosted_creatures.boss_title' => 'Boosted Boss',
	'boosted_creatures.fallback' => 'To be announced',
	'boosted_creatures.collapse' => 'Hide',
	'boosted_creatures.show' => 'Show',
);
