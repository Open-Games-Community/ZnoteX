<?php

return array(
	'boosted_creatures.panel_title' => 'Bonus del servidor',
	'boosted_creatures.creature_title' => 'Criatura potenciada',
	'boosted_creatures.boss_title' => 'Jefe potenciado',
	'boosted_creatures.fallback' => 'Por anunciar',
	'boosted_creatures.collapse' => 'Ocultar',
	'boosted_creatures.show' => 'Mostrar',
);
