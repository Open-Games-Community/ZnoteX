<?php

return array(
	'boosted_creatures.panel_title' => 'Server-Boosts',
	'boosted_creatures.creature_title' => 'Verstärkte Kreatur',
	'boosted_creatures.boss_title' => 'Verstärkter Boss',
	'boosted_creatures.fallback' => 'Wird noch bekannt gegeben',
	'boosted_creatures.collapse' => 'Ausblenden',
	'boosted_creatures.show' => 'Anzeigen',
);
