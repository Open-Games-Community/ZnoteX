<?php

return array(
	'boosted_creatures.panel_title' => 'Serwerowe bonusy',
	'boosted_creatures.creature_title' => 'Wzmocniony potwór',
	'boosted_creatures.boss_title' => 'Wzmocniony boss',
	'boosted_creatures.fallback' => 'Wkrótce',
	'boosted_creatures.collapse' => 'Ukryj',
	'boosted_creatures.show' => 'Pokaż',
);
