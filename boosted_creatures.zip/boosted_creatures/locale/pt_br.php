<?php

return array(
	'boosted_creatures.panel_title' => 'Bônus do servidor',
	'boosted_creatures.creature_title' => 'Criatura turbinada',
	'boosted_creatures.boss_title' => 'Chefe turbinado',
	'boosted_creatures.fallback' => 'A ser anunciado',
	'boosted_creatures.collapse' => 'Ocultar',
	'boosted_creatures.show' => 'Mostrar',
);
