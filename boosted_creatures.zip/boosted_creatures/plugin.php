<?php
/**
 * Boosted Creatures - today's boosted creature / boss in a theme-agnostic side box.
 *
 * The plugin never writes to the game database. It reads one row from the
 * server's own boost table. Because every distro (and every fork) names that
 * table and its columns differently, the name and the whole column map are
 * settings, pre-filled by autodetection and by a distro preset.
 */
if (!function_exists('boosted_creatures_setting')) {

function boosted_creatures_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('boosted_creatures:' . $key, $default) : $default;
}
function boosted_creatures_enabled(): bool { return boosted_creatures_setting('enabled', '1') === '1'; }
function boosted_creatures_claim_embedded_renderer(): void { $GLOBALS['boosted_creatures_embedded_renderer'] = true; }
function boosted_creatures_has_embedded_renderer(): bool { return !empty($GLOBALS['boosted_creatures_embedded_renderer']); }
function boosted_creatures_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function boosted_creatures_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string) $v, $text);
	return $text;
}
function boosted_creatures_text(string $settingKey, string $localeKey, string $fallback): string {
	$c = trim(boosted_creatures_setting($settingKey, ''));
	return $c !== '' ? $c : boosted_creatures_t($localeKey, $fallback);
}

// --- identifier / style validation -------------------------------------
function boosted_creatures_ident(string $v): string {
	$v = trim($v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}
function boosted_creatures_css_value(string $value): string {
	$value = trim($value);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value)) return $value;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $value) ? $value : '';
}
function boosted_creatures_color(string $key): string { return boosted_creatures_css_value(boosted_creatures_setting('style_' . $key, '')); }
function boosted_creatures_url_value(string $key): string {
	$v = trim(boosted_creatures_setting($key, ''));
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function boosted_creatures_style_attr(): string {
	$map = array('box_bg' => '--bc-surface', 'border' => '--bc-border', 'text' => '--bc-text', 'accent' => '--bc-accent', 'title_bg' => '--bc-title-bg', 'title_text' => '--bc-title-text');
	$css = '';
	foreach ($map as $k => $var) { $v = boosted_creatures_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	$radius = (int) boosted_creatures_setting('style_radius', '14');
	if ($radius >= 0 && $radius <= 40) $css .= '--bc-radius:' . $radius . 'px;';
	return $css !== '' ? ' style="' . boosted_creatures_h($css) . '"' : '';
}
function boosted_creatures_asset_image(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$path = __DIR__ . '/assets/img/' . $file;
	return is_file($path) ? znote_plugin_asset('boosted_creatures', 'img/' . $file) : '';
}

// --- column resolution -------------------------------------------------
function boosted_creatures_default_table(string $type): string {
	return $type === 'boss' ? 'boosted_boss' : 'boosted_creature';
}
function boosted_creatures_table(string $type): string {
	$t = boosted_creatures_ident(boosted_creatures_setting($type . '_table', ''));
	return $t !== '' ? $t : boosted_creatures_default_table($type);
}
/** Canonical field => list of column-name candidates, most common first. */
function boosted_creatures_candidates(): array {
	return array(
		'name'   => array('boostname', 'boostName', 'name', 'creature_name', 'raceName', 'racename'),
		'race'   => array('raceid', 'raceId', 'race_id', 'race'),
		'look'   => array('looktype', 'look_type', 'lookType', 'outfit'),
		'head'   => array('lookhead', 'look_head', 'lookHead'),
		'body'   => array('lookbody', 'look_body', 'lookBody'),
		'legs'   => array('looklegs', 'look_legs', 'lookLegs'),
		'feet'   => array('lookfeet', 'look_feet', 'lookFeet'),
		'addons' => array('lookaddons', 'look_addons', 'lookAddons', 'addons'),
		'mount'  => array('lookmount', 'look_mount', 'lookMount', 'mount'),
		'date'   => array('date', 'boostdate', 'boostDate', 'day', 'updated_at'),
	);
}
/** The column name for a canonical field: admin override, else autodetect, else ''. */
function boosted_creatures_column(string $type, string $table, string $field): string {
	static $cache = array();
	$ck = $type . '|' . $table . '|' . $field;
	if (isset($cache[$ck])) return $cache[$ck];

	$override = boosted_creatures_ident(boosted_creatures_setting($type . '_col_' . $field, ''));
	if ($override !== '') return $cache[$ck] = $override;

	$cands = boosted_creatures_candidates()[$field] ?? array();
	foreach ($cands as $c) {
		if (function_exists('znote_column_exists') && znote_column_exists($table, $c)) return $cache[$ck] = $c;
	}
	return $cache[$ck] = '';
}
/** List a table's columns (for the admin autodetect readout). */
function boosted_creatures_table_columns(string $table): array {
	$table = boosted_creatures_ident($table);
	if ($table === '' || !function_exists('znote_table_exists') || !znote_table_exists($table)) return array();
	$rows = db()->fetchAll("SHOW COLUMNS FROM `{$table}`;");
	if (!is_array($rows)) return array();
	$out = array();
	foreach ($rows as $r) if (isset($r['Field'])) $out[] = (string) $r['Field'];
	return $out;
}

// --- reading the boost row -------------------------------------------
function boosted_creatures_query(string $type): ?array {
	$table = boosted_creatures_table($type);
	if ($table === '' || !function_exists('znote_table_exists') || !znote_table_exists($table)) return null;

	$cols = array();
	foreach (array('name', 'race', 'look', 'head', 'body', 'legs', 'feet', 'addons', 'mount', 'date') as $f) {
		$c = boosted_creatures_column($type, $table, $f);
		if ($c !== '') $cols[$f] = $c;
	}
	if (!isset($cols['name'])) return null;

	$select = array();
	foreach ($cols as $f => $c) $select[] = "`{$c}` AS `{$f}`";
	$sql = 'SELECT ' . implode(',', $select) . " FROM `{$table}`";
	if (isset($cols['date'])) $sql .= " ORDER BY `{$cols['date']}` DESC";
	$sql .= ' LIMIT 1;';

	$row = db()->fetchOne($sql);
	if (!is_array($row) || trim((string) ($row['name'] ?? '')) === '') return null;

	return array(
		'type'   => $type,
		'name'   => trim((string) $row['name']),
		'race'   => (int) ($row['race'] ?? 0),
		'look'   => (int) ($row['look'] ?? 0),
		'head'   => (int) ($row['head'] ?? 0),
		'body'   => (int) ($row['body'] ?? 0),
		'legs'   => (int) ($row['legs'] ?? 0),
		'feet'   => (int) ($row['feet'] ?? 0),
		'addons' => (int) ($row['addons'] ?? 0),
		'mount'  => (int) ($row['mount'] ?? 0),
	);
}
/** Cached (default 30 min) resolution of both boosts. */
function boosted_creatures_data(bool $refresh = false): array {
	static $mem = null;
	if ($mem !== null && !$refresh) return $mem;

	$ttl = max(60, (int) boosted_creatures_setting('cache_ttl', '1800'));
	$at  = (int) boosted_creatures_setting('cache_at', '0');
	$raw = boosted_creatures_setting('cache', '');
	if (!$refresh && $at > 0 && $at + $ttl > time() && $raw !== '') {
		$decoded = json_decode($raw, true);
		if (is_array($decoded)) return $mem = $decoded;
	}

	$data = array();
	if (boosted_creatures_setting('show_creature', '1') === '1') { $c = boosted_creatures_query('creature'); if ($c) $data['creature'] = $c; }
	if (boosted_creatures_setting('show_boss', '1') === '1')     { $b = boosted_creatures_query('boss');     if ($b) $data['boss'] = $b; }

	if (function_exists('setting_set')) {
		setting_set('boosted_creatures:cache', json_encode($data));
		// No data yet (server not started): recheck soon so the first real boost shows quickly.
		setting_set('boosted_creatures:cache_at', (string) ($data ? time() : time() - $ttl + min($ttl, 300)));
	}
	return $mem = $data;
}
function boosted_creatures_clear_cache(): void {
	if (function_exists('setting_set')) { setting_set('boosted_creatures:cache', ''); setting_set('boosted_creatures:cache_at', '0'); }
}

// --- rendering -------------------------------------------------------
function boosted_creatures_outfit_url(array $row): string {
	global $config;
	if ((int) $row['look'] <= 0) return '';
	$srv = trim((string) ($config['show_outfits']['imageServer'] ?? ''));
	if ($srv === '') return '';
	$addons = boosted_creatures_setting('outfit_addons', '1') === '1' ? max(0, min(3, (int) $row['addons'])) : 0;
	$dir = (int) boosted_creatures_setting('outfit_dir', '3');
	if ($dir < 1 || $dir > 4) $dir = 3;
	$u = $srv . '?id=' . (int) $row['look']
		. '&addons=' . $addons
		. '&head=' . (int) $row['head'] . '&body=' . (int) $row['body']
		. '&legs=' . (int) $row['legs'] . '&feet=' . (int) $row['feet']
		. '&direction=' . $dir;
	if ((int) $row['mount'] > 0) $u .= '&mount=' . (int) $row['mount'];
	return $u;
}
function boosted_creatures_link_url(array $row): string {
	$linkTpl = trim(boosted_creatures_setting('link_template', 'creatures.php?search={name}'));
	if ($linkTpl === '') return '';
	return str_replace(
		array('{name}', '{race}'),
		array(rawurlencode((string) ($row['name'] ?? '')), (int) ($row['race'] ?? 0)),
		$linkTpl
	);
}
function boosted_creatures_card(array $row): string {
	$type = $row['type'];
	$title = boosted_creatures_h(boosted_creatures_text($type . '_title', 'boosted_creatures.' . $type . '_title', $type === 'boss' ? 'Boosted Boss' : 'Boosted Creature'));
	$boost = boosted_creatures_h(trim(boosted_creatures_setting($type . '_boost_text', '')));
	$size = (int) boosted_creatures_setting('outfit_size', '84');
	if ($size < 40 || $size > 160) $size = 84;

	$img = boosted_creatures_outfit_url($row);
	if ($img === '') {
		$img = boosted_creatures_url_value($type . '_fallback_img');
		if ($img === '') $img = boosted_creatures_asset_image('creature.svg');
	}
	$visual = $img !== ''
		? '<img class="bc-card__outfit" src="' . boosted_creatures_h($img) . '" alt="" style="width:' . $size . 'px;height:' . $size . 'px" loading="lazy">'
		: '';

	$name = boosted_creatures_h($row['name']);
	$href = boosted_creatures_link_url($row);
	if ($href !== '') {
		$name = '<a href="' . boosted_creatures_h($href) . '">' . $name . '</a>';
	}

	return '<div class="bc-card bc-card--' . boosted_creatures_h($type) . '">'
		. '<div class="bc-card__head">' . $title . '</div>'
		. '<div class="bc-card__body">' . $visual
		. '<div class="bc-card__meta"><strong class="bc-card__name">' . $name . '</strong>'
		. ($boost !== '' ? '<span class="bc-card__boost">' . $boost . '</span>' : '')
		. '</div></div></div>';
}
/** Text-only card shown when the boost row is empty (server never started, etc.). */
function boosted_creatures_fallback_card(string $type): string {
	$title = boosted_creatures_h(boosted_creatures_text($type . '_title', 'boosted_creatures.' . $type . '_title', $type === 'boss' ? 'Boosted Boss' : 'Boosted Creature'));
	$text  = trim(boosted_creatures_text($type . '_fallback_text', 'boosted_creatures.fallback', 'To be announced'));
	if ($text === '') return '';
	$img = boosted_creatures_url_value($type . '_fallback_img');
	if ($img === '') $img = boosted_creatures_asset_image('creature.svg');
	$size = (int) boosted_creatures_setting('outfit_size', '84');
	if ($size < 40 || $size > 160) $size = 84;
	$visual = $img !== '' ? '<img class="bc-card__outfit bc-card__outfit--dim" src="' . boosted_creatures_h($img) . '" alt="" style="width:' . $size . 'px;height:' . $size . 'px" loading="lazy">' : '';
	return '<div class="bc-card bc-card--' . boosted_creatures_h($type) . ' bc-card--empty">'
		. '<div class="bc-card__head">' . $title . '</div>'
		. '<div class="bc-card__body">' . $visual
		. '<div class="bc-card__meta"><span class="bc-card__fallback">' . boosted_creatures_h($text) . '</span></div>'
		. '</div></div>';
}
function boosted_creatures_footer(): string {
	if (!boosted_creatures_enabled()) return '';
	if (boosted_creatures_has_embedded_renderer()) return '';
	$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
	$pages = array_filter(array_map('trim', explode(',', boosted_creatures_setting('pages', 'index.php'))));
	if ($pages && !in_array($script, $pages, true)) return '';

	$data = boosted_creatures_data();

	$cards = '';
	foreach (array('creature', 'boss') as $type) {
		if (boosted_creatures_setting('show_' . $type, '1') !== '1') continue;
		if (isset($data[$type])) $cards .= boosted_creatures_card($data[$type]);
		else $cards .= boosted_creatures_fallback_card($type);
	}
	if ($cards === '') return '';

	$side   = boosted_creatures_setting('side', 'right') === 'left' ? 'left' : 'right';
	$offset = (int) boosted_creatures_setting('offset_top', '140');
	if ($offset < 0 || $offset > 800) $offset = 140;
	$banner = boosted_creatures_url_value('banner_img');
	$shadow = boosted_creatures_setting('style_shadow', '1') === '1';
	$title  = boosted_creatures_h(boosted_creatures_text('panel_title', 'boosted_creatures.panel_title', 'Server boosts'));
	$collapse = boosted_creatures_h(boosted_creatures_t('boosted_creatures.collapse', 'Hide'));

	$bannerHtml = $banner !== '' ? '<div class="bc-banner" style="background-image:url(' . boosted_creatures_h($banner) . ')"></div>' : '';

	$css = '#bcPanel{--bc-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(24,27,34))))))));--bc-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--bc-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--bc-accent:var(--accent,var(--link,var(--nz-accent,#f4c542)));--bc-title-bg:var(--bc-accent);--bc-title-text:#151515;--bc-radius:14px;position:fixed;top:' . $offset . 'px;' . $side . ':14px;z-index:930;width:212px;max-width:calc(100vw - 28px);color:var(--bc-text);font-size:13px;animation:bcIn .35s ease both}'
		. '@keyframes bcIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
		. '#bcPanel *{box-sizing:border-box}'
		. '#bcPanel .bc-inner{border:1px solid var(--bc-border);border-radius:var(--bc-radius);background:var(--bc-surface);overflow:hidden' . ($shadow ? ';box-shadow:0 12px 34px rgba(0,0,0,.4)' : '') . '}'
		. '#bcPanel .bc-top{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:7px 10px;background:var(--bc-title-bg);color:var(--bc-title-text);font-weight:800;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em}'
		. '#bcPanel .bc-toggle{border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;opacity:.85;padding:0}'
		. '#bcPanel .bc-banner{height:60px;background-size:cover;background-position:center}'
		. '#bcPanel .bc-body[hidden]{display:none}'
		. '#bcPanel .bc-card{padding:10px;border-top:1px solid var(--bc-border)}#bcPanel .bc-card:first-child{border-top:0}'
		. '#bcPanel .bc-card__head{font-size:10.5px;text-transform:uppercase;letter-spacing:.06em;opacity:.65;margin-bottom:4px}'
		. '#bcPanel .bc-card__body{display:flex;align-items:center;gap:10px}'
		. '#bcPanel .bc-card__outfit{flex:0 0 auto;object-fit:contain;image-rendering:auto;filter:drop-shadow(0 3px 6px rgba(0,0,0,.5))}'
		. '#bcPanel .bc-card__meta{min-width:0}'
		. '#bcPanel .bc-card__name{display:block;font-size:14px;font-weight:800;line-height:1.15;overflow-wrap:anywhere}'
		. '#bcPanel .bc-card__name a{color:inherit;text-decoration:none}#bcPanel .bc-card__name a:hover{color:var(--bc-accent)}'
		. '#bcPanel .bc-card__boost{display:block;margin-top:2px;font-size:11.5px;color:var(--bc-accent)}'
		. '#bcPanel .bc-card__fallback{font-size:12.5px;opacity:.75;line-height:1.35;overflow-wrap:anywhere}'
		. '#bcPanel .bc-card__outfit--dim{opacity:.4;filter:grayscale(1) drop-shadow(0 3px 6px rgba(0,0,0,.4))}'
		. '#bcPanel.bc-collapsed .bc-banner{display:none}'
		. '@media(max-width:760px){#bcPanel{position:static;width:auto;margin:0 0 14px;animation:none}}'
		. '@media(prefers-reduced-motion:reduce){#bcPanel{animation:none}}';

	$html = '<div id="bcPanel"' . boosted_creatures_style_attr() . '><div class="bc-inner">'
		. '<div class="bc-top"><span>' . $title . '</span><button type="button" class="bc-toggle" aria-expanded="true">' . $collapse . '</button></div>'
		. '<div class="bc-body">' . $bannerHtml . $cards . '</div>'
		. '</div></div>';

	return '<script>(function(){if(document.getElementById("bcPanel"))return;'
		. 'var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';var p=w.firstChild;'
		. 'var host=document.querySelector("main,#content,.content,.container")||document.body;'
		. '(window.matchMedia&&window.matchMedia("(max-width:760px)").matches?host:document.body).appendChild(p);'
		. 'var b=p.querySelector(".bc-body"),t=p.querySelector(".bc-toggle");'
		. 'try{if(localStorage.getItem("bcCollapsed")==="1"){b.hidden=true;p.classList.add("bc-collapsed");t.textContent=' . json_encode(boosted_creatures_t('boosted_creatures.show', 'Show')) . ';t.setAttribute("aria-expanded","false");}}catch(e){}'
		. 't.addEventListener("click",function(){var h=!b.hidden;b.hidden=h;p.classList.toggle("bc-collapsed",h);t.textContent=h?' . json_encode(boosted_creatures_t('boosted_creatures.show', 'Show')) . ':' . json_encode(boosted_creatures_t('boosted_creatures.collapse', 'Hide')) . ';t.setAttribute("aria-expanded",String(!h));try{localStorage.setItem("bcCollapsed",h?"1":"0");}catch(e){}});'
		. '}());</script>';
}

}

if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'boosted_creatures_footer');
}
