<?php
/**
 * Title: Boosted Creatures
 * Icon: fa-paw
 * Group: Installed Plugins
 * Order: 40
 * Description: Where the boosted creature / boss come from, and how the side box looks.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'boosted_creatures__boosted';
$types  = array('creature', 'boss');
$fields = array('name', 'race', 'look', 'head', 'body', 'legs', 'feet', 'addons', 'mount', 'date');

function boosted_creatures_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function boosted_creatures_admin_url($v): string {
	$v = trim((string) $v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function boosted_creatures_admin_ident($v): string {
	$v = trim((string) $v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? 'save');

	if ($do === 'detect' || $do === 'reset') {
		$type = in_array(($_POST['type'] ?? ''), $types, true) ? $_POST['type'] : 'creature';
		foreach ($fields as $f) setting_set('boosted_creatures:' . $type . '_col_' . $f, '');
		if ($do === 'detect') {
			$table = boosted_creatures_admin_ident($_POST['table'] ?? '') ?: boosted_creatures_default_table($type);
			setting_set('boosted_creatures:' . $type . '_table', $table);
			$have = array_map('strtolower', boosted_creatures_table_columns($table));
			foreach (boosted_creatures_candidates() as $field => $cands) {
				foreach ($cands as $c) {
					if (in_array(strtolower($c), $have, true)) { setting_set('boosted_creatures:' . $type . '_col_' . $field, $c); break; }
				}
			}
			acp_flash_success(ucfirst($type) . ': columns detected from `' . h($table) . '`.');
		} else {
			acp_flash_success(ucfirst($type) . ': back to autodetection.');
		}
		boosted_creatures_clear_cache();
		acp_redirect($module);
	}

	// --- full save ---
	setting_set('boosted_creatures:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('boosted_creatures:show_creature', !empty($_POST['show_creature']) ? '1' : '0');
	setting_set('boosted_creatures:show_boss', !empty($_POST['show_boss']) ? '1' : '0');
	setting_set('boosted_creatures:pages', trim((string) ($_POST['pages'] ?? 'index.php')));
	setting_set('boosted_creatures:side', ($_POST['side'] ?? 'right') === 'left' ? 'left' : 'right');
	setting_set('boosted_creatures:offset_top', (string) max(0, min(800, intv($_POST['offset_top'] ?? 140))));
	setting_set('boosted_creatures:cache_ttl', (string) max(60, min(86400, intv($_POST['cache_ttl'] ?? 1800))));
	setting_set('boosted_creatures:panel_title', trim((string) ($_POST['panel_title'] ?? '')));
	setting_set('boosted_creatures:link_template', trim((string) ($_POST['link_template'] ?? '')));

	setting_set('boosted_creatures:outfit_size', (string) max(40, min(160, intv($_POST['outfit_size'] ?? 84))));
	setting_set('boosted_creatures:outfit_dir', (string) max(1, min(4, intv($_POST['outfit_dir'] ?? 3))));
	setting_set('boosted_creatures:outfit_addons', !empty($_POST['outfit_addons']) ? '1' : '0');

	foreach (array('box_bg', 'border', 'text', 'accent', 'title_bg', 'title_text') as $k) {
		setting_set('boosted_creatures:style_' . $k, boosted_creatures_admin_color($_POST['style_' . $k] ?? ''));
	}
	setting_set('boosted_creatures:style_radius', (string) max(0, min(40, intv($_POST['style_radius'] ?? 14))));
	setting_set('boosted_creatures:style_shadow', !empty($_POST['style_shadow']) ? '1' : '0');
	setting_set('boosted_creatures:banner_img', boosted_creatures_admin_url($_POST['banner_img'] ?? ''));

	foreach ($types as $type) {
		setting_set('boosted_creatures:' . $type . '_table', boosted_creatures_admin_ident($_POST[$type . '_table'] ?? ''));
		setting_set('boosted_creatures:' . $type . '_title', trim((string) ($_POST[$type . '_title'] ?? '')));
		setting_set('boosted_creatures:' . $type . '_boost_text', trim((string) ($_POST[$type . '_boost_text'] ?? '')));
		setting_set('boosted_creatures:' . $type . '_fallback_text', trim((string) ($_POST[$type . '_fallback_text'] ?? '')));
		setting_set('boosted_creatures:' . $type . '_fallback_img', boosted_creatures_admin_url($_POST[$type . '_fallback_img'] ?? ''));
		foreach ($fields as $f) setting_set('boosted_creatures:' . $type . '_col_' . $f, boosted_creatures_admin_ident($_POST[$type . '_col_' . $f] ?? ''));
	}

	boosted_creatures_clear_cache();
	if (function_exists('acp_log')) acp_log('boosted_creatures.save', '');
	acp_flash_success('Boosted Creatures saved.');
	acp_redirect($module);
}

$get = static fn(string $k, string $d = '') => (string) setting('boosted_creatures:' . $k, $d);
$live = boosted_creatures_data(true); // force a fresh read for the preview
?>
<?php acp_card_open('Boosted Creatures', 'The box is injected on the pages below and inherits the active theme. Data is read from the server boost table - autodetection covers Canary / otservbr and most TFS forks; use the column fields for anything custom. Nothing is written to the game database.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>

	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label">Show on pages (comma separated, blank = all)</label><input class="acp-input" name="pages" value="<?= h($get('pages', 'index.php')) ?>" placeholder="index.php"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_creature" value="1" <?= $get('show_creature', '1') === '1' ? 'checked' : '' ?>> Show boosted creature</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_boss" value="1" <?= $get('show_boss', '1') === '1' ? 'checked' : '' ?>> Show boosted boss</label></div>
		<div class="acp-field"><label class="acp-label">Box side</label><select class="acp-select" name="side"><option value="right" <?= $get('side', 'right') !== 'left' ? 'selected' : '' ?>>Right</option><option value="left" <?= $get('side', 'right') === 'left' ? 'selected' : '' ?>>Left</option></select></div>
		<div class="acp-field"><label class="acp-label">Top offset (px)</label><input class="acp-input" type="number" min="0" max="800" name="offset_top" value="<?= (int) $get('offset_top', '140') ?>"></div>
		<div class="acp-field"><label class="acp-label">Cache time (seconds)</label><input class="acp-input" type="number" min="60" max="86400" name="cache_ttl" value="<?= (int) $get('cache_ttl', '1800') ?>"></div>
		<div class="acp-field"><label class="acp-label">Panel title</label><input class="acp-input" name="panel_title" value="<?= h($get('panel_title')) ?>" placeholder="Server boosts"></div>
		<div class="acp-field"><label class="acp-label">Name link template ({name}, {race}) — blank for none</label><input class="acp-input" name="link_template" value="<?= h($get('link_template', 'creatures.php?search={name}')) ?>"></div>
	</div>

	<h3>Outfit &amp; style</h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Outfit size (px)</label><input class="acp-input" type="number" min="40" max="160" name="outfit_size" value="<?= (int) $get('outfit_size', '84') ?>"></div>
		<div class="acp-field"><label class="acp-label">Outfit facing</label>
			<?php $od = (int) $get('outfit_dir', '3'); ?>
			<select class="acp-select" name="outfit_dir">
				<option value="3" <?= $od === 3 ? 'selected' : '' ?>>Down (towards the viewer)</option>
				<option value="1" <?= $od === 1 ? 'selected' : '' ?>>Up</option>
				<option value="2" <?= $od === 2 ? 'selected' : '' ?>>Right</option>
				<option value="4" <?= $od === 4 ? 'selected' : '' ?>>Left</option>
			</select>
		</div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="outfit_addons" value="1" <?= $get('outfit_addons', '1') === '1' ? 'checked' : '' ?>> Show outfit addons</label></div>
		<div class="acp-field"><label class="acp-label">Corner radius (px)</label><input class="acp-input" type="number" min="0" max="40" name="style_radius" value="<?= (int) $get('style_radius', '14') ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="style_shadow" value="1" <?= $get('style_shadow', '1') === '1' ? 'checked' : '' ?>> Drop shadow</label></div>
		<div class="acp-field"><label class="acp-label">Banner image URL (top of box)</label><input class="acp-input" name="banner_img" value="<?= h($get('banner_img')) ?>" placeholder="https://…/banner.png"></div>
	</div>
	<p class="acp-muted">Colours — leave empty to inherit the theme (default-theme fallback).</p>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent', 'title_bg' => 'Title bar background', 'title_text' => 'Title bar text') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>" placeholder="#1a1d24 or rgba(...)"></div>
		<?php endforeach; ?>
	</div>

	<?php foreach ($types as $type):
		$table = $get($type . '_table') ?: boosted_creatures_default_table($type);
		$cols  = boosted_creatures_table_columns($table);
		$row   = $live[$type] ?? null;
	?>
		<h3><?= ucfirst($type) ?> source</h3>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Table name</label><input class="acp-input" name="<?= $type ?>_table" value="<?= h($get($type . '_table')) ?>" placeholder="<?= h(boosted_creatures_default_table($type)) ?>"></div>
			<div class="acp-field"><label class="acp-label">Box heading</label><input class="acp-input" name="<?= $type ?>_title" value="<?= h($get($type . '_title')) ?>" placeholder="<?= $type === 'boss' ? 'Boosted Boss' : 'Boosted Creature' ?>"></div>
			<div class="acp-field"><label class="acp-label">Boost text (free text, e.g. +50% XP · +50% Loot)</label><input class="acp-input" name="<?= $type ?>_boost_text" value="<?= h($get($type . '_boost_text')) ?>"></div>
			<div class="acp-field"><label class="acp-label">Fallback text (shown when the table has no row yet — server not started)</label><input class="acp-input" name="<?= $type ?>_fallback_text" value="<?= h($get($type . '_fallback_text')) ?>" placeholder="To be announced"></div>
			<div class="acp-field"><label class="acp-label">Fallback image URL (no looktype in table)</label><input class="acp-input" name="<?= $type ?>_fallback_img" value="<?= h($get($type . '_fallback_img')) ?>"></div>
		</div>
		<div class="acp-grid acp-grid--2">
			<?php foreach ($fields as $f): ?>
				<div class="acp-field"><label class="acp-label">Column: <?= h($f) ?><?php if ($get($type . '_col_' . $f) === '' && boosted_creatures_column($type, $table, $f) !== ''): ?> <span class="acp-muted">(auto: <?= h(boosted_creatures_column($type, $table, $f)) ?>)</span><?php endif; ?></label><input class="acp-input" name="<?= $type ?>_col_<?= h($f) ?>" value="<?= h($get($type . '_col_' . $f)) ?>" placeholder="auto"></div>
			<?php endforeach; ?>
		</div>
		<p class="acp-muted">
			<?php if (!$cols): ?>
				Table <code><?= h($table) ?></code> not found.
			<?php else: ?>
				Columns in <code><?= h($table) ?></code>: <code><?= h(implode(', ', $cols)) ?></code>.
				<?php if ($row): ?><br>Current: <strong><?= h($row['name']) ?></strong> — looktype <?= (int) $row['look'] ?><?php if ($row['look'] > 0): ?>
					<br><img src="<?= h(boosted_creatures_outfit_url($row)) ?>" alt="" style="max-height:70px;vertical-align:middle">
				<?php endif; ?><?php else: ?><br>No readable row yet.<?php endif; ?>
			<?php endif; ?>
		</p>
		<div class="acp-actions">
			<button class="acp-btn" type="submit" name="do" value="detect" formnovalidate onclick="this.form.querySelector('[name=type]').value='<?= $type ?>';this.form.querySelector('[name=table]').value=this.form.querySelector('[name=<?= $type ?>_table]').value;"><i class="fa fa-magic"></i> Detect columns</button>
			<button class="acp-btn acp-btn--ghost" type="submit" name="do" value="reset" formnovalidate onclick="this.form.querySelector('[name=type]').value='<?= $type ?>';"><i class="fa fa-undo"></i> Reset to autodetect</button>
		</div>
	<?php endforeach; ?>

	<input type="hidden" name="type" value="creature">
	<input type="hidden" name="table" value="">

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit" name="do" value="save"><i class="fa fa-check"></i> Save</button></div>
</form>
<?php acp_card_close(); ?>
