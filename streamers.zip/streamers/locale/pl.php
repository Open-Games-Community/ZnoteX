<?php

return array(
	'streamers.title' => 'Streamerzy',
	'streamers.live' => 'NA ŻYWO',
	'streamers.offline' => 'Offline',
	'streamers.live_now' => 'na żywo',
	'streamers.code' => 'Kod: {c}',
);
