<?php

return array(
	'streamers.title' => 'Streamer',
	'streamers.live' => 'LIVE',
	'streamers.offline' => 'Offline',
	'streamers.live_now' => 'live',
	'streamers.code' => 'Code: {c}',
);
