<?php

return array(
	'streamers.title' => 'Streamers',
	'streamers.live' => 'EN VIVO',
	'streamers.offline' => 'Desconectado',
	'streamers.live_now' => 'en vivo',
	'streamers.code' => 'Código: {c}',
);
