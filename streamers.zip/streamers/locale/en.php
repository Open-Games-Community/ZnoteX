<?php

return array(
	'streamers.title' => 'Streamers',
	'streamers.live' => 'LIVE',
	'streamers.offline' => 'Offline',
	'streamers.live_now' => 'live',
	'streamers.code' => 'Code: {c}',
);
