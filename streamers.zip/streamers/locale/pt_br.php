<?php

return array(
	'streamers.title' => 'Streamers',
	'streamers.live' => 'AO VIVO',
	'streamers.offline' => 'Offline',
	'streamers.live_now' => 'ao vivo',
	'streamers.code' => 'Código: {c}',
);
