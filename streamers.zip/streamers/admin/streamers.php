<?php
/**
 * Title: Streamers
 * Icon: fa-video-camera
 * Group: Installed Plugins
 * Order: 42
 * Description: The streamer list, where the front-page box sits, and its colours.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'streamers__streamers';
$get = static fn(string $k, string $d = '') => (string) setting('streamers:' . $k, $d);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? 'config');

	if ($do === 'save_row') {
		$id   = intv($_POST['id'] ?? 0);
		$name = substr(trim((string) ($_POST['name'] ?? '')), 0, 64);
		$plat = in_array($_POST['platform'] ?? '', streamers_platforms(), true) ? (string) $_POST['platform'] : 'twitch';
		$chan = substr(trim((string) ($_POST['channel'] ?? '')), 0, 96);
		$ava  = substr(trim((string) ($_POST['avatar'] ?? '')), 0, 255);
		$promo= substr(trim((string) ($_POST['promo'] ?? '')), 0, 64);
		$sort = intv($_POST['sort_order'] ?? 0);
		$act  = !empty($_POST['active']) ? 1 : 0;
		if ($name !== '' && $chan !== '') {
			$n = esc($name); $c = esc($chan); $a = esc($ava); $pr = esc($promo); $p = esc($plat);
			if ($id > 0) {
				mysql_update("UPDATE `znote_streamers` SET `name`='{$n}',`platform`='{$p}',`channel`='{$c}',`avatar`='{$a}',`promo`='{$pr}',`sort_order`={$sort},`active`={$act} WHERE `id`={$id} LIMIT 1;");
			} else {
				mysql_insert("INSERT INTO `znote_streamers` (`name`,`platform`,`channel`,`avatar`,`promo`,`sort_order`,`active`) VALUES ('{$n}','{$p}','{$c}','{$a}','{$pr}',{$sort},{$act});");
			}
		}
		setting_set('streamers:cache', ''); setting_set('streamers:cache_at', '0');
		acp_flash_success('Streamer saved.');
		acp_redirect($module);
	}

	if ($do === 'delete_row') {
		$id = intv($_POST['id'] ?? 0);
		if ($id > 0) mysql_delete("DELETE FROM `znote_streamers` WHERE `id`={$id} LIMIT 1;");
		setting_set('streamers:cache', ''); setting_set('streamers:cache_at', '0');
		acp_flash_success('Streamer removed.');
		acp_redirect($module);
	}

	// config
	setting_set('streamers:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('streamers:title', substr(trim((string) ($_POST['title'] ?? '')), 0, 60));
	$positions = array('above_news', 'below_news', 'above_changelog', 'below_changelog', 'before_footer', 'top', 'bottom', 'custom');
	setting_set('streamers:position', in_array($_POST['position'] ?? '', $positions, true) ? (string) $_POST['position'] : 'above_news');
	setting_set('streamers:custom_selector', substr(trim((string) ($_POST['custom_selector'] ?? '')), 0, 120));
	setting_set('streamers:custom_where', ($_POST['custom_where'] ?? 'before') === 'after' ? 'after' : 'before');
	setting_set('streamers:poll_seconds', (string) max(0, min(600, intv($_POST['poll_seconds'] ?? 90))));
	setting_set('streamers:cache_ttl', (string) max(30, min(1800, intv($_POST['cache_ttl'] ?? 120))));
	setting_set('streamers:twitch_client_id', substr(trim((string) ($_POST['twitch_client_id'] ?? '')), 0, 80));
	if (trim((string) ($_POST['twitch_client_secret'] ?? '')) !== '') {
		setting_set('streamers:twitch_client_secret', substr(trim((string) $_POST['twitch_client_secret']), 0, 120));
		setting_set('streamers:tw_token', ''); setting_set('streamers:tw_token_exp', '0');
	}
	foreach (array('box_bg', 'border', 'text', 'accent', 'live', 'head_bg', 'head_text') as $k) {
		$v = trim((string) ($_POST['style_' . $k] ?? ''));
		setting_set('streamers:style_' . $k, streamers_css_val($v));
	}
	setting_set('streamers:cache', ''); setting_set('streamers:cache_at', '0');
	if (function_exists('acp_log')) acp_log('streamers.config', '');
	acp_flash_success('Streamers saved.');
	acp_redirect($module);
}

$rows = mysql_select_multi("SELECT * FROM `znote_streamers` ORDER BY `sort_order` ASC, `name` ASC;");
$rows = is_array($rows) ? $rows : array();
$edit = null;
if (isset($_GET['edit'])) {
	$e = intv($_GET['edit']);
	foreach ($rows as $r) if ((int) $r['id'] === $e) $edit = $r;
}
$twProbe = function_exists('streamers_twitch_probe') ? streamers_twitch_probe() : 'not_set';
$twOk = $twProbe === 'ok';
$live = ($twOk && streamers_enabled()) ? streamers_data(true) : array();
$nLive = count(array_filter($live, static fn($i) => !empty($i['live'])));
?>
<?php acp_card_open('Streamers', 'A front-page box of the server\'s streamers with left/right arrows. Twitch shows a live badge + viewers + thumbnail (needs a Twitch app id + secret from <code>dev.twitch.tv/console/apps</code>); YouTube / Kick show a Watch card. Works on every layout.'); ?>

<?php if ($twOk): ?>
	<p class="acp-muted" style="margin:-6px 0 14px"><?= (int) $nLive ?> live right now <span class="acp-muted">(Twitch credentials OK)</span>.</p>
<?php elseif ($twProbe === 'not_set'): ?>
	<p class="acp-muted" style="margin:-6px 0 14px"><b style="color:#c0392b">Twitch Client ID / Secret not set</b> — Twitch channels show as offline cards, YouTube / Kick still work. Both come from <code>dev.twitch.tv/console/apps</code> (Client ID is the long string on the app page, <b>not</b> your Twitch name; press "New Secret" for the secret). The OAuth Redirect URL there can be anything, e.g. <code>http://localhost</code> — it is not used.</p>
<?php else: ?>
	<p class="acp-muted" style="margin:-6px 0 14px"><b style="color:#c0392b">Twitch rejected the credentials</b> — <?= h($twProbe) ?>. Check the Client ID (the long string on the app page at <code>dev.twitch.tv/console/apps</code>, not your Twitch username) and generate a fresh secret.</p>
<?php endif; ?>

<form method="post"><?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label">Box title</label><input class="acp-input" name="title" value="<?= h($get('title')) ?>" placeholder="Streamers"></div>
		<div class="acp-field"><label class="acp-label">Place on the front page</label><select class="acp-select" name="position">
			<?php foreach (array('above_news'=>'Above the news','below_news'=>'Below the news','above_changelog'=>'Above the changelog','below_changelog'=>'Below the changelog','before_footer'=>'Just before the footer','top'=>'Page top','bottom'=>'Page bottom','custom'=>'Custom CSS selector') as $v=>$lbl): ?>
			<option value="<?= $v ?>" <?= $get('position','above_news') === $v ? 'selected' : '' ?>><?= h($lbl) ?></option>
			<?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label">Custom selector <span class="acp-muted">(only for "Custom")</span></label>
			<div style="display:flex;gap:6px"><select class="acp-select" name="custom_where" style="width:auto">
				<option value="before" <?= $get('custom_where','before') !== 'after' ? 'selected' : '' ?>>before</option>
				<option value="after" <?= $get('custom_where') === 'after' ? 'selected' : '' ?>>after</option>
			</select><input class="acp-input" name="custom_selector" value="<?= h($get('custom_selector')) ?>" placeholder=".home-news, #changelog"></div>
		</div>
		<div class="acp-field"><label class="acp-label">Live-status refresh on the page (seconds, 0 = off)</label><input class="acp-input" type="number" min="0" max="600" name="poll_seconds" value="<?= (int) $get('poll_seconds','90') ?>"></div>
		<div class="acp-field"><label class="acp-label">Server-side cache (seconds)</label><input class="acp-input" type="number" min="30" max="1800" name="cache_ttl" value="<?= (int) $get('cache_ttl','120') ?>"></div>
	</div>

	<h3>Twitch app <span class="acp-muted">(free — <code>dev.twitch.tv/console/apps</code>, any OAuth redirect, category "Website")</span></h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Client ID</label><input class="acp-input" name="twitch_client_id" value="<?= h($get('twitch_client_id')) ?>"></div>
		<div class="acp-field"><label class="acp-label">Client secret <span class="acp-muted">(leave blank to keep)</span></label><input class="acp-input" type="password" name="twitch_client_secret" value="" placeholder="<?= trim($get('twitch_client_secret')) !== '' ? '••••••••' : '' ?>"></div>
	</div>

	<h3>Colours <span class="acp-muted">(blank = inherit the layout)</span></h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg'=>'Box background','border'=>'Border','text'=>'Text','accent'=>'Accent','live'=>'Live badge','head_bg'=>'Header background','head_text'=>'Header text') as $k=>$lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>" placeholder="#9147ff"></div>
		<?php endforeach; ?>
	</div>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save settings</button></div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open($edit ? 'Edit streamer' : 'Add a streamer', 'Channel = the Twitch/Kick username, or a YouTube handle / channel id / full URL. Avatar is optional — Twitch fills it automatically.'); ?>
<form method="post"><?= acp_csrf_field() ?>
	<input type="hidden" name="do" value="save_row">
	<input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Name</label><input class="acp-input" name="name" value="<?= h($edit['name'] ?? '') ?>" required></div>
		<div class="acp-field"><label class="acp-label">Platform</label><select class="acp-select" name="platform">
			<?php foreach (streamers_platforms() as $p): ?><option value="<?= $p ?>" <?= ($edit['platform'] ?? 'twitch') === $p ? 'selected' : '' ?>><?= h(ucfirst($p)) ?></option><?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label">Channel</label><input class="acp-input" name="channel" value="<?= h($edit['channel'] ?? '') ?>" placeholder="mychannel" required></div>
		<div class="acp-field"><label class="acp-label">Avatar URL <span class="acp-muted">(optional)</span></label><input class="acp-input" name="avatar" value="<?= h($edit['avatar'] ?? '') ?>"></div>
		<div class="acp-field"><label class="acp-label">Promo code <span class="acp-muted">(optional)</span></label><input class="acp-input" name="promo" value="<?= h($edit['promo'] ?? '') ?>"></div>
		<div class="acp-field"><label class="acp-label">Sort order</label><input class="acp-input" type="number" name="sort_order" value="<?= (int) ($edit['sort_order'] ?? 0) ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="active" value="1" <?= (int) ($edit['active'] ?? 1) === 1 ? 'checked' : '' ?>> Active</label></div>
	</div>
	<div class="acp-actions">
		<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $edit ? 'Save' : 'Add' ?></button>
		<?php if ($edit): ?><a class="acp-btn acp-btn--ghost" href="<?= h(acp_url($module)) ?>">Cancel</a><?php endif; ?>
	</div>
</form>

<?php if ($rows): ?>
	<div class="acp-table-wrap"><table class="acp-table">
		<thead><tr><th>#</th><th>Name</th><th>Platform</th><th>Channel</th><th>Promo</th><th>Active</th><th></th></tr></thead>
		<tbody>
		<?php foreach ($rows as $r): ?>
			<tr>
				<td><?= (int) $r['sort_order'] ?></td>
				<td><?= h($r['name']) ?></td>
				<td><?= h(ucfirst($r['platform'])) ?></td>
				<td><?= h($r['channel']) ?></td>
				<td><?= h($r['promo']) ?></td>
				<td><?= (int) $r['active'] === 1 ? 'yes' : 'no' ?></td>
				<td style="white-space:nowrap">
					<a class="acp-btn acp-btn--sm" href="<?= h(acp_url($module, array('edit' => (int) $r['id']))) ?>">Edit</a>
					<form method="post" style="display:inline" data-confirm="Remove <?= h($r['name']) ?>?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete_row"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="acp-btn acp-btn--sm acp-btn--red" type="submit">Delete</button></form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
<?php else: ?>
	<p class="acp-muted">No streamers yet.</p>
<?php endif; ?>
