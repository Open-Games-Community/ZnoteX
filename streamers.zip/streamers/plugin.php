<?php
/**
 * Streamers - a front-page box of the server's streamers.
 *
 * The box HTML + a small relocation script go out through page.footer; the
 * script moves the box next to the changelog / news / footer on any layout.
 * Twitch live status is fetched with a free app token (client id + secret in
 * the admin panel) and cached; other platforms just show a Watch card.
 */
if (!function_exists('streamers_setting')) {

function streamers_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('streamers:' . $k, $d) : $d;
}
function streamers_int(string $k, int $d): int { $v = streamers_setting($k, ''); return $v === '' ? $d : (int) $v; }
function streamers_enabled(): bool { return streamers_setting('enabled', '1') === '1'; }
function streamers_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function streamers_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function streamers_tables_ok(): bool { return function_exists('znote_table_exists') && znote_table_exists('znote_streamers'); }
function streamers_platforms(): array { return array('twitch', 'youtube', 'kick'); }

/** bare channel login from whatever the admin typed (URL, @handle, plain). */
function streamers_channel_slug(string $ch): string {
	$ch = trim($ch);
	if (preg_match('~(?:twitch\.tv|kick\.com|youtube\.com)/(?:channel/|c/|@)?([^/?\s#]+)~i', $ch, $m)) $ch = $m[1];
	return strtolower(ltrim($ch, '@/'));
}

// --- data ------------------------------------------------------------
function streamers_list(): array {
	if (!streamers_tables_ok()) return array();
	$rows = mysql_select_multi("SELECT `id`,`name`,`platform`,`channel`,`avatar`,`promo` FROM `znote_streamers` WHERE `active` = 1 ORDER BY `sort_order` ASC, `name` ASC LIMIT 60;");
	return is_array($rows) ? $rows : array();
}

function streamers_http(string $url, array $headers = array(), $post = null) {
	if (!function_exists('curl_init')) return null;
	$ch = curl_init($url);
	curl_setopt_array($ch, array(
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_TIMEOUT        => 6,
		CURLOPT_CONNECTTIMEOUT => 4,
		CURLOPT_HTTPHEADER     => $headers,
		CURLOPT_SSL_VERIFYPEER => true,
	));
	if (function_exists('znote_cainfo')) { $ca = znote_cainfo(); if ($ca !== '') curl_setopt($ch, CURLOPT_CAINFO, $ca); }
	if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
	$body = curl_exec($ch);
	$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	if ($body === false || $code < 200 || $code >= 300) return null;
	$json = json_decode((string) $body, true);
	return is_array($json) ? $json : null;
}

/** Cached Twitch app access token. */
function streamers_twitch_token(): string {
	$id  = trim(streamers_setting('twitch_client_id', ''));
	$sec = trim(streamers_setting('twitch_client_secret', ''));
	if ($id === '' || $sec === '') return '';
	$tok = streamers_setting('tw_token', '');
	$exp = streamers_int('tw_token_exp', 0);
	if ($tok !== '' && $exp > time() + 120) return $tok;
	$res = streamers_http('https://id.twitch.tv/oauth2/token', array(), array(
		'client_id' => $id, 'client_secret' => $sec, 'grant_type' => 'client_credentials',
	));
	if (!is_array($res) || empty($res['access_token'])) return '';
	if (function_exists('setting_set')) {
		setting_set('streamers:tw_token', (string) $res['access_token']);
		setting_set('streamers:tw_token_exp', (string) (time() + max(300, (int) ($res['expires_in'] ?? 3600))));
	}
	return (string) $res['access_token'];
}

/** Human check of the Twitch credentials for the admin panel. */
function streamers_twitch_probe(): string {
	$id  = trim(streamers_setting('twitch_client_id', ''));
	$sec = trim(streamers_setting('twitch_client_secret', ''));
	if ($id === '' || $sec === '') return 'not_set';
	$ch = curl_init('https://id.twitch.tv/oauth2/token');
	curl_setopt_array($ch, array(
		CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_POST => true,
		CURLOPT_POSTFIELDS => http_build_query(array('client_id' => $id, 'client_secret' => $sec, 'grant_type' => 'client_credentials')),
		CURLOPT_SSL_VERIFYPEER => true,
	));
	if (function_exists('znote_cainfo')) { $ca = znote_cainfo(); if ($ca !== '') curl_setopt($ch, CURLOPT_CAINFO, $ca); }
	$body = curl_exec($ch);
	$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$err  = curl_error($ch);
	curl_close($ch);
	if ($body === false) return 'network: ' . ($err !== '' ? $err : 'no response');
	$j = json_decode((string) $body, true);
	if ($code >= 200 && $code < 300 && !empty($j['access_token'])) return 'ok';
	return 'twitch: ' . (is_array($j) && isset($j['message']) ? $j['message'] : 'HTTP ' . $code);
}

/** login(lower) => ['live'=>bool,'viewers'=>int,'title'=>str,'game'=>str,'thumb'=>str,'avatar'=>str] */
function streamers_twitch_status(array $logins): array {
	$out = array();
	$logins = array_values(array_unique(array_filter(array_map(static fn($l) => strtolower(trim($l)), $logins))));
	if (!$logins) return $out;
	$id  = trim(streamers_setting('twitch_client_id', ''));
	$tok = streamers_twitch_token();
	if ($id === '' || $tok === '') return $out;
	$hdr = array('Client-Id: ' . $id, 'Authorization: Bearer ' . $tok);

	foreach (array_chunk($logins, 100) as $chunk) {
		$q = implode('&', array_map(static fn($l) => 'user_login=' . rawurlencode($l), $chunk));
		$streams = streamers_http('https://api.twitch.tv/helix/streams?' . $q, $hdr);
		foreach ((array) ($streams['data'] ?? array()) as $s) {
			$out[strtolower((string) $s['user_login'])] = array(
				'live'    => true,
				'viewers' => (int) ($s['viewer_count'] ?? 0),
				'title'   => (string) ($s['title'] ?? ''),
				'game'    => (string) ($s['game_name'] ?? ''),
				'thumb'   => str_replace(array('{width}', '{height}'), array('440', '248'), (string) ($s['thumbnail_url'] ?? '')),
			);
		}
		$q = implode('&', array_map(static fn($l) => 'login=' . rawurlencode($l), $chunk));
		$users = streamers_http('https://api.twitch.tv/helix/users?' . $q, $hdr);
		foreach ((array) ($users['data'] ?? array()) as $u) {
			$k = strtolower((string) $u['login']);
			if (!isset($out[$k])) $out[$k] = array('live' => false);
			$out[$k]['avatar'] = (string) ($u['profile_image_url'] ?? '');
		}
	}
	return $out;
}

/** merged, cached list for rendering / polling */
function streamers_data(bool $fresh = false): array {
	if (!$fresh) {
		$ttl = max(30, streamers_int('cache_ttl', 120));
		$at  = streamers_int('cache_at', 0);
		$raw = streamers_setting('cache', '');
		if ($raw !== '' && (time() - $at) < $ttl) {
			$dec = json_decode($raw, true);
			if (is_array($dec)) return $dec;
		}
	}
	$rows = streamers_list();
	$tw = streamers_twitch_status(array_map(static fn($r) => streamers_channel_slug((string) $r['channel']), array_filter($rows, static fn($r) => $r['platform'] === 'twitch')));

	$out = array();
	foreach ($rows as $r) {
		$plat = in_array($r['platform'], streamers_platforms(), true) ? $r['platform'] : 'twitch';
		$ch   = trim((string) $r['channel']);
		$item = array(
			'name'    => (string) $r['name'],
			'platform'=> $plat,
			'url'     => streamers_channel_url($plat, $ch),
			'avatar'  => (string) $r['avatar'],
			'promo'   => (string) $r['promo'],
			'live'    => false, 'viewers' => 0, 'title' => '', 'game' => '', 'thumb' => '',
		);
		if ($plat === 'twitch' && isset($tw[streamers_channel_slug($ch)])) {
			$s = $tw[streamers_channel_slug($ch)];
			$item['live']    = !empty($s['live']);
			$item['viewers'] = (int) ($s['viewers'] ?? 0);
			$item['title']   = (string) ($s['title'] ?? '');
			$item['game']    = (string) ($s['game'] ?? '');
			$item['thumb']   = (string) ($s['thumb'] ?? '');
			if ($item['avatar'] === '' && !empty($s['avatar'])) $item['avatar'] = (string) $s['avatar'];
		}
		$out[] = $item;
	}
	// live first
	usort($out, static fn($a, $b) => ($b['live'] <=> $a['live']) ?: ($b['viewers'] <=> $a['viewers']));

	if (function_exists('setting_set')) {
		setting_set('streamers:cache', (string) json_encode($out));
		setting_set('streamers:cache_at', (string) time());
	}
	return $out;
}
function streamers_channel_url(string $plat, string $ch): string {
	$ch = ltrim(trim($ch), '@/');
	if (preg_match('#^https?://#i', $ch)) return $ch;
	if ($plat === 'youtube') return $ch === '' ? '' : 'https://www.youtube.com/' . (strpos($ch, 'UC') === 0 ? 'channel/' : '@') . $ch;
	if ($plat === 'kick')    return $ch === '' ? '' : 'https://kick.com/' . $ch;
	return $ch === '' ? '' : 'https://www.twitch.tv/' . $ch;
}

// --- polling endpoint ---------------------------------------------
function streamers_handle_ajax(): void {
	if (($_GET['streamers_json'] ?? '') === '' || headers_sent()) return;
	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: application/json; charset=utf-8');
	header('Cache-Control: no-store');
	echo json_encode(array('items' => streamers_enabled() ? streamers_data() : array()));
	exit;
}

// --- style -------------------------------------------------------
function streamers_css_val(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function streamers_style_attr(): string {
	$map = array('box_bg' => '--st-surface', 'border' => '--st-border', 'text' => '--st-text', 'accent' => '--st-accent', 'live' => '--st-live', 'head_bg' => '--st-head-bg', 'head_text' => '--st-head-text');
	$css = '';
	foreach ($map as $k => $var) { $v = streamers_css_val(streamers_setting('style_' . $k, '')); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	return $css !== '' ? ' style="' . streamers_h($css) . '"' : '';
}

// --- footer hook -----------------------------------------------
function streamers_footer(): string {
	if (!streamers_enabled()) return '';
	if (basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')) !== 'index.php') return '';
	if (isset($_GET['view']) || isset($_GET['id'])) return ''; // single-article view
	$items = streamers_data();
	if (!$items) return '';

	$title = streamers_h(trim(streamers_setting('title', '')) !== '' ? streamers_setting('title', '') : streamers_t('streamers.title', 'Streamers'));
	$pos   = streamers_setting('position', 'above_news');
	$poll  = max(0, streamers_int('poll_seconds', 90));
	$h     = 'streamers_h';

	$plIco = static function (string $p): string {
		if ($p === 'youtube') return '<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8M9.5 15.6V8.4l6.3 3.6z"/></svg>';
		if ($p === 'kick')    return '<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M3 3h5v6l4-6h6l-6 9 6 9h-6l-4-6v6H3z"/></svg>';
		return '<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M4 3 3 6v13h4v2h3l2-2h3l4-4V3zm14 10-3 3h-4l-2 2v-2H7V5h11zM13 8h2v4h-2zm-4 0h2v4H9z"/></svg>';
	};

	$cards = '';
	foreach ($items as $s) {
		$live = !empty($s['live']);
		$cards .= '<a class="st-card' . ($live ? ' is-live' : '') . '" href="' . $h($s['url']) . '" target="_blank" rel="noopener">'
			. '<div class="st-card__top">'
			. ($s['thumb'] !== '' && $live ? '<img class="st-card__thumb" src="' . $h($s['thumb']) . '" alt="" loading="lazy">' : '<span class="st-card__thumb st-card__thumb--ph">' . $plIco($s['platform']) . '</span>')
			. ($live ? '<span class="st-badge">' . $h(streamers_t('streamers.live', 'LIVE')) . '</span>' : '')
			. ($live && $s['viewers'] > 0 ? '<span class="st-viewers">' . number_format($s['viewers']) . '</span>' : '')
			. '</div>'
			. '<div class="st-card__body">'
			. '<span class="st-card__ava">' . ($s['avatar'] !== '' ? '<img src="' . $h($s['avatar']) . '" alt="" loading="lazy">' : $plIco($s['platform'])) . '</span>'
			. '<span class="st-card__meta"><b class="st-card__name">' . $h($s['name']) . '</b>'
			. '<span class="st-card__sub">' . ($live && $s['game'] !== '' ? $h($s['game']) : ($live && $s['title'] !== '' ? $h($s['title']) : $h(streamers_t('streamers.offline', 'Offline')))) . '</span></span>'
			. '</div>'
			. ($s['promo'] !== '' ? '<span class="st-card__promo">' . $h(streamers_t('streamers.code', 'Code: {c}', array('c' => $s['promo']))) . '</span>' : '')
			. '</a>';
	}

	$css = '#stBox{--st-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(24,27,34))))))));--st-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--st-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--st-accent:var(--accent,var(--link,#9147ff));--st-live:#e5484d;--st-head-bg:var(--st-accent);--st-head-text:#fff;--st-radius:12px;color:var(--st-text);font-size:13px;margin:0 0 20px}'
		. '#stBox *{box-sizing:border-box}'
		. '#stBox .st-inner{border:1px solid var(--st-border);border-radius:var(--st-radius);background:var(--st-surface);overflow:hidden}'
		. '#stBox .st-head{display:flex;align-items:center;gap:8px;padding:9px 14px;background:var(--st-head-bg);color:var(--st-head-text);font-weight:800;font-size:11.5px;text-transform:uppercase;letter-spacing:.06em}'
		. '#stBox .st-head .st-count{margin-left:auto;font-weight:600;opacity:.85;font-size:11px}'
		. '#stBox .st-wrap{position:relative;padding:12px}'
		. '#stBox .st-scroll{display:flex;gap:10px;overflow-x:auto;scroll-behavior:smooth;scrollbar-width:thin;padding:2px}'
		. '#stBox .st-scroll::-webkit-scrollbar{height:8px}#stBox .st-scroll::-webkit-scrollbar-thumb{background:var(--st-border);border-radius:8px}'
		. '#stBox .st-card{flex:0 0 240px;display:flex;flex-direction:column;border:1px solid var(--st-border);border-radius:10px;overflow:hidden;background:rgba(255,255,255,.02);color:inherit;text-decoration:none;transition:border-color .15s}'
		. '#stBox .st-card:hover{border-color:var(--st-accent)}'
		. '#stBox .st-card.is-live{border-color:color-mix(in srgb,var(--st-live) 55%,var(--st-border))}'
		. '#stBox .st-card__top{position:relative;aspect-ratio:16/9;background:#000}'
		. '#stBox .st-card__thumb{width:100%;height:100%;object-fit:cover;display:block}'
		. '#stBox .st-card__thumb--ph{display:flex;align-items:center;justify-content:center;color:var(--st-accent);opacity:.5;background:rgba(255,255,255,.03)}#stBox .st-card__thumb--ph svg{width:34px;height:34px}'
		. '#stBox .st-badge{position:absolute;top:8px;left:8px;background:var(--st-live);color:#fff;font-weight:800;font-size:10px;letter-spacing:.04em;padding:2px 6px;border-radius:4px}'
		. '#stBox .st-viewers{position:absolute;bottom:8px;left:8px;background:rgba(0,0,0,.7);color:#fff;font-size:11px;font-weight:700;padding:2px 6px;border-radius:4px}'
		. '#stBox .st-card__body{display:flex;align-items:center;gap:9px;padding:9px 10px;min-width:0}'
		. '#stBox .st-card__ava{flex:0 0 auto;width:34px;height:34px;border-radius:50%;overflow:hidden;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;color:var(--st-accent)}#stBox .st-card__ava img{width:100%;height:100%;object-fit:cover}'
		. '#stBox .st-card__meta{min-width:0;display:flex;flex-direction:column;line-height:1.2}'
		. '#stBox .st-card__name{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
		. '#stBox .st-card__sub{font-size:11px;opacity:.6;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
		. '#stBox .st-card__promo{padding:6px 10px;border-top:1px solid var(--st-border);font-size:11px;font-weight:700;color:var(--st-accent)}'
		. '#stBox .st-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:2;width:32px;height:32px;border-radius:50%;border:1px solid var(--st-border);background:var(--st-surface);color:var(--st-text);font:700 16px/1 system-ui,Arial;cursor:pointer;display:none;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,.25)}'
		. '#stBox.has-of .st-arrow{display:flex}#stBox .st-arrow--l{left:2px}#stBox .st-arrow--r{right:2px}#stBox .st-arrow[disabled]{opacity:.25;cursor:default}'
		. '@media(max-width:640px){#stBox .st-card{flex-basis:200px}}';

	$html = '<div id="stBox"' . streamers_style_attr() . '><div class="st-inner">'
		. '<div class="st-head"><span>' . $title . '</span><span class="st-count"><b data-st-n>' . count(array_filter($items, static fn($i) => !empty($i['live']))) . '</b> ' . $h(streamers_t('streamers.live_now', 'live')) . '</span></div>'
		. '<div class="st-wrap"><button type="button" class="st-arrow st-arrow--l" aria-label="left">&#8249;</button>'
		. '<div class="st-scroll" data-st-scroll>' . $cards . '</div>'
		. '<button type="button" class="st-arrow st-arrow--r" aria-label="right">&#8250;</button></div>'
		. '</div></div>';

	$customSel   = trim(streamers_setting('custom_selector', ''));
	$customWhere = streamers_setting('custom_where', 'before') === 'after' ? 'after' : 'before';

	$NEWS = json_encode(array('.postHolder', '.news__grid', '[data-news-pages]', '.news__pages', '.ec-news', '#news', '.znews', '.newsBox', '[class*="news" i]', 'article'));
	$CHG  = json_encode(array('#changelogTable', '.ts-changelog', '.zephyr-changelog', '[class*="changelog" i]', '[id*="changelog" i]', '[class*="ticker" i]'));
	$FOOT = json_encode(array('footer', '.footer', '#footer', '[class*="footer" i]'));
	$CONT = json_encode(array('.leftPane', '[data-news-pages]', '.ts-article-wrap', '.feedContainer', 'main', '[role="main"]', '#content', '.content', '.container .pull-left', '.container'));

	return '<style>' . $css . '</style>'
		. '<script>(function(){'
		. 'var HTML=' . json_encode($html) . ',P=' . json_encode($pos) . ',CS=' . json_encode($customSel) . ',CW=' . json_encode($customWhere) . ';'
		. 'var NEWS=' . $NEWS . ',CHG=' . $CHG . ',FOOT=' . $FOOT . ',CONT=' . $CONT . ';'
		. 'if(document.getElementById("stBox"))return;'
		. 'var w=document.createElement("div");w.innerHTML=HTML;var box=w.firstChild;'
		. 'function vis(el){return !!el&&(el.offsetParent!==null||el.getClientRects().length>0);}'
		. 'function pick(sels,last){var found=null;for(var i=0;i<sels.length;i++){var list;try{list=document.querySelectorAll(sels[i]);}catch(e){continue;}for(var j=0;j<list.length;j++){if(list[j]===box||list[j].contains(box)||!vis(list[j]))continue;found=list[j];if(!last)return found;}if(found)return found;}return found;}'
		. 'function blk(el){return (el&&el.closest&&el.closest(".well,.nz-panel,.postHolder,.ec-news,section,article,.box"))||el;}'
		. 'function ins(t,where){if(!t)return;if(where==="prepend")t.insertBefore(box,t.firstChild);else if(where==="append")t.appendChild(box);else if(t.parentNode)t.parentNode.insertBefore(box,where==="after"?t.nextSibling:t);}'
		. 'function place(){var t,n;'
		. 'if(P==="custom"&&CS){t=pick([CS],CW==="after");return ins(t,CW==="after"?"after":"before");}'
		. 'if(P==="above_news"){n=pick(NEWS,false);return ins(n?blk(n):pick(CONT,false),n?"before":"prepend");}'
		. 'if(P==="below_news"){n=pick(NEWS,true);return ins(n?blk(n):pick(CONT,false),n?"after":"append");}'
		. 'if(P==="above_changelog"){n=pick(CHG,false);return ins(n?blk(n):pick(CONT,false),n?"before":"prepend");}'
		. 'if(P==="below_changelog"){n=pick(CHG,true);return ins(n?blk(n):pick(CONT,false),n?"after":"prepend");}'
		. 'if(P==="before_footer"){n=pick(FOOT,false);return n?ins(n,"before"):ins(pick(CONT,false),"append");}'
		. 'if(P==="bottom"){return ins(pick(CONT,false)||document.body,"append");}'
		. 'return ins(pick(CONT,false)||document.body,"prepend");}'
		. 'place();'
		. 'var s=box.querySelector("[data-st-scroll]"),l=box.querySelector(".st-arrow--l"),r=box.querySelector(".st-arrow--r");'
		. 'function upd(){var of=s.scrollWidth-s.clientWidth-1;box.classList.toggle("has-of",of>0);l.disabled=s.scrollLeft<=0;r.disabled=s.scrollLeft>=of;}'
		. 'function step(d){s.scrollBy({left:d*Math.max(220,s.clientWidth*0.8),behavior:"smooth"});}'
		. 'l.addEventListener("click",function(){step(-1);});r.addEventListener("click",function(){step(1);});'
		. 's.addEventListener("scroll",upd);window.addEventListener("resize",upd);upd();'
		. ($poll > 0 ? 'setInterval(function(){fetch("?streamers_json=1",{credentials:"same-origin"}).then(function(x){return x.json();}).then(function(d){if(!d||!d.items)return;var lc=d.items.filter(function(i){return i.live;}).length;var n=box.querySelector("[data-st-n]");if(n)n.textContent=lc;}).catch(function(){});},' . ($poll * 1000) . ');' : '')
		. '}());</script>';
}

}

streamers_handle_ajax();
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'streamers_footer');
}
