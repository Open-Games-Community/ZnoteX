<?php
/**
 * Eclipse - front page (hero, news grid, features grid).
 *
 * Converted from the Flygard landing page. Prepared by index.php:
 * $news (array|false), $changelogs, $page, $view.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$bb = static function ($v): string { return function_exists('znote_bbcode_raw') ? znote_bbcode_raw((string)$v) : (string)$v; };
$ecSite   = (string)($config['site_name'] ?? theme_title());
$ecBanner = function_exists('theme_image') ? theme_image('banner_image', theme_asset('img/banner.jpg')) : theme_asset('img/banner.jpg');
$ecIp     = function_exists('theme_option') ? trim(theme_option('server_ip')) : '';
if ($ecIp === '') { $ecIp = (string)($config['server_ip'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost')); }
$ecWorld  = function_exists('theme_option') ? (theme_option('world_name') ?: 'Eclipse') : 'Eclipse';
$ecRates  = function_exists('theme_option') ? (theme_option('world_rates') ?: '') : '';
$online   = (int) (function_exists('user_count_online') ? user_count_online() : 0);

$firstImage = static function (string $text): string {
	if (preg_match('~\[img[^\]]*\]\s*([^\[\s]+)\s*\[/img\]~i', $text, $m)) return trim($m[1]);
	if (preg_match('~<img[^>]+src\s*=\s*["\']?([^"\'\s>]+)~i', $text, $m)) return trim($m[1]);
	return '';
};
$excerpt = static function ($text) use ($bb) {
	$p = trim(preg_replace('~\s+~', ' ', strip_tags($bb($text))));
	return function_exists('mb_strimwidth') ? mb_strimwidth($p, 0, 150, '…', 'UTF-8') : (strlen($p) > 150 ? substr($p, 0, 149) . '…' : $p);
};
$newsItems = (is_array($news ?? null)) ? array_values($news) : array();

// -------------------------------------------------------------------------
// Single article page: index.php?view=<id|title>  -> own page, then stop.
// -------------------------------------------------------------------------
if (($view ?? '') !== '') {
	$article = null;
	foreach ($newsItems as $row) {
		if ((ctype_digit((string)$view) && (int)$view === (int)$row['id']) || urlencode($row['title']) === $view) { $article = $row; break; }
	}
	$aImg   = $article ? $firstImage((string)$article['text']) : '';
	$aTitle = $article ? trim(strip_tags($bb($article['title']))) : t('news.not_found');
	$aLead  = $article ? $excerpt($article['text']) : '';
	?>
	<div class="max-w-4xl mx-auto space-y-4 sm:space-y-6">
		<div>
			<a href="index.php" class="group inline-flex items-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 text-slate-300 hover:text-amber-300 text-xs font-semibold transition-all backdrop-blur-md active:scale-95 shadow-sm">
				<i data-lucide="arrow-left" class="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-400 group-hover:-translate-x-0.5 transition-all"></i>
				<span><?= t('eclipse.news.all') ?></span>
			</a>
		</div>
		<article class="bg-[#030712] border border-slate-800/80 rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl">
			<div class="relative h-48 sm:h-64 md:h-80 w-full overflow-hidden bg-slate-950">
				<?php if ($aImg !== ''): ?>
					<img src="<?= $h($aImg) ?>" alt="" class="w-full h-full object-cover select-none">
				<?php else: ?>
					<span class="absolute inset-0 flex items-center justify-center font-brand text-7xl text-amber-500/20"><?= $h(function_exists('mb_substr') ? mb_substr($aTitle, 0, 1, 'UTF-8') : substr($aTitle, 0, 1)) ?></span>
				<?php endif; ?>
				<div class="absolute inset-0 bg-gradient-to-t from-[#030712] via-[#030712]/50 to-transparent pointer-events-none"></div>
				<?php if ($article): ?>
					<div class="absolute top-3 sm:top-4 left-3 sm:left-4">
						<span class="bg-amber-500 text-slate-950 text-[10px] sm:text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-sm font-mono"><?= t('eclipse.news.article') ?></span>
					</div>
				<?php endif; ?>
			</div>
			<div class="p-4 sm:p-6 md:p-8 space-y-4 sm:space-y-6">
				<?php if ($article): ?>
					<div class="flex items-center gap-2.5 sm:gap-3 text-[11px] sm:text-xs text-slate-400 border-b border-slate-800/80 pb-3 sm:pb-4">
						<span class="inline-flex items-center gap-1.5 font-mono"><i data-lucide="calendar" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i><time><?= $h(getClock((int)$article['date'], true)) ?></time></span>
						<span class="text-slate-600">•</span>
						<span class="inline-flex items-center gap-1.5 font-medium text-slate-300"><i data-lucide="user" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i><a href="characterprofile.php?name=<?= $h(urlencode($article['name'])) ?>"><?= $h($article['name']) ?></a></span>
					</div>
					<h1 class="font-brand text-lg sm:text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-tight"><?= $h($aTitle) ?></h1>
					<?php if ($aLead !== ''): ?><div class="p-3.5 sm:p-4 bg-slate-950/80 border-l-2 border-amber-500 rounded-r-xl sm:rounded-r-2xl text-slate-300 text-xs sm:text-sm font-medium leading-relaxed shadow-sm"><?= $h($aLead) ?></div><?php endif; ?>
					<div class="ec-article text-slate-300 text-xs sm:text-sm leading-relaxed space-y-4"><?= $bb($article['text']) ?></div>
				<?php else: ?>
					<h1 class="font-brand text-xl sm:text-2xl font-extrabold text-white"><?= t('news.not_found') ?></h1>
					<p class="text-slate-400 text-sm"><?= t('news.not_found_text') ?></p>
				<?php endif; ?>
			</div>
		</article>
	</div>
	<?php
	return;
}

// Changelog box (front-page ticker, if enabled).
$ecChangelog = array();
if (!empty($config['UseChangelogTicker']) && is_array($changelogs ?? null)) {
	$ecChangelog = array_slice($changelogs, 0, 5);
}

// The eight feature cards. Icon/title/text of each is editable in
// Admin Panel > Layouts > Eclipse; the locale strings are the fallback.
$featDefaults = array('key', 'scale', 'calendar-clock', 'sparkles', 'swords', 'home', 'graduation-cap', 'shirt');
$features = array();
for ($fi = 1; $fi <= 8; $fi++) {
	$fIcon  = function_exists('theme_option') ? trim(theme_option('feature_' . $fi . '_icon')) : '';
	$fTitle = function_exists('theme_option') ? trim(theme_option('feature_' . $fi . '_title')) : '';
	$fText  = function_exists('theme_option') ? trim(theme_option('feature_' . $fi . '_text')) : '';
	if ($fTitle === '') { $fTitle = t('eclipse.feat.' . $fi . '_title'); }
	if ($fText === '')  { $fText  = t('eclipse.feat.' . $fi . '_text'); }
	if ($fIcon === '')  { $fIcon  = $featDefaults[$fi - 1]; }
	// "-" as the title hides the card.
	if ($fTitle === '-' || $fTitle === 'eclipse.feat.' . $fi . '_title') { continue; }
	$features[] = array($fIcon, $fi === 1 ? 'purple' : 'amber', $fTitle, $fText);
}
?>
<div class="space-y-4 sm:space-y-6 md:space-y-8">

	<div class="relative overflow-hidden border border-slate-800/80 rounded-2xl sm:rounded-3xl bg-[#030712] shadow-2xl flex flex-col md:flex-row md:items-center min-h-[340px] sm:min-h-[380px] p-4 sm:p-6 md:p-8">
		<div class="absolute inset-0 z-0 overflow-hidden pointer-events-none">
			<img src="<?= $h($ecBanner) ?>" alt="<?= $h($ecSite) ?>" class="w-full h-full object-cover object-right md:object-center select-none">
			<div class="absolute inset-0 bg-gradient-to-t from-[#030712]/95 via-[#030712]/60 to-transparent md:bg-gradient-to-r md:from-[#030712]/95 md:via-[#030712]/70 md:to-transparent"></div>
		</div>

		<div class="relative z-10 w-full md:max-w-[480px] space-y-3.5 sm:space-y-4 mt-auto md:mt-0">
			<div class="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#030712]/80 backdrop-blur-md border border-amber-500/30 text-amber-300 text-[11px] sm:text-xs font-semibold tracking-wide shadow-sm">
				<span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
				<span><?= t('eclipse.hero.world_badge', ['world' => $h($ecWorld)]) ?></span>
			</div>
			<div class="drop-shadow-sm">
				<h1 class="font-brand text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight drop-shadow-md">
					<?= t('eclipse.hero.server') ?> <span class="bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 bg-clip-text text-transparent"><?= $h($ecSite) ?></span>
				</h1>
				<p class="text-slate-200 text-xs sm:text-sm mt-1.5 sm:mt-2 leading-relaxed font-normal drop-shadow"><?= t('eclipse.hero.tagline') ?></p>
			</div>

			<div class="space-y-2.5 sm:space-y-3 pt-1 w-full max-w-[440px]">
				<a href="register.php" class="group relative flex items-center justify-between w-full p-3 sm:px-5 sm:py-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold transition-all duration-300 shadow-[0_10px_30px_-8px_rgba(245,158,11,0.45)] active:scale-[0.99] border-t border-amber-200/60 overflow-hidden">
					<span class="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none"></span>
					<div class="flex items-center gap-2.5 sm:gap-3 min-w-0">
						<div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg sm:rounded-xl bg-slate-950/15 flex items-center justify-center border border-slate-950/10 shrink-0"><i data-lucide="user-plus" class="w-4 h-4 sm:w-5 sm:h-5"></i></div>
						<div class="text-left min-w-0">
							<div class="text-xs sm:text-sm md:text-base font-extrabold tracking-tight leading-tight truncate"><?= t('eclipse.hero.cta_title') ?></div>
							<div class="text-[10px] sm:text-[11px] text-slate-900/80 font-medium truncate"><?= t('eclipse.hero.cta_sub') ?></div>
						</div>
					</div>
					<div class="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-slate-950/10 flex items-center justify-center group-hover:translate-x-0.5 transition-transform shrink-0 ml-2"><i data-lucide="chevron-right" class="w-3.5 h-3.5 sm:w-4 sm:h-4"></i></div>
				</a>

				<div class="grid grid-cols-2 gap-1.5 sm:gap-2">
					<a href="downloads.php" class="group flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800/90 hover:border-amber-500/40 text-slate-200 hover:text-amber-300 text-[11px] sm:text-xs font-semibold transition-all shadow-sm backdrop-blur-md active:scale-95">
						<i data-lucide="download" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i><span class="truncate"><?= t('eclipse.nav.download') ?></span>
					</a>
					<a href="serverinfo.php" class="group flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800/90 hover:border-slate-700 text-slate-200 hover:text-white text-[11px] sm:text-xs font-semibold transition-all shadow-sm backdrop-blur-md active:scale-95">
						<i data-lucide="book-open" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i><span class="truncate"><?= t('nav.serverinfo') ?></span>
					</a>
				</div>

			</div>
		</div>
	</div>

	<div class="grid grid-cols-2 md:grid-cols-3 gap-2.5 sm:gap-3 items-stretch">
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 p-3 sm:p-4 rounded-xl sm:rounded-2xl flex items-center gap-2.5 sm:gap-3.5 shadow-sm min-h-[68px]">
			<div class="p-2 sm:p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg sm:rounded-xl text-amber-400 shrink-0"><i data-lucide="server" class="w-4 h-4 sm:w-5 sm:h-5"></i></div>
			<div class="min-w-0">
				<div class="text-slate-400 text-[10px] sm:text-xs font-medium leading-none mb-1"><?= t('eclipse.strip.world') ?></div>
				<div class="flex items-center gap-1.5 flex-wrap">
					<span class="text-white font-bold text-xs sm:text-sm tracking-tight truncate"><?= $h($ecWorld) ?></span>
					<?php if ($ecRates !== ''): ?><span class="inline-flex items-center px-1.5 rounded bg-amber-500/15 border border-amber-500/30 text-[10px] sm:text-[11px] font-mono font-bold text-amber-300"><?= $h($ecRates) ?></span><?php endif; ?>
				</div>
			</div>
		</div>
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 p-3 sm:p-4 rounded-xl sm:rounded-2xl flex items-center justify-between shadow-sm min-h-[68px]">
			<div class="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
				<div class="p-2 sm:p-2.5 bg-emerald-500/10 border-emerald-500/20 text-emerald-400 border rounded-lg sm:rounded-xl shrink-0 relative">
					<i data-lucide="users" class="w-4 h-4 sm:w-5 sm:h-5"></i>
					<span class="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
				</div>
				<div>
					<div class="text-slate-400 text-[10px] sm:text-xs font-medium leading-none mb-1"><?= t('eclipse.strip.online') ?></div>
					<div class="text-white font-bold text-xs sm:text-sm font-mono flex items-center gap-1"><span class="text-emerald-400"><?= number_format($online) ?></span></div>
				</div>
			</div>
			<span class="px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-semibold font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shrink-0 ml-1"><?= t('eclipse.strip.status_online') ?></span>
		</div>
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 p-3 sm:p-4 rounded-xl sm:rounded-2xl flex items-center gap-2.5 sm:gap-3.5 shadow-sm min-h-[68px] col-span-2 md:col-span-1">
			<div class="p-2 sm:p-2.5 bg-sky-500/10 border border-sky-500/20 rounded-lg sm:rounded-xl text-sky-400 shrink-0"><i data-lucide="trophy" class="w-4 h-4 sm:w-5 sm:h-5"></i></div>
			<div class="min-w-0">
				<div class="text-slate-400 text-[10px] sm:text-xs font-medium leading-none mb-1"><?= t('eclipse.strip.ranking') ?></div>
				<a href="highscores.php" class="text-amber-300 hover:text-amber-200 font-bold text-xs sm:text-sm tracking-tight"><?= t('eclipse.strip.ranking_link') ?> &rarr;</a>
			</div>
		</div>
	</div>

	<div class="bg-slate-900/90 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-4 sm:p-5 md:p-6 shadow-xl space-y-3.5 sm:space-y-4">
		<div class="flex items-center justify-between pb-3 border-b border-slate-800/80">
			<div class="flex items-center gap-2 sm:gap-2.5">
				<div class="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400"><i data-lucide="newspaper" class="w-4 h-4"></i></div>
				<div>
					<h2 class="text-sm sm:text-base font-bold text-white leading-tight font-brand"><?= t('eclipse.news.title') ?></h2>
					<p class="text-[10px] sm:text-[11px] text-slate-400"><?= t('eclipse.news.sub') ?></p>
				</div>
			</div>
		</div>

		<?php if ($newsItems): ?>
			<?php $ecPages = array_chunk(array_slice($newsItems, 0, 18), 3); ?>
			<div class="ec-news" data-ec-news>
				<div class="ec-news-track flex transition-transform duration-300 ease-out" data-ec-news-track>
					<?php foreach ($ecPages as $pi => $chunk): ?>
						<div class="ec-news-page shrink-0 w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4" data-ec-news-page="<?= $pi ?>">
							<?php foreach ($chunk as $item):
								$img = $firstImage((string)$item['text']);
								$title = trim(strip_tags($bb($item['title'])));
								$url = 'index.php?view=' . (int)$item['id'];
							?>
								<article class="group relative flex flex-col bg-slate-950 border border-amber-500/40 hover:border-amber-500/70 rounded-xl sm:rounded-2xl overflow-hidden shadow-md transition-all duration-300">
									<a href="<?= $h($url) ?>" class="relative h-32 sm:h-36 w-full overflow-hidden bg-slate-900 block">
										<?php if ($img !== ''): ?>
											<img src="<?= $h($img) ?>" alt="" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-85 group-hover:opacity-100" loading="lazy">
										<?php else: ?>
											<span class="absolute inset-0 flex items-center justify-center font-brand text-5xl text-amber-500/25"><?= $h(function_exists('mb_substr') ? mb_substr($title, 0, 1, 'UTF-8') : substr($title, 0, 1)) ?></span>
										<?php endif; ?>
										<div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent"></div>
									</a>
									<div class="p-3.5 sm:p-4 flex flex-col flex-grow space-y-1.5 sm:space-y-2">
										<div class="flex items-center gap-2 text-[10px] text-slate-400">
											<time class="font-mono"><?= $h(getClock((int)$item['date'], true)) ?></time><span>•</span><span class="truncate uppercase"><?= $h($item['name']) ?></span>
										</div>
										<h3 class="text-xs sm:text-sm font-semibold text-white group-hover:text-amber-400 transition-colors leading-snug line-clamp-2">
											<a href="<?= $h($url) ?>"><?= $h($title) ?></a>
										</h3>
										<p class="text-[11px] sm:text-xs text-slate-400 leading-relaxed flex-grow line-clamp-2"><?= $h($excerpt($item['text'])) ?></p>
										<div class="pt-2 border-t border-slate-800/80">
											<a href="<?= $h($url) ?>" class="text-[11px] sm:text-xs font-semibold text-amber-400 hover:text-amber-300 inline-flex items-center gap-1"><span><?= t('eclipse.news.read') ?></span><span>&rarr;</span></a>
										</div>
									</div>
								</article>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php if (count($ecPages) > 1): ?>
					<div class="flex items-center justify-center gap-2 pt-4" data-ec-news-pager>
						<button type="button" class="ec-news-arrow w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-amber-300 hover:border-amber-500/40 transition-all flex items-center justify-center" data-ec-news-dir="-1" aria-label="Previous"><i data-lucide="chevron-left" class="w-4 h-4"></i></button>
						<?php foreach ($ecPages as $pi => $chunk): ?>
							<button type="button" class="ec-news-dot w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono font-semibold text-slate-400 hover:text-amber-300 transition-all<?= $pi === 0 ? ' is-active' : '' ?>" data-ec-news-goto="<?= $pi ?>"><?= $pi + 1 ?></button>
						<?php endforeach; ?>
						<button type="button" class="ec-news-arrow w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-amber-300 hover:border-amber-500/40 transition-all flex items-center justify-center" data-ec-news-dir="1" aria-label="Next"><i data-lucide="chevron-right" class="w-4 h-4"></i></button>
					</div>
				<?php endif; ?>
			</div>
		<?php else: ?>
			<p class="text-sm text-slate-400"><?= t('news.none') ?></p>
		<?php endif; ?>
	</div>

	<?php if ($ecChangelog): ?>
	<div class="bg-slate-900/90 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-4 sm:p-5 md:p-6 shadow-xl">
		<div class="flex items-center gap-2 sm:gap-2.5 pb-3 mb-3 border-b border-slate-800/80">
			<div class="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"><i data-lucide="git-commit" class="w-4 h-4"></i></div>
			<h2 class="text-sm sm:text-base font-bold text-white leading-tight font-brand"><?= t('eclipse.changelog.title') ?></h2>
		</div>
		<ul class="divide-y divide-slate-800/70">
			<?php foreach ($ecChangelog as $cl):
				$clFull  = trim(strip_tags($bb($cl['text'])));
				$clShort = $excerpt($cl['text']);
				$clDate  = $h(getClock((int)$cl['time'], true, true));
				$clLong  = ($clFull !== '' && $clShort !== $clFull);
			?>
				<li class="py-2 sm:py-2.5 ec-cl-item">
					<?php if ($clLong): ?>
						<details class="ec-cl">
							<summary class="flex items-start gap-2.5 cursor-pointer text-xs sm:text-[13px] text-slate-300">
								<span class="ec-cl-mark mt-px w-4 h-4 shrink-0 rounded border border-slate-700 text-amber-400 font-bold leading-none flex items-center justify-center text-[13px]">+</span>
								<span class="font-mono text-amber-400 shrink-0"><?= $clDate ?></span>
								<span class="ec-cl-short text-white truncate"><?= $h($clShort) ?></span>
							</summary>
							<div class="ec-cl-full pl-[26px] pt-1 text-xs sm:text-[13px] text-slate-400 leading-relaxed ec-article"><?= $bb($cl['text']) ?></div>
						</details>
					<?php else: ?>
						<div class="flex items-start gap-2.5 text-xs sm:text-[13px] text-slate-300">
							<span class="mt-px w-4 h-4 shrink-0"></span>
							<span class="font-mono text-amber-400 shrink-0"><?= $clDate ?></span>
							<span class="text-white"><?= $h($clFull) ?></span>
						</div>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php endif; ?>

	<?php if ($features): ?>
	<div class="space-y-3 sm:space-y-4">
		<div class="flex items-center gap-2">
			<div class="p-1 sm:p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400"><i data-lucide="sparkles" class="w-3.5 h-3.5 sm:w-4 sm:h-4"></i></div>
			<h2 class="text-sm sm:text-base md:text-lg font-bold text-white tracking-tight font-brand"><?= t('eclipse.feat.title') ?></h2>
		</div>
		<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
			<?php foreach ($features as $f): [$icon, $c, $ft, $fx] = $f; ?>
				<div class="p-3.5 sm:p-4 bg-slate-950/70 border border-<?= $c ?>-500/30 hover:border-<?= $c ?>-500/60 rounded-xl sm:rounded-2xl transition-all group flex flex-col justify-between min-h-[130px] h-full">
					<div class="flex items-center gap-2.5 h-8 sm:h-9 shrink-0">
						<div class="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-<?= $c ?>-500/10 border border-<?= $c ?>-500/20 flex items-center justify-center text-<?= $c ?>-400 shrink-0 group-hover:scale-110 transition-transform"><i data-lucide="<?= $h($icon) ?>" class="w-3.5 h-3.5 sm:w-4 sm:h-4"></i></div>
						<h3 class="text-xs sm:text-sm font-semibold text-white group-hover:text-<?= $c ?>-300 transition-colors leading-tight"><?= $h($ft) ?></h3>
					</div>
					<p class="text-[11px] sm:text-[11.5px] text-slate-400 leading-relaxed mt-2"><?= $h($fx) ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php endif; ?>

</div>

