<?php
/**
 * Eclipse - downloads page. Rendered by downloads.php via view('downloads').
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$ecClientVer   = number_format(((int)$config['client']) / 100, 2);
$ecWin         = (string)$config['client_download'];
$ecLinux       = (string)$config['client_download_linux'];
$ecIpChanger   = 'https://github.com/jo3bingham/tibia-ip-changer/releases/latest';
$ecHost        = (string)($_SERVER['SERVER_NAME'] ?? 'localhost');

$ecSteps = array(
	array('download', t('downloads.step1')),
	array('settings-2', t('downloads.step2')),
	array('folder-open', t('downloads.step3')),
	array('server', t('downloads.step4') . ' ' . $h($ecHost)),
	array('check-circle', t('downloads.step5') . ' <strong>Apply</strong>. ' . t('downloads.step5b') . ' <a href="register.php" class="text-amber-400 hover:text-amber-300">' . t('downloads.here') . '</a>.'),
);
?>
<div class="max-w-4xl mx-auto space-y-4 sm:space-y-6">

	<div class="relative overflow-hidden border border-slate-800/80 rounded-2xl sm:rounded-3xl bg-[#030712] p-4 sm:p-6 md:p-8 shadow-2xl">
		<div class="absolute top-0 right-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
		<div class="relative z-10 flex items-center gap-3 sm:gap-4">
			<div class="p-2.5 sm:p-3.5 bg-gradient-to-br from-amber-500/20 to-amber-500/5 border border-amber-500/30 rounded-xl sm:rounded-2xl text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
				<i data-lucide="download-cloud" class="w-5 h-5 sm:w-6 sm:h-6"></i>
			</div>
			<div>
				<h1 class="font-brand text-lg sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
					<?= t('downloads.title') ?>
				</h1>
				<p class="text-[11px] sm:text-xs md:text-sm text-slate-300 font-normal mt-0.5"><?= t('downloads.intro') ?></p>
			</div>
		</div>
	</div>

	<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
		<a href="<?= $h($ecWin) ?>" class="group bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/90 hover:border-amber-500/50 rounded-xl sm:rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 shadow-lg transition-all active:scale-[0.99]">
			<div class="w-11 h-11 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 shrink-0"><i data-lucide="monitor" class="w-5 h-5"></i></div>
			<div class="min-w-0">
				<div class="text-sm font-bold text-white group-hover:text-amber-300 transition-colors"><?= t('downloads.win', ['version' => $h($ecClientVer)]) ?></div>
				<div class="text-[11px] text-slate-400 font-mono truncate"><?= t('downloads.here') ?> &rarr;</div>
			</div>
		</a>
		<a href="<?= $h($ecLinux) ?>" class="group bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/90 hover:border-amber-500/50 rounded-xl sm:rounded-2xl p-4 sm:p-5 flex items-center gap-3.5 shadow-lg transition-all active:scale-[0.99]">
			<div class="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0"><i data-lucide="terminal" class="w-5 h-5"></i></div>
			<div class="min-w-0">
				<div class="text-sm font-bold text-white group-hover:text-amber-300 transition-colors"><?= t('downloads.linux', ['version' => $h($ecClientVer)]) ?></div>
				<div class="text-[11px] text-slate-400 font-mono truncate"><?= t('downloads.here') ?> &rarr;</div>
			</div>
		</a>
	</div>

	<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 flex items-center gap-2.5 text-xs text-slate-400 shadow-sm">
		<div class="p-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0"><i data-lucide="git-fork" class="w-3.5 h-3.5"></i></div>
		<span class="leading-relaxed"><?= t('downloads.ipchanger') ?> <a href="<?= $h($ecIpChanger) ?>" class="text-amber-400 hover:text-amber-300"><?= t('downloads.here') ?></a>.</span>
	</div>

	<div class="bg-slate-900/90 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-4 sm:p-5 md:p-6 shadow-xl space-y-3.5">
		<div class="flex items-center gap-2.5 pb-3 border-b border-slate-800/80">
			<div class="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400"><i data-lucide="list-ordered" class="w-4 h-4"></i></div>
			<h2 class="text-sm sm:text-base font-bold text-white leading-tight font-brand"><?= t('downloads.howto') ?></h2>
		</div>
		<ol class="space-y-2.5">
			<?php foreach ($ecSteps as $i => $step): ?>
				<li class="flex items-start gap-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
					<span class="w-6 h-6 shrink-0 rounded-lg bg-slate-950 border border-slate-800 text-amber-400 font-mono font-bold text-[11px] flex items-center justify-center mt-px"><?= $i + 1 ?></span>
					<span><?= $step[1] ?></span>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</div>
