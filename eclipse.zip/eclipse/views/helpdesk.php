<?php
/**
 * Eclipse - helpdesk / support tickets.
 *
 * Rendered by the Eclipse shell (not by helpdesk.php, which is untouched) from
 * the variables it leaves in scope: $view, $ticketData, $replies, $tickets,
 * $account, $errors, $_GET, $config, $session_user_id.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$cardCls = 'bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl sm:rounded-3xl shadow-xl';

$hdView    = (isset($view) && $view !== false) ? (int) $view : 0;
$hdCreated = (isset($_GET['success']) && empty($_GET['success']));
$hdErrors  = (isset($errors) && is_array($errors)) ? $errors : array();
$hdTickets = (isset($tickets) && is_array($tickets)) ? $tickets : array();
$hdReplies = (isset($replies) && is_array($replies)) ? $replies : array();
$hdAccount = (isset($account) && is_array($account)) ? $account + array('name' => '', 'email' => '') : array('name' => '', 'email' => '');
$hdTicket  = (isset($ticketData) && is_array($ticketData)) ? $ticketData : null;
$hdOwned   = $hdTicket !== null && (int)($hdTicket['owner'] ?? -1) === (int)$session_user_id;
?>
<div class="space-y-4 sm:space-y-6 max-w-4xl mx-auto">

	<div class="relative overflow-hidden <?= $cardCls ?> p-4 sm:p-6 md:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
		<div class="absolute top-0 right-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
		<div class="relative z-10 flex items-center gap-3 sm:gap-4">
			<div class="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-500/5 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
				<i data-lucide="life-buoy" class="w-5 h-5 sm:w-6 sm:h-6"></i>
			</div>
			<div>
				<h1 class="font-brand text-lg sm:text-xl md:text-2xl font-extrabold text-white tracking-tight leading-tight">
					<?= t('eclipse.hd.title_a') ?> <span class="bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 bg-clip-text text-transparent"><?= t('eclipse.hd.title_b') ?></span>
				</h1>
				<p class="text-[11px] sm:text-xs text-slate-400 mt-1 font-normal"><?= t('eclipse.hd.subtitle') ?></p>
			</div>
		</div>
		<a href="<?= $hdView > 0 ? 'helpdesk.php' : 'myaccount.php' ?>" class="relative z-10 group inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 text-slate-300 hover:text-white text-xs font-semibold transition-all backdrop-blur-md active:scale-95 self-start sm:self-auto shadow-sm">
			<i data-lucide="arrow-left" class="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-400"></i>
			<span><?= $hdView > 0 ? t('eclipse.hd.new') : t('eclipse.hd.back') ?></span>
		</a>
	</div>

	<?php if ($hdView > 0 && !$hdOwned): ?>
		<div class="<?= $cardCls ?> p-6 text-center">
			<div class="w-12 h-12 mx-auto rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 mb-3"><i data-lucide="shield-x" class="w-6 h-6"></i></div>
			<p class="text-slate-300 text-sm"><?= t('helpdesk.no_access') ?></p>
		</div>
		<?php return; endif; ?>

	<?php if ($hdView > 0 && $hdOwned):
		$closed = ($hdTicket['status'] === 'CLOSED');
	?>
		<div class="<?= $cardCls ?> overflow-hidden">
			<div class="p-3.5 sm:p-4 border-b border-slate-800/80 bg-slate-950/70 flex items-center justify-between gap-3">
				<div class="flex items-center gap-2 min-w-0">
					<span class="font-mono text-amber-300 text-xs font-bold">#<?= (int)$hdTicket['id'] ?></span>
					<span class="text-sm font-semibold text-white truncate"><?= $h($hdTicket['subject']) ?></span>
				</div>
				<span class="shrink-0 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold <?= $closed ? 'bg-red-500/15 text-red-400 border border-red-500/30' : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' ?>"><?= $h($hdTicket['status']) ?></span>
			</div>
			<div class="divide-y divide-slate-800/60">
				<div class="p-3.5 sm:p-4">
					<div class="flex items-center gap-2 text-[11px] text-slate-400 mb-2 font-mono">
						<i data-lucide="user" class="w-3.5 h-3.5 text-amber-400"></i><span><?= $h($hdTicket['username']) ?></span>
						<span class="text-slate-600">•</span><span><?= $h(getClock($hdTicket['creation'], true)) ?></span>
					</div>
					<p class="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line"><?= $h($hdTicket['message']) ?></p>
				</div>
				<?php foreach ($hdReplies as $reply): ?>
					<div class="p-3.5 sm:p-4">
						<div class="flex items-center gap-2 text-[11px] text-slate-400 mb-2 font-mono">
							<i data-lucide="corner-down-right" class="w-3.5 h-3.5 text-slate-500"></i><span><?= $h($reply['username']) ?></span>
							<span class="text-slate-600">•</span><span><?= $h(getClock($reply['created'], true)) ?></span>
						</div>
						<p class="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line"><?= $h($reply['message']) ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<?php if (!$closed): ?>
			<form action="" method="post" class="<?= $cardCls ?> p-4 sm:p-5 space-y-3">
				<label class="text-xs font-semibold text-slate-300 flex items-center gap-1.5"><i data-lucide="message-square" class="w-3.5 h-3.5 text-amber-400"></i><?= t('helpdesk.reply') ?></label>
				<input type="hidden" name="username" value="<?= $h($hdTicket['username']) ?>">
				<textarea name="reply_text" rows="5" required class="w-full bg-[#030712] border border-slate-800 rounded-xl px-3.5 py-3 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/50 transition-all"></textarea>
				<button type="submit" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs transition-all active:scale-[0.98] border-t border-amber-200/60">
					<i data-lucide="send" class="w-3.5 h-3.5"></i><span><?= t('helpdesk.reply') ?></span>
				</button>
			</form>
		<?php endif; ?>
		<?php return; endif; ?>

	<div class="<?= $cardCls ?> p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs text-slate-400">
		<div class="flex items-center gap-2.5">
			<div class="p-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0"><i data-lucide="info" class="w-3.5 h-3.5"></i></div>
			<span class="text-[11px] sm:text-xs leading-relaxed"><?= t('eclipse.hd.info') ?></span>
		</div>
		<span class="font-mono text-amber-300 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-lg bg-[#030712] border border-slate-800/80 self-start sm:self-auto shrink-0"><?= t('eclipse.hd.total', ['count' => count($hdTickets)]) ?></span>
	</div>

	<?php if ($hdCreated): ?>
		<div class="<?= $cardCls ?> p-6 text-center">
			<div class="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-3"><i data-lucide="check-circle" class="w-6 h-6"></i></div>
			<p class="text-slate-300 text-sm"><?= t('helpdesk.created') ?></p>
		</div>
	<?php elseif (count($hdTickets) > 0): ?>
		<div class="<?= $cardCls ?> overflow-hidden">
			<div class="p-3.5 sm:p-4 border-b border-slate-800/80 bg-slate-950/70"><h2 class="text-xs font-bold text-white uppercase tracking-wider"><?= t('helpdesk.latest') ?></h2></div>
			<div class="divide-y divide-slate-800/60">
				<?php foreach ($hdTickets as $ticket): ?>
					<a href="helpdesk.php?view=<?= (int)$ticket['id'] ?>" class="flex items-center justify-between gap-3 p-3.5 sm:p-4 hover:bg-slate-800/40 transition-colors group">
						<div class="min-w-0">
							<div class="text-xs sm:text-sm font-semibold text-white group-hover:text-amber-300 transition-colors truncate"><span class="font-mono text-slate-500">#<?= (int)$ticket['id'] ?></span> <?= $h($ticket['subject']) ?></div>
							<div class="text-[11px] text-slate-500 font-mono mt-0.5"><?= $h(getClock($ticket['creation'], true)) ?></div>
						</div>
						<span class="shrink-0 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700"><?= $h($ticket['status']) ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	<?php else: ?>
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-dashed border-slate-800/80 rounded-2xl sm:rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center gap-3 shadow-xl">
			<div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400"><i data-lucide="message-square-off" class="w-6 h-6"></i></div>
			<p class="text-slate-400 text-xs font-normal leading-relaxed max-w-md"><?= t('eclipse.hd.empty') ?></p>
		</div>
	<?php endif; ?>

	<?php if (!$hdCreated): ?>
		<div class="<?= $cardCls ?> p-4 sm:p-5 md:p-6 space-y-3.5">
			<div class="flex items-center gap-2.5 pb-3 border-b border-slate-800/80">
				<div class="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400"><i data-lucide="plus-circle" class="w-4 h-4"></i></div>
				<h2 class="text-sm sm:text-base font-bold text-white leading-tight font-brand"><?= t('helpdesk.title') ?></h2>
			</div>

			<?php if (!empty($hdErrors)): ?>
				<div class="p-3 rounded-xl bg-red-500/10 border border-red-500/25 text-red-300 text-[11px] leading-snug space-y-1">
					<?php foreach ($hdErrors as $e): ?><div><?= $h(strip_tags((string)$e)) ?></div><?php endforeach; ?>
				</div>
			<?php endif; ?>

			<form action="" method="post" class="space-y-3">
				<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
					<div>
						<label class="block text-[11px] text-slate-400 mb-1.5">Account</label>
						<input type="text" value="<?= $h($hdAccount['name']) ?>" disabled class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-400 min-h-[40px]">
					</div>
					<div>
						<label class="block text-[11px] text-slate-400 mb-1.5">Email</label>
						<input type="text" value="<?= $h($hdAccount['email']) ?>" disabled class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-400 min-h-[40px]">
					</div>
				</div>
				<div>
					<label class="block text-[11px] text-slate-400 mb-1.5"><?= t('helpdesk.subject') ?></label>
					<input type="text" name="subject" required class="w-full bg-[#030712] border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/50 transition-all min-h-[42px]">
				</div>
				<div>
					<label class="block text-[11px] text-slate-400 mb-1.5">Message</label>
					<textarea name="message" rows="6" required class="w-full bg-[#030712] border border-slate-800 rounded-xl px-3.5 py-3 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/50 transition-all"></textarea>
				</div>
				<?php if (!empty($config['use_captcha'])): ?><div class="g-recaptcha" data-sitekey="<?= $h($config['captcha_site_key']) ?>"></div><?php endif; ?>
				<?php Token::create(); ?>
				<input type="hidden" name="username" value="<?= $h($hdAccount['name']) ?>">
				<button type="submit" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs transition-all active:scale-[0.98] border-t border-amber-200/60">
					<i data-lucide="send" class="w-3.5 h-3.5"></i><span><?= t('helpdesk.submit') ?></span>
				</button>
			</form>
		</div>
	<?php endif; ?>
</div>
