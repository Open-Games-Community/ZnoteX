<?php
/**
 * Eclipse - account dashboard.
 *
 * Rendered by the Eclipse shell (not by myaccount.php, which is untouched) from
 * the variables it leaves in scope: $char_count, $char_array, $user_data,
 * $user_znote_data, $config, $session_user_id. Reproduces the stock character
 * edit form field-for-field so the stock handler still works.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$cardCls = 'bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl sm:rounded-3xl shadow-xl';
$char_count = isset($char_count) ? (int) $char_count : 0;
$char_array = (isset($char_array) && is_array($char_array)) ? $char_array : array();

$premdays = (int)($user_data['premdays'] ?? 0);
$verifyEmail = !empty($config['mailserver']['myaccount_verify_email']);
$emailVerified = !empty($user_znote_data['active_email']);
$points = (int)($user_znote_data['points'] ?? 0);

$twofa = null;
if (!empty($config['twoFactorAuthenticator'])) {
	$q = mysql_select_single("SELECT `secret` FROM `accounts` WHERE `id`='" . (int)$session_user_id . "' LIMIT 1;");
	$twofa = ($q && $q['secret'] !== null);
}

$vocName = static function ($id) use ($config) {
	return $config['vocations'][(int)$id]['name'] ?? $id;
};
$townName = static function ($id) use ($config) {
	return $config['towns'][(int)$id] ?? $id;
};

$quick = array(
	array('buypoints.php', 'coins', t('buypoints.title')),
	array('shop.php', 'shopping-bag', t('shop.offers')),
	array('helpdesk.php', 'life-buoy', t('nav.support')),
);
?>
<div id="myaccount" class="space-y-4 sm:space-y-6 max-w-4xl mx-auto">

	<div class="relative overflow-hidden <?= $cardCls ?> p-4 sm:p-6 md:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
		<div class="absolute top-0 right-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
		<div class="relative z-10 flex items-center gap-3 sm:gap-4">
			<div class="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-500/5 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
				<i data-lucide="layout-dashboard" class="w-5 h-5 sm:w-6 sm:h-6"></i>
			</div>
			<div>
				<h1 class="font-brand text-lg sm:text-xl md:text-2xl font-extrabold text-white tracking-tight leading-tight">
					<?= t('eclipse.acc.title_a') ?> <span class="bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 bg-clip-text text-transparent"><?= t('eclipse.acc.title_b') ?></span>
				</h1>
				<p class="text-[11px] sm:text-xs text-slate-400 mt-1 font-normal"><?= t('eclipse.acc.subtitle') ?></p>
			</div>
		</div>
		<div class="relative z-10 flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/80 border border-amber-500/30 text-xs font-mono self-start sm:self-auto shrink-0">
			<i data-lucide="coins" class="w-4 h-4 text-amber-400"></i>
			<span class="text-slate-400"><?= t('shop.you_have') ?></span>
			<span class="font-bold text-amber-300 text-sm"><?= number_format($points) ?></span>
		</div>
	</div>

	<div class="grid grid-cols-3 gap-2.5 sm:gap-3">
		<?php foreach ($quick as $q): ?>
			<a href="<?= $h($q[0]) ?>" class="group <?= $cardCls ?> p-3 sm:p-4 flex flex-col items-center justify-center gap-2 text-center hover:border-amber-500/40 transition-all active:scale-95">
				<div class="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform"><i data-lucide="<?= $h($q[1]) ?>" class="w-4 h-4"></i></div>
				<span class="text-[11px] sm:text-xs font-semibold text-slate-200 group-hover:text-white"><?= $h($q[2]) ?></span>
			</a>
		<?php endforeach; ?>
	</div>

	<div class="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
		<div class="<?= $cardCls ?> p-4 sm:p-5 space-y-3">
			<div class="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider"><i data-lucide="user" class="w-3.5 h-3.5 text-amber-400"></i><span><?= t('acc.page_title') ?></span></div>
			<div class="space-y-2 text-xs sm:text-sm">
				<div class="flex items-center justify-between gap-3">
					<span class="text-slate-400"><?= t('acc.welcome') ?></span>
					<span class="font-mono font-semibold text-white truncate"><?= $h($user_data['name']) ?></span>
				</div>
				<div class="flex items-center justify-between gap-3">
					<span class="text-slate-400"><?= t('common.status') ?></span>
					<?php if ($premdays > 0): ?>
						<span class="font-mono text-amber-300"><?= $h(t('acc.premium_days', ['days' => $premdays])) ?></span>
					<?php else: ?>
						<span class="font-mono text-slate-400"><?= t('acc.free_account') ?></span>
					<?php endif; ?>
				</div>
				<?php if ($verifyEmail): ?>
					<div class="flex items-center justify-between gap-3">
						<span class="text-slate-400">Email</span>
						<?php if ($emailVerified): ?>
							<span class="inline-flex items-center gap-1 font-mono text-emerald-400"><i data-lucide="check-circle" class="w-3.5 h-3.5"></i><span class="truncate max-w-[160px]"><?= $h($user_data['email']) ?></span></span>
						<?php else: ?>
							<a href="?authenticate" class="inline-flex items-center gap-1 font-mono text-amber-400 hover:text-amber-300"><i data-lucide="alert-circle" class="w-3.5 h-3.5"></i><span><?= t('acc.please_verify') ?></span></a>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div class="<?= $cardCls ?> p-4 sm:p-5 space-y-3">
			<div class="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider"><i data-lucide="shield" class="w-3.5 h-3.5 text-amber-400"></i><span><?= t('eclipse.acc.security') ?></span></div>
			<?php if ($twofa !== null): ?>
				<div class="flex items-center justify-between gap-3 text-xs sm:text-sm">
					<span class="text-slate-400"><?= t('acc.security_2fa') ?></span>
					<a href="twofa.php" class="inline-flex items-center gap-1.5 font-mono <?= $twofa ? 'text-emerald-400' : 'text-slate-400 hover:text-amber-300' ?>">
						<i data-lucide="<?= $twofa ? 'lock' : 'lock-open' ?>" class="w-3.5 h-3.5"></i><span><?= $twofa ? 'Enabled' : 'Disabled' ?></span>
					</a>
				</div>
			<?php endif; ?>
			<div class="flex items-center justify-between gap-3 text-xs sm:text-sm">
				<span class="text-slate-400"><?= t('changepw.title') ?></span>
				<a href="changepassword.php" class="inline-flex items-center gap-1.5 font-mono text-slate-300 hover:text-amber-300"><i data-lucide="key-round" class="w-3.5 h-3.5"></i><span><?= t('account.change_password') ?></span></a>
			</div>
		</div>
	</div>

	<div class="<?= $cardCls ?> overflow-hidden">
		<div class="p-3.5 sm:p-4 border-b border-slate-800/80 bg-slate-950/70 flex items-center justify-between">
			<h2 class="text-xs font-bold text-white uppercase tracking-wider font-brand"><?= t('eclipse.acc.characters') ?></h2>
			<span class="font-mono text-amber-300 text-[11px] font-bold"><?= (int)$char_count ?></span>
		</div>

		<?php if (is_array($char_array) && $char_array): ?>
			<div class="overflow-x-auto">
				<table class="w-full text-left text-xs text-slate-300 min-w-[520px]">
					<thead class="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800/80">
						<tr>
							<th class="p-3">NAME</th><th class="p-3">LEVEL</th><th class="p-3">VOCATION</th><th class="p-3">TOWN</th><th class="p-3">STATUS</th><th class="p-3">HIDE</th>
						</tr>
					</thead>
					<tbody class="divide-y divide-slate-800/60">
						<?php foreach ($char_array as $c): ?>
							<tr class="hover:bg-slate-800/30">
								<td class="p-3"><a href="characterprofile.php?name=<?= $h(urlencode($c['name'])) ?>" class="font-semibold text-white hover:text-amber-300"><?= $h($c['name']) ?></a></td>
								<td class="p-3 font-mono"><?= (int)$c['level'] ?></td>
								<td class="p-3"><?= $h($vocName($c['vocation'])) ?></td>
								<td class="p-3"><?= $h($townName($c['town_id'])) ?></td>
								<td class="p-3"><?php if (!empty($c['online'])): ?><span class="text-emerald-400 font-mono">online</span><?php else: ?><span class="text-slate-500 font-mono">offline</span><?php endif; ?></td>
								<td class="p-3 font-mono text-slate-400"><?= $h(hide_char_to_name($c['hide_char'])) ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<form action="" method="post" class="p-3.5 sm:p-4 border-t border-slate-800/80 flex flex-col sm:flex-row gap-2.5">
				<select id="selected_character" name="selected_character" class="flex-1 bg-[#030712] border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-amber-500/60">
					<?php foreach ($char_array as $c): ?><option value="<?= $h($c['name']) ?>"><?= $h($c['name']) ?></option><?php endforeach; ?>
				</select>
				<select id="action" name="action" onchange="ecAccAction(this)" class="flex-1 bg-[#030712] border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60">
					<option value="none" selected><?= t('acc.select_action') ?></option>
					<option value="toggle_hide"><?= t('acc.toggle_hide') ?></option>
					<option value="change_comment"><?= t('acc.change_comment') ?></option>
					<option value="change_gender"><?= t('acc.change_gender') ?></option>
					<option value="change_name"><?= t('acc.change_name') ?></option>
					<option value="delete_character" class="needconfirmation"><?= t('acc.delete_char') ?></option>
				</select>
				<span id="ec-acc-name" hidden><input type="text" name="newName" placeholder="New name" class="bg-[#030712] border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-amber-500/60"></span>
				<?php Token::create(); ?>
				<button id="ec-acc-submit" type="submit" class="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs transition-all active:scale-[0.98] border-t border-amber-200/60 shrink-0">
					<i data-lucide="check" class="w-3.5 h-3.5"></i><span><?= t('common.submit') ?></span>
				</button>
			</form>
		<?php else: ?>
			<div class="p-8 sm:p-12 text-center flex flex-col items-center gap-3">
				<div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400"><i data-lucide="user-x" class="w-6 h-6"></i></div>
				<p class="text-slate-400 text-xs"><?= t('eclipse.acc.no_chars') ?></p>
				<a href="createcharacter.php" class="inline-flex items-center gap-1.5 py-2 px-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-slate-200 hover:text-amber-300 text-xs font-semibold transition-all"><i data-lucide="plus" class="w-3.5 h-3.5"></i><span><?= t('eclipse.acc.create_char') ?></span></a>
			</div>
		<?php endif; ?>
	</div>
</div>

<script>
function ecAccAction(sel) {
	var box = document.getElementById('ec-acc-name');
	if (box) box.hidden = (sel.value !== 'change_name');
}
document.getElementById('ec-acc-submit') && document.getElementById('ec-acc-submit').addEventListener('click', function (e) {
	var a = document.getElementById('action');
	var opt = a.options[a.selectedIndex];
	if (opt && opt.className === 'needconfirmation') {
		var n = document.getElementById('selected_character');
		if (!window.confirm('DELETE character ' + (n ? n.value : '') + '?')) e.preventDefault();
	}
});
</script>
