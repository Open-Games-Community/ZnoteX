<?php
/**
 * Eclipse - point shop. Rendered by shop.php via view('shop').
 * Scope: $shop, $shop_list, $loggedin, $user_znote_data, $config.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

if (empty($shop['enabled'])) {
	echo '<div class="ec-content"><h1>' . t('buypoints.disabled') . '</h1><p>' . t('buypoints.disabled_text') . '</p></div>';
	return;
}

$ecPoints = ($loggedin === true && isset($user_znote_data['points'])) ? (int)$user_znote_data['points'] : 0;
$sess = time();
$_SESSION['shop_session'] = $sess;

$itemImg = static function ($id) use ($config) {
	$server = (string)($config['shop']['imageServer'] ?? '');
	$type   = (string)($config['shop']['imageType'] ?? 'gif');
	if (preg_match('~^https?://~i', $server)) return rtrim($server, '/') . '/' . $id . '.' . $type;
	if (strpos($server, '.') !== false) return 'http://' . rtrim($server, '/') . '/' . $id . '.' . $type;
	return '/' . ltrim($server, '/') . '/' . $id . '.' . $type;
};
$outfitImg = static function ($id, $addons) use ($config) {
	return $config['show_outfits']['imageServer'] . '?id=' . (int)$id . '&addons=' . (int)$addons
		. '&head=' . rand(1, 132) . '&body=' . rand(1, 132) . '&legs=' . rand(1, 132) . '&feet=' . rand(1, 132);
};

$typeMeta = array(
	1 => array(t('shop.cat_items'), 'package'),
	2 => array(t('shop.cat_premium'), 'star'),
	3 => array(t('shop.cat_misc'), 'venus-and-mars'),
	4 => array(t('shop.cat_misc'), 'pencil'),
	5 => array(t('shop.cat_outfits'), 'shirt'),
	6 => array(t('shop.cat_mounts'), 'rabbit'),
);

$groups = array();
foreach ($shop_list as $key => $offer) {
	$t = (int)$offer['type'];
	$groups[$t][$key] = $offer;
}
ksort($groups);
?>
<div class="space-y-4 sm:space-y-6 md:space-y-8 max-w-5xl mx-auto">

	<div class="relative overflow-hidden border border-slate-800/80 rounded-2xl sm:rounded-3xl bg-[#030712] p-4 sm:p-6 md:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xl">
		<div class="absolute top-0 right-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
		<div class="relative z-10 flex items-center gap-3 sm:gap-4">
			<div class="p-2.5 sm:p-3.5 bg-gradient-to-br from-amber-500/20 to-amber-500/5 border border-amber-500/30 rounded-xl sm:rounded-2xl text-amber-400 shrink-0 shadow-lg shadow-amber-500/10">
				<i data-lucide="shopping-bag" class="w-5 h-5 sm:w-6 sm:h-6"></i>
			</div>
			<div>
				<h1 class="font-brand text-lg sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
					<?= t('shop.offers') ?>
				</h1>
				<p class="text-[11px] sm:text-xs md:text-sm text-slate-300 font-normal mt-0.5"><?= t('eclipse.shop.sub') ?></p>
			</div>
		</div>
		<div class="relative z-10 flex items-center gap-3 bg-slate-950/80 border border-amber-500/30 rounded-xl sm:rounded-2xl px-3.5 py-2 sm:px-4 sm:py-2.5 shadow-sm backdrop-blur-md self-stretch sm:self-auto justify-between sm:justify-start">
			<div class="flex items-center gap-2">
				<i data-lucide="coins" class="w-4 h-4 text-amber-400"></i>
				<span class="text-xs text-slate-400 font-medium"><?= t('shop.you_have') ?></span>
			</div>
			<div class="flex items-center gap-1.5 font-mono">
				<span class="text-sm sm:text-base font-bold text-amber-300"><?= number_format($ecPoints) ?></span>
				<span class="text-xs text-slate-500"><?= t('common.points') ?></span>
			</div>
			<a href="buypoints.php" title="<?= $h(t('shop.buy_points')) ?>" class="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all active:scale-90 shadow-sm ml-1"><i data-lucide="plus" class="w-3.5 h-3.5"></i></a>
		</div>
	</div>

	<?php if ($loggedin !== true): ?>
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 flex items-center gap-2.5 text-xs text-slate-300 shadow-sm">
			<div class="p-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0"><i data-lucide="lock" class="w-3.5 h-3.5"></i></div>
			<span class="leading-relaxed"><?= t('shop.need_login') ?> <a href="login.php" class="text-amber-400 hover:text-amber-300"><?= t('eclipse.nav.login') ?></a></span>
		</div>
	<?php endif; ?>

	<?php if (empty($groups)): ?>
		<p class="text-sm text-slate-400"><?= t('news.none') ?></p>
	<?php endif; ?>

	<?php foreach ($groups as $type => $offers): [$gLabel, $gIcon] = $typeMeta[$type] ?? array(t('shop.cat_misc'), 'package'); ?>
		<div class="bg-slate-900/90 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-4 sm:p-5 md:p-6 shadow-xl space-y-3.5 sm:space-y-4">
			<div class="flex items-center gap-2.5 pb-3 border-b border-slate-800/80">
				<div class="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400"><i data-lucide="<?= $h($gIcon) ?>" class="w-4 h-4"></i></div>
				<h2 class="text-sm sm:text-base font-bold text-white leading-tight font-brand"><?= $h($gLabel) ?></h2>
			</div>
			<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
				<?php foreach ($offers as $key => $o):
					$isOutfit = ((int)$o['type'] === 5);
					$isMount  = ((int)$o['type'] === 6);
					$ids = is_array($o['itemid']) ? $o['itemid'] : array($o['itemid']);
					$outfitIds = array_values(array_filter($ids, static function ($v) { return (int)$v > 0; }));
					$showImg = ($isOutfit || $isMount) ? !empty($config['show_outfits']['shop']) : !empty($config['shop']['showImage']);
				?>
					<div class="bg-slate-950/80 border border-slate-800/90 hover:border-amber-500/50 p-4 sm:p-5 rounded-xl sm:rounded-2xl flex flex-col gap-3.5 transition-all duration-200 shadow-lg group">
						<div class="flex items-start justify-between gap-3">
							<div class="min-w-0 space-y-1">
								<div class="text-xs sm:text-sm font-bold text-white group-hover:text-amber-300 transition-colors leading-snug"><?= $o['description'] ?></div>
								<div class="flex items-baseline gap-1 font-mono">
									<span class="text-lg sm:text-xl font-black text-amber-300"><?= (int)$o['points'] ?></span>
									<span class="text-[11px] text-slate-400"><?= t('common.points') ?></span>
								</div>
							</div>
							<?php if ($showImg): ?>
								<div class="w-16 h-16 shrink-0 rounded-xl bg-[#030712] border border-slate-800 overflow-hidden flex items-center justify-center">
									<?php if ($isOutfit): ?>
										<img src="<?= $h($outfitImg($outfitIds[0] ?? 0, $o['count'])) ?>" alt="" class="w-12 h-12 object-contain object-center" style="image-rendering:pixelated">
									<?php elseif ($isMount): ?>
										<img src="<?= $h($config['show_outfits']['imageServer'] . '?id=128&addons=0&head=0&body=0&legs=0&feet=0&mount=' . (int)$o['itemid'] . '&direction=3') ?>" alt="" class="w-12 h-12 object-contain object-center" style="image-rendering:pixelated">
									<?php else: ?>
										<img src="<?= $h($itemImg($o['itemid'])) ?>" alt="" class="max-w-full max-h-full object-contain" style="image-rendering:pixelated">
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
						<?php if ((int)$o['type'] === 2): ?>
							<div class="text-[11px] text-slate-400 font-mono"><?= $h(t('shop.days', ['count' => (int)$o['count']])) ?></div>
						<?php elseif (!$isOutfit && !$isMount && (int)$o['count'] > 0): ?>
							<div class="text-[11px] text-slate-400 font-mono"><?= (int)$o['count'] ?>x</div>
						<?php endif; ?>
						<?php if ($loggedin === true): ?>
							<form action="" method="POST" class="mt-auto">
								<input type="hidden" name="buy" value="<?= (int)$key ?>">
								<input type="hidden" name="session" value="<?= $sess ?>">
								<button type="submit" class="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 text-xs font-bold py-2.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 border-t border-amber-200/60 needconfirmation" data-item-name="<?= $h($o['description']) ?>" data-item-cost="<?= (int)$o['points'] ?>">
									<i data-lucide="shopping-cart" class="w-3.5 h-3.5"></i><span><?= t('shop.purchase') ?></span>
								</button>
							</form>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endforeach; ?>
</div>

<?php if (!empty($shop['enableShopConfirmation'])): ?>
<script>
document.addEventListener('click', function (e) {
	var b = e.target.closest('.needconfirmation');
	if (!b) return;
	var msg = "<?= $h(t('shop.purchase')) ?> " + b.getAttribute('data-item-name') + " (" + b.getAttribute('data-item-cost') + " <?= $h(t('common.points')) ?>)?";
	if (!window.confirm(msg)) e.preventDefault();
});
</script>
<?php endif; ?>
