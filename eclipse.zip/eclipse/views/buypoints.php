<?php
/**
 * Eclipse - buy points. Rendered by buypoints.php via view('buypoints').
 * Scope: $paypal, $stripe, $mercadopago, $pagseguro, $prices, $session_user_id.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$hasPaypal = !empty($config['paypal']['enabled']);
$hasStripe = !empty($stripe['enabled']);
$hasMp     = !empty($mercadopago['enabled']);
$hasAny    = $hasPaypal || $hasStripe || $hasMp || !empty($config['pagseguro']['enabled']) || !empty($config['paygol']['enabled']);

$ecBalance = isset($user_znote_data['points']) ? (int)$user_znote_data['points'] : null;
$prices = is_array($prices ?? null) ? $prices : array();
?>
<div class="space-y-4 sm:space-y-6 max-w-4xl mx-auto">

	<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
		<div class="flex items-center gap-3 sm:gap-4 min-w-0">
			<div class="w-11 h-11 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 shadow-sm">
				<i data-lucide="coins" class="w-5 h-5 sm:w-6 sm:h-6"></i>
			</div>
			<div class="min-w-0">
				<h1 class="font-brand text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
					<?= t('buypoints.title') ?>
				</h1>
				<p class="text-slate-400 text-xs mt-0.5 max-w-xl leading-relaxed font-normal"><?= t('eclipse.buypoints.sub') ?></p>
			</div>
		</div>
		<?php if ($ecBalance !== null): ?>
			<div class="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-xs font-mono self-start sm:self-auto shadow-inner shrink-0">
				<span class="text-slate-400"><?= t('shop.you_have') ?></span>
				<span class="font-bold text-amber-300 text-sm"><?= number_format($ecBalance) ?> <?= t('common.points') ?></span>
			</div>
		<?php endif; ?>
	</div>

	<?php if (!$hasAny): ?>
		<div class="bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl p-6 text-center shadow-xl">
			<h2 class="font-brand text-white font-bold text-base mb-1"><?= t('buypoints.disabled') ?></h2>
			<p class="text-slate-400 text-xs"><?= t('buypoints.disabled_text') ?></p>
		</div>
		<?php return; endif; ?>

	<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
		<?php foreach ($prices as $price => $points):
			$bonus = 0;
			if ($hasPaypal && !empty($paypal['showBonus'])) {
				$bonus = calculate_discount(($paypal['points_per_currency'] * $price), $points);
			} elseif ($hasStripe && !empty($stripe['showBonus'])) {
				$bonus = calculate_discount(((int)$stripe['points_per_currency'] * $price), $points);
			}
			$cur = $hasPaypal ? $paypal['currency'] : ($hasStripe ? $stripe['currency'] : ($hasMp ? $mercadopago['currency'] : ''));
		?>
			<div class="bg-slate-950/80 border border-slate-800/90 hover:border-amber-500/50 p-4 sm:p-5 rounded-xl sm:rounded-2xl flex flex-col gap-4 transition-all duration-200 shadow-lg group">
				<div class="space-y-1.5">
					<div class="flex items-center justify-between">
						<span class="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono"><?= $h($price) ?> <?= $h($cur) ?></span>
						<?php if ($bonus): ?><span class="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">+<?= $h($bonus) ?> <?= t('buypoints.bonus') ?></span><?php endif; ?>
					</div>
					<div class="flex items-baseline gap-1.5 font-mono">
						<span class="text-2xl sm:text-3xl font-black text-amber-300"><?= (int)$points ?></span>
						<span class="text-xs text-slate-400"><?= t('buypoints.points') ?></span>
					</div>
				</div>

				<div class="mt-auto space-y-2">
					<?php if ($hasPaypal): ?>
						<form action="https://www.paypal.com/cgi-bin/webscr" method="POST">
							<input type="hidden" name="cmd" value="_xclick">
							<input type="hidden" name="business" value="<?= $h($paypal['email']) ?>">
							<input type="hidden" name="item_name" value="<?= $h(t('buypoints.shop_points_on', ['points' => $points, 'site' => $config['site_title']])) ?>">
							<input type="hidden" name="item_number" value="1">
							<input type="hidden" name="amount" value="<?= $h($price) ?>">
							<input type="hidden" name="no_shipping" value="1">
							<input type="hidden" name="no_note" value="1">
							<input type="hidden" name="currency_code" value="<?= $h($paypal['currency']) ?>">
							<input type="hidden" name="lc" value="GB">
							<input type="hidden" name="bn" value="PP-BuyNowBF">
							<input type="hidden" name="return" value="<?= $h($paypal['success']) ?>">
							<input type="hidden" name="cancel_return" value="<?= $h($paypal['failed']) ?>">
							<input type="hidden" name="rm" value="2">
							<input type="hidden" name="notify_url" value="<?= $h($paypal['ipn']) ?>">
							<input type="hidden" name="custom" value="<?= (int)$session_user_id ?>">
							<button type="submit" class="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 text-xs font-bold py-2.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 border-t border-amber-200/60">
								<i data-lucide="credit-card" class="w-3.5 h-3.5"></i><span>PayPal</span>
							</button>
						</form>
					<?php endif; ?>
					<?php if ($hasStripe): ?>
						<form action="payment.php" method="post">
							<?php Token::create(); ?>
							<input type="hidden" name="provider" value="stripe">
							<input type="hidden" name="price" value="<?= $h($price) ?>">
							<button type="submit" class="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/40 text-slate-100 text-xs font-bold py-2.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-1.5">
								<i data-lucide="credit-card" class="w-3.5 h-3.5 text-amber-400"></i><span>Stripe</span>
							</button>
						</form>
					<?php endif; ?>
					<?php if ($hasMp): ?>
						<form action="payment.php" method="post">
							<?php Token::create(); ?>
							<input type="hidden" name="provider" value="mercadopago">
							<input type="hidden" name="price" value="<?= $h($price) ?>">
							<button type="submit" class="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/40 text-slate-100 text-xs font-bold py-2.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-1.5">
								<i data-lucide="credit-card" class="w-3.5 h-3.5 text-amber-400"></i><span>Mercado Pago</span>
							</button>
						</form>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400 leading-relaxed">
		<i data-lucide="shield-check" class="w-4 h-4 text-emerald-400 shrink-0 mt-px"></i>
		<span><?= t('eclipse.buypoints.note') ?></span>
	</div>
</div>
