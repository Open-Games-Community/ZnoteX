<?php
/**
 * Eclipse - account registration.
 *
 * Rendered by the Eclipse shell (not by register.php, which is untouched) from
 * the variables register.php leaves in scope: $errors, $config, $_GET, $_POST.
 * Reproduces the stock form fields exactly so the stock handler still works.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$inputCls = 'w-full bg-[#030712] border border-slate-800 rounded-xl px-3.5 py-3 text-xs sm:text-sm font-mono text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/50 transition-all min-h-[44px]';

$regErrors = (isset($errors) && is_array($errors)) ? $errors : array();

// -- non-form states ------------------------------------------------------
$state = '';
if (isset($_GET['success']) && empty($_GET['success'])) {
	$state = !empty($config['mailserver']['register']) ? 'email' : 'created';
} elseif (isset($_GET['authenticate']) && empty($_GET['authenticate'])) {
	$auid = (isset($_GET['u']) && (int)$_GET['u'] > 0) ? (int)$_GET['u'] : false;
	$akey = (isset($_GET['k']) && (int)$_GET['k'] > 0) ? (int)$_GET['k'] : false;
	$row = db()->fetchOne("SELECT `id` FROM `znote_accounts` WHERE `account_id`=? AND `activekey`=? LIMIT 1;", [$auid, $akey]);
	$state = ($row !== false) ? 'authok' : 'authfail';
}

if ($state !== ''):
	$map = array(
		'created'  => array('check-circle', true,  t('common.congrats'),   t('reg.created')),
		'email'    => array('mail-check',   true,  t('reg.email_required'), t('reg.created')),
		'authok'   => array('check-circle', true,  t('common.congrats'),   t('reg.created')),
		'authfail' => array('alert-triangle', false, t('acc.auth_failed'), t('acc.auth_failed_text')),
	);
	[$ic, $ok, $title, $text] = $map[$state];
	?>
	<div class="space-y-4 text-center">
		<div class="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center <?= $ok ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border border-red-500/20 text-red-400' ?>">
			<i data-lucide="<?= $h($ic) ?>" class="w-6 h-6"></i>
		</div>
		<h1 class="font-brand text-xl sm:text-2xl font-extrabold text-white tracking-tight"><?= $h($title) ?></h1>
		<p class="text-slate-400 text-xs sm:text-sm leading-relaxed"><?= $h($text) ?></p>
		<a href="login.php" class="inline-flex items-center gap-1.5 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs transition-all active:scale-95 border-t border-amber-200/60">
			<i data-lucide="log-in" class="w-3.5 h-3.5"></i><span><?= t('eclipse.nav.login') ?></span>
		</a>
	</div>
	<?php
	return;
endif;
?>
<div class="space-y-3 mb-5 sm:mb-6">
	<div class="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-semibold tracking-wide shadow-sm">
		<span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
		<span><?= t('eclipse.hero.world_badge', ['world' => $h(function_exists('theme_option') ? (theme_option('world_name') ?: 'Eclipse') : 'Eclipse')]) ?></span>
	</div>
	<div class="flex items-center gap-3">
		<div class="w-10 h-10 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 shadow-sm">
			<i data-lucide="user-plus" class="w-5 h-5"></i>
		</div>
		<div>
			<h1 class="font-brand text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
				<?= t('eclipse.reg.title_a') ?> <span class="bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 bg-clip-text text-transparent"><?= t('eclipse.reg.title_b') ?></span>
			</h1>
			<p class="text-[11px] sm:text-xs text-slate-400 mt-0.5 font-normal"><?= t('eclipse.reg.subtitle') ?></p>
		</div>
	</div>
</div>

<?php if (!empty($regErrors)): ?>
	<div class="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/25 text-red-300 text-[11px] leading-snug space-y-1">
		<?php foreach ($regErrors as $e): ?><div class="flex items-start gap-1.5"><i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0 mt-px"></i><span><?= $h(strip_tags((string)$e)) ?></span></div><?php endforeach; ?>
	</div>
<?php endif; ?>

<form action="" method="post" class="space-y-3.5 sm:space-y-4">
	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="user" class="w-3.5 h-3.5 text-slate-500"></i><span><?= t('reg.label_name') ?></span></label>
		<input type="text" name="username" required autocomplete="username" autocapitalize="none" spellcheck="false" class="<?= $h($inputCls) ?>">
	</div>
	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="mail" class="w-3.5 h-3.5 text-slate-500"></i><span>Email</span></label>
		<input type="text" name="email" required autocomplete="email" autocapitalize="none" placeholder="name@example.com" class="<?= $h($inputCls) ?>">
	</div>
	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="lock" class="w-3.5 h-3.5 text-slate-500"></i><span><?= t('reg.label_pw') ?></span></label>
		<input type="password" name="password" required autocomplete="new-password" placeholder="••••••••" class="<?= $h($inputCls) ?>">
	</div>
	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="lock" class="w-3.5 h-3.5 text-slate-500"></i><span><?= t('reg.label_pw2') ?></span></label>
		<input type="password" name="password_again" required autocomplete="new-password" placeholder="••••••••" class="<?= $h($inputCls) ?>">
	</div>
	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="flag" class="w-3.5 h-3.5 text-slate-500"></i><span><?= t('reg.label_country') ?></span></label>
		<select name="flag" required class="<?= $h($inputCls) ?> appearance-none cursor-pointer">
			<option value="">(<?= t('reg.choose_country') ?>)</option>
			<?php
			$countries = isset($config['countries']) && is_array($config['countries']) ? $config['countries'] : array();
			foreach (array('pl', 'se', 'br', 'us', 'gb') as $c) {
				if (isset($countries[$c])) echo '<option value="' . $h($c) . '">' . $h($countries[$c]) . '</option>';
			}
			echo '<option value="" disabled>──────────</option>';
			foreach ($countries as $code => $name) {
				echo '<option value="' . $h($code) . '">' . $h($name) . '</option>';
			}
			?>
		</select>
	</div>

	<?php if (!empty($config['use_captcha'])): ?>
		<div class="g-recaptcha" data-sitekey="<?= $h($config['captcha_site_key']) ?>"></div>
	<?php endif; ?>

	<details class="rounded-xl bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400">
		<summary class="cursor-pointer select-none px-3 py-2.5 font-semibold text-slate-300 flex items-center gap-1.5"><i data-lucide="scroll-text" class="w-3.5 h-3.5 text-amber-400"></i><?= t('reg.rules_title') ?></summary>
		<div class="px-3 pb-3 space-y-1.5 leading-relaxed">
			<p><?= t('reg.rule_golden') ?></p>
			<p><?= t('reg.rule_pwned') ?></p>
			<p><?= t('reg.rule_nocheat') ?></p>
		</div>
	</details>

	<div>
		<label class="text-[11px] sm:text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5"><i data-lucide="check-square" class="w-3.5 h-3.5 text-slate-500"></i><span><?= t('reg.rules_agree') ?></span></label>
		<select name="selected" required class="<?= $h($inputCls) ?> appearance-none cursor-pointer">
			<option value="0"><?= t('reg.agree_umh') ?></option>
			<option value="1"><?= t('reg.agree_yes') ?></option>
			<option value="2"><?= t('reg.agree_no') ?></option>
		</select>
	</div>

	<div class="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] leading-snug">
		<i data-lucide="gift" class="w-4 h-4 text-emerald-400 shrink-0"></i>
		<span><?= t('eclipse.reg.gift') ?></span>
	</div>

	<?php Token::create(); ?>

	<button type="submit" class="group relative flex items-center justify-center gap-2 w-full p-3 sm:py-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-xs sm:text-sm tracking-tight transition-all duration-300 shadow-[0_10px_30px_-8px_rgba(245,158,11,0.45)] active:scale-[0.99] border-t border-amber-200/60 overflow-hidden mt-2 min-h-[46px]">
		<span class="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none"></span>
		<i data-lucide="check" class="w-4 h-4"></i><span><?= t('reg.submit') ?></span>
	</button>
</form>

<div class="mt-5 sm:mt-6 pt-4 sm:pt-5 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
	<span><?= t('eclipse.reg.have_account') ?></span>
	<a href="login.php" class="inline-flex items-center gap-1 font-semibold text-amber-400 hover:text-amber-300 transition-colors py-1">
		<span><?= t('eclipse.nav.login') ?></span><i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
	</a>
</div>
