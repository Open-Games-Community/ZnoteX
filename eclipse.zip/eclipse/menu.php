<?php
/**
 * Eclipse - top navigation. Rendered twice by the shell: once for the desktop
 * bar ($ecNavMode = 'desktop') with hover dropdowns, once inside the mobile
 * drawer ($ecNavMode = 'mobile') as collapsible sections. Entries and their
 * nesting come from Admin Panel > Menus; a default tree is used when none
 * exists.
 */

$ecMenu    = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$ecHasMenu = function_exists('theme_menu_available') ? theme_menu_available() : (bool)$ecMenu;
$ecCurrent = (string)($page_filename ?? 'index');
$ecMobile  = (($ecNavMode ?? '') === 'mobile');
$hh = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$ml = static function ($v) use ($hh): string {
	return $hh(function_exists('theme_menu_label') ? theme_menu_label((string)$v) : (string)$v);
};

// Lucide icon per page. A menu entry can override this with its own icon in
// Admin Panel > Menus (a lucide name like "swords", or a Font-Awesome-style
// "fa-swords" - the fa- prefix is stripped). Anything still without an icon
// falls back to $ecIconFallback below (leaf links only, not category headers).
$ecIcons = array(
	'index.php' => 'home', 'news.php' => 'newspaper', 'changelog.php' => 'git-commit',
	'highscores.php' => 'trophy', 'powergamers.php' => 'flame', 'toponline.php' => 'activity',
	'guilds.php' => 'shield', 'topguilds.php' => 'crown', 'guildwar.php' => 'swords', 'guildwars.php' => 'swords',
	'shop.php' => 'shopping-bag', 'buypoints.php' => 'coins', 'market.php' => 'store',
	'auctionchar.php' => 'gavel', 'auctionchar' => 'gavel',
	'downloads.php' => 'download', 'serverinfo.php' => 'book-open', 'gallery.php' => 'image',
	'support.php' => 'life-buoy', 'helpdesk.php' => 'headset', 'contact.php' => 'mail', 'vote.php' => 'star',
	'onlinelist.php' => 'users', 'forum.php' => 'message-square', 'credits.php' => 'sparkles',
	'houses.php' => 'home', 'deaths.php' => 'skull', 'killers.php' => 'crosshair', 'bans.php' => 'ban',
	'spells.php' => 'wand-2', 'creatures.php' => 'bug', 'items.php' => 'package',
	'achievements.php' => 'award', 'queststatus.php' => 'list-checks',
	'myaccount.php' => 'user', 'settings.php' => 'settings', 'twofa.php' => 'key-round',
	'characterprofile.php' => 'id-card', 'createcharacter.php' => 'user-plus',
	'register.php' => 'user-plus', 'login.php' => 'log-in', 'lostaccount.php' => 'life-buoy',
	'changepassword.php' => 'lock', 'rules.php' => 'scroll-text', 'faq.php' => 'help-circle',
);
$ecIconFallback = function_exists('theme_option') ? trim((string) theme_option('menu_icon_fallback', 'dot')) : 'dot';
$ecIconNorm = static function (string $v): string {
	$v = strtolower(trim($v));
	// Tolerate Font Awesome / Glyphicon style input ("fa-users", "fas fa-swords").
	$v = preg_replace('/\bfa[srlbd]?\b[- ]?|\bglyphicon\b-?/', '', $v);
	$v = preg_replace('/[^a-z0-9-]+/', '-', str_replace(array(' ', '_'), '-', $v));
	return trim((string) $v, '-');
};
$ecIcon = static function (array $item) use ($ecIcons, $ecIconNorm): string {
	$own = $ecIconNorm((string) ($item['icon'] ?? ''));
	if ($own !== '') return $own;
	return $ecIcons[basename((string) ($item['url'] ?? ''))] ?? '';
};
$ecIconTag = static function (array $item, string $cls, bool $leaf) use ($ecIcon, $ecIconFallback, $hh): string {
	$n = $ecIcon($item);
	if ($n === '' && $leaf) $n = $ecIconFallback;
	return $n === '' ? '' : '<i data-lucide="' . $hh($n) . '" class="' . $hh($cls) . '"></i>';
};

if ($ecHasMenu) {
	$tree = $ecMenu;
} else {
	$tree = array(
		array('label' => t('nav.news'), 'url' => 'index.php', 'target' => '', 'children' => array()),
		array('label' => t('nav.community'), 'url' => '', 'target' => '', 'children' => array(
			array('label' => t('nav.online'),     'url' => 'onlinelist.php', 'target' => ''),
			array('label' => t('nav.highscores'), 'url' => 'highscores.php', 'target' => ''),
			array('label' => t('nav.guilds'),     'url' => 'guilds.php',     'target' => ''),
			array('label' => t('deaths.latest'),  'url' => 'deaths.php',     'target' => ''),
			array('label' => t('nav.kill_statistics'), 'url' => 'killers.php', 'target' => ''),
		)),
		array('label' => t('nav.library'), 'url' => '', 'target' => '', 'children' => array(
			array('label' => t('nav.serverinfo'), 'url' => 'serverinfo.php', 'target' => ''),
			array('label' => t('spells.title'),   'url' => 'spells.php',     'target' => ''),
			array('label' => t('creatures.title'),'url' => 'creatures.php',  'target' => ''),
		)),
		array('label' => t('nav.shop'), 'url' => 'shop.php', 'target' => '', 'children' => array()),
		array('label' => t('eclipse.nav.download'), 'url' => 'downloads.php', 'target' => '', 'children' => array()),
		array('label' => t('nav.support'), 'url' => 'support.php', 'target' => '', 'children' => array()),
	);
}

$deskLink = 'px-3 py-1.5 rounded-xl border border-transparent hover:border-amber-500/30 hover:bg-amber-500/10 text-slate-300 hover:text-amber-300 transition-all duration-200 flex items-center gap-2 whitespace-nowrap';

foreach ($tree as $it):
	$children = !empty($it['children']) ? $it['children'] : array();
	$hasKids  = count($children) > 0;
	$url      = $it['url'] !== '' ? $it['url'] : '#';
	$target   = ($it['target'] ?? '') !== '' ? ' target="' . $hh($it['target']) . '" rel="noopener"' : '';
	$active   = $url !== '#' && strpos($url, $ecCurrent . '.php') === 0;

	if ($ecMobile):
		if ($hasKids): ?>
			<details class="ec-m-group col-span-2">
				<summary class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs font-semibold text-slate-200 flex items-center justify-between cursor-pointer list-none">
					<span class="flex items-center gap-2"><?= $ecIconTag($it, 'w-4 h-4 text-amber-400', false) ?><?= $ml($it['label']) ?></span>
					<i data-lucide="chevron-down" class="w-4 h-4 text-amber-400 ec-m-caret"></i>
				</summary>
				<div class="grid grid-cols-2 gap-2 pt-2">
					<?php foreach ($children as $c):
						$ct = ($c['target'] ?? '') !== '' ? ' target="' . $hh($c['target']) . '" rel="noopener"' : ''; ?>
						<a href="<?= $hh($c['url'] !== '' ? $c['url'] : '#') ?>"<?= $ct ?> class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs font-medium text-slate-300 flex items-center gap-2">
							<?= $ecIconTag($c, 'w-3.5 h-3.5 text-amber-400/80', true) ?><span><?= $ml($c['label']) ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			</details>
		<?php else: ?>
			<a href="<?= $hh($url) ?>"<?= $target ?> class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/30 text-xs font-medium text-slate-200 flex items-center gap-2 transition-all<?= $active ? ' text-amber-300 border-amber-500/30' : '' ?>">
				<?= $ecIconTag($it, 'w-4 h-4 text-amber-400', true) ?><span><?= $ml($it['label']) ?></span>
			</a>
		<?php endif;
	else:
		if ($hasKids): ?>
			<div class="ec-dd relative">
				<button type="button" class="<?= $deskLink ?><?= $active ? ' text-amber-300' : '' ?>" data-ec-dd>
					<?= $ecIconTag($it, 'w-4 h-4 text-amber-400', false) ?>
					<span><?= $ml($it['label']) ?></span>
					<i data-lucide="chevron-down" class="w-3.5 h-3.5 text-amber-400 ec-dd-caret transition-transform"></i>
				</button>
				<div class="ec-dd-menu absolute left-0 top-full pt-2 min-w-[200px] z-50">
					<div class="rounded-xl border border-slate-800 bg-[#101423] shadow-2xl p-1.5">
						<?php foreach ($children as $c):
							$ct = ($c['target'] ?? '') !== '' ? ' target="' . $hh($c['target']) . '" rel="noopener"' : '';
							$ca = strpos((string)$c['url'], $ecCurrent . '.php') === 0; ?>
							<a href="<?= $hh($c['url'] !== '' ? $c['url'] : '#') ?>"<?= $ct ?> class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-slate-300 hover:text-amber-300 hover:bg-amber-500/10 transition-colors<?= $ca ? ' text-amber-300 bg-amber-500/10' : '' ?>">
								<?= $ecIconTag($c, 'w-4 h-4 text-amber-400/80', true) ?><span><?= $ml($c['label']) ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php else: ?>
			<a href="<?= $hh($url) ?>"<?= $target ?> class="<?= $deskLink ?><?= $active ? ' text-amber-300 border-amber-500/30 bg-amber-500/10' : '' ?>">
				<?= $ecIconTag($it, 'w-4 h-4 text-amber-400', true) ?>
				<span><?= $ml($it['label']) ?></span>
			</a>
		<?php endif;
	endif;
endforeach; ?>
