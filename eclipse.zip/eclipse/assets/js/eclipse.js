/**
 * Eclipse - front-end behaviour.
 *
 * Converted from the Flygard landing page. Lucide icons, the mobile drawer and
 * a copy-to-clipboard button for the server address. No analytics, no remote
 * status polling - the online count is rendered server-side.
 */
(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') fn();
		else document.addEventListener('DOMContentLoaded', fn);
	}

	ready(function () {
		if (window.lucide) window.lucide.createIcons();

		// desktop dropdowns: hover is CSS; this adds click/tap toggle + outside-close
		var dds = Array.prototype.slice.call(document.querySelectorAll('.ec-dd'));
		dds.forEach(function (dd) {
			var trigger = dd.querySelector('[data-ec-dd]');
			if (!trigger) return;
			trigger.addEventListener('click', function (e) {
				e.preventDefault();
				var open = dd.classList.contains('is-open');
				dds.forEach(function (o) { o.classList.remove('is-open'); });
				if (!open) dd.classList.add('is-open');
			});
		});
		document.addEventListener('click', function (e) {
			if (!e.target.closest('.ec-dd')) dds.forEach(function (o) { o.classList.remove('is-open'); });
		});

		var btn = document.getElementById('ec-menu-btn');
		var menu = document.getElementById('ec-mobile-menu');
		var iOpen = document.getElementById('ec-menu-open');
		var iClose = document.getElementById('ec-menu-close');
		if (btn && menu) {
			btn.addEventListener('click', function () {
				var hidden = menu.classList.toggle('hidden');
				if (iOpen && iClose) {
					iOpen.classList.toggle('hidden', !hidden);
					iClose.classList.toggle('hidden', hidden);
				}
			});
		}

		document.querySelectorAll('[data-ec-copy]').forEach(function (el) {
			el.addEventListener('click', function () {
				var value = el.getAttribute('data-ec-copy');
				var label = el.querySelector('[data-ec-copy-label]');
				var icon = el.querySelector('[data-lucide]');
				var done = function () {
					el.classList.add('is-copied');
					if (label) label.dataset.orig = label.dataset.orig || label.textContent;
					if (label) label.textContent = label.getAttribute('data-copied') || 'Copied';
					if (icon) { icon.setAttribute('data-lucide', 'check'); if (window.lucide) window.lucide.createIcons(); }
					setTimeout(function () {
						el.classList.remove('is-copied');
						if (label && label.dataset.orig) label.textContent = label.dataset.orig;
						if (icon) { icon.setAttribute('data-lucide', 'copy'); if (window.lucide) window.lucide.createIcons(); }
					}, 2000);
				};
				if (navigator.clipboard && window.isSecureContext) {
					navigator.clipboard.writeText(value).then(done, function () { fallback(value, done); });
				} else {
					fallback(value, done);
				}
			});
		});

		function fallback(text, cb) {
			var ta = document.createElement('textarea');
			ta.value = text;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild(ta);
			ta.focus();
			ta.select();
			try { document.execCommand('copy'); cb(); } catch (e) {}
			document.body.removeChild(ta);
		}

		// news slider: 3 per page, slide between pages, no reload
		var nw = document.querySelector('[data-ec-news]');
		if (nw) {
			var track = nw.querySelector('[data-ec-news-track]');
			var pages = Array.prototype.slice.call(nw.querySelectorAll('[data-ec-news-page]'));
			var pager = nw.querySelector('[data-ec-news-pager]');
			if (track && pages.length > 1 && pager) {
				var cur = 0;
				var dots = Array.prototype.slice.call(pager.querySelectorAll('[data-ec-news-goto]'));
				var arrows = Array.prototype.slice.call(pager.querySelectorAll('[data-ec-news-dir]'));
				var render = function () {
					track.style.transform = 'translateX(-' + (cur * 100) + '%)';
					dots.forEach(function (d, i) { d.classList.toggle('is-active', i === cur); });
					arrows.forEach(function (a) {
						var dir = parseInt(a.getAttribute('data-ec-news-dir'), 10);
						a.disabled = (dir < 0 && cur === 0) || (dir > 0 && cur === pages.length - 1);
					});
				};
				var go = function (i) { cur = Math.max(0, Math.min(pages.length - 1, i)); render(); };
				dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); }); });
				arrows.forEach(function (a) {
					a.addEventListener('click', function () { go(cur + parseInt(a.getAttribute('data-ec-news-dir'), 10)); });
				});
				// touch swipe
				var sx = null;
				track.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
				track.addEventListener('touchend', function (e) {
					if (sx === null) return;
					var dx = e.changedTouches[0].clientX - sx;
					if (Math.abs(dx) > 45) go(cur + (dx < 0 ? 1 : -1));
					sx = null;
				});
				render();
			}
		}

		var clock = document.getElementById('ec-clock');
		if (clock) {
			var tick = function () {
				var n = new Date();
				var p = function (x) { return String(x).padStart(2, '0'); };
				clock.textContent = p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
			};
			tick();
			setInterval(tick, 1000);
		}
	});
})();
