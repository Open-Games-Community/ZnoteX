<?php
/**
 * Eclipse - default shell.
 *
 * Converted from the Flygard WoW landing page. Tailwind (shipped locally) plus
 * a handful of custom rules in assets/css/eclipse.css. The design lives in the
 * utility classes; this file lays out the frame.
 */

$ecLogo = function_exists('theme_image')
	? theme_image('logo_image', theme_asset('img/logo.png'))
	: theme_asset('img/logo.png');
$ecFavicon = function_exists('theme_image') ? theme_image('favicon') : '';
$ecFooter  = function_exists('theme_option') ? theme_option('footer_html') : '';
$ecDiscord = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$ecDiscordSvg = '<svg viewBox="0 0 24 24" fill="currentColor" class="w-4 h-4 shrink-0" aria-hidden="true"><path d="M20.317 4.369A19.79 19.79 0 0 0 16.558 3c-.2.36-.43.845-.588 1.23a18.27 18.27 0 0 0-5.94 0A12.6 12.6 0 0 0 9.44 3c-1.32.226-2.58.62-3.76 1.37C1.9 8.06 1.18 11.64 1.5 15.17a19.94 19.94 0 0 0 6.07 3.08c.49-.67.93-1.38 1.3-2.13-.71-.27-1.4-.6-2.04-.99.17-.13.34-.26.5-.4a14.24 14.24 0 0 0 12.34 0c.16.15.33.28.5.4-.65.39-1.33.72-2.05.99.38.75.81 1.46 1.3 2.13a19.9 19.9 0 0 0 6.07-3.08c.38-4.1-.64-7.65-2.96-10.8ZM8.68 13.9c-1.18 0-2.15-1.08-2.15-2.42 0-1.33.95-2.42 2.15-2.42 1.2 0 2.17 1.1 2.15 2.42 0 1.34-.95 2.42-2.15 2.42Zm6.64 0c-1.18 0-2.15-1.08-2.15-2.42 0-1.33.95-2.42 2.15-2.42 1.2 0 2.17 1.1 2.15 2.42 0 1.34-.94 2.42-2.15 2.42Z"/></svg>';
$ecForum   = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$ecLang    = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';
$ecLoggedIn = function_exists('user_logged_in') ? user_logged_in() === true : false;
$ecIsAdmin  = $ecLoggedIn && function_exists('is_admin') && is_admin($user_data ?? null);
$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
$ecSite = (string)($config['site_name'] ?? theme_title());
?>
<!DOCTYPE html>
<html lang="<?= $h($ecLang) ?>" class="h-full">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#151A2D">
	<meta name="color-scheme" content="dark">
	<title><?= theme_title() ?></title>
	<?php if ($ecFavicon !== ''): ?><link rel="icon" href="<?= $ecFavicon ?>"><?php endif; ?>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700;800;900&family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap">
	<script src="<?= theme_asset('js/tailwind.js') ?>"></script>
	<script src="<?= theme_asset('js/lucide.min.js') ?>"></script>
	<link rel="stylesheet" href="<?= theme_asset('css/eclipse.css') ?>">
</head>
<body class="bg-[#151A2D] text-slate-100 min-h-full flex flex-col antialiased selection:bg-amber-500 selection:text-slate-950 overflow-x-hidden">

<nav class="border-b border-slate-800/80 bg-[#151A2D]/95 backdrop-blur-md sticky top-0 z-50">
	<div class="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
		<a href="index.php" class="flex items-center group active:scale-95 transition-transform shrink-0">
			<img src="<?= $ecLogo ?>" alt="<?= $h($ecSite) ?>" class="h-11 sm:h-12 w-auto object-contain transition-all group-hover:brightness-110">
		</a>

		<div class="hidden md:flex items-center gap-1.5 lg:gap-2 text-xs lg:text-sm font-medium">
			<?php $ecNavMode = 'desktop'; theme_menu(); ?>
			<?php if ($ecDiscord !== ''): ?>
				<a href="<?= $h($ecDiscord) ?>" target="_blank" rel="noopener" class="group px-3 py-1.5 rounded-xl border border-transparent hover:border-indigo-500/30 hover:bg-indigo-500/10 text-indigo-400 hover:text-indigo-300 transition-all flex items-center gap-2 font-medium">
					<?= $ecDiscordSvg ?><span>Discord</span>
				</a>
			<?php endif; ?>
			<div class="h-4 w-px bg-slate-800 mx-1"></div>
			<?php
			if (function_exists('translate_selector')) {
				$sel = translate_selector();
				if ($sel !== '') {
					echo '<div class="ec-lang">' . $sel . '</div>' . translate_selector_assets();
					translate_selector_rendered(true);
				}
			}
			?>
			<?php if ($ecLoggedIn): ?>
				<div class="ec-dd relative">
					<button type="button" data-ec-dd class="group px-3 py-1.5 rounded-xl border border-transparent hover:border-slate-700 hover:bg-slate-800/60 text-slate-300 hover:text-white transition-all flex items-center gap-1.5 font-medium">
						<i data-lucide="user" class="w-4 h-4 text-amber-400"></i><span><?= $h($user_data['name'] ?? t('eclipse.nav.account')) ?></span>
						<i data-lucide="chevron-down" class="w-3.5 h-3.5 text-slate-500 ec-dd-caret"></i>
					</button>
					<div class="ec-dd-menu absolute right-0 top-full pt-2 min-w-[190px] z-50">
						<div class="bg-[#151A2D] border border-slate-800 rounded-xl shadow-2xl overflow-hidden py-1">
							<a href="myaccount.php" class="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800/60 hover:text-white transition-colors">
								<i data-lucide="user" class="w-3.5 h-3.5 text-slate-400"></i><span><?= t('eclipse.nav.account') ?></span>
							</a>
							<?php if ($ecIsAdmin): ?>
							<a href="admin/" class="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800/60 hover:text-white transition-colors">
								<i data-lucide="shield" class="w-3.5 h-3.5 text-amber-400"></i><span><?= t('eclipse.nav.admin') ?></span>
							</a>
							<?php endif; ?>
							<a href="logout.php" class="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800/60 hover:text-white transition-colors border-t border-slate-800/70">
								<i data-lucide="log-out" class="w-3.5 h-3.5 text-slate-400"></i><span><?= t('eclipse.nav.logout') ?></span>
							</a>
						</div>
					</div>
				</div>
			<?php else: ?>
				<a href="login.php" class="relative inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-md shadow-amber-500/20 active:scale-95 border-t border-amber-200/50">
					<i data-lucide="log-in" class="w-3.5 h-3.5"></i><span><?= t('eclipse.nav.login') ?></span>
				</a>
			<?php endif; ?>
		</div>

		<button id="ec-menu-btn" aria-label="Menu" class="md:hidden relative p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-300 hover:text-white active:scale-95 transition-all shadow-sm">
			<i id="ec-menu-open" data-lucide="menu" class="w-5 h-5"></i>
			<i id="ec-menu-close" data-lucide="x" class="w-5 h-5 hidden"></i>
		</button>
	</div>

	<div id="ec-mobile-menu" class="hidden md:hidden border-t border-slate-800/80 bg-[#151A2D] px-4 pt-3 pb-5 space-y-2 shadow-2xl">
		<div class="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60">
			<?php $ecNavMode = 'mobile'; theme_menu(); ?>
			<?php if ($ecDiscord !== ''): ?><a href="<?= $h($ecDiscord) ?>" target="_blank" rel="noopener" class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-indigo-500/30 text-xs font-medium text-indigo-400 active:bg-slate-800 flex items-center gap-2 transition-all"><?= $ecDiscordSvg ?><span>Discord</span></a><?php endif; ?>
		</div>
		<div class="grid grid-cols-2 gap-2 pt-1">
			<?php if ($ecLoggedIn): ?>
				<a href="myaccount.php" class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs font-semibold text-slate-200 text-center flex items-center justify-center gap-1.5"><i data-lucide="user" class="w-3.5 h-3.5 text-amber-400"></i><span><?= $h($user_data['name'] ?? t('eclipse.nav.account')) ?></span></a>
				<?php if ($ecIsAdmin): ?><a href="admin/" class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs font-semibold text-slate-200 text-center flex items-center justify-center gap-1.5"><i data-lucide="shield" class="w-3.5 h-3.5 text-amber-400"></i><span><?= t('eclipse.nav.admin') ?></span></a><?php endif; ?>
				<a href="logout.php" class="p-2.5 rounded-xl bg-slate-800 active:scale-95 text-slate-100 text-xs font-bold text-center flex items-center justify-center gap-1.5 <?= $ecIsAdmin ? 'col-span-2' : '' ?>"><i data-lucide="log-out" class="w-3.5 h-3.5"></i><span><?= t('eclipse.nav.logout') ?></span></a>
			<?php else: ?>
				<a href="login.php" class="col-span-2 p-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 active:scale-95 text-slate-950 text-xs font-bold text-center flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 border-t border-amber-200/50"><i data-lucide="log-in" class="w-3.5 h-3.5"></i><span><?= t('eclipse.nav.login') ?></span></a>
			<?php endif; ?>
		</div>
	</div>
</nav>

<?php
	$ecPage = (string)($page_filename ?? '');
	$ecHasView = static function ($p) { return function_exists('theme_file') && theme_file('views/' . $p . '.php') !== null; };

	// The body the core .php produced. For pages that call view() themselves
	// (index, shop, buypoints, downloads) this already IS the Eclipse view.
	ob_start(); theme_content(); $ecBody = (string) ob_get_clean();

	// index/shop/buypoints/downloads: core called view(), body is theirs.
	$ecSelf = in_array($ecPage, array('index', 'shop', 'buypoints', 'downloads'), true) && $ecHasView($ecPage);

	// register/myaccount/helpdesk print inline HTML with no view() hook. When
	// Eclipse ships a view we render it here from the page's own variables
	// (globals) and drop the default markup - the core files stay untouched.
	$ecShellView = in_array($ecPage, array('register', 'myaccount', 'helpdesk'), true) && $ecHasView($ecPage);
	// The "change character comment" sub-page keeps the default form.
	if ($ecShellView && $ecPage === 'myaccount' && isset($render_page) && $render_page === false) {
		$ecShellView = false;
	}
	// Flash notices myaccount.php echoes before its <div id="myaccount"> block.
	$ecFlash = '';
	if ($ecShellView && $ecPage === 'myaccount') {
		$split = explode('<div id="myaccount"', $ecBody, 2);
		if (count($split) === 2) { $ecFlash = trim($split[0]); }
	}

	$ecNarrow = ($ecShellView && $ecPage === 'register')
		|| in_array($ecPage, array('login', 'lostaccount', 'createcharacter', 'changepassword'), true);
?>
<main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-8">
	<?php if ($ecSelf): ?>
		<?= $ecBody ?>
	<?php elseif ($ecShellView && $ecPage === 'register'): ?>
		<div class="py-2 sm:py-6 flex justify-center">
			<div class="ec-content ec-narrow w-full max-w-[480px] bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-5 sm:p-7 md:p-8 shadow-2xl relative overflow-hidden">
				<div class="absolute -top-20 -right-20 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
				<div class="relative z-10"><?php view('register'); ?></div>
			</div>
		</div>
	<?php elseif ($ecShellView): ?>
		<?php if ($ecFlash !== ''): ?>
			<div class="ec-content max-w-4xl mx-auto mb-4 rounded-xl bg-slate-950/70 border border-amber-500/30 px-4 py-3 text-sm"><?= $ecFlash ?></div>
		<?php endif; ?>
		<?php view($ecPage); ?>
	<?php elseif ($ecNarrow): ?>
		<div class="py-2 sm:py-6 flex justify-center">
			<div class="ec-content ec-narrow w-full max-w-[480px] bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800/80 rounded-2xl sm:rounded-3xl p-5 sm:p-7 md:p-8 shadow-2xl relative overflow-hidden">
				<div class="absolute -top-20 -right-20 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
				<div class="relative z-10"><?= $ecBody ?></div>
			</div>
		</div>
	<?php else: ?>
		<div class="ec-content bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 sm:p-6 md:p-8 shadow-xl">
			<?= $ecBody ?>
		</div>
	<?php endif; ?>
</main>

<footer class="border-t border-slate-800/80 bg-[#101423] py-8 text-xs text-slate-400 mt-auto">
	<div class="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-3 gap-6 text-center sm:text-left">
		<div class="space-y-2">
			<img src="<?= $ecLogo ?>" alt="<?= $h($ecSite) ?>" class="h-9 w-auto object-contain mx-auto sm:mx-0">
			<?php if ($ecFooter !== ''): ?><p class="text-slate-400 text-[11px] leading-relaxed"><?= $ecFooter ?></p><?php endif; ?>
			<div class="text-slate-500 text-[10px]"><?= t('eclipse.footer.server_time') ?> <span id="ec-clock" class="font-mono text-slate-300">00:00:00</span></div>
		</div>
		<div class="flex flex-col space-y-2 text-xs">
			<div class="text-white font-semibold uppercase text-[11px] tracking-wider text-slate-300"><?= t('eclipse.footer.links') ?></div>
			<a href="highscores.php" class="hover:text-amber-300 transition-colors"><?= t('nav.highscores') ?></a>
			<a href="serverinfo.php" class="hover:text-amber-300 transition-colors"><?= t('nav.serverinfo') ?></a>
			<a href="downloads.php" class="hover:text-amber-300 transition-colors"><?= t('eclipse.nav.download') ?></a>
			<a href="credits.php" class="hover:text-amber-300 transition-colors"><?= t('eclipse.footer.credits') ?></a>
			<?php if ($ecForum !== ''): ?><a href="<?= $h($ecForum) ?>" target="_blank" rel="noopener" class="hover:text-amber-300 transition-colors"><?= t('eclipse.nav.forum') ?></a><?php endif; ?>
		</div>
		<div class="flex flex-col justify-between space-y-3">
			<div class="text-white font-semibold uppercase text-[11px] tracking-wider text-slate-300"><?= t('eclipse.footer.social') ?></div>
			<div class="flex items-center justify-center sm:justify-start gap-4">
				<?php if ($ecDiscord !== ''): ?><a href="<?= $h($ecDiscord) ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 transition"><?= $ecDiscordSvg ?><span>Discord</span></a><?php endif; ?>
				<a href="support.php" class="text-slate-400 hover:text-amber-300 transition"><?= t('nav.support') ?></a>
			</div>
		</div>
	</div>
	<div class="max-w-7xl mx-auto px-4 sm:px-6 pt-6 mt-6 border-t border-slate-800/60 text-center text-slate-500 text-[11px] flex flex-col sm:flex-row items-center justify-between gap-2">
		<div><?= t('eclipse.footer.copyright', ['year' => date('Y'), 'site' => $h($ecSite)]) ?></div>
		<div class="text-slate-500 text-[10px]"><?= t('eclipse.footer.powered') ?> <a href="credits.php" class="hover:text-amber-300">ZnoteX</a> &middot; <?= elapsedTime() ?>s</div>
	</div>
</footer>

<script src="<?= theme_asset('js/eclipse.js') ?>" defer></script>
</body>
</html>
