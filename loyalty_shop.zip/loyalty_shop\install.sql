﻿CREATE TABLE IF NOT EXISTS `znote_loyalty_accounts` (
  `account_id` int NOT NULL,
  `spent_points` int NOT NULL DEFAULT '0',
  `bonus_points` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_loyalty_payment_bonus` (
  `source` varchar(160) NOT NULL,
  `account_id` int NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `bonus_points` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`source`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
