<?php

return array(
	'loyalty_shop.vip_title' => 'Fidelidade VIP',
	'loyalty_shop.starter' => 'Iniciante',
	'loyalty_shop.shop_discount' => '{pct}% de desconto na loja',
	'loyalty_shop.cashback_pct' => '{pct}% de cashback em pagamentos/loja',
	'loyalty_shop.loyalty_points' => '{n} pontos de fidelidade',
	'loyalty_shop.cashback_earned' => 'Cashback ganho: +{n} pontos',
	'loyalty_shop.next_tier' => 'Próximo nível: {name} em {n} pontos. Próximo cashback: {pct}%.',
	'loyalty_shop.top_tier' => 'Nível máximo alcançado.',
	'loyalty_shop.payment_note' => '<strong>Fidelidade VIP:</strong> pagamentos de pontos confirmados dão +{pct}% de pontos bônus para o seu nível atual.',
	'loyalty_shop.vip_off' => 'VIP -{pct}%',
	'loyalty_shop.cashback_tag' => '+{n} cashback {pct}%',
	'loyalty_shop.vip_tag' => 'VIP',
);
