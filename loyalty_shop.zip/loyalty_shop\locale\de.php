<?php

return array(
	'loyalty_shop.vip_title' => 'VIP-Treue',
	'loyalty_shop.starter' => 'Anfänger',
	'loyalty_shop.shop_discount' => '{pct}% Shop-Rabatt',
	'loyalty_shop.cashback_pct' => '{pct}% Cashback auf Zahlungen/Shop',
	'loyalty_shop.loyalty_points' => '{n} Treuepunkte',
	'loyalty_shop.cashback_earned' => 'Erhaltenes Cashback: +{n} Punkte',
	'loyalty_shop.next_tier' => 'Nächste Stufe: {name} in {n} Punkten. Nächstes Cashback: {pct}%.',
	'loyalty_shop.top_tier' => 'Höchste Stufe erreicht.',
	'loyalty_shop.payment_note' => '<strong>VIP-Treue:</strong> bestätigte Punkte-Zahlungen geben +{pct}% Bonuspunkte für deine aktuelle Stufe.',
	'loyalty_shop.vip_off' => 'VIP -{pct}%',
	'loyalty_shop.cashback_tag' => '+{n} Cashback {pct}%',
	'loyalty_shop.vip_tag' => 'VIP',
);
