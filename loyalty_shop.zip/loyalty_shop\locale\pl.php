<?php

return array(
	'loyalty_shop.vip_title' => 'Lojalność VIP',
	'loyalty_shop.starter' => 'Początkujący',
	'loyalty_shop.shop_discount' => '{pct}% zniżki w sklepie',
	'loyalty_shop.cashback_pct' => '{pct}% zwrotu za płatności/sklep',
	'loyalty_shop.loyalty_points' => '{n} punktów lojalnościowych',
	'loyalty_shop.cashback_earned' => 'Zdobyty zwrot: +{n} punktów',
	'loyalty_shop.next_tier' => 'Następny poziom: {name} za {n} punktów. Następny zwrot: {pct}%.',
	'loyalty_shop.top_tier' => 'Osiągnięto najwyższy poziom.',
	'loyalty_shop.payment_note' => '<strong>Lojalność VIP:</strong> potwierdzone płatności punktami dają +{pct}% punktów bonusowych dla Twojego poziomu.',
	'loyalty_shop.vip_off' => 'VIP -{pct}%',
	'loyalty_shop.cashback_tag' => '+{n} zwrot {pct}%',
	'loyalty_shop.vip_tag' => 'VIP',
);
