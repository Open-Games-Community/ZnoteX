<?php
if (!function_exists('loyalty_shop_setting')) {
function loyalty_shop_setting(string $k,string $d): string { return function_exists('setting')?(string)setting('loyalty_shop:'.$k,$d):$d; }
function loyalty_shop_enabled(): bool { return loyalty_shop_setting('enabled','1')==='1'; }
function loyalty_shop_h($v): string { return htmlspecialchars((string)($v??''),ENT_QUOTES,'UTF-8'); }
function loyalty_shop_style_color(string $k): string { $v=trim(loyalty_shop_setting('style_'.$k,'')); return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$v)?$v:''; }
function loyalty_shop_style_attr(array $map): string { $css=''; foreach($map as $k=>$var){$v=loyalty_shop_style_color($k); if($v!=='')$css.=$var.':'.$v.';';} return $css!==''?' style="'.loyalty_shop_h($css).'"':''; }
function loyalty_shop_style_vars_css(string $selector,array $map): string { $css=''; foreach($map as $k=>$var){$v=loyalty_shop_style_color($k); if($v!=='')$css.=$var.':'.$v.';';} return $css!==''?$selector.'{'.$css.'}':''; }
function loyalty_shop_default_tiers(): array { return [['name'=>'Bronze','spent'=>100,'discount'=>2,'bonus'=>1],['name'=>'Silver','spent'=>500,'discount'=>5,'bonus'=>2],['name'=>'Gold','spent'=>1500,'discount'=>8,'bonus'=>4],['name'=>'Diamond','spent'=>4000,'discount'=>12,'bonus'=>6]]; }
function loyalty_shop_tiers(): array { $t=json_decode(loyalty_shop_setting('tiers',''),true); return is_array($t)?$t:loyalty_shop_default_tiers(); }
function loyalty_shop_row(int $aid): array { if(!function_exists('znote_table_exists')||!znote_table_exists('znote_loyalty_accounts')) return ['spent_points'=>0,'bonus_points'=>0]; $r=db()->fetchOne("SELECT * FROM `znote_loyalty_accounts` WHERE `account_id` = ? LIMIT 1;", [$aid]); return is_array($r)?$r:['spent_points'=>0,'bonus_points'=>0]; }
function loyalty_shop_tier_for(int $spent): array { $best=['name'=>'Starter','spent'=>0,'discount'=>0,'bonus'=>0]; foreach(loyalty_shop_tiers() as $t) if($spent >= (int)($t['spent']??0)) $best=$t; return $best; }
function loyalty_shop_next_tier(int $spent): ?array { foreach(loyalty_shop_tiers() as $t) if($spent < (int)($t['spent']??0)) return $t; return null; }
function loyalty_shop_bonus_percent(array $tier): int { return max(0,min(50,(int)($tier['bonus']??0))); }
function loyalty_shop_ensure_payment_schema(): void {
	if(!function_exists('znote_table_exists')||znote_table_exists('znote_loyalty_payment_bonus')) return;
	db()->execute("CREATE TABLE IF NOT EXISTS `znote_loyalty_payment_bonus` (`source` varchar(160) NOT NULL,`account_id` int NOT NULL,`points` int NOT NULL DEFAULT '0',`bonus_points` int NOT NULL DEFAULT '0',`created_at` int NOT NULL DEFAULT '0',PRIMARY KEY (`source`),KEY `account_id` (`account_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
}
function loyalty_shop_award_payment_bonus(string $source,int $aid,int $points): void {
	if($source===''||$aid<=0||$points<=0) return;
	loyalty_shop_ensure_payment_schema();
	if(!function_exists('znote_table_exists')||!znote_table_exists('znote_loyalty_payment_bonus')||!znote_table_exists('znote_loyalty_accounts')) return;
	$s=substr($source,0,160);

	// Locked on the idempotency key (source), so the same payment reference
	// firing twice (a retried webhook, a duplicate hook call) can only award
	// the bonus once.
	db()->transaction(function ($db) use ($s,$aid,$points) {
		$exists=$db->fetchOne("SELECT `source` FROM `znote_loyalty_payment_bonus` WHERE `source` = ? LIMIT 1 FOR UPDATE;", [$s]);
		if(is_array($exists)) return false;

		$row=loyalty_shop_row($aid); $tier=loyalty_shop_tier_for((int)$row['spent_points']); $bonusPercent=loyalty_shop_bonus_percent($tier); $bonus=(int)floor($points*$bonusPercent/100); $now=time();
		$db->execute("INSERT INTO `znote_loyalty_payment_bonus` (`source`,`account_id`,`points`,`bonus_points`,`created_at`) VALUES (?, ?, ?, ?, ?);", [$s, $aid, $points, $bonus, $now]);
		$db->execute("INSERT INTO `znote_loyalty_accounts` (`account_id`,`spent_points`,`bonus_points`,`updated_at`) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE `spent_points`=`spent_points`+?,`bonus_points`=`bonus_points`+?,`updated_at`=?;", [$aid, $points, $bonus, $now, $points, $bonus, $now]);
		if($bonus>0) $db->execute("UPDATE `znote_accounts` SET `points`=COALESCE(`points`,0)+? WHERE `account_id` = ?;", [$bonus, $aid]);

		return true;
	});
}
function loyalty_shop_table_columns(string $table): array {
	if(!function_exists('znote_table_exists')||!znote_table_exists($table)) return array();
	$rows=db()->fetchAll("SHOW COLUMNS FROM `{$table}`;"); $cols=array();
	if(is_array($rows)) foreach($rows as $r) if(!empty($r['Field'])) $cols[(string)$r['Field']]=true;
	return $cols;
}
function loyalty_shop_sync_payment_bonuses(): void {
	if(!loyalty_shop_enabled()||!function_exists('znote_table_exists')) return;
	loyalty_shop_ensure_payment_schema();
	if(znote_table_exists('znote_payment_transactions')){
		$rows=db()->fetchAll("SELECT `id`,`provider`,`reference`,`account_id`,`points` FROM `znote_payment_transactions` WHERE `credited`=1 AND `account_id`>0 AND `points`>0 ORDER BY `credited_at` DESC LIMIT 50;");
		if(is_array($rows)) foreach($rows as $r) loyalty_shop_award_payment_bonus('payment:'.(string)$r['provider'].':'.(string)$r['reference'],(int)$r['account_id'],(int)$r['points']);
	}
	$cols=loyalty_shop_table_columns('znote_paypal');
	if(isset($cols['id'],$cols['txn_id'],$cols['custom'],$cols['points'])){
		$rows=db()->fetchAll("SELECT `id`,`txn_id`,`custom`,`points` FROM `znote_paypal` WHERE `custom`>0 AND `points`>0 AND `txn_id`<>'' ORDER BY `id` DESC LIMIT 50;");
		if(is_array($rows)) foreach($rows as $r) loyalty_shop_award_payment_bonus('paypal:'.(string)$r['txn_id'],(int)$r['custom'],(int)$r['points']);
	}
	$cols=loyalty_shop_table_columns('znote_pagseguro');
	if(isset($cols['id'],$cols['transaction'],$cols['account'],$cols['points'],$cols['completed'])){
		$rows=db()->fetchAll("SELECT `id`,`transaction`,`account`,`points` FROM `znote_pagseguro` WHERE `completed`=1 AND `account`>0 AND `points`>0 AND `transaction`<>'' ORDER BY `id` DESC LIMIT 50;");
		if(is_array($rows)) foreach($rows as $r) loyalty_shop_award_payment_bonus('pagseguro:'.(string)$r['transaction'],(int)$r['account'],(int)$r['points']);
	}
	$cols=loyalty_shop_table_columns('znote_paygol');
	$accountCol=isset($cols['account_id'])?'account_id':(isset($cols['account'])?'account':(isset($cols['custom'])?'custom':''));
	if($accountCol!==''&&isset($cols['id'],$cols['points'],$cols['message_id'])){
		$rows=db()->fetchAll("SELECT `id`,`message_id`,`{$accountCol}` AS `account_id`,`points` FROM `znote_paygol` WHERE `{$accountCol}`>0 AND `points`>0 AND `message_id`<>'' ORDER BY `id` DESC LIMIT 50;");
		if(is_array($rows)) foreach($rows as $r) loyalty_shop_award_payment_bonus('paygol:'.(string)$r['message_id'],(int)$r['account_id'],(int)$r['points']);
	}
}
function loyalty_shop_purchased(array $d): void {
	if(!loyalty_shop_enabled()||!function_exists('znote_table_exists')||!znote_table_exists('znote_loyalty_accounts')) return;
	$aid=(int)($d['account_id']??0); $pts=max(0,(int)($d['points']??0)); if($aid<=0||$pts<=0) return; $before=loyalty_shop_row($aid); $tier=loyalty_shop_tier_for((int)$before['spent_points']); $bonusPercent=loyalty_shop_bonus_percent($tier); $bonus=(int)floor($pts*$bonusPercent/100); $now=time();
	db()->execute("INSERT INTO `znote_loyalty_accounts` (`account_id`,`spent_points`,`bonus_points`,`updated_at`) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE `spent_points`=`spent_points`+?,`bonus_points`=`bonus_points`+?,`updated_at`=?;", [$aid, $pts, $bonus, $now, $pts, $bonus, $now]);
	if($bonus>0) db()->execute("UPDATE `znote_accounts` SET `points`=COALESCE(`points`,0)+? WHERE `account_id` = ?;", [$bonus, $aid]);
}
function loyalty_shop_price($price,array $d){ if(!loyalty_shop_enabled()) return $price; $aid=(int)($d['account_id']??0); if($aid<=0) return $price; $tier=loyalty_shop_tier_for((int)loyalty_shop_row($aid)['spent_points']); $disc=max(0,min(90,(int)($tier['discount']??0))); return $disc>0 ? max(1,(int)floor(((int)$price)*(100-$disc)/100)) : $price; }
function loyalty_shop_shop_footer(): string {
	if(!loyalty_shop_enabled()||basename((string)($_SERVER['SCRIPT_NAME']??''))!=='shop.php'||empty($GLOBALS['session_user_id'])||!function_exists('znote_table_exists')||!znote_table_exists('znote_shop_offers')) return '';
	$aid=(int)$GLOBALS['session_user_id']; $loyaltyRow=loyalty_shop_row($aid); $spent=(int)$loyaltyRow['spent_points']; $tier=loyalty_shop_tier_for($spent); $disc=max(0,min(90,(int)($tier['discount']??0))); $cashback=loyalty_shop_bonus_percent($tier); if($aid<=0||($disc<=0&&$cashback<=0)) return '';
	$columns=function_exists('shop_db_offer_columns')?shop_db_offer_columns():array(); $where=!empty($columns['active'])?'WHERE `active` = 1':'';
	$rows=db()->fetchAll("SELECT `id`,`points` FROM `znote_shop_offers` {$where};"); if(!is_array($rows)) return '';
	$prices=array(); foreach($rows as $r){$id=(int)$r['id']; $base=max(0,(int)$r['points']); $vip=(int)loyalty_shop_price($base,array('account_id'=>$aid,'offer_id'=>$id)); $bonus=(int)floor($vip*$cashback/100); if($id>0&&$base>0&&($vip<$base||$bonus>0))$prices[$id]=array('base'=>$base,'vip'=>$vip,'discount'=>$disc,'bonus'=>$bonus,'cashback'=>$cashback);}
	if(empty($prices)) return '';
	$currentPoints=(int)($GLOBALS['user_znote_data']['points']??0);
	$css='.ls-vip-price{display:inline-flex;flex-wrap:wrap;align-items:center;gap:6px;color:var(--ls-shop-text,inherit)}.ls-vip-price__old{text-decoration:line-through;opacity:.55;color:var(--ls-shop-old,inherit)}.ls-vip-price__new{font-weight:800;color:var(--ls-shop-new,inherit)}.ls-vip-price__tag{font-size:10px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;opacity:.72;color:var(--ls-shop-tag,inherit)}'.loyalty_shop_style_vars_css('.ls-vip-price',['shop_text'=>'--ls-shop-text','shop_old'=>'--ls-shop-old','shop_new'=>'--ls-shop-new','shop_tag'=>'--ls-shop-tag']);
	$js='(function(){var prices='.json_encode($prices).',points='.json_encode($currentPoints).',T_VIPOFF='.json_encode(t_default('loyalty_shop.vip_off','VIP -{pct}%')).',T_CBTAG='.json_encode(t_default('loyalty_shop.cashback_tag','+{n} cashback {pct}%')).';if(!prices)return;if(!document.getElementById("loyaltyShopPriceCss")){var s=document.createElement("style");s.id="loyaltyShopPriceCss";s.textContent='.json_encode($css).';document.head.appendChild(s);}function fmt(n){try{return Number(n).toLocaleString();}catch(e){return String(n);}}function patchText(node,p){if(!node||node.getAttribute("data-loyalty-price-patched"))return;var html=node.innerHTML,base=fmt(p.base),raw=String(p.base),discount=p.vip<p.base?"<span class=\"ls-vip-price__tag\">"+T_VIPOFF.replace("{pct}",p.discount)+"</span>":"",bonus=p.bonus>0?"<span class=\"ls-vip-price__tag\">"+T_CBTAG.replace("{n}",fmt(p.bonus)).replace("{pct}",p.cashback)+"</span>":"";var out="<span class=\"ls-vip-price\"><span class=\"ls-vip-price__old\">"+base+"</span><span class=\"ls-vip-price__new\">"+fmt(p.vip)+"</span>"+discount+bonus+"</span>";if(html.indexOf(base)!==-1)node.innerHTML=html.replace(base,out);else if(html.indexOf(raw)!==-1)node.innerHTML=html.replace(raw,out);else node.innerHTML=out;node.setAttribute("data-loyalty-price-patched","1");}document.querySelectorAll("form input[name=buy]").forEach(function(input){var id=parseInt(input.value,10),p=prices[id];if(!p)return;var form=input.closest("form");if(!form)return;var btn=form.querySelector("button,input[type=submit]");if(btn){btn.setAttribute("data-item-cost",p.vip);if(points>=p.vip)btn.disabled=false;}var card=form.closest("article,li,.ts-shop-card,.void-shop-card,.shop-offer-card,.ak-mosaic-item,.shop-offer,.shop-card,tr,div");if(!card)return;var baseA=String(p.base);var target=[].slice.call(card.querySelectorAll(".ts-shop-card__cost,.void-shop-card__cost,.shop-offer-price,[class*=cost i],[class*=price i]")).filter(function(n){return !n.closest("form")&&/\\d/.test(n.textContent||"");})[0];if(!target){var cands=[].slice.call(card.querySelectorAll("td,span,b,strong,em,small,p,div")).filter(function(n){if(n.closest("form"))return false;var t=(n.textContent||"").replace(/[\\s\\u00a0,]/g,"");var m=t.match(/^\\d+/);return m&&m[0]===baseA&&t.length<=baseA.length+9;});cands.sort(function(a,b){return (a.textContent||"").length-(b.textContent||"").length;});target=cands[0];}patchText(target,p);});}());';
	return '<script>'.$js.'</script>';
}
function loyalty_shop_buypoints_footer(): string {
	if(!loyalty_shop_enabled()||basename((string)($_SERVER['SCRIPT_NAME']??''))!=='buypoints.php'||empty($GLOBALS['session_user_id'])) return '';
	$aid=(int)$GLOBALS['session_user_id']; $row=loyalty_shop_row($aid); $tier=loyalty_shop_tier_for((int)$row['spent_points']); $bonusPercent=loyalty_shop_bonus_percent($tier); if($bonusPercent<=0) return '';
	$prices=(array)($GLOBALS['config']['paypal_prices']??array()); $packages=array();
	foreach($prices as $price=>$points){$p=(int)$points; $bonus=(int)floor($p*$bonusPercent/100); if($p>0&&$bonus>0)$packages[(string)$price]=array('points'=>$p,'bonus'=>$bonus,'percent'=>$bonusPercent);}
	if(empty($packages)) return '';
	$css='.ls-payment-bonus{display:inline-flex;align-items:center;gap:4px;margin-left:8px;font-size:12px;font-weight:700;opacity:.85;color:var(--ls-payment-bonus-color,inherit)}.ls-payment-bonus::before{content:"+"}.ls-payment-note{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 10px;padding:10px 12px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.9}'.loyalty_shop_style_vars_css('.ls-payment-bonus',['payment_bonus_text'=>'--ls-payment-bonus-color']);
	$html='<div id="loyaltyPaymentBonusNote" class="ls-payment-note"'.loyalty_shop_style_attr(['payment_box_bg'=>'--znx-plugin-surface','payment_text'=>'--znx-plugin-text','payment_border'=>'--znx-plugin-border']).'><strong>VIP Loyalty:</strong> confirmed point payments give +'.(int)$bonusPercent.'% bonus points for your current tier.</div>';
	$js='(function(){var packages='.json_encode($packages).',T_VIPTAG='.json_encode(t_default('loyalty_shop.vip_tag','VIP')).';if(!packages)return;if(!document.getElementById("loyaltyPaymentBonusCss")){var s=document.createElement("style");s.id="loyaltyPaymentBonusCss";s.textContent='.json_encode($css).';document.head.appendChild(s);}function fmt(n){try{return Number(n).toLocaleString();}catch(e){return String(n);}}if(!document.getElementById("loyaltyPaymentBonusNote")){var t=document.querySelector("table,#buypointsTable,form");if(t&&t.parentNode){var w=document.createElement("div");w.innerHTML='.json_encode($html).';t.parentNode.insertBefore(w.firstChild,t);}}document.querySelectorAll("form").forEach(function(form){var priceInput=form.querySelector("input[name=amount],input[name=price]");if(!priceInput)return;var key=String(priceInput.value),p=packages[key]||packages[String(parseFloat(key))];if(!p)return;var row=form.closest("tr")||form.parentNode;if(!row||row.getAttribute("data-loyalty-payment-patched"))return;var cells=row.querySelectorAll("td");var target=cells.length>=3?cells[2]:(cells.length>=2?cells[1]:row);var span=document.createElement("span");span.className="ls-payment-bonus";span.textContent=fmt(p.bonus)+" "+T_VIPTAG;target.appendChild(span);row.setAttribute("data-loyalty-payment-patched","1");});}());';
	return '<script>'.$js.'</script>';
}
function loyalty_shop_footer(): string {
	loyalty_shop_sync_payment_bonuses();
	$page=basename((string)($_SERVER['SCRIPT_NAME']??''));
	if($page==='shop.php') return loyalty_shop_shop_footer();
	if($page==='buypoints.php') return loyalty_shop_buypoints_footer();
	if(!loyalty_shop_enabled()||$page!=='myaccount.php'||empty($GLOBALS['session_user_id'])) return '';
	$aid=(int)$GLOBALS['session_user_id']; $row=loyalty_shop_row($aid); $spent=(int)$row['spent_points']; $bonusEarned=(int)($row['bonus_points']??0); $tier=loyalty_shop_tier_for($spent); $next=loyalty_shop_next_tier($spent); $need=$next?max(0,(int)$next['spent']-$spent):0; $pct=$next?min(100,(int)floor($spent/(int)$next['spent']*100)):100;
	$css='.ls-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 18px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.96;overflow:hidden}.ls-box *{box-sizing:border-box}.ls-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;overflow-wrap:anywhere}.ls-badge{padding:6px 10px;border-radius:999px;border:1px solid var(--znx-plugin-border);background:var(--ls-badge-bg,var(--znx-plugin-surface));color:var(--ls-badge-text,var(--znx-plugin-text))}.ls-bar{height:8px;margin-top:10px;border-radius:99px;border:1px solid var(--znx-plugin-border);background:var(--ls-bar-bg,transparent);opacity:.75;overflow:hidden}.ls-bar i{display:block;height:100%;background:var(--ls-bar-fill,currentColor);opacity:.55}.ls-box p{margin:8px 0 0;overflow-wrap:anywhere}';
	$html='<div id="loyaltyShopBox" class="ls-box"'.loyalty_shop_style_attr(['myaccount_box_bg'=>'--znx-plugin-surface','myaccount_text'=>'--znx-plugin-text','myaccount_border'=>'--znx-plugin-border','myaccount_badge_bg'=>'--ls-badge-bg','myaccount_badge_text'=>'--ls-badge-text','myaccount_bar_bg'=>'--ls-bar-bg','myaccount_bar_fill'=>'--ls-bar-fill']).'><div class="ls-row"><strong>VIP Loyalty</strong><span class="ls-badge">'.loyalty_shop_h($tier['name']??'Starter').'</span><span>'.(int)($tier['discount']??0).'% shop discount</span><span>'.loyalty_shop_bonus_percent($tier).'% payment/shop cashback</span><span>'.number_format($spent).' loyalty points</span><span>Cashback earned: +'.number_format($bonusEarned).' points</span></div><div class="ls-bar"><i style="width:'.$pct.'%"></i></div><p>'.($next?loyalty_shop_h(t_default('loyalty_shop.next_tier','Next tier: {name} in {n} points. Next cashback: {pct}%.',['name'=>(string)($next['name']??''),'n'=>$need,'pct'=>loyalty_shop_bonus_percent($next)])):loyalty_shop_h(t_default('loyalty_shop.top_tier','Top tier reached.'))).'</p></div>';
	return '<script>(function(){if(document.getElementById("loyaltyShopBox"))return;var s=document.createElement("style");s.textContent='.json_encode($css).';document.head.appendChild(s);var root=document.getElementById("myaccount")||document.querySelector("main,#content,.content");if(!root)return;var w=document.createElement("div");w.innerHTML='.json_encode($html).';root.insertBefore(w.firstChild,root.firstChild);}());</script>';
}
}
if(function_exists('znote_hook_register')){znote_hook_register('shop.purchased','loyalty_shop_purchased');znote_hook_register('shop.price','loyalty_shop_price');znote_hook_register('page.footer','loyalty_shop_footer');}
