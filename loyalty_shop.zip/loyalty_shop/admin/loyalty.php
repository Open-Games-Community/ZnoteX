<?php
/**
 * Title: VIP Loyalty
 * Icon: fa-star
 * Group: Installed Plugins
 * Order: 40
 * Description: Configure VIP spending tiers.
 */
if(!defined('ACP_ROOT')){http_response_code(403);die('Direct access denied.');}
function loyalty_shop_admin_color($v):string{$v=trim((string)$v);return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$v)?$v:'';}
if($_SERVER['REQUEST_METHOD']==='POST'){ $tiers=[]; foreach(($_POST['name']??[]) as $i=>$name){$name=trim((string)$name); if($name==='')continue; $tiers[]=['name'=>$name,'spent'=>max(0,(int)($_POST['spent'][$i]??0)),'discount'=>max(0,min(90,(int)($_POST['discount'][$i]??0))),'bonus'=>max(0,min(50,(int)($_POST['bonus'][$i]??0)))];} usort($tiers,fn($a,$b)=>$a['spent']<=>$b['spent']); setting_set('loyalty_shop:enabled',!empty($_POST['enabled'])?'1':'0'); setting_set('loyalty_shop:tiers',json_encode($tiers)); foreach(['myaccount_box_bg','myaccount_text','myaccount_border','myaccount_badge_bg','myaccount_badge_text','myaccount_bar_bg','myaccount_bar_fill','shop_text','shop_old','shop_new','shop_tag','payment_box_bg','payment_text','payment_border','payment_bonus_text'] as $k)setting_set('loyalty_shop:style_'.$k,loyalty_shop_admin_color($_POST['style_'.$k]??'')); acp_flash_success('Loyalty tiers saved.'); acp_redirect('loyalty_shop__loyalty');}
$tiers=json_decode((string)setting('loyalty_shop:tiers',''),true)?:loyalty_shop_default_tiers(); $enabled=(string)setting('loyalty_shop:enabled','1')==='1';
$styleGroups=[
	'My Account'=>['myaccount_box_bg'=>'Box background','myaccount_text'=>'Text color','myaccount_border'=>'Border color','myaccount_badge_bg'=>'Badge background','myaccount_badge_text'=>'Badge text','myaccount_bar_bg'=>'Progress bar background','myaccount_bar_fill'=>'Progress bar fill'],
	'Shop Price Display'=>['shop_text'=>'VIP price text','shop_old'=>'Old price text','shop_new'=>'New price text','shop_tag'=>'Discount/cashback tag'],
	'Buy Points Display'=>['payment_box_bg'=>'Info box background','payment_text'=>'Info box text','payment_border'=>'Info box border','payment_bonus_text'=>'Bonus label text'],
];
?>
<?php acp_card_open('VIP Loyalty Shop','Discount applies on shop purchases. Bonus % is cashback on confirmed shop point payments and item shop purchases.'); ?>
<form method="post"><?= acp_csrf_field() ?><label><input type="checkbox" name="enabled" value="1" <?= $enabled?'checked':'' ?>> Enabled</label><div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Tier</th><th>Loyalty points required</th><th>Shop discount %</th><th>Payment bonus %</th></tr></thead><tbody>
<?php for($i=0;$i<6;$i++):$t=$tiers[$i]??['name'=>'','spent'=>0,'discount'=>0,'bonus'=>0];?><tr><td><input class="acp-input" name="name[]" value="<?= h($t['name']) ?>"></td><td><input class="acp-input" type="number" min="0" name="spent[]" value="<?= (int)$t['spent'] ?>"></td><td><input class="acp-input" type="number" min="0" max="90" name="discount[]" value="<?= (int)$t['discount'] ?>"></td><td><input class="acp-input" type="number" min="0" max="50" name="bonus[]" value="<?= min(50,(int)$t['bonus']) ?>"></td></tr><?php endfor; ?>
</tbody></table></div><?php foreach($styleGroups as $group=>$fields):?><h3><?= h($group) ?> Style</h3><p class="acp-muted">Leave empty to inherit the theme, with default theme fallback.</p><div class="acp-grid acp-grid--2"><?php foreach($fields as $k=>$label):?><div class="acp-field"><label class="acp-label"><?= h($label) ?></label><?php acp_color_field('style_'.$k, (string) setting('loyalty_shop:style_'.$k,''), '#1e2128 or rgba(30,33,40,.95)'); ?></div><?php endforeach;?></div><?php endforeach;?><div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit">Save</button></div></form>
<?php acp_card_close(); ?>
