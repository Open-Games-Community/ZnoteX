<?php

return array(
	'loyalty_shop.vip_title' => 'VIP Loyalty',
	'loyalty_shop.starter' => 'Starter',
	'loyalty_shop.shop_discount' => '{pct}% shop discount',
	'loyalty_shop.cashback_pct' => '{pct}% payment/shop cashback',
	'loyalty_shop.loyalty_points' => '{n} loyalty points',
	'loyalty_shop.cashback_earned' => 'Cashback earned: +{n} points',
	'loyalty_shop.next_tier' => 'Next tier: {name} in {n} points. Next cashback: {pct}%.',
	'loyalty_shop.top_tier' => 'Top tier reached.',
	'loyalty_shop.payment_note' => '<strong>VIP Loyalty:</strong> confirmed point payments give +{pct}% bonus points for your current tier.',
	'loyalty_shop.vip_off' => 'VIP -{pct}%',
	'loyalty_shop.cashback_tag' => '+{n} cashback {pct}%',
	'loyalty_shop.vip_tag' => 'VIP',
);
