<?php

return array(
	'loyalty_shop.vip_title' => 'Fidelidad VIP',
	'loyalty_shop.starter' => 'Inicial',
	'loyalty_shop.shop_discount' => '{pct}% de descuento en la tienda',
	'loyalty_shop.cashback_pct' => '{pct}% de reembolso en pagos/tienda',
	'loyalty_shop.loyalty_points' => '{n} puntos de fidelidad',
	'loyalty_shop.cashback_earned' => 'Reembolso ganado: +{n} puntos',
	'loyalty_shop.next_tier' => 'Siguiente nivel: {name} en {n} puntos. Próximo reembolso: {pct}%.',
	'loyalty_shop.top_tier' => 'Nivel máximo alcanzado.',
	'loyalty_shop.payment_note' => '<strong>Fidelidad VIP:</strong> los pagos de puntos confirmados dan +{pct}% de puntos extra para tu nivel actual.',
	'loyalty_shop.vip_off' => 'VIP -{pct}%',
	'loyalty_shop.cashback_tag' => '+{n} reembolso {pct}%',
	'loyalty_shop.vip_tag' => 'VIP',
);
