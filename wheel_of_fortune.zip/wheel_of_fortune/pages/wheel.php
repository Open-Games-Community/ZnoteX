﻿<?php
/**
 * Public page: page.php?plugin=wheel_of_fortune&p=wheel
 *
 * The wheel is drawn server-side; spinning is an AJAX POST to the endpoint in
 * plugin.php (which runs before the theme, so it can answer with clean JSON).
 * The result - segment index and reward - is decided on the server; the page
 * only animates the wheel to that segment. No reload.
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h         = 'wheel_of_fortune_h';
$accountId = wheel_of_fortune_account_id();
$enabled   = wheel_of_fortune_enabled();
$segments  = wheel_of_fortune_segments();
$cost      = wheel_of_fortune_cost();

if (empty($_SESSION['wof_spin_token'])) $_SESSION['wof_spin_token'] = bin2hex(random_bytes(16));

$state    = $accountId > 0 ? wheel_of_fortune_state($accountId) : array('free_spins' => 0, 'total_spins' => 0);
$points   = $accountId > 0 ? wheel_of_fortune_points($accountId) : 0;
$freeLeft = (int) ($state['free_spins'] ?? 0);
$canSpin  = $enabled && $accountId > 0 && ($freeLeft > 0 || $points >= $cost);

$count    = count($segments);
$anglePer = $count > 0 ? 360 / $count : 360;

// ---- server-rendered wheel -------------------------------------------------
$cx = 210; $cy = 210; $r = 202; $rLabel = 118; $rIcon = 162;
$slices = ''; $labels = '';
$wrap = static function (string $s): array {
	$s = trim($s);
	if (strlen($s) <= 12) return array($s);
	$words = preg_split('/\s+/', $s);
	$lines = array(''); $k = 0;
	foreach ($words as $w) {
		if ($lines[$k] !== '' && strlen($lines[$k] . ' ' . $w) > 12) { $lines[++$k] = $w; }
		else { $lines[$k] = $lines[$k] === '' ? $w : $lines[$k] . ' ' . $w; }
	}
	return array_slice($lines, 0, 2);
};
foreach ($segments as $i => $seg) {
	$t1 = deg2rad(($i - 0.5) * $anglePer);
	$t2 = deg2rad(($i + 0.5) * $anglePer);
	$x1 = $cx + $r * sin($t1); $y1 = $cy - $r * cos($t1);
	$x2 = $cx + $r * sin($t2); $y2 = $cy - $r * cos($t2);
	$large = $anglePer > 180 ? 1 : 0;
	$slices .= '<path d="M' . round($cx, 2) . ' ' . round($cy, 2) . ' L' . round($x1, 2) . ' ' . round($y1, 2)
		. ' A' . $r . ' ' . $r . ' 0 ' . $large . ' 1 ' . round($x2, 2) . ' ' . round($y2, 2) . ' Z" fill="' . $h($seg['color'])
		. '" stroke="rgba(0,0,0,.28)" stroke-width="2"></path>';

	$mid = deg2rad($i * $anglePer);
	$lx = $cx + $rLabel * sin($mid); $ly = $cy - $rLabel * cos($mid);
	$label = trim((string) $seg['label']);
	if ($label === '') $label = wheel_of_fortune_reward_text($seg);
	$lines = $wrap($label);
	$icon = wheel_of_fortune_segment_icon($seg);

	$g = '';
	if ($icon !== '') {
		$ix = $cx + $rIcon * sin($mid); $iy = $cy - $rIcon * cos($mid);
		$g .= '<image href="' . $h($icon) . '" x="' . round($ix - 17, 2) . '" y="' . round($iy - 17, 2) . '" width="34" height="34"></image>';
	}
	$ty = $ly - (count($lines) - 1) * 8;
	foreach ($lines as $ln) {
		$g .= '<text x="' . round($lx, 2) . '" y="' . round($ty, 2) . '" text-anchor="middle" dominant-baseline="middle" font-size="13" font-weight="700" fill="' . $h($seg['text_color']) . '" paint-order="stroke" stroke="rgba(0,0,0,.18)" stroke-width="3">' . $h($ln) . '</text>';
		$ty += 15;
	}
	$labels .= $g;
}

// ---- style ---------------------------------------------------------------
$bgImage = wheel_of_fortune_bg_image();
$styleVars = wheel_of_fortune_style_attr(array(
	'box_bg' => '--wof-surface', 'text' => '--wof-text', 'border' => '--wof-border',
	'rim' => '--wof-rim', 'hub' => '--wof-hub', 'pointer' => '--wof-pointer',
	'button_bg' => '--wof-btn-bg', 'button_text' => '--wof-btn-text', 'accent' => '--wof-accent',
));
$pageBg = wheel_of_fortune_color('page_bg');

$title = wheel_of_fortune_text('title', 'wheel_of_fortune.title', 'Wheel of Fortune');
$intro = wheel_of_fortune_text('intro', 'wheel_of_fortune.intro', 'Spend your shop points for a chance at points, premium days, items and more. One spin, one prize.');

$recent = wheel_of_fortune_recent_view($accountId, 8);

$jsConfig = array(
	'count'    => $count,
	'anglePer' => $anglePer,
	'cost'     => $cost,
	'endpoint' => znote_plugin_url('wheel_of_fortune', 'wheel'),
	'token'    => $_SESSION['wof_spin_token'],
	'canSpin'  => (bool) $canSpin,
	'i18n' => array(
		'won'      => wheel_of_fortune_t('wheel_of_fortune.you_won', 'You won'),
		'noluck'   => wheel_of_fortune_t('wheel_of_fortune.rw_nothing', 'No luck this time'),
		'close'    => wheel_of_fortune_t('wheel_of_fortune.close', 'Close'),
		'spinAgain'=> wheel_of_fortune_t('wheel_of_fortune.spin_again', 'Spin again'),
		'spinning' => wheel_of_fortune_t('wheel_of_fortune.spinning', 'Spinning...'),
		'error'    => wheel_of_fortune_t('wheel_of_fortune.error', 'Something went wrong, try again.'),
		'free'     => wheel_of_fortune_t('wheel_of_fortune.free', 'Free'),
		'spin'     => wheel_of_fortune_t('wheel_of_fortune.spin', 'Spin'),
	),
);
?>
<style>
<?php if ($pageBg !== '' || $bgImage !== ''): ?>
body.page_wheel_of_fortune_wheel {
<?php if ($pageBg !== ''): ?>	background-color: <?= $h($pageBg) ?> !important;
<?php endif; ?><?php if ($bgImage !== ''): ?>	background-image: url("<?= $h($bgImage) ?>") !important;
	background-size: cover !important; background-position: center !important; background-attachment: fixed !important;
<?php endif; ?>}
<?php endif; ?>
.wof-wrap{--wof-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--wof-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--wof-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--wof-accent:var(--accent,var(--link,var(--nz-accent,#f4c542)));--wof-rim:#0d0f14;--wof-hub:#f4c542;--wof-pointer:#f4c542;--wof-btn-bg:var(--wof-accent);--wof-btn-text:#151515;color:var(--wof-text)}
.wof-wrap *{box-sizing:border-box}
.wof-hero{text-align:center;margin:0 0 20px}
.wof-hero h1{margin:0 0 6px;font-size:28px;letter-spacing:.02em}
.wof-hero p{margin:0 auto;max-width:640px;opacity:.82;font-size:14px;line-height:1.55}
.wof-stage{display:flex;flex-wrap:wrap;gap:28px;align-items:flex-start;justify-content:center}
.wof-panel{flex:1 1 260px;min-width:250px;max-width:330px;padding:16px;border:1px solid var(--wof-border);border-radius:14px;background:var(--wof-surface)}
.wof-panel h4{margin:0 0 8px;font-size:13px;text-transform:uppercase;letter-spacing:.06em;opacity:.7}
.wof-wheelbox{position:relative;flex:0 0 auto;width:460px;max-width:96vw}
.wof-wheelbox svg{display:block;width:100%;height:auto;overflow:visible;filter:drop-shadow(0 18px 40px rgba(0,0,0,.45))}
#wofWheel{transition:transform 6s cubic-bezier(.1,.62,.16,1);transform-origin:210px 210px}
#wofWheel.wof-nudge{animation:wofNudge .5s ease}
@keyframes wofNudge{25%{transform:rotate(-5deg)}60%{transform:rotate(3deg)}100%{transform:rotate(0)}}
.wof-rim-stroke{fill:none;stroke:var(--wof-rim);stroke-width:13}
.wof-pin-shadow{fill:rgba(0,0,0,.35)}
.wof-pin{fill:var(--wof-pointer);stroke:var(--wof-rim);stroke-width:2.5;stroke-linejoin:round}
.wof-pin-cap{fill:var(--wof-rim)}
.wof-pin-dot{fill:color-mix(in srgb,var(--wof-pointer) 70%,#fff)}
.wof-hub{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:126px;height:126px;border-radius:50%;display:flex;align-items:center;justify-content:center;z-index:2;background:radial-gradient(circle at 32% 24%,#fff4b8 0 9%,color-mix(in srgb,var(--wof-hub) 92%,#fff) 10% 27%,var(--wof-hub) 46%,color-mix(in srgb,var(--wof-hub) 66%,#000) 76%,#8b5c08 100%);border:6px solid var(--wof-rim);box-shadow:0 16px 34px rgba(0,0,0,.48),inset 0 3px 0 rgba(255,255,255,.45),inset 0 -9px 15px rgba(0,0,0,.28)}
.wof-hub::before{content:"";position:absolute;inset:9px;border-radius:50%;border:2px solid rgba(255,255,255,.42);box-shadow:inset 0 0 0 3px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.2);pointer-events:none}
.wof-hub::after{content:"";position:absolute;inset:20px;border-radius:50%;background:radial-gradient(circle at 35% 28%,rgba(255,255,255,.52),rgba(255,255,255,0) 35%),linear-gradient(145deg,#ffc94a 0%,#f3a40d 54%,#c67406 100%);box-shadow:inset 0 2px 0 rgba(255,255,255,.48),inset 0 -5px 9px rgba(86,48,0,.32),0 5px 12px rgba(0,0,0,.28);pointer-events:none}
.wof-spin-btn{position:relative;z-index:1;width:86px!important;height:86px!important;min-width:86px!important;min-height:86px!important;margin:0!important;padding:0!important;border:0!important;border-radius:50%!important;outline:0;appearance:none;-webkit-appearance:none;display:grid!important;place-items:center;cursor:pointer;background:transparent!important;color:#17100a!important;font-weight:950;font-size:16px;line-height:1;letter-spacing:.08em;text-align:center;text-transform:uppercase;text-shadow:0 1px 0 rgba(255,255,255,.55);box-shadow:none!important;transition:transform .14s ease,filter .14s ease}
.wof-spin-btn:not([disabled]):hover{transform:scale(1.04);filter:brightness(1.05)}
.wof-spin-btn:not([disabled]):focus-visible{box-shadow:0 0 0 3px rgba(255,255,255,.48),0 0 0 6px rgba(244,197,66,.34)!important}
.wof-spin-btn:not([disabled]):active{transform:scale(.95)}
.wof-spin-btn[disabled]{cursor:not-allowed;opacity:.62;filter:saturate(.65)}
.wof-cta{display:block;width:100%;margin-top:14px;padding:13px 16px;border:0;border-radius:10px;background:var(--wof-btn-bg);color:var(--wof-btn-text);font-weight:800;font-size:15px;text-transform:uppercase;letter-spacing:.04em;cursor:pointer}
.wof-cta[disabled]{opacity:.5;cursor:not-allowed}
.wof-meta{display:grid;gap:10px;margin:0 0 6px}
.wof-meta div{display:flex;justify-content:space-between;gap:10px;padding:9px 12px;border:1px solid var(--wof-border);border-radius:9px;font-size:14px}
.wof-meta b{color:var(--wof-accent)}
.wof-note{margin:12px 0 0;font-size:12.5px;opacity:.7;line-height:1.5}
.wof-msg{margin:0 0 14px;padding:10px 13px;border-radius:9px;border:1px solid var(--wof-border);font-size:14px}
.wof-msg.is-bad{border-color:#9a3d3d;background:rgba(154,61,61,.14)}
.wof-recent{list-style:none;margin:0;padding:0;display:grid;gap:6px;max-height:260px;overflow:auto}
.wof-recent li{display:flex;justify-content:space-between;gap:10px;font-size:13px;padding:7px 10px;border-radius:7px;background:rgba(255,255,255,.045)}
.wof-recent li.is-new{animation:wofRow .5s ease}
@keyframes wofRow{from{background:var(--wof-accent);color:#151515}to{}}
.wof-recent time{opacity:.6;white-space:nowrap}
.wof-empty{font-size:13px;opacity:.6}
.wof-modal{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;background:rgba(6,8,12,.72);opacity:0;pointer-events:none;transition:opacity .3s}
.wof-modal.is-open{opacity:1;pointer-events:auto}
.wof-modal__card{width:340px;max-width:90vw;text-align:center;padding:26px 22px;border-radius:16px;border:1px solid var(--wof-border);background:var(--wof-surface);color:var(--wof-text);transform:scale(.9);transition:transform .3s}
.wof-modal.is-open .wof-modal__card{transform:scale(1)}
.wof-modal__card h3{margin:0 0 4px;font-size:15px;text-transform:uppercase;letter-spacing:.08em;opacity:.7}
.wof-modal__card strong{display:block;font-size:23px;margin:2px 0 14px;color:var(--wof-accent)}
.wof-modal__card img{width:92px;height:92px;object-fit:contain;margin:0 auto 12px;display:block;padding:14px;border:0;border-radius:50%;background:radial-gradient(circle at 35% 28%,rgba(255,255,255,.18),rgba(255,255,255,.05) 42%,rgba(0,0,0,.22));box-shadow:inset 0 1px 0 rgba(255,255,255,.2),0 10px 26px rgba(0,0,0,.3)}
.wof-modal__card button{margin-top:6px;padding:10px 18px;border:0;border-radius:9px;background:var(--wof-btn-bg);color:var(--wof-btn-text);font-weight:800;cursor:pointer}
@media(max-width:560px){.wof-hero h1{font-size:22px}.wof-panel{max-width:none}}
@media(prefers-reduced-motion:reduce){#wofWheel{transition:transform 1s ease}}
</style>

<div class="wof-wrap" <?= $styleVars ?>>
	<div class="wof-hero">
		<h1><?= $h($title) ?></h1>
		<p><?= $h($intro) ?></p>
	</div>

	<p class="wof-msg is-bad" id="wofError" hidden></p>

	<div class="wof-stage">
		<div class="wof-wheelbox">
			<svg viewBox="0 0 420 420" role="img" aria-label="<?= $h($title) ?>">
				<circle cx="210" cy="210" r="206" fill="var(--wof-rim)"></circle>
				<g id="wofWheel">
					<?= $slices ?>
					<?= $labels ?>
				</g>
				<circle class="wof-rim-stroke" cx="210" cy="210" r="202"></circle>
				<!-- aiguille / needle, fixed above the wheel, pointing into the winning slice -->
				<path class="wof-pin-shadow" d="M210 -6 L232 40 Q210 62 188 40 Z" transform="translate(3 4)"></path>
				<path class="wof-pin" d="M210 -6 L232 40 Q210 62 188 40 Z"></path>
				<circle class="wof-pin-cap" cx="210" cy="8" r="15"></circle>
				<circle class="wof-pin-dot" cx="210" cy="8" r="6"></circle>
			</svg>
			<div class="wof-hub">
				<button class="wof-spin-btn" type="button" id="wofSpinBtn" <?= $canSpin ? '' : 'disabled' ?>>
					<?= $h(wheel_of_fortune_t('wheel_of_fortune.spin', 'Spin')) ?>
				</button>
			</div>
		</div>

		<div class="wof-panel">
			<?php if ($accountId === 0): ?>
				<p class="wof-msg"><?= wheel_of_fortune_t('wheel_of_fortune.login_html', 'You need to <a href="login.php">log in</a> to spin the wheel.') ?></p>
			<?php elseif (!$enabled): ?>
				<p class="wof-msg"><?= $h(wheel_of_fortune_t('wheel_of_fortune.disabled', 'The wheel is currently disabled.')) ?></p>
			<?php endif; ?>

			<div class="wof-meta">
				<div><span><?= $h(wheel_of_fortune_t('wheel_of_fortune.your_points', 'Your points')) ?></span><b id="wofBalance"><?= (int) $points ?></b></div>
				<div><span><?= $h(wheel_of_fortune_t('wheel_of_fortune.cost', 'Cost per spin')) ?></span><b><?= $cost > 0 ? (int) $cost : $h(wheel_of_fortune_t('wheel_of_fortune.free', 'Free')) ?></b></div>
				<div<?= (wheel_of_fortune_daily_free() || $freeLeft > 0) ? '' : ' hidden' ?> id="wofFreeRow"><span><?= $h(wheel_of_fortune_t('wheel_of_fortune.free_spins', 'Free spins')) ?></span><b id="wofFree"><?= (int) $freeLeft ?></b></div>
			</div>

			<button class="wof-cta" type="button" id="wofSpinCta" <?= $canSpin ? '' : 'disabled' ?>>
				<?php if ($freeLeft > 0): ?>
					<?= $h(wheel_of_fortune_t('wheel_of_fortune.spin_free', 'Spin (free)')) ?>
				<?php elseif ($cost > 0): ?>
					<?= $h(wheel_of_fortune_t('wheel_of_fortune.spin_cost', 'Spin ({n} points)', array('n' => $cost))) ?>
				<?php else: ?>
					<?= $h(wheel_of_fortune_t('wheel_of_fortune.spin', 'Spin')) ?>
				<?php endif; ?>
			</button>

			<?php if ($accountId > 0 && $points < $cost && $freeLeft === 0): ?>
				<p class="wof-note" id="wofGetPoints"><?= wheel_of_fortune_t('wheel_of_fortune.get_points_html', 'Not enough points? <a href="buypoints.php">Buy points</a> or <a href="shop.php">visit the shop</a>.') ?></p>
			<?php endif; ?>

			<noscript><p class="wof-note"><?= $h(wheel_of_fortune_t('wheel_of_fortune.need_js', 'JavaScript is required to spin the wheel.')) ?></p></noscript>

			<h4 style="margin-top:16px"><?= $h(wheel_of_fortune_t('wheel_of_fortune.your_spins', 'Your recent spins')) ?></h4>
			<ul class="wof-recent" id="wofRecent">
				<?php foreach ($recent as $row): ?>
					<li><span><?= $h($row['text']) ?><?= $row['free'] ? ' - ' . $h(wheel_of_fortune_t('wheel_of_fortune.free', 'Free')) : '' ?></span><time><?= $h($row['when']) ?></time></li>
				<?php endforeach; ?>
			</ul>
			<p class="wof-empty" id="wofRecentEmpty"<?= $recent ? ' hidden' : '' ?>><?= $h(wheel_of_fortune_t('wheel_of_fortune.no_spins', 'No spins yet - give the wheel a turn.')) ?></p>
		</div>
	</div>
</div>

<div class="wof-modal" id="wofModal" aria-hidden="true">
	<div class="wof-modal__card">
		<h3 id="wofModalHead"></h3>
		<img id="wofModalImg" alt="" hidden>
		<strong id="wofModalText"></strong>
		<button type="button" id="wofModalClose"></button>
	</div>
</div>

<script>window.WOF = <?= json_encode($jsConfig, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="<?= $h(znote_plugin_asset('wheel_of_fortune', 'wheel.js')) ?>" defer></script>




