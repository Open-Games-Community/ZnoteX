CREATE TABLE IF NOT EXISTS `znote_wof_accounts` (
  `account_id` int NOT NULL,
  `free_spins` int NOT NULL DEFAULT '0',
  `last_free_at` int NOT NULL DEFAULT '0',
  `total_spins` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_wof_spins` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `player_id` int NOT NULL DEFAULT '0',
  `segment_key` varchar(48) NOT NULL DEFAULT '',
  `reward_kind` varchar(24) NOT NULL DEFAULT 'nothing',
  `reward_value` int NOT NULL DEFAULT '0',
  `reward_itemid` int NOT NULL DEFAULT '0',
  `reward_count` int NOT NULL DEFAULT '0',
  `cost` int NOT NULL DEFAULT '0',
  `free` tinyint NOT NULL DEFAULT '0',
  `created_at` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_created` (`account_id`, `created_at`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DELETE FROM `znote_menu`
WHERE `url` = 'page.php?plugin=wheel_of_fortune&p=wheel'
  AND `label` = 'Wheel of Fortune';
