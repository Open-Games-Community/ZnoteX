<?php
/**
 * Title: Wheel of Fortune
 * Icon: fa-life-ring
 * Group: Installed Plugins
 * Order: 30
 * Description: Segments, odds, rewards, colours and background for the prize wheel.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'wheel_of_fortune__wheel';

function wheel_of_fortune_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function wheel_of_fortune_admin_url($v): string {
	$v = trim((string) $v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}

$kinds = array('nothing', 'points', 'premium_days', 'item', 'outfit', 'mount', 'free_spin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	setting_set('wheel_of_fortune:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('wheel_of_fortune:daily_free', !empty($_POST['daily_free']) ? '1' : '0');
	setting_set('wheel_of_fortune:show_in_shop', !empty($_POST['show_in_shop']) ? '1' : '0');
	setting_set('wheel_of_fortune:show_floating', !empty($_POST['show_floating']) ? '1' : '0');
	setting_set('wheel_of_fortune:cost', (string) max(0, intv($_POST['cost'] ?? 0)));
	setting_set('wheel_of_fortune:title', trim((string) ($_POST['title'] ?? '')));
	setting_set('wheel_of_fortune:intro', trim((string) ($_POST['intro'] ?? '')));

	foreach (array('page_bg', 'box_bg', 'text', 'border', 'rim', 'hub', 'pointer', 'button_bg', 'button_text', 'accent') as $k) {
		setting_set('wheel_of_fortune:style_' . $k, wheel_of_fortune_admin_color($_POST['style_' . $k] ?? ''));
	}
	setting_set('wheel_of_fortune:style_page_image', wheel_of_fortune_admin_url($_POST['style_page_image'] ?? ''));

	$segments = array();
	$rows = isset($_POST['seg']) && is_array($_POST['seg']) ? $_POST['seg'] : array();
	foreach ($rows as $row) {
		$row = (array) $row;
		$label = trim((string) ($row['label'] ?? ''));
		$key = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($row['key'] ?? ''));
		$kind = in_array(($row['kind'] ?? ''), $kinds, true) ? $row['kind'] : 'nothing';
		if ($label === '' && $key === '' && $kind === 'nothing') continue;
		if ($key === '') $key = 'seg' . (count($segments) + 1);
		$segments[] = array(
			'key'        => $key,
			'label'      => $label,
			'weight'     => max(0, (float) ($row['weight'] ?? 0)),
			'color'      => wheel_of_fortune_admin_color($row['color'] ?? '') ?: '#3b4252',
			'text_color' => wheel_of_fortune_admin_color($row['text_color'] ?? '') ?: '#ffffff',
			'icon'       => trim((string) ($row['icon'] ?? '')),
			'kind'       => $kind,
			'value'      => max(0, intv($row['value'] ?? 0)),
			'itemid'     => max(0, intv($row['itemid'] ?? 0)),
			'count'      => max(0, intv($row['count'] ?? 0)),
			'male'       => max(0, intv($row['male'] ?? 0)),
			'female'     => max(0, intv($row['female'] ?? 0)),
			'addons'     => max(0, min(3, intv($row['addons'] ?? 3))),
			'mount'      => max(0, intv($row['mount'] ?? 0)),
		);
	}
	if ($segments) setting_set('wheel_of_fortune:segments', json_encode(array_slice($segments, 0, 16)));

	if (function_exists('acp_log')) acp_log('wheel_of_fortune.save', count($segments) . ' segments');
	acp_flash_success('Wheel of Fortune saved.');
	acp_redirect($module);
}

$enabled   = (string) setting('wheel_of_fortune:enabled', '1') === '1';
$dailyFree = (string) setting('wheel_of_fortune:daily_free', '0') === '1';
$showShop  = (string) setting('wheel_of_fortune:show_in_shop', '1') === '1';
$showFloat = (string) setting('wheel_of_fortune:show_floating', '1') === '1';
$cost      = (int) setting('wheel_of_fortune:cost', '100');
$segments  = wheel_of_fortune_segments();
$total     = wheel_of_fortune_weight_total($segments);

$styleKeys = array(
	'page_bg'     => 'Page background colour',
	'page_image'  => 'Page background image URL',
	'box_bg'      => 'Panel background',
	'text'        => 'Text colour',
	'border'      => 'Border colour',
	'rim'         => 'Wheel rim colour',
	'hub'         => 'Centre hub colour',
	'pointer'     => 'Pointer colour',
	'button_bg'   => 'Spin button background',
	'button_text' => 'Spin button text',
	'accent'      => 'Accent / highlight',
);

while (count($segments) < 8) {
	$segments[] = array('key' => '', 'label' => '', 'weight' => 0, 'color' => '#3b4252', 'text_color' => '#ffffff', 'icon' => '', 'kind' => 'nothing', 'value' => 0, 'itemid' => 0, 'count' => 0, 'male' => 0, 'female' => 0, 'addons' => 3, 'mount' => 0);
}
$segments = array_slice($segments, 0, 12);
?>
<?php acp_card_open('Wheel of Fortune', 'The spin result is picked on the server by the weights below and delivered immediately: points and premium days go straight onto the account, items / outfits / mounts arrive as pending shop orders, and a free spin is credited back. The page lives at page.php?plugin=wheel_of_fortune&p=wheel; players reach it from the shop button and the floating box (toggles above). Add your own menu entry in Admin ▸ Menu if you want one.'); ?>
<form method="post">
	<?= acp_csrf_field() ?>

	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $enabled ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="daily_free" value="1" <?= $dailyFree ? 'checked' : '' ?>> Give one free spin every day</label></div>
		<div class="acp-field"><label class="acp-label">Cost per spin (shop points)</label><input class="acp-input" type="number" min="0" name="cost" value="<?= (int) $cost ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_shop" value="1" <?= $showShop ? 'checked' : '' ?>> Show a button on the shop &amp; buy-points pages</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_floating" value="1" <?= $showFloat ? 'checked' : '' ?>> Show a small floating box on other pages</label></div>
	</div>

	<h3>Texts</h3>
	<p class="acp-muted">Leave empty to use the translated defaults.</p>
	<div class="acp-field"><label class="acp-label">Page title</label><input class="acp-input" name="title" value="<?= h(setting('wheel_of_fortune:title', '')) ?>" placeholder="Wheel of Fortune"></div>
	<div class="acp-field"><label class="acp-label">Intro text</label><textarea class="acp-textarea" name="intro" placeholder="Spend your shop points for a chance at points, premium days, items and more."><?= h(setting('wheel_of_fortune:intro', '')) ?></textarea></div>

	<h3>Colours &amp; background</h3>
	<p class="acp-muted">Leave empty to inherit the active theme, with default-theme fallback. Colours accept <code>#rrggbb</code>, <code>rgba()</code> or a gradient; the background image accepts a URL.</p>
	<div class="acp-grid acp-grid--2">
		<?php foreach ($styleKeys as $k => $label): ?>
			<div class="acp-field">
				<label class="acp-label"><?= h($label) ?></label>
				<?php if ($k === 'page_image'): ?>
					<input class="acp-input" name="style_<?= h($k) ?>" value="<?= h(setting('wheel_of_fortune:style_' . $k, '')) ?>" placeholder="https://…/bg.jpg">
				<?php else: ?>
					<?php acp_color_field('style_' . $k, (string) setting('wheel_of_fortune:style_' . $k, ''), '#1a1d24 or rgba(26,29,36,.95)'); ?>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>

	<h3>Segments <span class="acp-muted" id="wofWeightSum"></span></h3>
	<p class="acp-muted">Weights are relative — they do not have to add up to 100. A row with no label and kind <code>nothing</code> is ignored. Icon is an image URL or a file in the plugin's <code>assets/img/</code>.</p>

	<div class="acp-table-wrap">
		<table class="acp-table" id="wofSegTable">
			<thead><tr>
				<th>Key</th><th>Label</th><th>Weight</th><th>Odds</th><th>Slice</th><th>Text</th><th>Icon</th>
				<th>Reward</th><th>Value / Item</th><th>Count</th><th>Outfit ♂</th><th>Outfit ♀</th><th>Addons</th><th>Mount</th>
			</tr></thead>
			<tbody>
			<?php foreach ($segments as $i => $s): ?>
				<tr>
					<td><input class="acp-input" style="width:80px" name="seg[<?= $i ?>][key]" value="<?= h($s['key']) ?>"></td>
					<td><input class="acp-input" style="width:130px" name="seg[<?= $i ?>][label]" value="<?= h($s['label']) ?>"></td>
					<td><input class="acp-input wof-weight" style="width:64px" type="number" min="0" step="0.1" name="seg[<?= $i ?>][weight]" value="<?= h($s['weight']) ?>"></td>
					<td class="wof-odds" style="white-space:nowrap;opacity:.7">—</td>
					<td><?php acp_color_field('seg[' . $i . '][color]', (string) $s['color'], '', 'width:92px'); ?></td>
					<td><?php acp_color_field('seg[' . $i . '][text_color]', (string) $s['text_color'], '', 'width:92px'); ?></td>
					<td><input class="acp-input" style="width:120px" name="seg[<?= $i ?>][icon]" value="<?= h($s['icon']) ?>"></td>
					<td>
						<select class="acp-select" name="seg[<?= $i ?>][kind]">
							<?php foreach ($kinds as $kd): ?>
								<option value="<?= h($kd) ?>" <?= $s['kind'] === $kd ? 'selected' : '' ?>><?= h($kd) ?></option>
							<?php endforeach; ?>
						</select>
					</td>
					<td><input class="acp-input" style="width:84px" type="number" min="0" name="seg[<?= $i ?>][value]" value="<?= (int) $s['value'] ?>" title="points / premium days / free spins">
						<input class="acp-input" style="width:84px;margin-top:3px" type="number" min="0" name="seg[<?= $i ?>][itemid]" value="<?= (int) $s['itemid'] ?>" title="item id"></td>
					<td><input class="acp-input" style="width:64px" type="number" min="0" name="seg[<?= $i ?>][count]" value="<?= (int) $s['count'] ?>"></td>
					<td><input class="acp-input" style="width:70px" type="number" min="0" name="seg[<?= $i ?>][male]" value="<?= (int) $s['male'] ?>"></td>
					<td><input class="acp-input" style="width:70px" type="number" min="0" name="seg[<?= $i ?>][female]" value="<?= (int) $s['female'] ?>"></td>
					<td><input class="acp-input" style="width:56px" type="number" min="0" max="3" name="seg[<?= $i ?>][addons]" value="<?= (int) $s['addons'] ?>"></td>
					<td><input class="acp-input" style="width:70px" type="number" min="0" name="seg[<?= $i ?>][mount]" value="<?= (int) $s['mount'] ?>"></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<script>
(function () {
	var table = document.getElementById('wofSegTable');
	if (!table) return;
	function recalc() {
		var rows = table.querySelectorAll('tbody tr'), total = 0, vals = [];
		rows.forEach(function (r) { var v = parseFloat(r.querySelector('.wof-weight').value) || 0; vals.push(v); total += v; });
		rows.forEach(function (r, i) {
			var cell = r.querySelector('.wof-odds');
			cell.textContent = total > 0 && vals[i] > 0 ? (vals[i] / total * 100).toFixed(1) + '%' : '—';
		});
		var sum = document.getElementById('wofWeightSum');
		if (sum) sum.textContent = total > 0 ? '· total weight ' + (Math.round(total * 100) / 100) : '';
	}
	table.addEventListener('input', function (e) { if (e.target.classList.contains('wof-weight')) recalc(); });
	recalc();
}());
</script>
<?php acp_card_close(); ?>
