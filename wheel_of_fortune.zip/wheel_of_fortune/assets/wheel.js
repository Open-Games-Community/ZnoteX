﻿(function () {
	'use strict';
	var cfg = window.WOF || {};
	var $ = function (id) { return document.getElementById(id); };
	var wheel = $('wofWheel');
	if (!wheel) return;

	var spinBtn = $('wofSpinBtn'), cta = $('wofSpinCta'), modal = $('wofModal');
	var elBalance = $('wofBalance'), elFree = $('wofFree'), elFreeRow = $('wofFreeRow');
	var elRecent = $('wofRecent'), elRecentEmpty = $('wofRecentEmpty'), elError = $('wofError');
	var i18n = cfg.i18n || {};
	var anglePer = cfg.anglePer || (360 / (cfg.count || 8));
	var cost = +cfg.cost || 0;
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	var rot = 0;
	var busy = false;
	var canSpin = !!cfg.canSpin;
	var ctaLabel = cta ? cta.textContent.trim() : '';

	function setBusy(state) {
		busy = state;
		[spinBtn, cta].forEach(function (b) { if (b) b.disabled = state || !canSpin; });
		if (cta) cta.textContent = state ? (i18n.spinning || '...') : ctaLabel;
	}

	function showError(msg) {
		if (!elError) { alert(msg); return; }
		elError.textContent = msg;
		elError.hidden = false;
		setTimeout(function () { elError.hidden = true; }, 6000);
	}

	function applyState(data) {
		if (elBalance && typeof data.balance === 'number') elBalance.textContent = data.balance;
		if (elFree && typeof data.free_spins === 'number') {
			elFree.textContent = data.free_spins;
			if (elFreeRow && data.free_spins > 0) elFreeRow.hidden = false;
		}
		if (elRecent && data.recent && data.recent.length) {
			elRecent.innerHTML = data.recent.map(function (r, idx) {
				var tag = r.free ? ' - ' + (i18n.free || 'Free') : '';
				return '<li' + (idx === 0 ? ' class="is-new"' : '') + '><span>' + esc(r.text) + esc(tag) + '</span><time>' + esc(r.when) + '</time></li>';
			}).join('');
			if (elRecentEmpty) elRecentEmpty.hidden = true;
		}
		canSpin = (data.free_spins > 0) || (data.balance >= cost);
	}

	function esc(s) {
		return String(s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	function openModal(reward) {
		if (!modal) return;
		var nothing = !reward || reward.kind === 'nothing' || !reward.text;
		$('wofModalHead').textContent = nothing ? '' : (i18n.won || 'You won');
		$('wofModalText').textContent = nothing ? (i18n.noluck || (reward && reward.text) || '') : reward.text;
		var img = $('wofModalImg');
		if (reward && reward.image) { img.src = reward.image; img.hidden = false; img.onerror = function () { img.hidden = true; }; }
		else img.hidden = true;
		var close = $('wofModalClose');
		close.textContent = (reward && reward.free ? i18n.spinAgain : i18n.close) || 'Close';
		close.onclick = function () {
			modal.classList.remove('is-open');
			modal.setAttribute('aria-hidden', 'true');
			if (reward && reward.free && canSpin) spin();
		};
		modal.classList.add('is-open');
		modal.setAttribute('aria-hidden', 'false');
	}

	function animateTo(index, data) {
		var turns = 6 + Math.floor(Math.random() * 3);
		var jitter = (Math.random() - 0.5) * anglePer * 0.6;
		var base = (((-index * anglePer + jitter) % 360) + 360) % 360;
		var target = rot + turns * 360;
		target += (((base - (target % 360)) % 360) + 360) % 360;
		rot = target;

		var done = false;
		function finish() {
			if (done) return;
			done = true;
			wheel.removeEventListener('transitionend', finish);
			applyState(data);
			openModal(data.reward);
			setBusy(false);
		}
		wheel.addEventListener('transitionend', finish);
		setTimeout(finish, reduce ? 1300 : 7000);
		requestAnimationFrame(function () {
			requestAnimationFrame(function () { wheel.style.transform = 'rotate(' + target.toFixed(2) + 'deg)'; });
		});
	}

	function spin() {
		if (busy || !canSpin) return;
		setBusy(true);
		if (elError) elError.hidden = true;

		var body = new URLSearchParams();
		body.set('wof_ajax', '1');
		body.set('wof_token', cfg.token || '');

		fetch(cfg.endpoint, {
			method: 'POST',
			headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString(),
			credentials: 'same-origin'
		}).then(function (r) { return r.json(); }).then(function (data) {
			if (!data || !data.ok) {
				showError((data && data.message) || i18n.error || 'Error');
				setBusy(false);
				return;
			}
			animateTo(data.index | 0, data);
		}).catch(function () {
			showError(i18n.error || 'Error');
			setBusy(false);
		});
	}

	[spinBtn, cta].forEach(function (b) { if (b) b.addEventListener('click', spin); });
	setBusy(false);
}());



