﻿<?php
/**
 * Wheel of Fortune - a weighted prize wheel on its own page.
 *
 * Loaded on every request while enabled. This file only declares helpers and,
 * optionally, a small footer teaser. The spin itself happens in pages/wheel.php.
 */
if (!function_exists('wheel_of_fortune_setting')) {

function wheel_of_fortune_setting(string $key, string $default = ''): string {
	return function_exists('setting') ? (string) setting('wheel_of_fortune:' . $key, $default) : $default;
}
function wheel_of_fortune_enabled(): bool { return wheel_of_fortune_setting('enabled', '1') === '1'; }
function wheel_of_fortune_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function wheel_of_fortune_cost(): int { return max(0, (int) wheel_of_fortune_setting('cost', '100')); }
function wheel_of_fortune_daily_free(): bool { return wheel_of_fortune_setting('daily_free', '0') === '1'; }

function wheel_of_fortune_t(string $key, string $fallback, array $vars = array()): string {
	$text = function_exists('t_default') ? t_default($key, $fallback, $vars) : $fallback;
	foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', (string) $v, $text);
	return $text;
}
function wheel_of_fortune_text(string $settingKey, string $localeKey, string $fallback): string {
	$custom = trim(wheel_of_fortune_setting($settingKey, ''));
	return $custom !== '' ? $custom : wheel_of_fortune_t($localeKey, $fallback);
}

// --- style helpers --------------------------------------------------------
function wheel_of_fortune_css_value(string $value): string {
	$value = trim($value);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $value)) return $value;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $value) ? $value : '';
}
function wheel_of_fortune_color(string $key): string { return wheel_of_fortune_css_value(wheel_of_fortune_setting('style_' . $key, '')); }
function wheel_of_fortune_bg_image(): string {
	$url = trim(wheel_of_fortune_setting('style_page_image', ''));
	if ($url === '') return '';
	return preg_match('#^(https?:)?//[^\s"\'()]+$#i', $url) || preg_match('#^/[^\s"\'()]+$#', $url) ? $url : '';
}
function wheel_of_fortune_style_attr(array $map): string {
	$css = '';
	foreach ($map as $key => $var) {
		$value = wheel_of_fortune_color($key);
		if ($value !== '') $css .= $var . ':' . $value . ';';
	}
	return $css !== '' ? ' style="' . wheel_of_fortune_h($css) . '"' : '';
}
function wheel_of_fortune_asset_image(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$path = __DIR__ . '/assets/img/' . $file;
	return is_file($path) ? znote_plugin_asset('wheel_of_fortune', 'img/' . $file) : '';
}
function wheel_of_fortune_segment_icon(array $seg): string {
	$icon = trim((string) ($seg['icon'] ?? ''));
	if ($icon === '') return '';
	if (preg_match('#^(https?:)?//#i', $icon) || strpos($icon, '/') === 0) return $icon;
	return wheel_of_fortune_asset_image($icon);
}

// --- segments -----------------------------------------------------------
function wheel_of_fortune_default_segments(): array {
	return array(
		array('key' => 'p250',   'label' => '250 Points',    'weight' => 22, 'color' => '#f4c542', 'text_color' => '#1c1400', 'icon' => 'points.svg',    'kind' => 'points',       'value' => 250),
		array('key' => 'miss1',  'label' => 'Try again',     'weight' => 20, 'color' => '#3b4252', 'text_color' => '#e5e9f0', 'icon' => 'nothing.svg',   'kind' => 'nothing',      'value' => 0),
		array('key' => 'p500',   'label' => '500 Points',    'weight' => 14, 'color' => '#f0932b', 'text_color' => '#1c1400', 'icon' => 'points.svg',    'kind' => 'points',       'value' => 500),
		array('key' => 'respin', 'label' => 'Free Spin',     'weight' => 12, 'color' => '#6c5ce7', 'text_color' => '#f5f3ff', 'icon' => 'free_spin.svg', 'kind' => 'free_spin',    'value' => 1),
		array('key' => 'prem3',  'label' => '3 Premium Days','weight' => 12, 'color' => '#00b894', 'text_color' => '#04231b', 'icon' => 'premium.svg',   'kind' => 'premium_days', 'value' => 3),
		array('key' => 'coins',  'label' => '5 Crystal Coins','weight' => 8, 'color' => '#0984e3', 'text_color' => '#eaf4ff', 'icon' => 'item.svg',     'kind' => 'item',         'value' => 0, 'itemid' => 2160, 'count' => 5),
		array('key' => 'p1000',  'label' => '1000 Points',   'weight' => 8,  'color' => '#eb4d4b', 'text_color' => '#fff0f0', 'icon' => 'points.svg',    'kind' => 'points',       'value' => 1000),
		array('key' => 'prem7',  'label' => '7 Premium Days','weight' => 4,  'color' => '#e84393', 'text_color' => '#2a0c1c', 'icon' => 'premium.svg',   'kind' => 'premium_days', 'value' => 7),
	);
}
function wheel_of_fortune_normalize_segment($seg): array {
	$seg = (array) $seg;
	$kind = (string) ($seg['kind'] ?? 'nothing');
	$allowed = array('nothing', 'points', 'premium_days', 'item', 'outfit', 'mount', 'free_spin');
	if (!in_array($kind, $allowed, true)) $kind = 'nothing';
	return array(
		'key'        => preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($seg['key'] ?? '')) ?: ('seg' . mt_rand(1000, 9999)),
		'label'      => (string) ($seg['label'] ?? ''),
		'weight'     => max(0, (float) ($seg['weight'] ?? 0)),
		'color'      => wheel_of_fortune_css_value((string) ($seg['color'] ?? '')) ?: '#3b4252',
		'text_color' => wheel_of_fortune_css_value((string) ($seg['text_color'] ?? '')) ?: '#ffffff',
		'icon'       => (string) ($seg['icon'] ?? ''),
		'kind'       => $kind,
		'value'      => max(0, (int) ($seg['value'] ?? 0)),
		'itemid'     => max(0, (int) ($seg['itemid'] ?? 0)),
		'count'      => max(0, (int) ($seg['count'] ?? 0)),
		'male'       => max(0, (int) ($seg['male'] ?? 0)),
		'female'     => max(0, (int) ($seg['female'] ?? 0)),
		'addons'     => max(0, min(3, (int) ($seg['addons'] ?? 3))),
		'mount'      => max(0, (int) ($seg['mount'] ?? 0)),
	);
}
function wheel_of_fortune_segments(): array {
	$raw = json_decode(wheel_of_fortune_setting('segments', ''), true);
	$raw = is_array($raw) && $raw ? $raw : wheel_of_fortune_default_segments();
	$out = array();
	foreach (array_slice(array_values($raw), 0, 16) as $seg) $out[] = wheel_of_fortune_normalize_segment($seg);
	return $out ?: array(wheel_of_fortune_normalize_segment(array('key' => 'miss', 'label' => 'Try again', 'kind' => 'nothing')));
}
function wheel_of_fortune_weight_total(array $segs): float {
	$t = 0.0;
	foreach ($segs as $s) $t += max(0, (float) ($s['weight'] ?? 0));
	return $t;
}
function wheel_of_fortune_pick(array $segs): int {
	$total = wheel_of_fortune_weight_total($segs);
	if ($total <= 0) return random_int(0, count($segs) - 1);
	$roll = random_int(1, (int) round($total * 1000)) / 1000;
	$acc = 0.0;
	foreach ($segs as $i => $s) {
		$acc += max(0, (float) ($s['weight'] ?? 0));
		if ($roll <= $acc) return (int) $i;
	}
	return count($segs) - 1;
}

// --- account state -----------------------------------------------------
function wheel_of_fortune_account_id(): int {
	if (!empty($GLOBALS['session_user_id'])) return (int) $GLOBALS['session_user_id'];
	return (function_exists('user_logged_in') && user_logged_in() === true) ? (int) getSession('user_id') : 0;
}
function wheel_of_fortune_points(int $accountId): int {
	if ($accountId <= 0) return 0;
	$row = mysql_select_single("SELECT `points` FROM `znote_accounts` WHERE `account_id` = {$accountId} LIMIT 1;");
	return is_array($row) ? max(0, (int) $row['points']) : 0;
}
/** Cheap read: current free-spin count, no row creation, no daily grant. */
function wheel_of_fortune_free_spins_peek(int $accountId): int {
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_wof_accounts')) return 0;
	$row = mysql_select_single("SELECT `free_spins` FROM `znote_wof_accounts` WHERE `account_id` = {$accountId} LIMIT 1;");
	return is_array($row) ? max(0, (int) $row['free_spins']) : 0;
}
/** Ensures the row exists, grants the daily free spin when due, returns the state. */
function wheel_of_fortune_state(int $accountId): array {
	$blank = array('free_spins' => 0, 'last_free_at' => 0, 'total_spins' => 0);
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_wof_accounts')) return $blank;
	$row = mysql_select_single("SELECT `free_spins`,`last_free_at`,`total_spins` FROM `znote_wof_accounts` WHERE `account_id` = {$accountId} LIMIT 1;");
	if (!is_array($row)) {
		mysql_insert("INSERT INTO `znote_wof_accounts` (`account_id`,`free_spins`,`last_free_at`,`total_spins`,`updated_at`) VALUES ({$accountId},0,0,0," . time() . ");");
		$row = $blank;
	}
	$row = array('free_spins' => max(0, (int) $row['free_spins']), 'last_free_at' => (int) $row['last_free_at'], 'total_spins' => (int) $row['total_spins']);
	if (wheel_of_fortune_daily_free()) {
		$today = (int) strtotime('today 00:00');
		if ($row['last_free_at'] < $today) {
			mysql_update("UPDATE `znote_wof_accounts` SET `free_spins` = `free_spins` + 1, `last_free_at` = " . time() . ", `updated_at` = " . time() . " WHERE `account_id` = {$accountId};");
			$row['free_spins'] += 1;
			$row['last_free_at'] = time();
		}
	}
	return $row;
}

// --- reward presentation ----------------------------------------------
function wheel_of_fortune_item_image_url(int $itemid): string {
	global $config;
	if ($itemid <= 0 || empty($config['shop']['showImage'])) return '';
	if (function_exists('znote_item_image_url')) return znote_item_image_url($itemid);
	$server = trim((string) ($config['shop']['imageServer'] ?? ''));
	$type = preg_replace('/[^a-zA-Z0-9]/', '', (string) ($config['shop']['imageType'] ?? 'gif'));
	if ($server === '' || $type === '') return '';
	$path = rtrim($server, '/') . '/' . $itemid . '.' . $type;
	if (preg_match('#^https?://#i', $path)) return $path;
	return (strpos($path, '/') === 0 ? '' : 'http://') . $path;
}
function wheel_of_fortune_outfit_image_url(int $outfitId, int $addons = 3, int $mountId = 0): string {
	global $config;
	if ($outfitId <= 0 || empty($config['show_outfits']['shop'])) return '';
	$server = trim((string) ($config['show_outfits']['imageServer'] ?? ''));
	if ($server === '') return '';
	$url = $server . '?id=' . $outfitId . '&addons=' . max(0, min(3, $addons)) . '&head=94&body=79&legs=114&feet=114';
	if ($mountId > 0) $url .= '&mount=' . $mountId . '&direction=2';
	return $url;
}
function wheel_of_fortune_reward_image_url(array $seg): string {
	$segmentIcon = wheel_of_fortune_segment_icon($seg);
	if ($segmentIcon !== '') return $segmentIcon;

	switch ($seg['kind']) {
		case 'item':  return wheel_of_fortune_item_image_url((int) $seg['itemid']);
		case 'outfit': return wheel_of_fortune_outfit_image_url((int) $seg['male'], (int) $seg['addons']);
		case 'mount': return wheel_of_fortune_outfit_image_url(128, 0, (int) $seg['mount']);
	}
	return '';
}
function wheel_of_fortune_reward_text(array $seg): string {
	$label = trim((string) ($seg['label'] ?? ''));
	switch ($seg['kind']) {
		case 'points':       return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_points', '{n} Points', array('n' => (int) $seg['value']));
		case 'premium_days': return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_premium', '{n} Premium Days', array('n' => (int) $seg['value']));
		case 'item':         return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_item', '{c}x Item {id}', array('c' => (int) $seg['count'], 'id' => (int) $seg['itemid']));
		case 'outfit':       return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_outfit', 'Outfit', array());
		case 'mount':        return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_mount', 'Mount', array());
		case 'free_spin':    return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_free', '{n} Free Spin', array('n' => max(1, (int) $seg['value'])));
	}
	return $label !== '' ? $label : wheel_of_fortune_t('wheel_of_fortune.rw_nothing', 'No luck this time');
}

// --- spin -------------------------------------------------------------
function wheel_of_fortune_deliver(int $accountId, int $playerId, array $seg): void {
	$now = time();
	switch ($seg['kind']) {
		case 'points':
			if ((int) $seg['value'] > 0) mysql_update("UPDATE `znote_accounts` SET `points` = COALESCE(`points`,0) + " . (int) $seg['value'] . " WHERE `account_id` = {$accountId};");
			return;
		case 'premium_days':
			if ((int) $seg['value'] > 0 && function_exists('user_account_add_premdays')) user_account_add_premdays($accountId, (int) $seg['value']);
			return;
		case 'free_spin':
			mysql_update("UPDATE `znote_wof_accounts` SET `free_spins` = `free_spins` + " . max(1, (int) $seg['value']) . ", `updated_at` = {$now} WHERE `account_id` = {$accountId};");
			return;
		case 'item':
			if ((int) $seg['itemid'] > 0 && (int) $seg['count'] > 0)
				mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$accountId},1," . (int) $seg['itemid'] . "," . (int) $seg['count'] . ",{$now});");
			return;
		case 'outfit':
			if ((int) $seg['male'] > 0 && (int) $seg['female'] > 0)
				mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$accountId},5," . (int) $seg['male'] . "," . (int) $seg['female'] . ",{$now});");
			return;
		case 'mount':
			if ((int) $seg['mount'] > 0)
				mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$accountId},6," . (int) $seg['mount'] . ",1,{$now});");
			return;
	}
}
/**
 * Runs one spin. Returns:
 *   ['ok'=>true,'index'=>int,'segment'=>array,'reward_text'=>string,'free'=>bool]
 *   ['ok'=>false,'message'=>string]
 */
function wheel_of_fortune_spin(int $accountId, int $playerId = 0): array {
	if (!wheel_of_fortune_enabled()) return array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.disabled', 'The wheel is currently disabled.'));
	if ($accountId <= 0) return array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.need_login', 'Log in to spin the wheel.'));
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_wof_spins')) return array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.not_installed', 'The wheel is not installed correctly.'));

	$segs = wheel_of_fortune_segments();
	$state = wheel_of_fortune_state($accountId);
	$cost = wheel_of_fortune_cost();
	$useFree = $state['free_spins'] > 0;

	if ($useFree) {
		$affected = mysql_update("UPDATE `znote_wof_accounts` SET `free_spins` = `free_spins` - 1, `updated_at` = " . time() . " WHERE `account_id` = {$accountId} AND `free_spins` > 0;");
		if ($affected === false) return array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.spin_failed', 'Could not start the spin, try again.'));
		$cost = 0;
	} else {
		$points = wheel_of_fortune_points($accountId);
		if ($points < $cost) return array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.not_enough', 'You need {n} points to spin.', array('n' => $cost)));
		mysql_update("UPDATE `znote_accounts` SET `points` = `points` - {$cost} WHERE `account_id` = {$accountId} AND `points` >= {$cost};");
	}

	$index = wheel_of_fortune_pick($segs);
	$seg = $segs[$index];

	wheel_of_fortune_deliver($accountId, $playerId, $seg);

	$now = time();
	mysql_insert("INSERT INTO `znote_wof_spins` (`account_id`,`player_id`,`segment_key`,`reward_kind`,`reward_value`,`reward_itemid`,`reward_count`,`cost`,`free`,`created_at`) VALUES ("
		. $accountId . "," . (int) $playerId . ",'" . mysql_znote_escape_string($seg['key']) . "','" . mysql_znote_escape_string($seg['kind']) . "',"
		. (int) $seg['value'] . "," . (int) $seg['itemid'] . "," . (int) $seg['count'] . "," . (int) $cost . "," . ($useFree ? 1 : 0) . "," . $now . ");");
	mysql_update("UPDATE `znote_wof_accounts` SET `total_spins` = `total_spins` + 1, `updated_at` = {$now} WHERE `account_id` = {$accountId};");

	if (function_exists('znote_hook')) znote_hook('wheel_of_fortune.spun', array('account_id' => $accountId, 'segment' => $seg['key'], 'kind' => $seg['kind'], 'value' => (int) $seg['value'], 'free' => $useFree));

	return array('ok' => true, 'index' => $index, 'segment' => $seg, 'reward_text' => wheel_of_fortune_reward_text($seg), 'free' => $useFree);
}
function wheel_of_fortune_recent(int $accountId, int $limit = 8): array {
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_wof_spins')) return array();
	$limit = max(1, min(30, $limit));
	$rows = mysql_select_multi("SELECT `segment_key`,`reward_kind`,`reward_value`,`reward_itemid`,`reward_count`,`free`,`created_at` FROM `znote_wof_spins` WHERE `account_id` = {$accountId} ORDER BY `id` DESC LIMIT {$limit};");
	return is_array($rows) ? $rows : array();
}
/** History rows formatted for display / the AJAX response. */
function wheel_of_fortune_recent_view(int $accountId, int $limit = 8): array {
	$segs = wheel_of_fortune_segments();
	$byKey = array();
	foreach ($segs as $s) $byKey[$s['key']] = $s;
	$out = array();
	foreach (wheel_of_fortune_recent($accountId, $limit) as $row) {
		$seg = $byKey[$row['segment_key']] ?? null;
		if ($seg) {
			$text = wheel_of_fortune_reward_text($seg);
		} elseif ((string) $row['reward_kind'] === 'nothing') {
			$text = wheel_of_fortune_t('wheel_of_fortune.rw_nothing', 'No luck this time');
		} else {
			$text = ucfirst((string) $row['reward_kind']);
		}
		$out[] = array(
			'text' => $text,
			'free' => !empty($row['free']),
			'when' => function_exists('getClock') ? getClock((int) $row['created_at'], true) : date('Y-m-d H:i', (int) $row['created_at']),
		);
	}
	return $out;
}

/** POST spin endpoint. Runs from plugin load (before the theme), so it can emit clean JSON. */
function wheel_of_fortune_handle_ajax(): void {
	if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !isset($_POST['wof_ajax']) || headers_sent()) return;

	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: application/json; charset=utf-8');
	header('X-Content-Type-Options: nosniff');
	$send = static function (array $arr): void { echo json_encode($arr, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); exit; };

	$host = (string) ($_SERVER['HTTP_HOST'] ?? '');
	foreach (array('HTTP_ORIGIN', 'HTTP_REFERER') as $k) {
		if (!empty($_SERVER[$k]) && $host !== '') {
			$oh = parse_url((string) $_SERVER[$k], PHP_URL_HOST);
			if ($oh !== null && strcasecmp((string) $oh, $host) !== 0) $send(array('ok' => false, 'message' => 'bad_origin'));
		}
	}

	$accountId = wheel_of_fortune_account_id();
	if ($accountId <= 0) $send(array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.need_login', 'Log in to spin the wheel.')));

	$token = (string) ($_POST['wof_token'] ?? '');
	$sess  = (string) ($_SESSION['wof_spin_token'] ?? '');
	if ($sess === '' || $token === '' || !hash_equals($sess, $token)) $send(array('ok' => false, 'message' => wheel_of_fortune_t('wheel_of_fortune.err_session', 'Session expired, reload the page and try again.')));

	$playerId = 0;
	if (function_exists('user_character_list')) {
		foreach ((array) user_character_list($accountId) as $c) { $playerId = (int) ($c['id'] ?? 0); break; }
	}

	$res = wheel_of_fortune_spin($accountId, $playerId);
	if (empty($res['ok'])) $send(array('ok' => false, 'message' => (string) ($res['message'] ?? 'error')));

	$state = wheel_of_fortune_state($accountId);
	$send(array(
		'ok'         => true,
		'index'      => (int) $res['index'],
		'reward'     => array(
			'text'  => $res['reward_text'],
			'image' => wheel_of_fortune_reward_image_url($res['segment']),
			'kind'  => (string) $res['segment']['kind'],
			'free'  => (string) $res['segment']['kind'] === 'free_spin',
		),
		'balance'    => wheel_of_fortune_points($accountId),
		'free_spins' => (int) ($state['free_spins'] ?? 0),
		'recent'     => wheel_of_fortune_recent_view($accountId, 8),
	));
}

/**
 * A button inside the shop / buy-points page, and a small floating box
 * (like the coupon banner) on every other page for logged-in visitors.
 */
function wheel_of_fortune_footer(): string {
	if (!wheel_of_fortune_enabled() || wheel_of_fortune_account_id() <= 0) return '';
	$script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

	// Not on the wheel page itself.
	if ($script === 'page.php' && (string) ($_GET['plugin'] ?? '') === 'wheel_of_fortune') return '';

	$url  = wheel_of_fortune_h(znote_plugin_url('wheel_of_fortune', 'wheel'));
	$icon = wheel_of_fortune_asset_image('free_spin.svg');
	$title = wheel_of_fortune_h(wheel_of_fortune_text('title', 'wheel_of_fortune.title', 'Wheel of Fortune'));
	$cost  = wheel_of_fortune_cost();
	$free  = wheel_of_fortune_free_spins_peek(wheel_of_fortune_account_id());
	$tag   = $free > 0
		? wheel_of_fortune_h(wheel_of_fortune_t('wheel_of_fortune.free_ready', '{n} free spin ready!', array('n' => $free)))
		: ($cost > 0 ? wheel_of_fortune_h(wheel_of_fortune_t('wheel_of_fortune.tag_cost', 'From {n} points a spin', array('n' => $cost)))
		             : wheel_of_fortune_h(wheel_of_fortune_t('wheel_of_fortune.free', 'Free')));
	$cta   = wheel_of_fortune_h(wheel_of_fortune_t('wheel_of_fortune.spin_now', 'Spin now'));
	$img   = $icon !== '' ? '<img src="' . wheel_of_fortune_h($icon) . '" alt="" width="30" height="30">' : '';

	$inShop = in_array($script, array('shop.php', 'buypoints.php'), true) && wheel_of_fortune_setting('show_in_shop', '1') === '1';
	$floating = !$inShop && wheel_of_fortune_setting('show_floating', '1') === '1';
	if (!$inShop && !$floating) return '';

	$style = wheel_of_fortune_style_attr(array('box_bg' => '--wof-surface', 'text' => '--wof-text', 'border' => '--wof-border', 'button_bg' => '--wof-btn-bg', 'button_text' => '--wof-btn-text', 'accent' => '--wof-accent'));

	$css = '#wofPromo{--wof-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(24,27,34))))))));--wof-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--wof-border:var(--border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,rgb(19,20,23))))));--wof-accent:var(--accent,var(--link,#f4c542));--wof-btn-bg:var(--wof-accent);--wof-btn-text:#151515}'
		. '#wofPromo *{box-sizing:border-box}'
		. '#wofPromo.wof-promo--float{position:fixed;right:16px;bottom:16px;z-index:940;width:270px;max-width:calc(100vw - 32px);animation:wofPromoIn .35s ease both}'
		. '@keyframes wofPromoIn{from{transform:translateY(14px);opacity:0}to{transform:none;opacity:1}}'
		. '#wofPromo .wof-promo__card{position:relative;display:flex;gap:11px;align-items:center;padding:12px 13px;border:1px solid var(--wof-border);border-radius:12px;background:var(--wof-surface);color:var(--wof-text);box-shadow:0 10px 30px rgba(0,0,0,.35)}'
		. '#wofPromo.wof-promo--inline{margin:0 0 16px}#wofPromo.wof-promo--inline .wof-promo__card{box-shadow:none}'
		. '#wofPromo .wof-promo__spin{width:44px;height:44px;flex:0 0 auto;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 40% 35%,color-mix(in srgb,var(--wof-accent) 90%,#fff),var(--wof-accent));animation:wofPromoSpin 9s linear infinite}'
		. '@keyframes wofPromoSpin{to{transform:rotate(360deg)}}'
		. '#wofPromo .wof-promo__body{min-width:0;flex:1 1 auto}'
		. '#wofPromo .wof-promo__body b{display:block;font-size:13.5px;line-height:1.2}'
		. '#wofPromo .wof-promo__body span{display:block;font-size:11.5px;opacity:.72;margin-top:1px}'
		. '#wofPromo .wof-promo__go{flex:0 0 auto;padding:8px 12px;border-radius:8px;background:var(--wof-btn-bg);color:var(--wof-btn-text);font-weight:800;font-size:12.5px;text-decoration:none;white-space:nowrap}'
		. '#wofPromo .wof-promo__x{position:absolute;top:-8px;right:-8px;width:20px;height:20px;border-radius:50%;border:1px solid var(--wof-border);background:var(--wof-surface);color:inherit;font-size:12px;line-height:18px;cursor:pointer;padding:0}'
		. '#wofPromo.wof-promo--inline .wof-promo__x{display:none}'
		. '@media(prefers-reduced-motion:reduce){#wofPromo .wof-promo__spin{animation:none}#wofPromo.wof-promo--float{animation:none}}';

	$closeBtn = $floating ? '<button type="button" class="wof-promo__x" aria-label="close">&times;</button>' : '';
	$html = '<div id="wofPromo" class="' . ($inShop ? 'wof-promo--inline' : 'wof-promo--float') . '"' . $style . '>'
		. '<div class="wof-promo__card">' . $closeBtn
		. '<span class="wof-promo__spin">' . $img . '</span>'
		. '<span class="wof-promo__body"><b>' . $title . '</b><span>' . $tag . '</span></span>'
		. '<a class="wof-promo__go" href="' . $url . '">' . $cta . ' &rarr;</a>'
		. '</div></div>';

	$place = $inShop
		? 'var t=document.querySelector("#shop,#buypoints,.shop,.buypoints,form[action*=shop],form[action*=buypoints],main,#content,.content");if(t&&t.parentNode){t.parentNode.insertBefore(w.firstChild,t);}else{document.body.appendChild(w.firstChild);}'
		: 'document.body.appendChild(w.firstChild);';

	return '<script>(function(){if(document.getElementById("wofPromo"))return;'
		. 'try{if(localStorage.getItem("wofPromoHidden")==="1"&&' . ($floating ? 'true' : 'false') . ')return;}catch(e){}'
		. 'var s=document.createElement("style");s.textContent=' . json_encode($css) . ';document.head.appendChild(s);'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($html) . ';'
		. $place
		. 'var x=document.querySelector("#wofPromo .wof-promo__x");if(x)x.addEventListener("click",function(){var p=document.getElementById("wofPromo");if(p)p.remove();try{localStorage.setItem("wofPromoHidden","1");}catch(e){}});'
		. '}());</script>';
}

}

wheel_of_fortune_handle_ajax();
if (function_exists('znote_hook_register')) {
	znote_hook_register('page.footer', 'wheel_of_fortune_footer');
}

