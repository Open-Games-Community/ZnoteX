<?php
/**
 * Guild Recruitment - guild leaders post one recruitment ad per guild. A paged
 * card grid shows above the guild list; each card opens a detail page with an
 * "Apply" button, and the leader reviews / accepts applications.
 * The admin panel only enables/disables, styles, and moderates (delete an ad).
 */
if(!function_exists('guild_recruitment_setting')){

function guild_recruitment_setting(string $k,string $d):string{return function_exists('setting')?(string)setting('guild_recruitment:'.$k,$d):$d;}
function guild_recruitment_enabled():bool{return guild_recruitment_setting('enabled','1')==='1';}
function guild_recruitment_per_page():int{return max(2,min(24,(int)guild_recruitment_setting('per_page','9')));}
function guild_recruitment_h($v):string{return htmlspecialchars((string)($v??''),ENT_QUOTES,'UTF-8');}
function guild_recruitment_excerpt(string $s,int $n=140):string{$s=trim(preg_replace('/\s+/',' ',strip_tags($s)));return (function_exists('mb_strimwidth')?mb_strimwidth($s,0,$n,'…','UTF-8'):(strlen($s)>$n?substr($s,0,$n-1).'…':$s));}
function guild_recruitment_style_color(string $k):string{$v=trim(guild_recruitment_setting('style_'.$k,''));return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$v)?$v:'';}
function guild_recruitment_style_attr():string{$map=['box_bg'=>'--znx-plugin-surface','text'=>'--znx-plugin-text','border'=>'--znx-plugin-border','card_bg'=>'--gr-card-bg','tag_bg'=>'--gr-tag-bg','tag_text'=>'--gr-tag-text','link'=>'--gr-link','button_bg'=>'--gr-btn-bg','button_text'=>'--gr-btn-text'];$css='';foreach($map as $k=>$var){$v=guild_recruitment_style_color($k);if($v!=='')$css.=$var.':'.$v.';';}return $css!==''?' style="'.guild_recruitment_h($css).'"':'';}

function guild_recruitment_ready():bool{return function_exists('znote_table_exists')&&znote_table_exists('znote_guild_recruitment')&&znote_table_exists('guilds');}

/** [guild_id => ['id'=>,'name'=>,'char_id'=>,'char_name'=>]] for guilds a character on this account owns. */
function guild_recruitment_led_guilds(int $accountId):array{
	$out=[]; if($accountId<=0||!function_exists('user_character_list')||!function_exists('guild_leader_gid'))return $out;
	$chars=user_character_list($accountId); if(!is_array($chars))return $out;
	foreach($chars as $c){$cid=(int)($c['id']??0); if($cid<=0)continue; $gid=guild_leader_gid($cid);
		if($gid){$gid=(int)$gid; $name=function_exists('get_guild_name')?get_guild_name($gid):''; $out[$gid]=['id'=>$gid,'name'=>(string)$name,'char_id'=>$cid,'char_name'=>(string)($c['name']??'')];}}
	return $out;
}

function guild_recruitment_posts(bool $activeOnly=true):array{
	static $cache=[];
	$key=$activeOnly?'a':'x';
	if(isset($cache[$key]))return $cache[$key];
	if(!guild_recruitment_ready())return $cache[$key]=[];
	$where=$activeOnly?'WHERE `r`.`active`=1':'';
	$rows=mysql_select_multi("SELECT `r`.`guild_id`,`r`.`title`,`r`.`message`,`r`.`min_level`,`r`.`vocations`,`r`.`active`,`r`.`updated_at`,`g`.`name` AS `guild_name` FROM `znote_guild_recruitment` AS `r` INNER JOIN `guilds` AS `g` ON `g`.`id`=`r`.`guild_id` {$where} ORDER BY `r`.`updated_at` DESC LIMIT 300;");
	return $cache[$key]=(is_array($rows)?$rows:[]);
}
function guild_recruitment_post(int $gid):?array{
	if($gid<=0||!guild_recruitment_ready())return null;
	$r=mysql_select_single("SELECT `r`.*,`g`.`name` AS `guild_name`,`g`.`ownerid` FROM `znote_guild_recruitment` AS `r` INNER JOIN `guilds` AS `g` ON `g`.`id`=`r`.`guild_id` WHERE `r`.`guild_id`={$gid} LIMIT 1;");
	return is_array($r)?$r:null;
}
function guild_recruitment_save(int $gid,string $title,string $message,int $minLevel,string $vocations):void{
	$gid=(int)$gid; if($gid<=0)return; $t=mysql_znote_escape_string(mb_substr(trim($title),0,120)); $m=mysql_znote_escape_string(trim($message)); $v=mysql_znote_escape_string(mb_substr(trim($vocations),0,255)); $lvl=max(0,$minLevel); $now=time();
	mysql_insert("INSERT INTO `znote_guild_recruitment` (`guild_id`,`title`,`message`,`min_level`,`vocations`,`active`,`created_at`,`updated_at`) VALUES ({$gid},'{$t}','{$m}',{$lvl},'{$v}',1,{$now},{$now}) ON DUPLICATE KEY UPDATE `title`='{$t}',`message`='{$m}',`min_level`={$lvl},`vocations`='{$v}',`updated_at`={$now};");
}
function guild_recruitment_delete(int $gid):void{$gid=(int)$gid; if($gid<=0)return; mysql_delete("DELETE FROM `znote_guild_recruitment` WHERE `guild_id`={$gid} LIMIT 1;"); mysql_delete("DELETE FROM `znote_guild_recruitment_apps` WHERE `guild_id`={$gid};");}

function guild_recruitment_logo(string $guildName):string{
	if(function_exists('theme_guild_logo')){$t=theme_guild_logo($guildName); if(is_string($t)&&$t!=='')return $t;}
	$f='engine/guildimg/'.$guildName.'.gif';
	return is_file($f)?$f:'engine/guildimg/default@logo.gif';
}

/** applications for a guild by status */
function guild_recruitment_apps(int $gid,string $status=''):array{
	if($gid<=0||!function_exists('znote_table_exists')||!znote_table_exists('znote_guild_recruitment_apps'))return [];
	$w=$status!==''?" AND `status`='".mysql_znote_escape_string($status)."'":'';
	$rows=mysql_select_multi("SELECT * FROM `znote_guild_recruitment_apps` WHERE `guild_id`={$gid}{$w} ORDER BY `created_at` DESC LIMIT 200;");
	return is_array($rows)?$rows:[];
}
function guild_recruitment_apply(int $gid,int $playerId,string $charName,string $message):string{
	if($gid<=0||$playerId<=0)return t_default('guild_recruitment.apply_invalid','Invalid request.');
	if(!function_exists('znote_table_exists')||!znote_table_exists('znote_guild_recruitment_apps'))return t_default('guild_recruitment.apply_notinstalled','This feature is not installed yet.');
	$post=guild_recruitment_post($gid); if(!$post||(int)$post['active']!==1)return t_default('guild_recruitment.apply_notrecruiting','This guild is not recruiting.');
	$char=mysql_select_single("SELECT `p`.`id`,`p`.`level` FROM `players` AS `p` WHERE `p`.`id`={$playerId} LIMIT 1;");
	if(!is_array($char))return t_default('guild_recruitment.apply_nochar','Character not found.');
	if((int)$char['level']<(int)$post['min_level'])return t_default('guild_recruitment.apply_minlevel','That character does not meet the minimum level ({n}).',['n'=>(int)$post['min_level']]);
	$g=$gid; $pid=$playerId; $n=mysql_znote_escape_string(mb_substr($charName,0,255)); $msg=mysql_znote_escape_string(mb_substr(trim($message),0,1000)); $now=time();
	$ok=mysql_insert("INSERT IGNORE INTO `znote_guild_recruitment_apps` (`guild_id`,`player_id`,`character_name`,`message`,`status`,`created_at`) VALUES ({$g},{$pid},'{$n}','{$msg}','pending',{$now});");
	return $ok!==false?'ok':t_default('guild_recruitment.apply_already','You have already applied to this guild.');
}
function guild_recruitment_app_decide(int $appId,int $guildId,string $decision):void{
	$appId=(int)$appId; $guildId=(int)$guildId; if($appId<=0||$guildId<=0)return;
	$app=mysql_select_single("SELECT * FROM `znote_guild_recruitment_apps` WHERE `id`={$appId} AND `guild_id`={$guildId} LIMIT 1;");
	if(!is_array($app))return;
	if($decision==='accepted'){$pid=(int)$app['player_id']; mysql_delete("DELETE FROM `guild_invites` WHERE `player_id`={$pid} AND `guild_id`={$guildId};"); mysql_insert("INSERT INTO `guild_invites` (`player_id`,`guild_id`) VALUES ({$pid},{$guildId});");}
	$s=$decision==='accepted'?'accepted':'rejected';
	mysql_update("UPDATE `znote_guild_recruitment_apps` SET `status`='{$s}' WHERE `id`={$appId} LIMIT 1;");
}

function guild_recruitment_box_css():string{
	return '.gr-box{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));margin:0 0 16px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--znx-plugin-surface);color:var(--znx-plugin-text);opacity:.97;overflow:hidden}.gr-box *{box-sizing:border-box}.gr-box a{color:var(--gr-link,inherit);text-decoration:none}.gr-head{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;align-items:center;margin-bottom:12px}.gr-head strong{font-size:15px}.gr-manage{font-size:12px;padding:5px 10px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:var(--gr-btn-bg,transparent);color:var(--gr-btn-text,inherit)}.gr-page{display:grid;grid-template-columns:repeat(auto-fill,200px);justify-content:start;gap:12px}.gr-page[hidden]{display:none}.gr-card{width:200px;height:200px;display:flex;flex-direction:column;gap:6px;padding:12px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--gr-card-bg,transparent);color:inherit;overflow:hidden;transition:border-color .15s,transform .05s}.gr-card:hover{border-color:var(--gr-link,var(--znx-plugin-text))}.gr-card:active{transform:translateY(1px)}.gr-card__logo{width:52px;height:52px;object-fit:contain;image-rendering:pixelated;border:1px solid var(--znx-plugin-border);border-radius:6px;background:rgba(0,0,0,.15);flex:0 0 auto}.gr-card__title{font-weight:700;font-size:13px;line-height:1.25;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.gr-card__text{font-size:11.5px;opacity:.75;line-height:1.35;flex:1 1 auto;overflow:hidden;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical}.gr-card__guild{flex:0 0 auto;font-size:11px;opacity:.9;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-top:6px;border-top:1px solid var(--znx-plugin-border)}@media(max-width:520px){.gr-page{grid-template-columns:repeat(auto-fill,minmax(150px,1fr));justify-content:stretch}.gr-card{width:auto;height:auto;aspect-ratio:1}}.gr-nav{display:flex;flex-wrap:wrap;gap:4px;justify-content:center;align-items:center;margin-top:12px}.gr-nav button{min-width:28px;height:28px;padding:0 6px;font:inherit;font-size:12px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:transparent;color:inherit;cursor:pointer}.gr-nav button.is-active{background:var(--gr-link,var(--znx-plugin-text));color:var(--znx-plugin-surface);border-color:transparent}.gr-nav button:disabled{opacity:.4;cursor:default}.gr-empty{opacity:.7;font-size:13px;margin:0}';
}
function guild_recruitment_box_html(?int $accountId=null):string{
	$posts=guild_recruitment_posts(true);
	$per=guild_recruitment_per_page();
	$led=$accountId!==null?guild_recruitment_led_guilds((int)$accountId):[];
	$manage=$led?'<a class="gr-manage" href="'.guild_recruitment_h(znote_plugin_url('guild_recruitment','manage')).'">'.guild_recruitment_h(t_default('guild_recruitment.manage',"Manage my guild's ad")).'</a>':'';
	$head='<div class="gr-head"><strong>'.guild_recruitment_h(t_default('guild_recruitment.title','Guild Recruitment')).'</strong>'.$manage.'</div>';
	if(!$posts)return '<div id="guildRecruitmentBox" class="gr-box"'.guild_recruitment_style_attr().'>'.$head.'<p class="gr-empty">'.guild_recruitment_h(t_default('guild_recruitment.none','No guild is recruiting right now.')).'</p></div>';
	$pages=array_chunk($posts,$per); $body='';
	foreach($pages as $pi=>$chunk){$cards='';
		foreach($chunk as $p){$gid=(int)$p['guild_id']; $url=znote_plugin_url('guild_recruitment','view').'&guild='.$gid;
			$cards.='<a class="gr-card" href="'.guild_recruitment_h($url).'"><img class="gr-card__logo" src="'.guild_recruitment_h(guild_recruitment_logo((string)$p['guild_name'])).'" alt="" loading="lazy"><span class="gr-card__title">'.guild_recruitment_h($p['title']!==''?$p['title']:t_default('guild_recruitment.join','Join {guild}',['guild'=>(string)$p['guild_name']])).'</span><span class="gr-card__text">'.guild_recruitment_h(guild_recruitment_excerpt((string)$p['message'])).'</span><span class="gr-card__guild">'.guild_recruitment_h($p['guild_name']).'</span></a>';
		}
		$body.='<div class="gr-page" data-gr-page="'.$pi.'"'.($pi>0?' hidden':'').'>'.$cards.'</div>';
	}
	$nav='';
	if(count($pages)>1){$dots='';for($i=0;$i<count($pages);$i++)$dots.='<button type="button" data-gr-goto="'.$i.'"'.($i===0?' class="is-active"':'').'>'.($i+1).'</button>';
		$nav='<div class="gr-nav" data-gr-nav><button type="button" data-gr-dir="-1" disabled>&lsaquo;</button>'.$dots.'<button type="button" data-gr-dir="1">&rsaquo;</button></div>';}
	return '<div id="guildRecruitmentBox" class="gr-box"'.guild_recruitment_style_attr().'>'.$head.'<div class="gr-grid-wrap">'.$body.'</div>'.$nav.'</div>';
}

function guild_recruitment_footer():string{
	if(!guild_recruitment_enabled()||basename((string)($_SERVER['SCRIPT_NAME']??''))!=='guilds.php'||!guild_recruitment_ready())return '';
	$accountId=(int)($GLOBALS['session_user_id']??0);
	$led=$accountId>0?guild_recruitment_led_guilds($accountId):[];
	// Nothing to show: no active ads and the viewer is not a guild leader.
	if(!guild_recruitment_posts(true)&&!$led)return '';
	$html=guild_recruitment_box_html($accountId>0?$accountId:null);
	$css=guild_recruitment_box_css();
	$pager='function grPager(box){var pages=[].slice.call(box.querySelectorAll(".gr-page")),nav=box.querySelector("[data-gr-nav]");if(pages.length<2||!nav)return;var dots=[].slice.call(nav.querySelectorAll("[data-gr-goto]")),arrows=[].slice.call(nav.querySelectorAll("[data-gr-dir]")),cur=0;function render(){pages.forEach(function(p,i){p.hidden=i!==cur;});dots.forEach(function(d,i){d.classList.toggle("is-active",i===cur);});arrows.forEach(function(a){var d=parseInt(a.getAttribute("data-gr-dir"),10);a.disabled=(d<0&&cur===0)||(d>0&&cur===pages.length-1);});}function go(i){cur=Math.max(0,Math.min(pages.length-1,i));render();}dots.forEach(function(d,i){d.addEventListener("click",function(){go(i);});});arrows.forEach(function(a){a.addEventListener("click",function(){go(cur+parseInt(a.getAttribute("data-gr-dir"),10));});});render();}';
	$js='(function(){if(document.getElementById("guildRecruitmentBox"))return;var s=document.createElement("style");s.textContent='.json_encode($css).';document.head.appendChild(s);var w=document.createElement("div");w.innerHTML='.json_encode($html).';var box=w.firstChild;var sel=[".ec-content",".wc-content",".ts-content",".ts-inner",".void-content",".nz-panel",".leftPane",".feedContainer",".znoteInner","#content",".content","main [class*=content]","main"],root=null;for(var i=0;i<sel.length&&!root;i++)root=document.querySelector(sel[i]);if(root){root.insertBefore(box,root.firstChild);}else{var all=document.body?document.body.querySelectorAll("h1,h2,h3,table,form"):[],a=null;for(var j=0;j<all.length;j++){if(all[j].closest("nav,header,footer,aside")){continue;}a=all[j];break;}if(a&&a.parentNode)a.parentNode.insertBefore(box,a);else return;}'.$pager.'grPager(box);}());';
	return '<script>'.$js.'</script>';
}

}
if(function_exists('znote_hook_register'))znote_hook_register('page.footer','guild_recruitment_footer');
