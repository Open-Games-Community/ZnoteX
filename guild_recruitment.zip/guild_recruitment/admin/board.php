<?php
/**
 * Title: Guild Recruitment
 * Icon: fa-bullhorn
 * Group: Installed Plugins
 * Order: 60
 * Description: Enable, style and moderate the guild recruitment board. Guild leaders write the ads themselves from the site.
 */
if(!defined('ACP_ROOT')){http_response_code(403);die('Direct access denied.');}
function guild_recruitment_admin_color($v):string{$v=trim((string)$v);return preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/',$v)?$v:'';}
$styleKeys=['box_bg'=>'Box background','text'=>'Text color','border'=>'Border color','card_bg'=>'Card background','tag_bg'=>'Tag background','tag_text'=>'Tag text','link'=>'Link / hover color','button_bg'=>'Button background','button_text'=>'Button text'];
if($_SERVER['REQUEST_METHOD']==='POST'){
	$do=(string)($_POST['do']??'');
	if($do==='style'){
		setting_set('guild_recruitment:enabled',!empty($_POST['enabled'])?'1':'0');
		setting_set('guild_recruitment:per_page',(string)max(2,min(24,(int)($_POST['per_page']??9))));
		foreach(array_keys($styleKeys) as $k)setting_set('guild_recruitment:style_'.$k,guild_recruitment_admin_color($_POST['style_'.$k]??''));
		acp_flash_success('Guild Recruitment settings saved.');acp_redirect('guild_recruitment__board');
	}
	if($do==='toggle'){
		$g=(int)($_POST['guild_id']??0);
		if($g>0)mysql_update("UPDATE `znote_guild_recruitment` SET `active`=CASE WHEN `active`=1 THEN 0 ELSE 1 END WHERE `guild_id`={$g} LIMIT 1;");
		acp_flash_success('Ad visibility updated.');acp_redirect('guild_recruitment__board');
	}
	if($do==='delete'){
		$g=(int)($_POST['guild_id']??0);
		if($g>0){mysql_delete("DELETE FROM `znote_guild_recruitment` WHERE `guild_id`={$g} LIMIT 1;");mysql_delete("DELETE FROM `znote_guild_recruitment_apps` WHERE `guild_id`={$g};");}
		acp_flash_info('Ad and its applications deleted.');acp_redirect('guild_recruitment__board');
	}
	acp_redirect('guild_recruitment__board');
}
$rows=mysql_select_multi("SELECT `r`.`guild_id`,`r`.`title`,`r`.`min_level`,`r`.`vocations`,`r`.`active`,`r`.`updated_at`,`g`.`name` AS `guild_name`,(SELECT COUNT(*) FROM `znote_guild_recruitment_apps` AS `a` WHERE `a`.`guild_id`=`r`.`guild_id` AND `a`.`status`='pending') AS `pending` FROM `znote_guild_recruitment` AS `r` LEFT JOIN `guilds` AS `g` ON `g`.`id`=`r`.`guild_id` ORDER BY `r`.`active` DESC,`r`.`updated_at` DESC LIMIT 300;");
if(!is_array($rows))$rows=[];
?>
<?php acp_card_open('Display & Style','Guild leaders create the ads themselves on the site (a guild owner sees a "Manage my guild\'s ad" button above the guild list). Here you only turn the board on/off, style it, and moderate. Leave a colour empty to inherit the theme.'); ?>
<form method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="style">
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label><input type="checkbox" name="enabled" value="1" <?= setting('guild_recruitment:enabled','1')==='1'?'checked':'' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label">Cards per page</label><input class="acp-input" type="number" min="2" max="24" name="per_page" value="<?= (int)setting('guild_recruitment:per_page','9') ?>"></div>
	</div>
	<div class="acp-grid acp-grid--2"><?php foreach($styleKeys as $k=>$label):?><div class="acp-field"><label class="acp-label"><?= h($label) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h(setting('guild_recruitment:style_'.$k,'')) ?>" placeholder="#1e2128 or rgba(30,33,40,.95)"></div><?php endforeach;?></div>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit">Save</button></div>
</form>
<?php acp_card_close(); ?>
<?php acp_card_open('Recruitment ads','Every ad below was written by a guild leader. Hide or delete abusive ones.'); ?>
<?php if(!$rows): ?>
	<p class="acp-muted">No guild has posted a recruitment ad yet.</p>
<?php else: ?>
<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Guild</th><th>Title</th><th>Requirements</th><th>Pending</th><th>Updated</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): ?>
	<tr>
		<td><?= h($r['guild_name'] ?? ('#'.(int)$r['guild_id'].' (deleted)')) ?></td>
		<td><?= h($r['title']) ?> <?= (int)$r['active']===1?'':'<span class="acp-muted">(hidden)</span>' ?></td>
		<td><?= (int)$r['min_level'] ?>+ <?= h($r['vocations']) ?></td>
		<td><?= (int)$r['pending'] ?></td>
		<td class="acp-muted"><?= h(function_exists('getClock')?getClock((int)$r['updated_at'],true):date('Y-m-d',(int)$r['updated_at'])) ?></td>
		<td style="white-space:nowrap">
			<form method="post" style="display:inline"><?= acp_csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="guild_id" value="<?= (int)$r['guild_id'] ?>"><button class="acp-btn acp-btn--sm" type="submit"><?= (int)$r['active']===1?'Hide':'Show' ?></button></form>
			<form method="post" style="display:inline" onsubmit="return confirm('Delete this ad and its applications?')"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="guild_id" value="<?= (int)$r['guild_id'] ?>"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit">Delete</button></form>
		</td>
	</tr>
<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
<?php acp_card_close(); ?>
