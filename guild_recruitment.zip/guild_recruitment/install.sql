﻿-- Guild Recruitment v2: guild leaders post one recruitment ad per guild.
-- Coming from the old admin-managed v1? Run first: DROP TABLE `znote_guild_recruitment`;

CREATE TABLE IF NOT EXISTS `znote_guild_recruitment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` int NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL DEFAULT '',
  `message` text,
  `min_level` int NOT NULL DEFAULT '0',
  `vocations` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint NOT NULL DEFAULT '1',
  `created_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `guild_uniq` (`guild_id`),
  KEY `active_updated` (`active`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_guild_recruitment_apps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` int NOT NULL,
  `player_id` int NOT NULL,
  `character_name` varchar(255) NOT NULL DEFAULT '',
  `message` text,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `guild_player` (`guild_id`,`player_id`),
  KEY `guild_status` (`guild_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DELETE FROM `znote_guild_recruitment` WHERE `guild_id` <= 0;
