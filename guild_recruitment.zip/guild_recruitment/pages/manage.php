<?php
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }
if (function_exists('protect_page')) protect_page();

$h     = 'guild_recruitment_h';
$accId = (int)($GLOBALS['session_user_id'] ?? 0);
$led   = guild_recruitment_led_guilds($accId);
$back  = '<a class="gr-vbtn gr-vbtn--ghost" href="guilds.php">&larr; '.guild_recruitment_h(t_default('guild_recruitment.back','Back to guilds')).'</a>';

echo '<style>' . guild_recruitment_box_css()
	. '.gr-view{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));color:var(--znx-plugin-text)}'
	. '.gr-view *{box-sizing:border-box}.gr-view h1{font-size:20px;margin:0 0 4px}.gr-view h2{font-size:15px;margin:20px 0 8px}'
	. '.gr-form{display:grid;gap:6px;max-width:520px;margin-top:10px}'
	. '.gr-form label{font-size:12px;opacity:.8;margin-top:6px}'
	. '.gr-form input,.gr-form textarea{width:100%;padding:8px 10px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:rgba(0,0,0,.15);color:inherit;font:inherit}'
	. '.gr-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}'
	. '.gr-vbtn{display:inline-flex;align-items:center;gap:6px;padding:8px 15px;font:inherit;font-weight:700;font-size:13px;border-radius:6px;border:1px solid var(--gr-link,var(--znx-plugin-text));background:var(--gr-link,var(--znx-plugin-text));color:var(--znx-plugin-surface);cursor:pointer}'
	. '.gr-vbtn--ghost{background:transparent;color:inherit;border-color:var(--znx-plugin-border);font-weight:600}'
	. '.gr-vbtn--danger{background:transparent;border-color:#b3403a;color:#d9756f}'
	. '.gr-apps{width:100%;border-collapse:collapse;margin-top:8px;font-size:13px}'
	. '.gr-apps th,.gr-apps td{text-align:left;padding:7px 8px;border-bottom:1px solid var(--znx-plugin-border);vertical-align:top}'
	. '.gr-apps form{display:inline}.gr-note{margin-top:10px;padding:9px 12px;border:1px solid var(--znx-plugin-border);border-radius:6px;font-size:13px}'
	. '</style><div class="gr-view">';

if (!$led) {
	echo '<h1>'.$h(t_default('guild_recruitment.v_title','Guild recruitment')).'</h1><p class="gr-note">'.t_default('guild_recruitment.m_only_leader','Only a <b>guild leader</b> (the character that owns the guild) can post a recruitment ad.').'</p><div class="gr-actions">' . $back . '</div></div>';
	return;
}

// Pick the guild: ?guild= when the account leads several, else the only one.
$gids = array_keys($led);
$gid  = (int)($_GET['guild'] ?? 0);
if (!isset($led[$gid])) $gid = (int)$gids[0];
$guild = $led[$gid];

$note = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && class_exists('Token') && Token::isValid($_POST['token'] ?? null)) {
	$do = (string)($_POST['do'] ?? '');
	$pg = (int)($_POST['guild_id'] ?? 0);
	if (isset($led[$pg])) {
		if ($do === 'save') {
			guild_recruitment_save($pg, (string)($_POST['title'] ?? ''), (string)($_POST['message'] ?? ''), (int)($_POST['min_level'] ?? 0), (string)($_POST['vocations'] ?? ''));
			$note = t_default('guild_recruitment.m_saved','Recruitment ad saved.');
		} elseif ($do === 'delete') {
			guild_recruitment_delete($pg);
			$note = t_default('guild_recruitment.m_removed','Recruitment ad removed.');
		} elseif ($do === 'app') {
			guild_recruitment_app_decide((int)($_POST['app_id'] ?? 0), $pg, (string)($_POST['decision'] ?? ''));
			$note = ($_POST['decision'] ?? '') === 'accepted' ? t_default('guild_recruitment.m_accepted','Applicant accepted and invited to the guild.') : t_default('guild_recruitment.m_rejected','Application rejected.');
		}
		$gid = $pg; $guild = $led[$pg];
	}
}

$post = guild_recruitment_post($gid);

echo '<h1>' . $h(t_default('guild_recruitment.m_title','{guild} - recruitment',['guild'=>$guild['name']])) . '</h1>';
if (count($gids) > 1) {
	echo '<p style="font-size:12px;opacity:.8">' . $h(t_default('guild_recruitment.m_your_guilds','Your guilds:')) . ' ';
	foreach ($gids as $g) echo ($g === $gid ? '<b>' . $h($led[$g]['name']) . '</b>' : '<a href="?plugin=guild_recruitment&p=manage&guild=' . $g . '">' . $h($led[$g]['name']) . '</a>') . ' ';
	echo '</p>';
}
if ($note !== '') echo '<p class="gr-note">' . $h($note) . '</p>';

$tokenField = ''; if (class_exists('Token')) { ob_start(); Token::create(); $tokenField = ob_get_clean(); }

echo '<form class="gr-form" method="post">' . $tokenField
	. '<input type="hidden" name="do" value="save"><input type="hidden" name="guild_id" value="' . $gid . '">'
	. '<label>' . $h(t_default('guild_recruitment.m_f_title','Title')) . '</label><input type="text" name="title" maxlength="120" value="' . $h($post['title'] ?? '') . '" placeholder="' . $h(t_default('guild_recruitment.m_f_title_ph','e.g. {guild} is recruiting active hunters',['guild'=>$guild['name']])) . '">'
	. '<label>' . $h(t_default('guild_recruitment.m_f_message','Message')) . '</label><textarea name="message" rows="6" placeholder="' . $h(t_default('guild_recruitment.m_f_message_ph','Who you are looking for, activity, requirements, contact…')) . '">' . $h($post['message'] ?? '') . '</textarea>'
	. '<label>' . $h(t_default('guild_recruitment.m_f_minlevel','Minimum level')) . '</label><input type="number" name="min_level" min="0" value="' . (int)($post['min_level'] ?? 0) . '">'
	. '<label>' . $h(t_default('guild_recruitment.m_f_vocations','Vocations wanted')) . '</label><input type="text" name="vocations" maxlength="255" value="' . $h($post['vocations'] ?? '') . '" placeholder="EK, RP, MS">'
	. '<div class="gr-actions"><button class="gr-vbtn" type="submit">' . ($post ? $h(t_default('guild_recruitment.m_update','Update ad')) : $h(t_default('guild_recruitment.m_publish','Publish ad'))) . '</button>';
if ($post) {
	echo '<button class="gr-vbtn gr-vbtn--danger" type="submit" form="grDel">' . $h(t_default('guild_recruitment.m_remove','Remove ad')) . '</button>';
}
echo $back . '</div></form>';
if ($post) {
	echo '<form id="grDel" method="post" onsubmit="return confirm(\'' . $h(t_default('guild_recruitment.m_remove_confirm','Remove your recruitment ad?')) . '\')">' . $tokenField
		. '<input type="hidden" name="do" value="delete"><input type="hidden" name="guild_id" value="' . $gid . '"></form>';
}

// ---- applications -------------------------------------------------------
$apps = guild_recruitment_apps($gid);
echo '<h2>' . $h(t_default('guild_recruitment.m_apps','Applications')) . '</h2>';
if (!$apps) {
	echo '<p class="gr-note">' . $h(t_default('guild_recruitment.m_no_apps','No applications yet.')) . '</p>';
} else {
	echo '<table class="gr-apps"><thead><tr><th>' . $h(t_default('guild_recruitment.m_col_char','Character')) . '</th><th>' . $h(t_default('guild_recruitment.m_col_msg','Message')) . '</th><th>' . $h(t_default('guild_recruitment.m_col_when','When')) . '</th><th>' . $h(t_default('guild_recruitment.m_col_status','Status')) . '</th><th></th></tr></thead><tbody>';
	foreach ($apps as $a) {
		$st = (string)$a['status'];
		echo '<tr><td><a href="characterprofile.php?name=' . $h(urlencode($a['character_name'])) . '">' . $h($a['character_name']) . '</a></td>'
			. '<td>' . ($a['message'] !== '' ? $h(guild_recruitment_excerpt((string)$a['message'], 200)) : '<span style="opacity:.5">—</span>') . '</td>'
			. '<td style="white-space:nowrap">' . $h(function_exists('getClock') ? getClock((int)$a['created_at'], true) : date('Y-m-d', (int)$a['created_at'])) . '</td>'
			. '<td>' . $h(t_default('guild_recruitment.status_' . $st, ucfirst($st))) . '</td><td style="white-space:nowrap">';
		if ($st === 'pending') {
			echo '<form method="post">' . $tokenField . '<input type="hidden" name="do" value="app"><input type="hidden" name="guild_id" value="' . $gid . '"><input type="hidden" name="app_id" value="' . (int)$a['id'] . '"><button class="gr-vbtn" style="padding:4px 10px" name="decision" value="accepted" type="submit">' . $h(t_default('guild_recruitment.m_accept','Accept')) . '</button> <button class="gr-vbtn gr-vbtn--ghost" style="padding:4px 10px" name="decision" value="rejected" type="submit">' . $h(t_default('guild_recruitment.m_reject','Reject')) . '</button></form>';
		} elseif ($st === 'accepted') {
			echo '<span style="opacity:.7;font-size:12px">' . $h(t_default('guild_recruitment.m_invited','Invited - they join in-game')) . '</span>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

echo '</div>';
