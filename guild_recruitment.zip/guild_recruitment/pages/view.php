<?php
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$grGid  = (int)($_GET['guild'] ?? 0);
$grPost = guild_recruitment_post($grGid);
$h      = 'guild_recruitment_h';
$accId  = (int)($GLOBALS['session_user_id'] ?? 0);
$back   = '<a class="gr-vbtn gr-vbtn--ghost" href="guilds.php">&larr; '.guild_recruitment_h(t_default('guild_recruitment.back','Back to guilds')).'</a>';

echo '<style>' . guild_recruitment_box_css()
	. '.gr-view{--znx-plugin-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(30,33,40))))))));--znx-plugin-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(155,162,177)))))));--znx-plugin-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));color:var(--znx-plugin-text)}'
	. '.gr-view *{box-sizing:border-box}.gr-view a{color:var(--gr-link,inherit)}'
	. '.gr-vhead{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:14px}'
	. '.gr-vhead img{width:64px;height:64px;object-fit:contain;image-rendering:pixelated;border:1px solid var(--znx-plugin-border);border-radius:8px;background:rgba(0,0,0,.15)}'
	. '.gr-vhead h1{margin:0;font-size:20px}.gr-vhead p{margin:2px 0 0;opacity:.8;font-size:13px}'
	. '.gr-tags{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}'
	. '.gr-tags span{font-size:12px;padding:3px 9px;border:1px solid var(--znx-plugin-border);border-radius:999px;background:var(--gr-tag-bg,transparent);color:var(--gr-tag-text,inherit)}'
	. '.gr-msg{white-space:pre-line;line-height:1.55;margin:12px 0;padding:12px;border:1px solid var(--znx-plugin-border);border-radius:8px;background:var(--gr-card-bg,transparent);overflow-wrap:anywhere}'
	. '.gr-apply{margin-top:16px;padding:14px;border:1px solid var(--znx-plugin-border);border-radius:8px}'
	. '.gr-apply label{display:block;font-size:12px;opacity:.8;margin:8px 0 4px}'
	. '.gr-apply select,.gr-apply textarea{width:100%;max-width:420px;padding:8px 10px;border:1px solid var(--znx-plugin-border);border-radius:6px;background:rgba(0,0,0,.15);color:inherit;font:inherit}'
	. '.gr-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}'
	. '.gr-vbtn{display:inline-flex;align-items:center;gap:6px;padding:9px 16px;font:inherit;font-weight:700;font-size:13px;border-radius:6px;border:1px solid var(--gr-btn-bg,var(--gr-link,var(--znx-plugin-text)));background:var(--gr-btn-bg,var(--gr-link,var(--znx-plugin-text)));color:var(--gr-btn-text,var(--znx-plugin-surface));cursor:pointer}'
	. '.gr-vbtn--ghost{background:transparent;color:inherit;border-color:var(--znx-plugin-border);font-weight:600}'
	. '.gr-note{margin-top:10px;padding:9px 12px;border:1px solid var(--znx-plugin-border);border-radius:6px;font-size:13px}'
	. '</style>';

echo '<div class="gr-view">';

if (!$grPost || (int)$grPost['active'] !== 1) {
	echo '<h1>'.$h(t_default('guild_recruitment.v_title','Guild recruitment')).'</h1><p class="gr-note">'.$h(t_default('guild_recruitment.v_notrecruiting','This guild is not recruiting right now.')).'</p><div class="gr-actions">' . $back . '</div></div>';
	return;
}

$guildName = (string)$grPost['guild_name'];
$members   = function_exists('get_guild_players') ? get_guild_players((int)$grPost['guild_id']) : array();
$memberCnt = is_array($members) ? count($members) : 0;
$minLevel  = (int)$grPost['min_level'];

// ---- apply POST ----------------------------------------------------------
$grMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['gr_action'] ?? '') === 'apply' && $accId > 0
	&& class_exists('Token') && Token::isValid($_POST['token'] ?? null)) {
	$charId   = (int)($_POST['character_id'] ?? 0);
	$charName = '';
	if (function_exists('user_character_list')) {
		foreach ((array)user_character_list($accId) as $c) {
			if ((int)$c['id'] === $charId) { $charName = (string)$c['name']; break; }
		}
	}
	if ($charName === '') { $grMsg = t_default('guild_recruitment.v_pick_char','Pick one of your characters.'); }
	else {
		$res = guild_recruitment_apply((int)$grPost['guild_id'], $charId, $charName, (string)($_POST['message'] ?? ''));
		$grMsg = $res === 'ok' ? t_default('guild_recruitment.v_sent','Your application was sent to the guild leader.') : $res;
	}
}

$led      = $accId > 0 ? guild_recruitment_led_guilds($accId) : array();
$isLeader = isset($led[(int)$grPost['guild_id']]);
$myApp    = null;
if ($accId > 0 && function_exists('user_character_list') && znote_table_exists('znote_guild_recruitment_apps')) {
	$ids = array();
	foreach ((array)user_character_list($accId) as $c) { $ids[] = (int)$c['id']; }
	if ($ids) {
		$ph = implode(',', array_fill(0, count($ids), '?'));
		$myApp = db()->fetchOne("SELECT `status`,`character_name` FROM `znote_guild_recruitment_apps` WHERE `guild_id`=? AND `player_id` IN ({$ph}) LIMIT 1;", array_merge([(int)$grPost['guild_id']], $ids));
	}
}

echo '<div class="gr-vhead"><img src="' . $h(guild_recruitment_logo($guildName)) . '" alt="">'
	. '<div><h1>' . $h($grPost['title'] !== '' ? $grPost['title'] : t_default('guild_recruitment.join','Join {guild}',['guild'=>$guildName])) . '</h1>'
	. '<p><a href="guilds.php?name=' . $h(urlencode($guildName)) . '">' . $h($guildName) . '</a> &middot; ' . $h(t_default($memberCnt === 1 ? 'guild_recruitment.member_one' : 'guild_recruitment.members', $memberCnt === 1 ? '1 member' : '{n} members', ['n' => (int)$memberCnt])) . '</p></div></div>';

echo '<div class="gr-tags">';
if ($minLevel > 0) echo '<span>' . $h(t_default('guild_recruitment.v_minlevel','Min level {n}',['n'=>$minLevel])) . '</span>';
if (trim((string)$grPost['vocations']) !== '') echo '<span>' . $h($grPost['vocations']) . '</span>';
echo '</div>';

echo '<div class="gr-msg">' . $h(trim((string)$grPost['message']) !== '' ? $grPost['message'] : t_default('guild_recruitment.v_default_msg','This guild is looking for new members.')) . '</div>';

if ($grMsg !== '') echo '<p class="gr-note">' . $h($grMsg) . '</p>';

if ($isLeader) {
	echo '<p class="gr-note">' . $h(t_default('guild_recruitment.v_your_guild','This is your guild.')) . ' <a href="' . $h(znote_plugin_url('guild_recruitment', 'manage')) . '">' . $h(t_default('guild_recruitment.v_manage_link','Manage the ad and applications')) . '</a>.</p>';
} elseif (is_array($myApp)) {
	echo '<p class="gr-note">' . t_default('guild_recruitment.v_applied','You applied with <b>{name}</b> &mdash; status: <b>{status}</b>.',['name'=>$h($myApp['character_name']),'status'=>$h(t_default('guild_recruitment.status_'.$myApp['status'], ucfirst($myApp['status'])))]) . '</p>';
} elseif ($accId <= 0) {
	echo '<p class="gr-note">' . t_default('guild_recruitment.v_login','You need to <a href="login.php">log in</a> to apply.') . '</p>';
} else {
	$chars = function_exists('user_character_list') ? (array)user_character_list($accId) : array();
	$opts  = '';
	foreach ($chars as $c) {
		if ((int)($c['level'] ?? 0) < $minLevel) continue;
		$opts .= '<option value="' . (int)$c['id'] . '">' . $h($c['name']) . ' (' . (int)($c['level'] ?? 0) . ')</option>';
	}
	if ($opts === '') {
		echo '<p class="gr-note">' . $h(t_default('guild_recruitment.v_nochar_level','None of your characters meet the level requirement yet.')) . '</p>';
	} else {
		echo '<form class="gr-apply" method="post"><h3 style="margin:0 0 6px">' . $h(t_default('guild_recruitment.v_apply_h','Apply for this guild')) . '</h3>';
		ob_start(); Token::create(); echo ob_get_clean();
		echo '<input type="hidden" name="gr_action" value="apply">';
		echo '<label>' . $h(t_default('guild_recruitment.v_char','Character')) . '</label><select name="character_id" required>' . $opts . '</select>';
		echo '<label>' . $h(t_default('guild_recruitment.v_msg_label','Message to the guild (optional)')) . '</label><textarea name="message" rows="3" maxlength="1000" placeholder="' . $h(t_default('guild_recruitment.v_msg_ph','Why you want to join…')) . '"></textarea>';
		echo '<div class="gr-actions"><button class="gr-vbtn" type="submit">' . $h(t_default('guild_recruitment.v_apply_btn','Apply for the guild')) . '</button></div></form>';
	}
}

echo '<div class="gr-actions">' . $back . '</div>';
echo '</div>';
