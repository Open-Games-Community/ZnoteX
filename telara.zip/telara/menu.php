<?php
$telaraMenu = theme_menu_items('main');

if (!function_exists('telara_menu_label')) {
	function telara_menu_label($value): string {
		return htmlspecialchars(
			function_exists('theme_menu_label') ? theme_menu_label((string)$value) : (string)$value,
			ENT_QUOTES,
			'UTF-8'
		);
	}
}
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#telara-main-nav" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand visible-xs" href="index.php"><?= h(t('nav.home')) ?></a>
		</div>

		<div class="collapse navbar-collapse" id="telara-main-nav">
			<ul class="nav navbar-nav">
			<?php if ($telaraMenu): ?>
				<?php foreach ($telaraMenu as $item): ?>
					<?php if (!empty($item['children'])): ?>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
								<?php if ($item['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i><?php endif; ?>
								<?= telara_menu_label($item['label']) ?> <span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<?php if ($item['url'] !== ''): ?>
									<li><a href="<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>"<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>><?= telara_menu_label($item['label']) ?></a></li>
									<li role="separator" class="divider"></li>
								<?php endif; ?>
								<?php foreach ($item['children'] as $child): ?>
									<li><a href="<?= htmlspecialchars($child['url'], ENT_QUOTES, 'UTF-8') ?>"<?= $child['target'] !== '' ? ' target="' . htmlspecialchars($child['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>><?= telara_menu_label($child['label']) ?></a></li>
								<?php endforeach; ?>
							</ul>
						</li>
					<?php else: ?>
						<li><a href="<?= htmlspecialchars($item['url'] !== '' ? $item['url'] : '#', ENT_QUOTES, 'UTF-8') ?>"<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
							<?php if ($item['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i><?php endif; ?>
							<?= telara_menu_label($item['label']) ?>
						</a></li>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php else: ?>
				<li><a href="index.php"><i class="fa fa-home"></i> <?= h(t('nav.home')) ?></a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?= h(t('nav.account_section')) ?> <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="myaccount.php"><?= h(t('nav.account_management')) ?></a></li>
						<li><a href="register.php"><?= h(t('nav.register')) ?></a></li>
						<li><a href="downloads.php"><?= h(t('nav.download_client')) ?></a></li>
					</ul>
				</li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?= h(t('nav.community')) ?> <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="onlinelist.php"><?= h(t('nav.online')) ?></a></li>
						<li><a href="deaths.php"><?= h(t('deaths.latest')) ?></a></li>
						<li><a href="guilds.php"><?= h(t('nav.guilds')) ?></a></li>
						<li><a href="highscores.php"><?= h(t('nav.highscores')) ?></a></li>
					</ul>
				</li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?= h(t('nav.library')) ?> <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="serverinfo.php"><?= h(t('nav.serverinfo')) ?></a></li>
						<li><a href="items.php"><?= h(t('items.title')) ?></a></li>
						<li><a href="spells.php"><?= h(t('spells.title')) ?></a></li>
						<li><a href="creatures.php"><?= h(t('creatures.title')) ?></a></li>
					</ul>
				</li>
				<li><a href="shop.php"><?= h(t('nav.shop')) ?></a></li>
			<?php endif; ?>
			</ul>

			<form class="navbar-form navbar-right telara-search" action="characterprofile.php" method="get">
				<div class="form-group">
					<input type="text" name="name" class="form-control" placeholder="<?= htmlspecialchars(t('widget.search.placeholder'), ENT_QUOTES, 'UTF-8') ?>">
				</div>
				<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
			</form>
		</div>
	</div>
</nav>
