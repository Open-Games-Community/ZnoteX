<?php

return array(
	'telara.status.players_online' => 'Gracze online',
	'telara.footer.legacy' => 'Projekt oryginalny: Gunz / Michal',
	'telara.footer.engine' => 'Silnik:',
);
