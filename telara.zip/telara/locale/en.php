<?php

return array(
	'telara.status.players_online' => 'Players Online',
	'telara.footer.legacy' => 'Legacy design: Gunz / Michal',
	'telara.footer.engine' => 'Engine:',
);
