<?php

return array(
	'telara.status.players_online' => 'Spieler online',
	'telara.footer.legacy' => 'Original-Design: Gunz / Michal',
	'telara.footer.engine' => 'Engine:',
);
