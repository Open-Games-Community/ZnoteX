<?php

return array(
	'telara.status.players_online' => 'Jogadores online',
	'telara.footer.legacy' => 'Design original: Gunz / Michal',
	'telara.footer.engine' => 'Motor:',
);
