<?php

return array(
	'telara.status.players_online' => 'Jugadores en línea',
	'telara.footer.legacy' => 'Diseño original: Gunz / Michal',
	'telara.footer.engine' => 'Motor:',
);
