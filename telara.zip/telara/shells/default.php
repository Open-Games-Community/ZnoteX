<?php
if (!function_exists('telara_escape')) {
	function telara_escape($value): string {
		return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
	}
}

$telaraOnline  = function_exists('user_count_online') ? (int)user_count_online() : 0;
$telaraFooter  = theme_option('footer_html');
$telaraFavicon = function_exists('theme_image') ? theme_image('favicon') : '';
$telaraDiscord = theme_option('discord_url');
?>
<!doctype html>
<html lang="<?= telara_escape(function_exists('translate_active') ? explode('_', translate_active())[0] : 'en') ?>">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= theme_title() ?></title>
	<?php if ($telaraFavicon !== ''): ?><link rel="icon" href="<?= $telaraFavicon ?>"><?php endif; ?>

	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap-theme.min.css') ?>">
	<link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= theme_asset('css/legacy-main.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/znotex.css') ?>">

	<script src="assets/js/jquery.js"></script>
	<script src="<?= theme_asset('js/bootstrap.min.js') ?>"></script>
</head>
<body class="<?= theme_body_class() ?>">

<div class="status-bar notranslate">
	<div class="container">
		<div class="item">
			<a href="onlinelist.php"><span class="online"><?= $telaraOnline ?></span> <span class="value"><?= h(t('telara.status.players_online')) ?></span></a>
		</div>
		<div class="item"><a href="serverinfo.php" class="value"><?= h(t('nav.serverinfo')) ?></a></div>
		<div class="item"><a href="downloads.php" class="value"><?= h(t('nav.download_client')) ?></a></div>
		<?php if ($telaraDiscord !== ''): ?>
			<div class="item"><a href="<?= telara_escape($telaraDiscord) ?>" target="_blank" rel="noopener" class="value telara-discord-link"><?php theme_include('parts/discord-icon.php'); ?> Discord</a></div>
		<?php endif; ?>
		<div class="item pull-right telara-account-links">
			<?php if (user_logged_in() === true): ?>
				<a class="value" href="myaccount.php"><?= telara_escape($user_data['name'] ?? t('widget.account.my_account')) ?></a>
				<span class="telara-status-separator">/</span>
				<a class="value" href="logout.php"><?= h(t('nav.logout')) ?></a>
			<?php else: ?>
				<a class="value" href="myaccount.php"><?= h(t('nav.login')) ?></a>
				<span class="telara-status-separator">/</span>
				<a class="value" href="register.php"><?= h(t('nav.register')) ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="container telara-branding">
	<a href="index.php" class="logo telara-logo" aria-label="<?= theme_title() ?>"></a>
	<?php
	if (function_exists('translate_selector')) {
		$telaraSelector = translate_selector();
		if ($telaraSelector !== '') {
			echo '<div class="telara-lang">' . $telaraSelector . '</div>' . translate_selector_assets();
			translate_selector_rendered(true);
		}
	}
	?>
</div>

<div class="menu container">
	<?php theme_menu(); ?>
</div>

<div class="content">
	<div class="container">
		<div class="content-wrapper">
			<div class="corner-top-left"></div>
			<div class="corner-top-right"></div>
			<div class="row telara-columns">
				<main class="col-md-8 main-content">
					<div class="telara-page">
						<?php theme_content(); ?>
					</div>
				</main>
				<?php theme_sidebar(); ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<footer class="telara-footer">
	<div class="container">
		<?php if ($telaraFooter !== ''): ?>
			<div class="telara-footer-custom"><?= $telaraFooter ?></div>
		<?php endif; ?>
		<div class="telara-footer-credits">
			<?= t('credits.copyright', ['year' => date('Y'), 'site' => telara_escape((string)($config['site_name'] ?? theme_title()))]) ?><br>
			<span><?= t('telara.footer.legacy') ?> &middot; <?= t('telara.footer.engine') ?> <a href="credits.php">ZnoteX</a></span>
		</div>
	</div>
</footer>

</body>
</html>
