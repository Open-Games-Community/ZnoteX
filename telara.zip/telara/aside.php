<div class="col-md-4 right-panel">
	<?php
	if (user_logged_in() === true) {
		widget('myaccount');
		if (isset($user_data) && is_admin($user_data)) {
			widget('admin');
		}
	} else {
		widget('login');
	}

	widget('charactersearch');
	widget('serverinfo');
	widget('topplayers');
	widget('highscore');

	if (!empty($config['powergamers']['enabled'])) {
		widget('powergamers');
	}

	if (!empty($config['ServerEngine']) && $config['ServerEngine'] !== 'TFS_02') {
		widget('houses');
	}
	?>
</div>
