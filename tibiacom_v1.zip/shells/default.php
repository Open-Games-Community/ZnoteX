<?php
/**
 * TibiaCOM v1 - default shell.
 *
 * The original theme had 17 near-identical header files that differed only by
 * the headline graphic above the content box. They are one shell here, with
 * the graphic chosen from the table below.
 *
 * To give a page its own headline, add a line to $headlines. The key is the
 * page name without .php, or "page_<name>" for a page this theme adds.
 * A page with no entry gets no headline, just the box.
 *
 * A page that draws its own content box uses shells/bare.php instead:
 *   <?php theme_shell('bare'); ?>
 */

$headlines = array(
	// Account
	'myaccount'       => 'accountmanagement.png',
	'settings'        => 'accountmanagement.png',
	'helpdesk'        => 'accountmanagement.png',
	'register'        => 'createaccount.png',

	// Community
	'forum'           => 'forum.png',
	'forum_search'    => 'forum.png',
	'guilds'          => 'guilds.png',
	'guildwar'        => 'guilds.png',
	'topguilds'       => 'guilds.png',
	'onlinelist'      => 'whoisonline.png',
	'toponline'       => 'whoisonline.png',
	'killers'         => 'kills.png',
	'gallery'         => 'screenshots.gif',
	'support'         => 'team.png',

	// Server
	'houses'          => 'houses.png',
	'house'           => 'houses.png',
	'serverinfo'      => 'serverinfo.png',
	'raids'           => 'raids.png',
	'premmyfeature'   => 'premiumfeatures.gif',
	'shop'            => 'donate.png',
);

$pageKey = isset($page_filename) ? (string)$page_filename : '';

// Pages this theme adds (page.php?p=carlin) are the map/library pages.
if (str_starts_with($pageKey, 'page_')) {
	$shellHeadline = 'headline-maps.gif';
} else {
	$shellHeadline = $headlines[$pageKey] ?? '';
}

theme_include('parts/head.php');
theme_include('parts/box-open.php', array('shellHeadline' => $shellHeadline));
?>

<?php theme_content(); ?>

<?php theme_include('parts/foot.php'); ?>
