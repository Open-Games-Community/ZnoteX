<div id="DeactivationContainerThemebox" ></div>
<div id="RightArtwork">
	<img id="Monster" src="<?= theme_asset('images/global/header/monsters/King_Zelos.gif') ?>" onClick="window.location = 'onlinelist.php';" alt="<?= htmlspecialchars(t('tibiacom.alt.monster_week'), ENT_QUOTES, 'UTF-8') ?>" />
	<img id="PedestalAndOnline" src="<?= theme_asset('images/global/header/pedestal-and-online1.gif') ?>" alt="<?= htmlspecialchars(t('tibiacom.alt.pedestal_online'), ENT_QUOTES, 'UTF-8') ?>"/>
	<div id="PlayersOnline" onClick="window.location = 'onlinelist.php';">
		<a href="onlinelist.php" id="online"><?= t('widget.serverinfo.online', ['count' => '<br>' . user_count_online()]) ?></a>
		
	</div>
</div>
<div id="Themeboxes">
	<div id="HighscoreBox" class="HighscoreBox" style="background-image:url(<?= theme_asset('images/global/themeboxes/current-poll/bk_themebox8.png') ?>);">
<div class="HighscoreList">
		<?php
		$cache = new Cache('engine/cache/topPlayer');
		if ($cache->hasExpired()) {
			$players = db()->fetchAll('SELECT `name`, `level`, `experience`, `looktype`, `lookaddons`, `lookhead`, `lookbody`, `looklegs`, `lookfeet` FROM `players` WHERE `group_id` < ? ORDER BY `experience` DESC LIMIT 5;', [(int)($config['highscore']['ignoreGroupId'] ?? 3)]);
			$cache->setContent($players);
			$cache->save();
		} else {
			$players = $cache->load();
		}

		$outfitServer = (string)($config['show_outfits']['imageServer'] ?? '');

		if (is_array($players)):
			foreach ($players as $player):
				$outfit = $outfitServer . '?id=' . (int)$player['looktype']
					. '&addons=' . (int)$player['lookaddons']
					. '&head='   . (int)$player['lookhead']
					. '&body='   . (int)$player['lookbody']
					. '&legs='   . (int)$player['looklegs']
					. '&feet='   . (int)$player['lookfeet']
					. '&g=0&h=3&i=1';
		?>
			<a class="HighscoreEntry" href="characterprofile.php?name=<?= urlencode($player['name']) ?>"
			   title="<?= htmlspecialchars($player['name'], ENT_QUOTES, 'UTF-8') ?> - <?= htmlspecialchars(t('common.level'), ENT_QUOTES, 'UTF-8') ?> <?= (int)$player['level'] ?>">
				<img class="HighscoreOutfit" src="<?= htmlspecialchars($outfit, ENT_QUOTES, 'UTF-8') ?>" alt="">
				<span class="HighscoreName"><?= htmlspecialchars($player['name'], ENT_QUOTES, 'UTF-8') ?></span>
				<span class="HighscoreLevel"><?= (int)$player['level'] ?></span>
			</a>
		<?php
			endforeach;
		endif;
		?>
	</div>
            </div>
            <div id="PremiumBox" class="Themebox" style="background-image:url(<?= theme_asset('images/global/images/themeboxtibiacoin.png') ?>);">
		
			<br><br><br><br><br><br><br><br><br>
			<a href="buypoints.php"><img src="<?= theme_asset('images/global/images/getibiacoins.png') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/images/getibiacoins1.png') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/images/getibiacoins.png') ?>'" 
		 ></img></a>
			
		
	</div>
	<div id="ScreenshotBox" class="Themebox" style="background-image:url(<?= theme_asset('images/global/themeboxes/screenshot/screenshotbox.gif') ?>);">
		<a href="{$path}/index.php/p/v/gallery">
			<img id="ScreenshotContent" class="ThemeboxContent" src="<?= theme_asset('images/abouttibia/screenshotoftheday.png') ?>" alt="<?= htmlspecialchars(t('tibiacom.alt.screenshot_day'), ENT_QUOTES, 'UTF-8') ?>"/>
		</a>
		<div class="Bottom" style="background-image:url(http://static.tibia.com/images/global/general/box-bottom.gif);"></div>
	</div>
	<div id="NewcomerBox" class="Themebox" style="background-image:url(<?= theme_asset('images/global/themeboxes/newcomer/newcomerbox.gif') ?>);">
		<a class="ThemeboxButton" href="register.php" onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" style="background-image:url(<?= theme_asset('images/global/buttons/sbutton.gif') ?>);">
			<div class="BigButtonOver" style="background-image:url(<?= theme_asset('images/global/buttons/sbutton_over.gif') ?>);"></div>
			<div class="ButtonText" style="background-image:url(<?= theme_asset('images/global/buttons/_sbutton_jointibia.gif') ?>);"></div>
		</a>
		<div class="Bottom" style="background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>);"></div>
	</div>
</div>