<?php
/**
 * Opens the scroll content box. $shellHeadline is the headline image
 * inside assets/images/global/images/, or '' for no headline.
 */
?>
								<div id="news" class="Box">
									<div class="Corner-tl" style="background-image:url(<?= theme_asset('images/global/content/corner-tl.gif') ?>);"></div>
									<div class="Corner-tr" style="background-image:url(<?= theme_asset('images/global/content/corner-tr.gif') ?>);"></div>
									<div class="Border_1" style="background-image:url(<?= theme_asset('images/global/content/border-1.gif') ?>);"></div>
									<div class="BorderTitleText" style="background-image:url(<?= theme_asset('images/global/content/title-background-green.gif') ?>);"></div>
<?php if (!empty($shellHeadline)): ?>
									<img id="ContentBoxHeadline" class="Title" src="<?= theme_asset('images/global/images/' . $shellHeadline) ?>" alt="Contentbox headline" />
<?php endif; ?> 
									<div class="Border_2">
										<div class="Border_3">
											<div class="BoxContent" style="background-image:url(<?= theme_asset('images/global/content/scroll.gif') ?>);">
