<table id="questTable">
	<?php
	$completed = '<font color="green">' . t('quest.completed') . '</font>';
	$notstarted = '';
	function Progress($min, $max, $design = '<font color="orange">[x%]</font>') {
		$design = explode("x%",$design);
		$percent = ($min / $max) * 100;
		return $design[0] . $percent . $design[1];
	}
	$quests = array(
		// Simple quests
		'Bearslayer' => 1050,
		'Sword Quest' => 1337,

		// Advanced quest with progress par:
		'Postman Quest' => array(
			1338,
			3,
		),
	);
	?>
	<tr class="yellow">
		<td><?= t('quest.name') ?></td>
		<td><?= t('common.status') ?></td>
	</tr>
	<?php
	// Rolling through quests
	foreach ($quests as $key => $quest) {

		// Is quest NOT an array (advanced quest?)
		if (!is_array($quest)) {
			// Query to find quest results
			$query = db()->fetchOne("SELECT `value` FROM `player_storage` WHERE `key`=? AND `player_id`=? AND `value`='1' LIMIT 1;", [$quest, $user_id]);

			if ($query !== false) $quest = $completed;
			else $quest = $notstarted;

		} else {
			$query = db()->fetchOne("SELECT `value` FROM `player_storage` WHERE `key`=? AND `player_id`=? AND `value`>'0' LIMIT 1;", [$quest[0], $user_id]);
			if (!$query) $quest = $notstarted;
			else {
				if ($query['value'] >= $quest[1]) $quest = $completed;
				else $quest = Progress($query['value'], $quest[1]);
			}
		}
		?>
		<tr>
			<td><?php echo $key; ?></td>
			<td><?php echo $quest; ?></td>
		</tr>
		<?php
	}
	?>
</table>