<?php
/**
 * Menu helpers. Also defined in shells/default.php, but a page on the "bare"
 * shell (downloads, contact, serverrules...) never loads that file, and this
 * part still renders the menu - so define them here too when missing.
 */
if (!function_exists('tibiacomv1_managed_extra_items')) {
	function tibiacomv1_managed_extra_items(string $section): array {
		$known = array(
			'latest news', 'ticket support', 'changelog', 'account management', 'create account',
			'download client', 'downloads', 'premium features', 'server rules', 'lost account?', 'characters',
			'chars auction', 'highscores', 'experience history', 'latest deaths', 'kills statistics',
			'kill statistics', 'houses', 'support list', 'guilds', 'item market', 'forum', 'forum boards',
			'feedback', 'top guilds', 'guild wars', 'server info', 'image gallery', 'raids',
			'maps', 'buy points', 'shop', 'discussion',
		);
		$sections = array(
			'home' => 'news',
			'support' => 'news',
			'account' => 'account',
			'login' => 'account',
			'register' => 'account',
			'community' => 'community',
			'library' => 'library',
			'shop' => 'shops',
		);

		$items = array();
		$collect = static function (array $menuItems) use (&$collect, &$items, $known): void {
			foreach ($menuItems as $item) {
				if (!in_array(strtolower(trim($item['label'])), $known, true)) {
					$items[] = $item;
				}
				if (!empty($item['children'])) {
					$collect($item['children']);
				}
			}
		};
		foreach (theme_menu_items('main') as $item) {
			$label = strtolower(trim($item['label']));
			$itemSection = $sections[$label] ?? 'news';
			if ($itemSection === $section) {
				if (isset($sections[$label])) {
					$collect($item['children']);
				} else {
					$collect(array($item));
				}
			}
		}

		return $items;
	}
}

if (!function_exists('tibiacomv1_managed_menu_links')) {
	function tibiacomv1_managed_menu_links(string $section): void {
		foreach (tibiacomv1_managed_extra_items($section) as $item) {
			tibiacomv1_managed_link($item);
		}
	}
}

if (!function_exists('tibiacomv1_managed_link')) {
	function tibiacomv1_managed_link(array $item): void {
		if (trim((string)$item['url']) === '') {
			return;
		}
		$label = function_exists('theme_menu_label') ? theme_menu_label((string)$item['label']) : (string)$item['label'];
		?>
		<a href='<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>'<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
			<div class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
				<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div class='SubmenuitemLabel'><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div>
			</div>
		</a>
		<?php
	}
}

if (!function_exists('tibiacomv1_menu_section_meta')) {
	function tibiacomv1_menu_section_meta(array $item): array {
		$label = strtolower(trim((string)$item['label']));
		$slug = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)$item['label']));

		$known = array(
			'home' => array('news', 'images/global/images/Golden_Newspaper.gif', 'images/global/menu/label-news.gif'),
			'news' => array('news', 'images/global/images/Golden_Newspaper.gif', 'images/global/menu/label-news.gif'),
			'account' => array('account', 'images/global/menu/icon-account.gif', 'images/global/menu/label-account.gif'),
			'login' => array('account', 'images/global/menu/icon-account.gif', 'images/global/menu/label-account.gif'),
			'register' => array('account', 'images/global/menu/icon-account.gif', 'images/global/menu/label-account.gif'),
			'community' => array('community', 'images/global/menu/icon-community.gif', 'images/global/menu/label-community.gif'),
			'forum' => array('forum', 'images/global/menu/icon-forum.gif', 'images/global/menu/label-forum.gif'),
			'wars' => array('wars', 'images/global/images/icon-wars.gif', 'images/global/images/label-wars.gif'),
			'library' => array('library', 'images/global/images/Spellbook_of_Ancient_Arcana.gif', 'images/global/menu/label-library.gif'),
			'shop' => array('shops', 'images/global/images/Tibia_Coins.gif', 'images/global/menu/label-shops.gif'),
			'shops' => array('shops', 'images/global/images/Tibia_Coins.gif', 'images/global/menu/label-shops.gif'),
			'support' => array('support', 'images/global/menu/icon-support.gif', 'images/global/menu/label-support.gif'),
		);

		if (isset($known[$label])) {
			return $known[$label];
		}

		return array($slug !== '' ? $slug : ('menu_' . (int)$item['id']), '', '');
	}
}

if (!function_exists('tibiacomv1_render_menu_section')) {
	function tibiacomv1_render_menu_section(array $item): void {
		[$section, $icon, $labelImage] = tibiacomv1_menu_section_meta($item);
		$sectionId = 'menu_' . (int)$item['id'] . '_' . $section;
		$links = $item['children'];
		if (trim((string)$item['url']) !== '') {
			array_unshift($links, array(
				'id' => $item['id'],
				'label' => $item['label'],
				'url' => $item['url'],
				'target' => $item['target'],
				'children' => array(),
			));
		}
		?>
		<div id='<?= htmlspecialchars($sectionId, ENT_QUOTES, 'UTF-8') ?>' class='menuitem'>
			<span onClick="MenuItemAction('<?= htmlspecialchars($sectionId, ENT_QUOTES, 'UTF-8') ?>')">
				<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
					<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
						<span id='<?= htmlspecialchars($sectionId, ENT_QUOTES, 'UTF-8') ?>_Lights' class='Lights'>
							<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
							<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
							<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						</span>
						<?php if ($icon !== ''): ?>
							<div class='Icon' style='background-image:url(<?= theme_asset($icon) ?>);'></div>
						<?php elseif ((string)$item['icon'] !== ''): ?>
							<div class='Icon'><i class='fa <?= htmlspecialchars((string)$item['icon'], ENT_QUOTES, 'UTF-8') ?>'></i></div>
						<?php endif; ?>
						<?php if ($labelImage !== ''): ?>
							<div class='Label' style='background-image:url(<?= theme_asset($labelImage) ?>);'></div>
						<?php else: ?>
							<div class='Label' style='color:#f7e0b3;font:bold 13px Verdana,Arial,sans-serif;line-height:32px;text-shadow:1px 1px #000;'>
								<?= htmlspecialchars(function_exists('theme_menu_label') ? theme_menu_label((string)$item['label']) : (string)$item['label'], ENT_QUOTES, 'UTF-8') ?>
							</div>
						<?php endif; ?>
						<div id='<?= htmlspecialchars($sectionId, ENT_QUOTES, 'UTF-8') ?>_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
					</div>
				</div>
			</span>
			<div id='<?= htmlspecialchars($sectionId, ENT_QUOTES, 'UTF-8') ?>_Submenu' class='Submenu'>
				<?php foreach ($links as $link): ?>
					<?php tibiacomv1_managed_link($link); ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
?>
<div id="MenuColumn">
<div id="LeftArtwork">
	<a href="index.php" ><img id="TibiaLogoArtworkTop" src="<?= theme_image('logo_main', theme_asset('images/global/header/tibia-logo-artwork-top1.gif')) ?>" alt="logoartwork" /></a>
</div>
<?php if (user_logged_in() === true): ?>
	<div id="Loginbox">
		<div id="LoginTop" style="background-image:url(<?= theme_asset('images/global/general/box-top.gif') ?>)"></div>
		<div id="BorderLeft" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)"></div>

		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			
		</div>
		<div id="LoginButtonContainer" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			<div id="LoginButton">
				<a href="sub.php?page=loggedin"><img src="<?= theme_asset('images/global/buttons/myaccountbutton1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/myaccountbutton2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/myaccountbutton1.gif') ?>'" 
		 ></img></a>
			</div>
		</div>


		<div style="clear:both"></div>

		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
		</div>

		<div id="BorderRight" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)"></div>
		<div id="LoginBottom" class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>)"></div>
	</div>
	<div id="Loginbox">
		<div id="LoginTop" style="background-image:url(<?= theme_asset('images/global/general/box-top.gif') ?>)"></div>
		<div id="BorderLeft" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)"></div>

		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			
		</div>
		<div id="LoginButtonContainer" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			<div id="LoginButton">
				<a href="downloads.php"><img src="<?= theme_asset('images/global/buttons/downloadbutton1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/downloadbutton2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/downloadbutton1.gif') ?>'" 
		 ></img></a>
			</div>
		</div>


		<div style="clear:both"></div>

		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
		</div>

		<div id="BorderRight" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)"></div>
		<div id="LoginBottom" class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>)"></div>
	</div>
<?php else: ?>
	<div id="Loginbox" >
		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)" >
		</div>
		<div id="LoginTop" style="background-image:url(<?= theme_asset('images/global/general/box-top.gif') ?>)" ></div>
		<div id="BorderLeft" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)" ></div>
		<div id="LoginButtonContainer" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			<div id="LoginButton">
				<a href="sub.php?page=login"><img src="<?= theme_asset('images/global/buttons/loginbutton1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/loginbutton2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/loginbutton1.gif') ?>'" 
		 ></img></a>
			</div>
		</div>
		<div style="clear:both" ></div>
		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)" >
		</div>
		<div id="BorderRight" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)" ></div>
		<div id="LoginBottom" class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>)" ></div>
	</div>
	<div id="Loginbox" >
		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)" >
		</div>
		<div id="LoginTop" style="background-image:url(<?= theme_asset('images/global/general/box-top.gif') ?>)" ></div>
		<div id="BorderLeft" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)" ></div>
		<div id="LoginButtonContainer" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)">
			<div id="LoginButton">
				<a href="downloads.php"><img src="<?= theme_asset('images/global/buttons/downloadbutton1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/downloadbutton2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/downloadbutton1.gif') ?>'" 
		 ></img></a>
			</div>
		</div>
		<div style="clear:both" ></div>
		<div class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/loginbox/loginbox-textfield-background.gif') ?>)" >
		</div>
		<div id="BorderRight" class="LoginBorder" style="background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>)" ></div>
		<div id="LoginBottom" class="Loginstatus" style="background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>)" ></div>
	</div>

<?php endif; ?>

<div id='Menu'>
	<div id='MenuTop' style='background-image:url(<?= theme_asset('images/global/general/box-top.gif') ?>);'></div>
	<?php $tibiacomv1MenuItems = function_exists('theme_menu_items') ? theme_menu_items('main') : array(); ?>
	<?php $tibiacomv1MenuLive = function_exists('theme_menu_available') ? theme_menu_available() : false; ?>
	<?php if ($tibiacomv1MenuLive): ?>
		<?php foreach ($tibiacomv1MenuItems as $tibiacomv1MenuItem): ?>
			<?php tibiacomv1_render_menu_section($tibiacomv1MenuItem); ?>
		<?php endforeach; ?>
	<?php else: ?>
	<div id='news' class='menuitem'>
		<span onClick="MenuItemAction('news')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='news_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='news_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/images/Golden_Newspaper.gif') ?>);'></div>
					<div id='news_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-news.gif') ?>);'></div>
					<div id='news_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='news_Submenu' class='Submenu'>
			<a href='sub.php?page=news'>
				<div id='submenu_latestnews' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_latestnews' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_latestnews' class='SubmenuitemLabel'><?= t('tibiacom.menu.latest_news') ?>&nbsp;<img src="<?= theme_asset('images/global/images/new2.gif') ?>" width="30"></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='helpdesk.php'>
				<div id='submenu_latestnews' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_latestnews' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_latestnews' class='SubmenuitemLabel'><?= t('tibiacom.menu.ticket_support') ?>&nbsp;<img src="<?= theme_asset('images/global/images/aten.png') ?>" width="13"></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='changelog.php'>
				<div id='submenu_latestnews' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_latestnews' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_latestnews' class='SubmenuitemLabel'><?= t('changelog.title') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('news'); ?>
		</div>
	</div>
	<div id='account' class='menuitem'>
		<span onClick="MenuItemAction('account')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='account_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='account_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/menu/icon-account.gif') ?>);'></div>
					<div id='account_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-account.gif') ?>);'></div>
					<div id='account_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='account_Submenu' class='Submenu'>
			<a href='myaccount.php'>
				<div id='submenu_accountmanagement' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_accountmanagement' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_accountmanagement' class='SubmenuitemLabel'><?= t('tibiacom.menu.account_management') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='register.php'>
				<div id='submenu_createaccountanddownload' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_createaccountanddownload' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_createaccountanddownload' class='SubmenuitemLabel'><?= t('tibiacom.menu.create_account') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='downloads.php'>
				<div id='submenu_downloadclient' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_downloadclient' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_downloadclient' class='SubmenuitemLabel'><?= t('tibiacom.menu.download_client') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
						<a href='page.php?p=premmyfeature'>
				<div id='submenu_downloadclient' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_downloadclient' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_downloadclient' class='SubmenuitemLabel'><?= t('tibiacom.menu.premium_features') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='page.php?p=serverrules'>
				<div id='submenu_downloadclient' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_downloadclient' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_downloadclient' class='SubmenuitemLabel'><?= t('tibiacom.menu.server_rules') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php if (!user_logged_in()): ?>
				<a href='sub.php?page=recover'>
					<div id='submenu_lostaccount' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
						<div style='background-color:#131b33;'>
						<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
						<div id='ActiveSubmenuItemIcon_lostaccount' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
						<div id='ActiveSubmenuItemLabel_lostaccount' class='SubmenuitemLabel'><?= t('tibiacom.menu.lost_account') ?></div>
						<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					</div></div>
				</a>
			<?php endif; ?>
			<?php tibiacomv1_managed_menu_links('account'); ?>
		</div>
	</div>
	<div id='community' class='menuitem'>
		<span onClick="MenuItemAction('community')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='community_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='community_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/images/animoutfit1.gif') ?>);'></div>
					<div id='community_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-community.gif') ?>);'></div>
					<div id='community_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='community_Submenu' class='Submenu'>
			<a href='sub.php?page=charactersearch'>
				<div id='submenu_characters' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_characters' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_characters' class='SubmenuitemLabel'><?= t('tibiacom.menu.characters') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='auctionchar.php'>
				<div id='submenu_characters' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_characters' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_characters' class='SubmenuitemLabel'><font color="yellow"><?= t('tibiacom.menu.char_auction') ?> &nbsp;<img src="<?= theme_asset('images/global/images/hot2-fix.gif') ?>"></font></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='highscores.php'>
				<div id='submenu_highscores' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_highscores' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_highscores' class='SubmenuitemLabel'><?= t('nav.highscores') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='powergamers.php'>
				<div id='submenu_powergamers' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_creatures' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_creatures' class='SubmenuitemLabel'><?= t('tibiacom.menu.experience_history') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='deaths.php'>
				<div id='submenu_deaths' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_creatures' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_creatures' class='SubmenuitemLabel'><?= t('tibiacom.menu.latest_deaths') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='killers.php'>
				<div id='submenu_killers' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_spells' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_spells' class='SubmenuitemLabel'><?= t('tibiacom.menu.kills_statistics') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='sub.php?page=houses'>
				<div id='submenu_houses' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_houses' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_houses' class='SubmenuitemLabel'><?= t('nav.houses') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='support.php'>
				<div id='submenu_downloadclient' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_downloadclient' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_downloadclient' class='SubmenuitemLabel'><?= t('tibiacom.menu.support_list') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='guilds.php'>
				<div id='submenu_guilds' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_guilds' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_guilds' class='SubmenuitemLabel'><?= t('nav.guilds') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='market.php'>
				<div id='submenu_guilds' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_guilds' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_guilds' class='SubmenuitemLabel'><?= t('tibiacom.menu.item_market') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('community'); ?>
		</div>
	</div>
	<div id='forum' class='menuitem'>
		<span onClick="MenuItemAction('forum')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='forum_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='forum_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/menu/icon-forum.gif') ?>);'></div>
					<div id='forum_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-forum.gif') ?>);'></div>
					<div id='forum_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='forum_Submenu' class='Submenu'>
			<a href='forum.php'>
				<div id='submenu_forum' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_characters' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_characters' class='SubmenuitemLabel'><font color="green"><?= t('tibiacom.menu.forum_boards') ?></font></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='forum.php?cat=3'>
				<div id='submenu_forum' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_characters' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_characters' class='SubmenuitemLabel'><?= t('tibiacom.menu.discussion') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='forum.php?cat=4'>
				<div id='submenu_forum' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_characters' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_characters' class='SubmenuitemLabel'><?= t('tibiacom.menu.feedback') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('forum'); ?>
		</div>
	</div>
	<div id='wars' class='menuitem'>
		<span onClick="MenuItemAction('wars')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='wars_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='wars_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/images/icon-wars.gif') ?>);'></div>
					<div id='wars_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/images/label-wars.gif') ?>);'></div>
					<div id='wars_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='wars_Submenu' class='Submenu'>
			<a href='topguilds.php'>
				<div id='submenu_topguilds' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_guilds' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_guilds' class='SubmenuitemLabel'><font color="red"><?= t('tibiacom.menu.top_guilds') ?></font>&nbsp;<img src="<?= theme_asset('images/global/images/green-ico.gif') ?>"></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='guildwar.php'>
				<div id='submenu_guildwar' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_guilds' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_guilds' class='SubmenuitemLabel'><?= t('tibiacom.menu.guild_wars') ?>&nbsp;<img src="<?= theme_asset('images/global/images/green-ico.gif') ?>"></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('wars'); ?>
		</div>
	</div>
	<div id='library' class='menuitem'>
		<span onClick="MenuItemAction('library')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='library_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='library_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/images/Spellbook_of_Ancient_Arcana.gif') ?>);'></div>
					<div id='library_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-library.gif') ?>);'></div>
					<div id='library_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='library_Submenu' class='Submenu'>
			<a href='serverinfo.php'>
				<div id='submenu_worldquests' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_worldquests' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_worldquests' class='SubmenuitemLabel'><?= t('nav.serverinfo') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='gallery.php'>
				<div id='submenu_worldquests' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_worldquests' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_worldquests' class='SubmenuitemLabel'><?= t('tibiacom.menu.image_gallery') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='page.php?p=raids'>
				<div id='submenu_worldquests' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_worldquests' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_worldquests' class='SubmenuitemLabel'><font color="yellow"><?= t('tibiacom.menu.raids') ?></font></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='page.php?p=maps'>
				<div id='submenu_worldquests' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_worldquests' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_worldquests' class='SubmenuitemLabel'><?= t('tibiacom.menu.maps') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('library'); ?>
		</div>
	</div>
	<div id='shops' class='menuitem'>
		<span onClick="MenuItemAction('shops')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='shops_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='shops_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/images/Tibia_Coins.gif') ?>);'></div>
					<div id='shops_Label' class='Label' style='background-image:url(<?= theme_asset('images/global/menu/label-shops.gif') ?>);'></div>
					<div id='shops_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='shops_Submenu' class='Submenu'>
			<a href='buypoints.php'>
				<div id='submenu_cafepress' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_cafepress' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_cafepress' class='SubmenuitemLabel'><font color="yellow"><?= t('tibiacom.menu.buy_points') ?></font></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<a href='shop.php'>
				<div id='submenu_cafepress' class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
					<div style='background-color:#131b33;'>
					<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
					<div id='ActiveSubmenuItemIcon_cafepress2' class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
					<div id='ActiveSubmenuItemLabel_cafepress2' class='SubmenuitemLabel'><?= t('nav.shop') ?></div>
					<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				</div></div>
			</a>
			<?php tibiacomv1_managed_menu_links('shops'); ?>
		</div>
	</div>
	<?php endif; ?>
	<div id='MenuBottom' style='background-image:url(<?= theme_asset('images/global/general/box-bottom.gif') ?>);'></div>
</div>
</div>
