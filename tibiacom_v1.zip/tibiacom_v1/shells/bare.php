<?php
/**
 * TibiaCOM v1 - bare shell.
 *
 * Same chrome as shells/default.php, but WITHOUT the content box. The page is
 * responsible for opening its own box, which is what the original theme's
 * pages using layout/overall/header.php did.
 *
 * Ask for it from the first line of a view or page:
 *   <?php theme_shell('bare'); ?>
 *
 * The footer always closes the box, so a page on this shell must open one.
 */

theme_include('parts/head.php');
?>

<?php theme_content(); ?>

<?php theme_include('parts/foot.php'); ?>
