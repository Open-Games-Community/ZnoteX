<?php
/**
 * TibiaCOM v1 - default shell.
 *
 * The original theme had 17 near-identical header files that differed only by
 * the headline graphic above the content box. They are one shell here, with
 * the graphic chosen from the table below.
 *
 * To give a page its own headline, add a line to $headlines. The key is the
 * page name without .php, or "page_<name>" for a page this theme adds.
 * A page with no entry gets no headline, just the box.
 *
 * A page that draws its own content box uses shells/bare.php instead:
 *   <?php theme_shell('bare'); ?>
 */

function tibiacomv1_managed_extra_items(): array {
	$known = array(
		'latest news', 'ticket support', 'changelog', 'account management', 'create account',
		'download client', 'premium features', 'server rules', 'lost account?', 'characters',
		'chars auction', 'highscores', 'experience history', 'latest deaths', 'kills statistics',
		'houses', 'support list', 'guilds', 'item market', 'forum boards', 'discussion',
		'feedback', 'top guilds', 'guild wars', 'server info', 'image gallery', 'raids',
		'maps', 'buy points', 'shop',
	);

	$items = array();
	foreach (theme_menu_items('main') as $item) {
		if (in_array(strtolower(trim($item['label'])), $known, true)) {
			continue;
		}
		$items[] = $item;
	}

	return $items;
}

function tibiacomv1_managed_menu(): void {
	$items = tibiacomv1_managed_extra_items();
	if (!$items) {
		return;
	}
	?>
	<div id='managed' class='menuitem'>
		<span onClick="MenuItemAction('managed')">
			<div class='MenuButton' style='background-image:url(<?= theme_asset('images/global/menu/button-background.gif') ?>);'>
				<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'>
					<div class='Button' style='background-image:url(<?= theme_asset('images/global/menu/button-background-over.gif') ?>);'></div>
					<span id='managed_Lights' class='Lights'>
						<div class='light_lu' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ld' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
						<div class='light_ru' style='background-image:url(<?= theme_asset('images/global/menu/green-light.gif') ?>);'></div>
					</span>
					<div id='managed_Icon' class='Icon' style='background-image:url(<?= theme_asset('images/global/menu/icon-news.gif') ?>);'></div>
					<div id='managed_Label' class='Label' style='color:#f8d77b;font:bold 12px Verdana,Arial;text-shadow:1px 1px #000;padding-top:4px;'>Managed</div>
					<div id='managed_Extend' class='Extend' style='background-image:url(<?= theme_asset('images/global/general/plus.gif') ?>);'></div>
				</div>
			</div>
		</span>
		<div id='managed_Submenu' class='Submenu'>
			<?php foreach ($items as $item): ?>
				<?php tibiacomv1_managed_link($item); ?>
				<?php foreach ($item['children'] as $child): ?>
					<?php tibiacomv1_managed_link($child); ?>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
}

function tibiacomv1_managed_link(array $item): void {
	?>
	<a href='<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>'<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
		<div class='Submenuitem' onMouseOver='MouseOverSubmenuItem(this)' onMouseOut='MouseOutSubmenuItem(this)'>
			<div style='background-color:#131b33;'>
				<div class='LeftChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
				<div class='ActiveSubmenuItemIcon' style='background-image:url(<?= theme_asset('images/global/menu/icon-activesubmenu.gif') ?>);'></div>
				<div class='SubmenuitemLabel'><?= htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') ?></div>
				<div class='RightChain' style='background-image:url(<?= theme_asset('images/global/general/chain.gif') ?>);'></div>
			</div>
		</div>
	</a>
	<?php
}

$headlines = array(
	// Account
	'myaccount'       => 'accountmanagement.png',
	'settings'        => 'accountmanagement.png',
	'helpdesk'        => 'accountmanagement.png',
	'register'        => 'createaccount.png',

	// Community
	'forum'           => 'forum.png',
	'forum_search'    => 'forum.png',
	'guilds'          => 'guilds.png',
	'guildwar'        => 'guilds.png',
	'topguilds'       => 'guilds.png',
	'onlinelist'      => 'whoisonline.png',
	'toponline'       => 'whoisonline.png',
	'killers'         => 'kills.png',
	'gallery'         => 'screenshots.gif',
	'support'         => 'team.png',

	// Server
	'houses'          => 'houses.png',
	'house'           => 'houses.png',
	'serverinfo'      => 'serverinfo.png',
	'raids'           => 'raids.png',
	'premmyfeature'   => 'premiumfeatures.gif',
	'shop'            => 'donate.png',
);

$pageKey = isset($page_filename) ? (string)$page_filename : '';

// Pages this theme adds (page.php?p=carlin) are the map/library pages.
if (str_starts_with($pageKey, 'page_')) {
	$shellHeadline = 'headline-maps.gif';
} else {
	$shellHeadline = $headlines[$pageKey] ?? '';
}

theme_include('parts/head.php');
theme_include('parts/box-open.php', array('shellHeadline' => $shellHeadline));
?>

<?php theme_content(); ?>

<?php theme_include('parts/foot.php'); ?>
