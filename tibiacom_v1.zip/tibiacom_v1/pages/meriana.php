<?php
/**
 * Title: Meriana
 *
 * Imported from the TibiaCOM layout. Reachable at page.php?p=meriana
 */
?>





<div class="BoxContent" style="background-image:url(https://static.tibia.com/images/global/content/scroll.gif);">
<center><h3>Meriana</h3></center><center><img border="2" src="https://static.tibia.com/images/library/map_meriana.jpg"></center><br>The small island Meriana is located in the north of Vandura. Some of the natives have founded a small hideout here to escape from the oppression of the Thaians. The nature of the island offers perfect conditions for this rebel hideout. The southern coast is almost completely coated by huge mountains, creating a rather hostile and uninhabited impression. However, behind the mountains, the spectator is offered a surprising view. Palm trees and exotic plants offer shelter and food for the rebels. </div>
