<?php
/**
 * Title: Maps
 *
 * Imported from the TibiaCOM layout. Reachable at page.php?p=maps
 */
?>



The world of Tibia is separated in two continents and several islands. Please click on a link or on a part of the map below to learn more about the different areas.<BR><BR>


	
<h2>Main Continent:</h2><br>
<li>Cities:
<A HREF="abdendriel.php">Ab'Dendriel</A>,
<A HREF="carlin.php">Carlin</A>,
<A HREF="kazordoon.php">Kazordoon</A>,
<A HREF="thais.php">Thais</A> and
<A HREF="venore.php">Venore</A>
</li> <br>
<li>Northern Wilderness:
<A HREF="femorhills.php">Femor Hills</A>,
<A HREF="fieldsofglory.php">Fields of Glory</A>,
<A HREF="ghostlands.php">Ghostlands</A> and
<A HREF="uldereksrock.php">Ulderek's Rock</A>
</li> 
<br><li>Southern Wilderness:
<A HREF="greenclawswamp.php">Green Claw Swamp</A>,
<A HREF="jakundafdesert.php">Jakundaf Desert</A>,
<A HREF="mountsternum.php">Mount Sternum</A>,
<A HREF="outlawcamp.php">Outlaw Camp</A>,
<A HREF="plainsofhavoc.php">Plains of Havoc</A> and
<A HREF="trollscave.php">Trolls' Cave</A>
</li> 

<br><B>Darama:</B>
<br><li>Cities:
<A HREF="ankrahmun.php">Ankrahmun</A>,
<A HREF="darashia.php">Darashia</A> and
<A HREF="porthope.php">Port Hope</A>
</li> 
<br><li>Wilderness:
<A HREF="banuta.php">Banuta</A>,
<A HREF="chor.php">Chor</A>,
<A HREF="khazeel.php">Kha'zeel</A> and
<A HREF="trapwood.php">Trapwood</A>
</li> 

<br><B>Shattered Isles:</B></li> 
<br><li>City:
<A HREF="libertybay.php">Liberty Bay</A>
</li> 
<br><li>Isles:
<A HREF="bounac.php">Bounac</A>,
<A HREF="forbiddenislands.php">Forbidden Islands</A>,
<A HREF="lagunaislands.php">Laguna Islands</A>,
<A HREF="meriana.php">Meriana</A>,
<A HREF="nargor.php">Nargor</A> and
<A HREF="treasureisland.php">Treasure Island</A>
</li> 

<br><B>Ice Islands:</B>
<br><li>City:
<A HREF="svargrond.php">Svargrond</A>
</li> 
<br><li>Isles:
<A HREF="barbariansettlements.php">Barbarian Settlements</A>,
<A HREF="grimlund.php">Grimlund</A>,
<A HREF="helheim.php">Helheim</A>,
<A HREF="nibelor.php">Nibelor</A>,
<A HREF="okolnir.php">Okolnir</A>,
<A HREF="southerniceislands.php">Southern Ice Islands</A> and
<A HREF="tyrsung.php">Tyrsung</A>
</li> 
<br><B>Zao:</B>
<br><li>
<A HREF="chazorai.php">Chazorai</A>,
<A HREF="dragonblazepeaks.php">Dragonblaze Peaks</A>,
<A HREF="farmine.php">Farmine</A>,
<A HREF="muggyplains.php">Muggy Plains</A>,
<A HREF="northernzao.php">Northern Zao</A>,
<A HREF="razachai.php">Razachai</A>,
<A HREF="vengoth.php">Vengoth</A> and
<A HREF="zzaion.php">Zzaion</A>
</li> 
<br><B>Quirefang:</B>
<li>
<A HREF="fiehonja.php">Fiehonja</A>,
<A HREF="graybeach.php">Gray Beach</A> and
<A HREF="thehive.php">The Hive</A>
</li> 
<br><B>Oramond:</B></li> 
<br><li>Cities:
<A HREF="rathleton.php">Rathleton</A> and
<A HREF="issavi.php">Issavi</A>
</li> 
<br><li>Islands:
<A HREF="oramond.php">Oramond</A>,
<A HREF="kilmaresh.php">Kilmaresh</A> and
<A HREF="furiouscrater.php">Furious Crater</A>
</li> 
<br><li>Wilderness:
<A HREF="krailos.php">Krailos</A>
</li> 
<br><b>Islands:</B></li> 
<br><li>
<A HREF="cormaya.php">Cormaya</A>,
<A HREF="dawnport.php">Dawnport</A>,
<A HREF="draconia.php">Draconia</A>,
<A HREF="edron.php">Edron</A>,
<A HREF="fenrock.php">Fenrock</A>,
<A HREF="feyrist.php">Feyrist</A>,
<A HREF="fibula.php">Fibula</A>,
<A HREF="islandofdestiny.php">Island of Destiny</A>,
<A HREF="isleofevil.php">Isle of Evil</A>,
<A HREF="isleofthekings.php">Isle of the Kings</A>,
<A HREF="meluna.php">Meluna</A>,
<A HREF="mistrock.php">Mistrock</A>,
<A HREF="rascacoon.php">Rascacoon</A>,
<A HREF="rookgaard.php">Rookgaard</A>,
<A HREF="roshamuul.php">Roshamuul</A>,
<A HREF="templeoflight.php">Temple of Light</A>,
<A HREF="travora.php">Travora</A>,
<A HREF="wreckoning.php">Wreckoning</A> and
<A HREF="yalahar.php">Yalahar</A>

	

<BR><BR>
<CENTER>
<MAP NAME="map_small">
<area shape=rect coords="48,408,143,493" href="page.php?p=rookgaard">
<area shape=rect coords="102,502,160,553" href="page.php?p=fibula">
<area shape=rect coords="162,430,221,488" href="page.php?p=thais">
<area shape=rect coords="221,463,255,497" href="page.php?p=trollscave">
<area shape=rect coords="216,399,260,430" href="page.php?p=mountsternum">
<area shape=rect coords="260,407,311,444" href="page.php?p=jakundafdesert">
<area shape=rect coords="272,444,312,471" href="page.php?p=outlawcamp">
<area shape=rect coords="317,464,371,515" href="page.php?p=plainsofhavoc">
<area shape=rect coords="300,363,358,400" href="page.php?p=greenclawswamp">
<area shape=rect coords="253,343,300,387" href="page.php?p=kazordoon">
<area shape=rect coords="240,303,284,343" href="page.php?p=femorhills">
<area shape=rect coords="356,290,413,337" href="page.php?p=uldereksrock">
<area shape=rect coords="262,240,326,294" href="page.php?p=abdendriel">
<area shape=rect coords="181,243,248,298" href="page.php?p=fieldsofglory">
<area shape=rect coords="164,298,215,342" href="page.php?p=carlin">
<area shape=rect coords="427,251,535,369" href="page.php?p=edron">
<area shape=rect coords="359,383,420,447" href="page.php?p=venore">
<area shape=rect coords="20,553,134,644" href="page.php?p=forbiddenislands">
<area shape=rect coords="25,643,103,727" href="page.php?p=nargor">
<area shape=rect coords="155,556,215,612" href="page.php?p=meriana">
<area shape=rect coords="178,675,262,735" href="page.php?p=lagunaislands">
<area shape=rect coords="97,686,148,731" href="page.php?p=treasureisland">
<area shape=rect coords="152,641,198,695" href="page.php?p=libertybay">
<area shape=rect coords="122,307,165,349" href="page.php?p=ghostlands">
<area shape=rect coords="417,629,501,697" href="page.php?p=ankrahmun">
<area shape=rect coords="466,513,516,556" href="page.php?p=darashia">
<area shape=rect coords="245,626,303,667" href="page.php?p=porthope">
<area shape=rect coords="322,544,366,591" href="page.php?p=banuta">
<area shape=rect coords="365,660,414,693" href="page.php?p=chor">
<area shape=rect coords="391,568,448,638" href="page.php?p=khazeel">
<area shape=rect coords="269,679,322,724" href="page.php?p=trapwood">
<area shape=rect coords="134,79,194,118" href="page.php?p=svargrond">
<area shape=rect coords="203,64,244,94" href="page.php?p=grimlund">
<area shape=rect coords="215,91,250,126" href="page.php?p=helheim">
<area shape=rect coords="36,113,126,203" href="page.php?p=barbariansettlements">
<area shape=rect coords="173,50,209,81" href="page.php?p=nibelor">
<area shape=rect coords="117,154,179,210" href="page.php?p=okolnir">
<area shape=rect coords="173,97,229,175" href="page.php?p=tyrsung">
<area shape=rect coords="87,370,118,403" href="page.php?p=islandofdestiny">
<area shape=rect coords="487,363,541,414" href="page.php?p=cormaya">
<area shape=rect coords="238,131,268,163" href="page.php?p=fenrock">
<area shape=rect coords="236,172,296,221" href="page.php?p=mistrock">
<area shape=rect coords="358,199,400,245" href="page.php?p=vengoth">
<area shape=rect coords="274,45,406,180" href="page.php?p=yalahar">
<area shape=rect coords="83,520,109,549" href="page.php?p=meluna">
<area shape=rect coords="85,504,97,516" href="page.php?p=travora">
<area shape=rect coords="45,222,143,310" href="page.php?p=southerniceislands">
<area shape=rect coords="419,45,454,74" href="page.php?p=chazorai">
<area shape=rect coords="460,75,536,135" href="page.php?p=muggyplains">
<area shape=rect coords="446,129,544,178" href="page.php?p=dragonblazepeaks">
<area shape=rect coords="495,215,533,262" href="page.php?p=zzaion">
<area shape=rect coords="403,217,428,241" href="page.php?p=farmine">
<area shape=rect coords="121,356,140,376" href="page.php?p=isleofthekings">
<area shape=rect coords="330,232,353,260" href="page.php?p=draconia">
<area shape=rect coords="292,188,335,222" href="page.php?p=isleofevil">
<area shape=rect coords="39,377,81,422" href="page.php?p=templeoflight">
<area shape=rect coords="448,50,524,111" href="page.php?p=northernzao">
<area shape=rect coords="404,69,458,147" href="page.php?p=razachai">
<area shape=rect coords="559,101,621,175" href="page.php?p=thehive">
<area shape=rect coords="547,97,627,177" href="page.php?p=fiehonja">
<area shape=rect coords="552,145,589,173" href="page.php?p=graybeach">
<area shape=rect coords="569,472,664,585" href="page.php?p=roshamuul">
<area shape=rect coords="557,302,667,415" href="page.php?p=oramond">
<area shape=rect coords="589,345,638,388" href="page.php?p=rathleton">
<area shape=rect coords="72,333,113,371" href="page.php?p=dawnport">
<area shape=rect coords="570,230,671,318" href="page.php?p=krailos">
<area shape=rect coords="532,433,618,500" href="page.php?p=feyrist">
<area shape=rect coords="647,191,747,312" href="page.php?p=kilmaresh">
<area shape=rect coords="694,201,743,242" href="page.php?p=issavi">
<area shape=rect coords="671,316,726,373" href="page.php?p=furiouscrater">
<area shape=rect coords="182,534,237,573" href="page.php?p=bounac">
<area shape=rect coords="686,102,732,145" href="page.php?p=wreckoning">
<area shape=rect coords="624,133,692,187" href="page.php?p=rascacoon">
</MAP>
<IMG BORDER=0 SRC="https://static.tibia.com/images/library/map_small.jpg" USEMAP="#map_small" WIDTH=768 HEIGHT=762><BR><IMG SRC="https://static.tibia.com/images/global/general/blank.gif" WIDTH=5 HEIGHT=1 BORDER=0>
<BR>[<A HREF="https://static.tibia.com/images/library/map_big.jpg">Download high resolution map (5,57 MB)</A>]
</CENTER>
