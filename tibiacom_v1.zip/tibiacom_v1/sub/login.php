<center><h2><?= t('widget.login.title') ?></h2>
<div class="inner">
	<form action="login.php" method="post">
	<ul id="login">
		<div>
			<?= t('widget.login.username') ?> <br>
			<input type="text" name="username">
		</div>
		<div>
			<?= t('widget.login.password') ?> <br>
			<input type="password" name="password">
		</div>
		<div>
			<input type="submit" value="<?= htmlspecialchars(t('widget.login.submit'), ENT_QUOTES, 'UTF-8') ?>">
		</div>
		<?php
			/* Form file */
			Token::create();
		?><br></br>
	<div><a href="register.php"><img src="<?= theme_asset('images/global/buttons/newacc1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/newacc2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/newacc1.gif') ?>'" 
		 ></img></a></div><br>
	<font size="1">- <?= t('widget.login.lost') ?></font>
	</ul>
	</form>
</div></center