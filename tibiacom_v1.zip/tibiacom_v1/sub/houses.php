

<form action="houses.php" method="post">
	<?= t('common.select_town') ?><br>
	<select name="selected">
	<?php
	foreach ($config['towns'] as $id => $name) echo '<option value="'. $id .'">'. $name .'</option>';
	?>
	</select> 
	<?php
		/* Form file */
		Token::create();
	?>
	<input type="submit" value="<?= htmlspecialchars(t('widget.houses.submit'), ENT_QUOTES, 'UTF-8') ?>">
</form>