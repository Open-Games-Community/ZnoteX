<div class="postHolder">
	<div class="well">
		<div class="header">
			<?= t('widget.search.title') ?>
		</div>
		<div class="body">
			<form type="submit" action="characterprofile.php" method="get">
				<input type="text" name="name" class="search">
				<input type="submit" name="submitName" value="<?= htmlspecialchars(t('common.search'), ENT_QUOTES, 'UTF-8') ?>">
			</form>
		</div>
	</div>
</div>