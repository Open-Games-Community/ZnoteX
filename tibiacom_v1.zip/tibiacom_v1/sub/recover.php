<h2><?= t('recovery.lost_account') ?></h2>
<div class="inner">
	<font size="4">- <?= t('widget.login.lost') ?></font>
	</ul>
	</form>
</div>