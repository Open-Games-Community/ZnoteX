<div class="inner">
	<div class="SmallBox">
				<div class="MessageContainer">
					<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
					<div class="BoxFrameEdgeLeftTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="BoxFrameEdgeRightTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="Message">
						<div class="BoxFrameVerticalLeft" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
						<div class="BoxFrameVerticalRight" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
<center><h2><?= t('widget.account.welcome', ['name' => htmlspecialchars($user_data['name'], ENT_QUOTES, 'UTF-8')]) ?></h2></center>

</div><div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
						<div class="BoxFrameEdgeRightBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
						<div class="BoxFrameEdgeLeftBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
				</div></div>
<br>
<div class="inner">
	<div class="SmallBox">
				<div class="MessageContainer">
					<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
					<div class="BoxFrameEdgeLeftTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="BoxFrameEdgeRightTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="Message">
						<div class="BoxFrameVerticalLeft" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
						<div class="BoxFrameVerticalRight" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
	<ul>
		<?php
		// If admin
		if (is_admin($user_data)) {

			// Feedback threads with no staff reply yet.
			$new = 0;
			$cache = new Cache('engine/cache/asideFeedbackCount');
			if ($cache->hasExpired()) {
				$threads = db()->fetchAll("SELECT `id` FROM `znote_forum_threads` WHERE `forum_id`='4' AND `closed`='0';");
				if (is_array($threads)) {
					$staffIds = array();
					$staffs = db()->fetchAll("SELECT `id` FROM `players` WHERE `group_id` > '1';");
					if (is_array($staffs)) {
						foreach ($staffs as $staff) { $staffIds[(int)$staff['id']] = true; }
					}
					foreach ($threads as $thread) {
						$answered = false;
						$posts = db()->fetchAll("SELECT `player_id` FROM `znote_forum_posts` WHERE `thread_id`=?;", [(int)$thread['id']]);
						if (is_array($posts)) {
							foreach ($posts as $post) {
								if (isset($staffIds[(int)$post['player_id']])) { $answered = true; break; }
							}
						}
						if (!$answered) { $new++; }
					}
				}
				$cache->setContent($new);
				$cache->save();
			} else {
				$new = (int)$cache->load();
			}
		?>
		<center>
		<div><a href="admin/index.php"><b><?= t('widget.admin.panel') ?></b></a></div>
		<div><a href="forum.php?cat=4"><?= t('widget.admin.feedback', ['count' => $new]) ?></a></div>
		</center>
		<br>
		<?php
		}
		// end if admin
		?><center>
		<div><a href="myaccount.php"><img src="<?= theme_asset('images/global/buttons/myacc1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/myacc2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/myacc1.gif') ?>'" 
		 ></img></a></div><br>
		<div><a href="createcharacter.php"><img src="<?= theme_asset('images/global/buttons/char1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/char2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/char1.gif') ?>'" 
		 ></img></a></div><br>
		<div><a href="changepassword.php"><img src="<?= theme_asset('images/global/buttons/changepass1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/changepass2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/changepass1.gif') ?>'" 
		 ></img></a></div><br>
		<div><a href="settings.php"><img src="<?= theme_asset('images/global/buttons/settings1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/settings2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/settings1.gif') ?>'" 
		 ></img></a></div><br>

		<div><a href="logout.php"><img src="<?= theme_asset('images/global/buttons/logout1.gif') ?>" 
  		  onMouseOver="this.src='<?= theme_asset('images/global/buttons/logout2.gif') ?>'" 
  		  onMouseOut="this.src='<?= theme_asset('images/global/buttons/logout1.gif') ?>'" 
		 ></img></a></div></center>
	</ul>
	</div>
						<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
						<div class="BoxFrameEdgeRightBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
						<div class="BoxFrameEdgeLeftBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					</div>
				</div>

</div>
