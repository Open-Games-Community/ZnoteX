<h1><?= t('widget.search.title') ?></h1>
<div class="inner">
	<form type="submit" action="characterprofile.php" method="get">
		<input type="text" name="name" class="search">
		<input type="submit" name="submitName" value="<?= htmlspecialchars(t('common.search'), ENT_QUOTES, 'UTF-8') ?>">
	</form>
</div>