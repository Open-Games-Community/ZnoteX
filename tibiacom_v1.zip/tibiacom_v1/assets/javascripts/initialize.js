/** ------------------------------------------------------------------
 * JavaScripts which are loaded by the OnLoad function of the body tag
 * -------------------------------------------------------------------
 */

// executes JavaScripts for the loginbox and the menu
function InitializePage() {
  LoadLoginBox();
  LoadMenu();
}

// functions for mouse-over and click events of non-content-buttons
function MouseOverBigButton(source)
{
  //source.firstChild.style.visibility = "visible";
}
function MouseOutBigButton(source)
{
  //source.firstChild.style.visibility = "hidden";
}



/** ---------------------
 * Loginbox functionality
 * ----------------------
 */

// initialisation of the loginbox status by the value of the variable 'loginStatus' which is provided to the HTML-document by PHP in the file 'header.inc'
function LoadLoginBox()
{
  if(loginStatus == "false") {
    document.getElementById('LoginstatusText_1').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-you-are-not-logged-in.gif')";
    document.getElementById('ButtonText').style.backgroundImage = "url('" + IMAGES + "/buttons/_sbutton_login.gif')";
    document.getElementById('LoginstatusText_2').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-create-account.gif')";
    document.getElementById('LoginstatusText_2_1').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-create-account.gif')";
    document.getElementById('LoginstatusText_2_2').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-create-account-over.gif')";
  } else {
    document.getElementById('LoginstatusText_1').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-welcome.gif')";
    document.getElementById('ButtonText').style.backgroundImage = "url('" + IMAGES + "/buttons/_sbutton_myaccount.gif')";
    document.getElementById('LoginstatusText_2').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-logout.gif')";
    document.getElementById('LoginstatusText_2_1').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-logout.gif')";
    document.getElementById('LoginstatusText_2_2').style.backgroundImage = "url('" + IMAGES + "/loginbox/loginbox-font-logout-over.gif')";
  }
}

// mouse-over and click events of the loginbox
function MouseOverLoginBoxText(source)
{
  //source.lastChild.style.visibility = "visible";
  //source.firstChild.style.visibility = "hidden";
}
function MouseOutLoginBoxText(source)
{
  //source.firstChild.style.visibility = "visible";
  //source.lastChild.style.visibility = "hidden";
}
function LoginButtonAction()
{
  if(loginStatus == "false") {
    window.location = LINK_ACCOUNT + "/?subtopic=accountmanagement";
  } else {
    window.location = LINK_ACCOUNT + "/?subtopic=accountmanagement";
  }
}
function LoginstatusTextAction(source) {
  if(loginStatus == "false") {
    window.location = LINK_ACCOUNT + "/?subtopic=createaccount";
  } else {
    window.location = LINK_ACCOUNT + "/?subtopic=accountmanagement&action=logout";
  }
}

/** ------------------
 *  Menu functionality
 *  ------------------
 */

var menu = new Array();
menu[0] = new Object();
var unloadhelper = false;
var MENU_STORAGE_KEY = "tibiacom_v1_menu_state_v2";

function GetMenuItems()
{
  var items = [];
  var nodes = document.getElementsByClassName("menuitem");

  for(var i = 0; i < nodes.length; i++) {
    var id = nodes[i].id;
    if(id && document.getElementById(id + "_Submenu")) {
      items.push(id);
    }
  }

  return items;
}

// load the menu and restore the visitor's own open/closed state.
// On the first visit every category starts closed.
function LoadMenu()
{
  var activeLabel = document.getElementById("submenu_" + activeSubmenuItem);
  var activeIcon = document.getElementById("ActiveSubmenuItemIcon_" + activeSubmenuItem);

  if(activeLabel) {
    activeLabel.style.color = "white";
  }
  if(activeIcon) {
    activeIcon.style.visibility = "visible";
  }

  FillMenuArray();
  InitializeMenu();
}

function SaveMenu()
{
  if(unloadhelper == false) {
    SaveMenuArray();
    unloadhelper = true;
  }
}

// Restore the menu state from localStorage.
// Missing/invalid values deliberately fall back to 0 = closed.
function FillMenuArray()
{
  var stored = {};
  var items = GetMenuItems();

  try {
    stored = JSON.parse(localStorage.getItem(MENU_STORAGE_KEY) || "{}");
  } catch(e) {
    stored = {};
  }

  for(var i = 0; i < items.length; i++) {
    var menuItemName = items[i];

    // First visit: closed.
    // Later visits/page changes: restore exactly what the visitor chose.
    menu[0][menuItemName] =
      (stored[menuItemName] === 1 || stored[menuItemName] === "1") ? 1 : 0;
  }
}

// hide or show the corresponding submenus
function InitializeMenu()
{
  for(var menuItemName in menu[0]) {
    if(!Object.prototype.hasOwnProperty.call(menu[0], menuItemName)) {
      continue;
    }

    var submenu = document.getElementById(menuItemName + "_Submenu");
    var lights = document.getElementById(menuItemName + "_Lights");
    var extend = document.getElementById(menuItemName + "_Extend");

    if(!submenu) {
      continue;
    }

    if(menu[0][menuItemName] == 0) {
      submenu.style.visibility = "hidden";
      submenu.style.display = "none";
      if(lights) lights.style.visibility = "visible";
      if(extend) extend.style.backgroundImage = "url(" + IMAGES + "/general/plus.gif)";
    }
    else {
      submenu.style.visibility = "visible";
      submenu.style.display = "block";
      if(lights) lights.style.visibility = "hidden";
      if(extend) extend.style.backgroundImage = "url(" + IMAGES + "/general/minus.gif)";
    }
  }
}

// Save the menu immediately so the state survives page changes.
function SaveMenuArray()
{
  try {
    localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(menu[0]));
  } catch(e) {
    // localStorage can be unavailable in very restrictive browser modes.
  }
}

// onClick open or close submenus
function MenuItemAction(sourceId)
{
  if(menu[0][sourceId] == 1) {
    CloseMenuItem(sourceId);
  }
  else {
    OpenMenuItem(sourceId);
  }
}
function OpenMenuItem(sourceId)
{
  menu[0][sourceId] = 1;
  var submenu = document.getElementById(sourceId+"_Submenu");
  var lights = document.getElementById(sourceId+"_Lights");
  var extend = document.getElementById(sourceId+"_Extend");
  if(submenu) { submenu.style.visibility = "visible"; submenu.style.display = "block"; }
  if(lights) lights.style.visibility = "hidden";
  if(extend) extend.style.backgroundImage = "url(" + IMAGES + "/general/minus.gif)";
  SaveMenuArray();
}
function CloseMenuItem(sourceId)
{
  menu[0][sourceId] = 0;
  var submenu = document.getElementById(sourceId+"_Submenu");
  var lights = document.getElementById(sourceId+"_Lights");
  var extend = document.getElementById(sourceId+"_Extend");
  if(submenu) { submenu.style.visibility = "hidden"; submenu.style.display = "none"; }
  if(lights) lights.style.visibility = "visible";
  if(extend) extend.style.backgroundImage = "url(" + IMAGES + "/general/plus.gif)";
  SaveMenuArray();
}

// mouse-over effects of menubuttons and submenuitems
function MouseOverMenuItem(source)
{
  source.firstChild.style.visibility = "visible";
}
function MouseOutMenuItem(source)
{
  source.firstChild.style.visibility = "hidden";
}
function MouseOverSubmenuItem(source)
{
  source.style.backgroundColor = "#14433F";
}
function MouseOutSubmenuItem(source)
{
  source.style.backgroundColor = "#0D2E2B";
}


/** -------------------------
 * functions related to forms 
 * --------------------------
 */

// set cursor focus in form (g_FormName) to field (g_FieldName)
function SetFormFocus()
{
  if (g_FormName.length > 0 && g_FieldName.length > 0 ) {
    document.forms[g_FormName].elements[g_FieldName].focus();
  }
}


// toggle masked texts with readable texts
function ToggleMaskedText(a_TextFieldID)
{
  m_DisplayedText = document.getElementById('Display' + a_TextFieldID).innerHTML;
  m_MaskedText = document.getElementById('Masked' + a_TextFieldID).innerHTML;
  m_ReadableText = document.getElementById('Readable' + a_TextFieldID).innerHTML;
  if (m_DisplayedText == m_MaskedText) {
    document.getElementById('Display' + a_TextFieldID).innerHTML = document.getElementById('Readable' + a_TextFieldID).innerHTML;
    document.getElementById('Button' + a_TextFieldID).src = IMAGES + '/general/hide.gif';
  } else {
    document.getElementById('Display' + a_TextFieldID).innerHTML = document.getElementById('Masked' + a_TextFieldID).innerHTML;
    document.getElementById('Button' + a_TextFieldID).src = IMAGES + '/general/show.gif';
  }
}

// Restore the menu state as soon as the DOM is ready, not on window.onload
// (which waits for every image). The CSS keeps submenus closed until this runs,
// so the open categories appear right away instead of every category flashing
// open first. The body's onLoad still calls LoadMenu() again, which is harmless.
if (document.addEventListener) {
  document.addEventListener("DOMContentLoaded", function () {
    try { LoadMenu(); } catch (e) {}
  });
}