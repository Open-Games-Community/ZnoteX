<div class="sidebar">
	<h2><?= t('widget.highscores.search_title') ?></h2>
	<div class="inner">
		<form action="highscores.php" method="post">
		
			<?= t('widget.highscores.select_skill') ?><br>
			<select name="selected">
			<option value="7"><?= t('skill.experience') ?></option>
			<option value="5"><?= t('skill.shielding') ?></option>
			<option value="3"><?= t('skill.axe') ?></option>
			<option value="2"><?= t('skill.sword') ?></option>
			<option value="1"><?= t('skill.club') ?></option>
			<option value="4"><?= t('skill.distance') ?></option>
			<option value="0"><?= t('skill.fist') ?></option>
			<option value="6"><?= t('skill.fishing') ?></option>
			<option value="8"><?= t('skill.magic') ?></option>
			</select> 
			<?php
				/* Form file */
				Token::create();
			?>
			<input type="submit" value="<?= htmlspecialchars(t('widget.highscores.submit'), ENT_QUOTES, 'UTF-8') ?>">
		</form>
	</div>
</div>