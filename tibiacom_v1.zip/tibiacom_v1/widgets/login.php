<div class="sidebar">
	<h2><?= t('widget.login.title') ?></h2>
	<div class="inner">
		<form action="login.php" method="post">
		<ul id="login">
			<li>
				<?= t('widget.login.username') ?> <br>
				<input type="text" name="username">
			</li>
			<li>
				<?= t('widget.login.password') ?> <br>
				<input type="password" name="password">
			</li>
			<li>
				<input type="submit" value="<?= htmlspecialchars(t('widget.login.submit'), ENT_QUOTES, 'UTF-8') ?>">
			</li>
			<?php
				/* Form file */
				Token::create();
			?>
		<center>	<h3><a href="register.php"><?= t('widget.login.new_account') ?></a></h3>
		<font size="1">- <?= t('widget.login.lost') ?></font></center>
		</ul>
		</form>
	</div>
</div>