<div class="sidebar">
	<h2>Welcome, <?php echo $user_data['name']; ?>.</h2>
	<div class="inner">
		<ul>
			<?php
		// If admin
		if (is_admin($user_data)) {

			// Feedback threads with no staff reply yet.
			$new = 0;
			$cache = new Cache('engine/cache/asideFeedbackCount');
			if ($cache->hasExpired()) {
				$threads = mysql_select_multi("SELECT `id` FROM `znote_forum_threads` WHERE `forum_id`='4' AND `closed`='0';");
				if (is_array($threads)) {
					$staffIds = array();
					$staffs = mysql_select_multi("SELECT `id` FROM `players` WHERE `group_id` > '1';");
					if (is_array($staffs)) {
						foreach ($staffs as $staff) { $staffIds[(int)$staff['id']] = true; }
					}
					foreach ($threads as $thread) {
						$answered = false;
						$posts = mysql_select_multi("SELECT `player_id` FROM `znote_forum_posts` WHERE `thread_id`='" . (int)$thread['id'] . "';");
						if (is_array($posts)) {
							foreach ($posts as $post) {
								if (isset($staffIds[(int)$post['player_id']])) { $answered = true; break; }
							}
						}
						if (!$answered) { $new++; }
					}
				}
				$cache->setContent($new);
				$cache->save();
			} else {
				$new = (int)$cache->load();
			}
		?>
		<center>
		<div><a href="admin/index.php"><b>Admin Panel</b></a></div>
		<div><a href="forum.php?cat=4">Feedback: [<?php echo $new; ?>] new</a></div>
		</center>
		<br>
		<?php
		}
		// end if admin
		?>
			<li>
				<a href='myaccount.php'>My Account</a>
			</li>
			<li>
				<a href='createcharacter.php'>Create Character</a>
			</li>
			<li>
				<a href='changepassword.php'>Change Password</a>
			</li>
			<li>
				<a href='settings.php'>Settings</a>
			</li>
			<li>
				<a href='logout.php'>Logout</a>
			</li>
		</ul>
	</div>
</div>