<div class="sidebar">
	<h2><?= t('widget.search.title') ?></h2>
	<div class="inner">
		<form type="submit" action="characterprofile.php" method="get">
			<input type="text" name="name" class="search">
		</form>
	</div>
</div>