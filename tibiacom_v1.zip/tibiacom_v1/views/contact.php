<?php
/**
 * contact - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by contact.php in the site root.
 */
theme_shell('bare');
?>


<h1><?= t('contact.title') ?></h1>
<p><?= t('contact.text') ?></p>
