<?php
/**
 * contact - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by contact.php in the site root.
 */
theme_shell('bare');
?>


<h1>Contact</h1>
<p>TODO: Edit the contact details here.</p>
