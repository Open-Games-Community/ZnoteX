<?php
/**
 * downloads - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by downloads.php in the site root.
 */
theme_shell('bare');
?>



<div id="news" class="Box">

									<div class="Corner-tl" style="background-image:url(<?= theme_asset('images/global/content/corner-tl.gif') ?>);"></div>
									<div class="Corner-tr" style="background-image:url(<?= theme_asset('images/global/content/corner-tr.gif') ?>);"></div>
									<div class="Border_1" style="background-image:url(<?= theme_asset('images/global/content/border-1.gif') ?>);"></div>
									<div class="BorderTitleText" style="background-image:url(<?= theme_asset('images/global/content/title-background-green.gif') ?>);"></div>
									<img id="ContentBoxHeadline" class="Title" src="<?= theme_asset('images/global/images/downloads.png') ?>" alt="Contentbox headline" /> 
									<div class="Border_2">
										<div class="Border_3">
											<div class="BoxContent" style="background-image:url(<?= theme_asset('images/global/content/scroll.gif') ?>);">
												<div class="SmallBox">
				<div class="MessageContainer">
					<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
					<div class="BoxFrameEdgeLeftTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="BoxFrameEdgeRightTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="Message">
						<div class="BoxFrameVerticalLeft" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
						<div class="BoxFrameVerticalRight" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>

<center><h1><?= t('downloads.title') ?></h1></center><a href="YOUR_LINK"><center><img src="<?= theme_asset('images/global/images/download_windows.gif') ?>"></center></a><!--YOUR LINK on href="HERE", MEGA/DRIVE/ OR DIRECT LINK -->
<p><?= t('downloads.tibia_intro', ['site' => '<strong>' . htmlspecialchars(theme_title(), ENT_QUOTES, 'UTF-8') . '</strong>']) ?></p>

<p><img src="<?= theme_asset('images/global/images/mega.png') ?>" width="20"> <?= t('downloads.from_mega') ?> <a href="YOUR MEGA LINK"><?= t('common.click_here') ?> </a></p>
<p><img src="<?= theme_asset('images/global/images/googledrive.png') ?>" width="20"> <?= t('downloads.from_drive') ?> <a href="YOUR DRIVE LINK"><?= t('common.click_here') ?> </a></p>
<p> <img src="<?= theme_asset('images/global/images/directlink.png') ?>" width="25"><?= t('downloads.from_direct') ?> <a href="YOUR FILE LINK"><?= t('common.click_here') ?> </a></p> <!-- Create a Folder in www called Files, insert your client in rar file then add on link: "files/tibiaclient.rar" -->

</div>
						<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
						<div class="BoxFrameEdgeRightBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
						<div class="BoxFrameEdgeLeftBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					</div>
				</div>
