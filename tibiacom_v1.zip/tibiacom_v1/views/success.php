<?php
/**
 * success - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by success.php in the site root.
 */
?>

<h1><?= t('success.title') ?></h1>
<?= t('success.go') ?> <script> document.write('<a href="' + document.referrer + '"><?= addslashes(t('success.back')) ?></a>'); </script>
