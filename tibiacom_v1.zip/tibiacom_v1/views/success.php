<?php
/**
 * success - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by success.php in the site root.
 */
?>

<h1>Success!</h1>
Go <script> document.write('<a href="' + document.referrer + '">back</a>'); </script>
