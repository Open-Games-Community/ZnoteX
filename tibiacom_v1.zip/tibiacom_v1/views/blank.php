<?php
/**
 * blank - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by blank.php in the site root.
 */
theme_shell('bare');
?>


<h1>Blank</h1>
<p>This is a blank sample page.</p>
