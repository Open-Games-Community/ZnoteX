<?php
/**
 * blank - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by blank.php in the site root.
 */
theme_shell('bare');
?>


<h1><?= t('blank.title') ?></h1>
<p><?= t('blank.text') ?></p>
