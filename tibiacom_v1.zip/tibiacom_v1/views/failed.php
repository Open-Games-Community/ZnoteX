<?php
/**
 * failed - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by failed.php in the site root.
 */
?>

<h1>Failed!</h1>
<p>Something went wrong. :(</p>
