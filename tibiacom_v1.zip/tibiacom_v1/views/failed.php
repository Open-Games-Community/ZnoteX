<?php
/**
 * failed - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by failed.php in the site root.
 */
?>

<h1><?= t('failed.title') ?></h1>
<p><?= t('failed.text') ?></p>
