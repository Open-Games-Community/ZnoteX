<?php
/**
 * powergamers - imported from the TibiaCOM layout.
 *
 * Uses the variables prepared by powergamers.php in the site root.
 */

if (!$config['powergamers']['enabled']) {
echo t('common.disabled_config');
include 'layout/overall/footer.php';
	exit();
}
?>
<div class="panel">
	<div class="SmallBox">
				<div class="MessageContainer">
					<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
					<div class="BoxFrameEdgeLeftTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="BoxFrameEdgeRightTop" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					<div class="Message">
						<div class="BoxFrameVerticalLeft" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
						<div class="BoxFrameVerticalRight" style="background-image:url(<?= theme_asset('images/global/images/box-frame-vertical.gif') ?>);"></div>
<div class="page-header"><h3><?= t('powergamers.title') ?></h3></div>
	<?php
	$limit = $config['powergamers']['limit'];
	$days = isset($_POST['days']);
	$today = true;
	if ($days) {
		$selected = ($_POST['days']);
		$days = (int) $selected[1];
		$vocation = (int) $selected[0];
		if ($days > 0)
		$today = false;
	} else {
		$znotePlayers = mysql_select_multi('SELECT `a`.`id`, `b`.`player_id`, `a`.`name`, `a`.`vocation`, `a`.`level`, `a`.`group_id`, `a`.`experience`, `b`.`exphist_lastexp`, `b`.`exphist1`, `b`.`exphist2`, `b`.`exphist3`, `b`.`exphist4`, `b`.`exphist5`, `b`.`exphist6`, `b`.`exphist7`,   (`a`.`experience` - `b`.`exphist_lastexp`)  AS `expdiff` FROM `players` `a` JOIN `znote_players` `b` ON `a`.`id` = `b`.`player_id`  WHERE `a`.`group_id` < 2 ORDER BY `expdiff` DESC LIMIT '.$limit);
	}
	$limit = $config['powergamers']['limit'];

	if(!empty($days) && !empty($vocation))
		$znotePlayers = mysql_select_multi('SELECT `a`.`id`, `b`.`player_id`, `a`.`name`, `a`.`vocation`, `a`.`level`, `a`.`group_id`, `a`.`experience`, `b`.`exphist_lastexp`, `b`.`exphist1`, `b`.`exphist2`, `b`.`exphist3`, `b`.`exphist4`, `b`.`exphist5`, `b`.`exphist6`, `b`.`exphist7`, (`a`.`experience` - `b`.`exphist_lastexp`) AS `expdiff` FROM `players` `a` JOIN `znote_players` `b` ON `a`.`id` = `b`.`player_id`  WHERE `a`.`group_id` < 2 AND `a`.`vocation`='. (int)$vocation .' OR `a`.`vocation`='. ((int)$vocation +4) .' ORDER BY `exphist' . (int)$days . '` DESC LIMIT '.$limit);
	elseif(empty($days) && !empty($vocation)) {
		$znotePlayers = mysql_select_multi('SELECT `a`.`id`, `b`.`player_id`, `a`.`name`, `a`.`vocation`, `a`.`level`, `a`.`group_id`, `a`.`experience`, `b`.`exphist_lastexp`, `b`.`exphist1`, `b`.`exphist2`, `b`.`exphist3`, `b`.`exphist4`, `b`.`exphist5`, `b`.`exphist6`, `b`.`exphist7`,   (`a`.`experience` - `b`.`exphist_lastexp`)  AS `expdiff` FROM `players` `a` JOIN `znote_players` `b` ON `a`.`id` = `b`.`player_id`  WHERE `a`.`group_id` < 2 AND `a`.`vocation`='. (int)$vocation .' OR `a`.`vocation`='. ((int)$vocation +4) .' ORDER BY `expdiff` DESC LIMIT '.$limit);
	}elseif(!empty($days) && empty($vocation))
		$znotePlayers = mysql_select_multi('SELECT `a`.`id`, `b`.`player_id`, `a`.`name`, `a`.`vocation`, `a`.`level`, `a`.`group_id`, `a`.`experience`, `b`.`exphist_lastexp`, `b`.`exphist1`, `b`.`exphist2`, `b`.`exphist3`, `b`.`exphist4`, `b`.`exphist5`, `b`.`exphist6`, `b`.`exphist7`, (`a`.`experience` - `b`.`exphist_lastexp`) AS `expdiff` FROM `players` `a` JOIN `znote_players` `b` ON `a`.`id` = `b`.`player_id`  WHERE `a`.`group_id` < 2 ORDER BY `exphist' . (int)$days . '` DESC LIMIT '.$limit);
	else
		$znotePlayers = mysql_select_multi('SELECT `a`.`id`, `b`.`player_id`, `a`.`name`, `a`.`vocation`, `a`.`level`, `a`.`group_id`, `a`.`experience`, `b`.`exphist_lastexp`, `b`.`exphist1`, `b`.`exphist2`, `b`.`exphist3`, `b`.`exphist4`, `b`.`exphist5`, `b`.`exphist6`, `b`.`exphist7`,   (`a`.`experience` - `b`.`exphist_lastexp`)  AS `expdiff` FROM `players` `a` JOIN `znote_players` `b` ON `a`.`id` = `b`.`player_id`  WHERE `a`.`group_id` < 2 ORDER BY `expdiff` DESC LIMIT '.$limit);

	$showVoc = (!empty($vocation)) ? $vocation : 0;
	?>
	<form class="form form-inline" action="" method="post">
		<div class="col sm-4">
			<center>
			<select class="form-control" name="days[]">
				<option value="" selected="all"><?= t('common.all') ?></option>
				<option value="1"><?= t('powergamers.sorcerers') ?></option>
				<option value="2"><?= t('powergamers.druids') ?></option>
				<option value="3"><?= t('powergamers.paladins') ?></option>
				<option value="4"><?= t('powergamers.knights') ?></option>
				<option value="none"><?= t('common.no_vocation') ?></option>
			</select>
			<select class="form-control" name="days[]">
				<option value="" selected="Today"><?= t('common.today') ?></option>
				<option value="1"><?= t('common.yesterday') ?></option>
				<option value="2"><?= t('common.days_ago', ['days' => 2]) ?></option>
				<option value="3"><?= t('common.days_ago', ['days' => 3]) ?></option>
			</select>
			<input type="submit" class="btn btn-primary" value="<?= htmlspecialchars(t('common.submit'), ENT_QUOTES, 'UTF-8') ?>"><br>
			<?php
			$vocationLabels = [
				1 => t('powergamers.sorcerers'),
				2 => t('powergamers.druids'),
				3 => t('powergamers.paladins'),
				4 => t('powergamers.knights'),
			];
			$shownVocation = $vocationLabels[(int)$showVoc] ?? htmlspecialchars(vocation_id_to_name((int)$showVoc), ENT_QUOTES, 'UTF-8');
			echo ($showVoc > 0)
				? t('powergamers.showing_only', ['vocation' => $shownVocation])
				: t('powergamers.showing_all');
			?>
			<?= ($days > 0) ? t('powergamers.sorted_days', ['days' => $days]) : t('powergamers.sorted_today') ?>.
			</center>
		</div>
	</form>
	<table class="table table-striped">
		<td width="5%"><center>#</center></td>
		<td><?= t('common.name') ?></td>
		<?php
	for($i = 3; $i >= 2; $i--)
		echo ($days == $i) ? '<td class="pull-right" width="70%"><b>' . t('toponline.days_ago', ['days' => $i]) . '</b></td>' : '';
		echo ($days == 1) ? '<td class="pull-right" width="70%"><b>' . t('common.yesterday') . '</b></td>' : '';
		echo ($today) ? '<td class="pull-right" width="70%"><b>' . t('common.today') . '</b></td>' : '';
		echo ($days == 4) ? '<td class="pull-right" width="70%"><b>' . t('common.total') . '</b></td>' : '';
		echo '</tr>';

	$number_of_rows = 0;
	if($znotePlayers) {
		foreach($znotePlayers as $player)
		{
			$number_of_rows++;
			echo '<td><center>'. $number_of_rows . '.</center></td>';
			echo '<td><a href="characterprofile.php?name=' .$player['name']. '">' .$player['name']. '</a>';
			echo '<br> '. ($player['level']. ' '.htmlspecialchars(vocation_id_to_name($player['vocation'])) ).' ';
			echo ($days == 3) ? '<td><center>'. number_format($player['exphist3']) .'</center></td>' : '';
			echo ($days == 2) ? '<td><center>'. $player['exphist2'] .'</center></td>' : '';
			echo ($days == 1) ? '<td><center>'. $player['exphist1'] .'</center></td>' : '';
			echo ($today == true) ? '<td><center>'. ($player['experience']-$player['exphist_lastexp']) .'</center></td>' : '';
			echo '</tr>';
		}
	}
	?>
	</table>
	<br>
	</div>
						<div class="BoxFrameHorizontal" style="background-image:url(<?= theme_asset('images/global/images/box-frame-horizontal.gif') ?>);"></div>
						<div class="BoxFrameEdgeRightBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
						<div class="BoxFrameEdgeLeftBottom" style="background-image:url(<?= theme_asset('images/global/images/box-frame-edge.gif') ?>);"></div>
					</div>
				</div>
</div>

<?php
include 'layout/overall/footer.php';
