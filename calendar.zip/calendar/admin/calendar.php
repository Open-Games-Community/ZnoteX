<?php
/**
 * Title: Calendar
 * Icon: fa-calendar
 * Group: Installed Plugins
 * Order: 43
 * Description: Fill the days, pick the colours, and grab the server script.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'calendar__calendar';
$get = static fn(string $k, string $d = '') => (string) setting('calendar:' . $k, $d);
$kinds = calendar_kinds();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? 'config');

	if ($do === 'save_event') {
		$id    = intv($_POST['id'] ?? 0);
		$title = substr(trim((string) ($_POST['title'] ?? '')), 0, 120);
		$desc  = substr(trim((string) ($_POST['description'] ?? '')), 0, 4000);
		$kind  = isset($kinds[$_POST['kind'] ?? '']) ? (string) $_POST['kind'] : 'info';
		$mult  = max(1.0, min(100.0, (float) ($_POST['multiplier'] ?? 2)));
		$skey  = intv($_POST['storage_key'] ?? 0);
		$sval  = (int) ($_POST['storage_value'] ?? 1);
		$color = calendar_css_val((string) ($_POST['color'] ?? ''));
		$icon  = substr(trim((string) ($_POST['icon'] ?? '')), 0, 12);
		$sd = strtotime((string) ($_POST['starts_at'] ?? '')) ?: 0;
		$ed = strtotime((string) ($_POST['ends_at'] ?? '')) ?: 0;
		if ($ed <= $sd) $ed = $sd + 86400;
		$act = !empty($_POST['active']) ? 1 : 0;
		$now = time();
		if ($title !== '' || $kind !== 'info') {
			if ($id > 0) {
				db()->execute("UPDATE `znote_calendar_events` SET `title`=?,`description`=?,`kind`=?,`multiplier`=?,`storage_key`=?,`storage_value`=?,`color`=?,`icon`=?,`starts_at`=?,`ends_at`=?,`active`=?,`updated_at`=? WHERE `id`=? LIMIT 1;", [$title, $desc, $kind, $mult, $skey, $sval, $color, $icon, $sd, $ed, $act, $now, $id]);
			} else {
				db()->execute("INSERT INTO `znote_calendar_events` (`title`,`description`,`kind`,`multiplier`,`storage_key`,`storage_value`,`color`,`icon`,`starts_at`,`ends_at`,`active`,`created_at`,`updated_at`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);", [$title, $desc, $kind, $mult, $skey, $sval, $color, $icon, $sd, $ed, $act, $now, $now]);
			}
		}
		acp_flash_success('Event saved.');
		acp_redirect($module);
	}
	if ($do === 'delete_event') {
		$id = intv($_POST['id'] ?? 0);
		if ($id > 0) db()->execute("DELETE FROM `znote_calendar_events` WHERE `id`=? LIMIT 1;", [$id]);
		acp_flash_success('Event removed.');
		acp_redirect($module);
	}

	// config
	setting_set('calendar:enabled', !empty($_POST['enabled']) ? '1' : '0');
	setting_set('calendar:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
	setting_set('calendar:menu_v', '');
	setting_set('calendar:week_start', ($_POST['week_start'] ?? 'monday') === 'sunday' ? 'sunday' : 'monday');
	setting_set('calendar:range_months', (string) max(1, min(6, intv($_POST['range_months'] ?? 3))));
	setting_set('calendar:day_chips', (string) max(1, min(6, intv($_POST['day_chips'] ?? 3))));
	setting_set('calendar:sync_seconds', (string) max(20, min(600, intv($_POST['sync_seconds'] ?? 60))));
	foreach (array('page_bg','border','text','accent','head_bg','head_text','today','muted') as $k) {
		setting_set('calendar:style_' . $k, calendar_css_val((string) ($_POST['style_' . $k] ?? '')));
	}
	foreach (array_keys($kinds) as $k) {
		setting_set('calendar:color_' . $k, calendar_css_val((string) ($_POST['color_' . $k] ?? '')));
		setting_set('calendar:storagekey_' . $k, (string) intv($_POST['storagekey_' . $k] ?? $kinds[$k][3]));
	}
	if (function_exists('calendar_ensure_menu')) calendar_ensure_menu();
	if (function_exists('acp_log')) acp_log('calendar.config', '');
	acp_flash_success('Calendar saved.');
	acp_redirect($module);
}

$rows = db()->fetchAll("SELECT * FROM `znote_calendar_events` ORDER BY `starts_at` DESC, `id` DESC LIMIT 400;");
$rows = is_array($rows) ? $rows : array();
$edit = null;
if (isset($_GET['edit'])) { $e = intv($_GET['edit']); foreach ($rows as $r) if ((int) $r['id'] === $e) $edit = $r; }
$dt = static fn($ts) => $ts > 0 ? date('Y-m-d\TH:i', (int) $ts) : '';
?>
<?php acp_card_open('Calendar', 'A month calendar under Community (up to ' . (int) calendar_range_months() . ' months back / forward). Each event turns into a global storage in game via the Lua bundle below; Double EXP/Loot/Skill also get a rate multiplier on revscript / Canary.'); ?>

<form method="post"><?= acp_csrf_field() ?>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Show "Calendar" in the Community menu</label></div>
		<div class="acp-field"><label class="acp-label">Week starts on</label><select class="acp-select" name="week_start">
			<option value="monday" <?= $get('week_start', 'monday') !== 'sunday' ? 'selected' : '' ?>>Monday</option>
			<option value="sunday" <?= $get('week_start') === 'sunday' ? 'selected' : '' ?>>Sunday</option>
		</select></div>
		<div class="acp-field"><label class="acp-label">Months back / forward</label><input class="acp-input" type="number" min="1" max="6" name="range_months" value="<?= (int) $get('range_months', '3') ?>"></div>
		<div class="acp-field"><label class="acp-label">Event chips per day cell</label><input class="acp-input" type="number" min="1" max="6" name="day_chips" value="<?= (int) $get('day_chips', '3') ?>"></div>
		<div class="acp-field"><label class="acp-label">Lua sync interval (seconds)</label><input class="acp-input" type="number" min="20" max="600" name="sync_seconds" value="<?= (int) $get('sync_seconds', '60') ?>"></div>
	</div>

	<h3>Page colours <span class="acp-muted">(blank = inherit the layout)</span></h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('page_bg'=>'Background','border'=>'Border','text'=>'Text','accent'=>'Accent','head_bg'=>'Header background','head_text'=>'Header text','today'=>'Today highlight','muted'=>'Muted') as $k=>$lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="style_<?= h($k) ?>" value="<?= h($get('style_' . $k)) ?>" placeholder="#f4c542"></div>
		<?php endforeach; ?>
	</div>

	<h3>Event kinds <span class="acp-muted">(colour + the game global storage key the Lua bundle flips)</span></h3>
	<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Kind</th><th>Colour</th><th>Global storage key</th></tr></thead><tbody>
		<?php foreach ($kinds as $k => $meta): ?>
			<tr><td><?= h(calendar_kind_label($k)) ?></td>
				<td><input class="acp-input" name="color_<?= h($k) ?>" value="<?= h($get('color_' . $k)) ?>" placeholder="<?= h($meta[2]) ?>"></td>
				<td><input class="acp-input" type="number" name="storagekey_<?= h($k) ?>" value="<?= (int) $get('storagekey_' . $k, (string) $meta[3]) ?>" <?= $meta[3] === 0 ? 'placeholder="per event"' : '' ?>></td>
			</tr>
		<?php endforeach; ?>
	</tbody></table></div>

	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save settings</button></div>
</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Server script', 'Download, unzip into your server and reload. The globalevent polls <code>znote_calendar_events</code> and sets the storage keys above; the revscript / Canary bundle also multiplies EXP / Loot / Skill while the matching storage is set. "Double Spawn" only sets a flag - wire it to your own spawn logic.'); ?>
<div class="acp-actions">
	<?php foreach (calendar_distros() as $d => $lbl): ?>
		<a class="acp-btn" href="../index.php?calendar_dl=<?= h($d) ?>"><i class="fa fa-download"></i> <?= h($lbl) ?></a>
	<?php endforeach; ?>
</div>
<?php acp_card_close(); ?>

<?php acp_card_open($edit ? 'Edit event' : 'Add an event'); ?>
<form method="post"><?= acp_csrf_field() ?>
	<input type="hidden" name="do" value="save_event">
	<input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Title</label><input class="acp-input" name="title" value="<?= h($edit['title'] ?? '') ?>" placeholder="Double EXP weekend"></div>
		<div class="acp-field"><label class="acp-label">Kind</label><select class="acp-select" name="kind">
			<?php foreach ($kinds as $k => $m): ?><option value="<?= $k ?>" <?= ($edit['kind'] ?? 'info') === $k ? 'selected' : '' ?>><?= h(calendar_kind_label($k)) ?></option><?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label">Multiplier <span class="acp-muted">(Double * kinds)</span></label><input class="acp-input" type="number" step="0.25" min="1" max="100" name="multiplier" value="<?= h($edit['multiplier'] ?? '2.00') ?>"></div>
		<div class="acp-field"><label class="acp-label">Icon <span class="acp-muted">(emoji, optional)</span></label><input class="acp-input" name="icon" value="<?= h($edit['icon'] ?? '') ?>" maxlength="12"></div>
		<div class="acp-field"><label class="acp-label">Colour <span class="acp-muted">(blank = kind colour)</span></label><input class="acp-input" name="color" value="<?= h($edit['color'] ?? '') ?>" placeholder="#e8590c"></div>
		<div class="acp-field"><label class="acp-label">Storage key <span class="acp-muted">(for "Storage flag", or override)</span></label><input class="acp-input" type="number" name="storage_key" value="<?= (int) ($edit['storage_key'] ?? 0) ?>"></div>
		<div class="acp-field"><label class="acp-label">Storage value</label><input class="acp-input" type="number" name="storage_value" value="<?= (int) ($edit['storage_value'] ?? 1) ?>"></div>
		<div class="acp-field"><label class="acp-label">Starts</label><input class="acp-input" type="datetime-local" name="starts_at" value="<?= h($dt($edit['starts_at'] ?? strtotime('today'))) ?>"></div>
		<div class="acp-field"><label class="acp-label">Ends</label><input class="acp-input" type="datetime-local" name="ends_at" value="<?= h($dt($edit['ends_at'] ?? strtotime('tomorrow'))) ?>"></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="active" value="1" <?= (int) ($edit['active'] ?? 1) === 1 ? 'checked' : '' ?>> Active</label></div>
	</div>
	<div class="acp-field"><label class="acp-label">Description</label><textarea class="acp-textarea" name="description" rows="3"><?= h($edit['description'] ?? '') ?></textarea></div>
	<div class="acp-actions">
		<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $edit ? 'Save' : 'Add' ?></button>
		<?php if ($edit): ?><a class="acp-btn acp-btn--ghost" href="<?= h(acp_url($module)) ?>">Cancel</a><?php endif; ?>
	</div>
</form>

<?php if ($rows): ?>
	<div class="acp-table-wrap"><table class="acp-table">
		<thead><tr><th>Title</th><th>Kind</th><th>When</th><th>On</th><th></th></tr></thead>
		<tbody>
		<?php foreach ($rows as $r): ?>
			<tr>
				<td><?= h($r['title'] !== '' ? $r['title'] : calendar_kind_label($r['kind'])) ?></td>
				<td><?= h(calendar_kind_label($r['kind'])) ?><?= in_array($r['kind'], array('double_exp','double_loot','double_skill','double_spawn'), true) ? ' &times;' . rtrim(rtrim(number_format((float) $r['multiplier'], 2), '0'), '.') : '' ?></td>
				<td><?= h(date('M j H:i', (int) $r['starts_at'])) ?> &rarr; <?= h(date('M j H:i', (int) $r['ends_at'])) ?></td>
				<td><?= (int) $r['active'] === 1 ? 'yes' : 'no' ?></td>
				<td style="white-space:nowrap">
					<a class="acp-btn acp-btn--sm" href="<?= h(acp_url($module, array('edit' => (int) $r['id']))) ?>">Edit</a>
					<form method="post" style="display:inline" data-confirm="Remove this event?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete_event"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="acp-btn acp-btn--sm acp-btn--red" type="submit">Delete</button></form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
<?php else: ?>
	<p class="acp-muted">No events yet.</p>
<?php endif; ?>
