<?php
/**
 * Public page: page.php?plugin=calendar&p=calendar
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'calendar_h';
$range = calendar_range_months();
$off   = (int) ($_GET['m'] ?? 0);
if ($off < -$range) $off = -$range;
if ($off > $range)  $off = $range;

$mondayFirst = calendar_setting('week_start', 'monday') !== 'sunday';

$now   = time();
$base  = new DateTime('first day of this month 00:00');
if ($off !== 0) $base->modify(($off > 0 ? '+' : '-') . abs($off) . ' month');
$year  = (int) $base->format('Y');
$month = (int) $base->format('n');
$daysInMonth = (int) $base->format('t');
$monthStart  = (int) $base->format('U');
$monthEnd    = $monthStart + $daysInMonth * 86400;

$monthName = calendar_t('calendar.month.' . $month, $base->format('F'));
$dow = array();
for ($i = 1; $i <= 7; $i++) {
	$d = $mondayFirst ? $i : ($i % 7) + 1; // 1..7 (Mon..Sun) reordered
	$dow[] = calendar_t('calendar.dow.' . $d, $base->format('D'));
}

$events = calendar_events($monthStart, $monthEnd);

// index events per day-of-month + collect JSON for the detail panel
$byDay = array_fill(1, $daysInMonth, array());
$json  = array();
foreach ($events as $e) {
	$kind  = (string) $e['kind'];
	$color = calendar_css_val((string) $e['color']) ?: calendar_kind_color($kind);
	$sd = max($monthStart, (int) $e['starts_at']);
	$ed = min($monthEnd, (int) $e['ends_at']);
	$row = array(
		'id'    => (int) $e['id'],
		'title' => (string) $e['title'] !== '' ? (string) $e['title'] : calendar_kind_label($kind),
		'desc'  => (string) $e['description'],
		'kind'  => $kind,
		'klabel'=> calendar_kind_label($kind),
		'color' => $color,
		'icon'  => (string) $e['icon'],
		'mult'  => in_array($kind, array('double_exp', 'double_loot', 'double_skill', 'double_spawn'), true) ? (float) $e['multiplier'] : 0,
		'from'  => (int) $e['starts_at'],
		'to'    => (int) $e['ends_at'],
	);
	$json[$row['id']] = $row;
	for ($t = $sd; $t < $ed; $t += 86400) {
		$dn = (int) date('j', $t);
		if ($dn >= 1 && $dn <= $daysInMonth && !in_array($row['id'], $byDay[$dn], true)) $byDay[$dn][] = $row['id'];
	}
}

$activeNow = array_values(array_filter($events, static fn($e) => (int) $e['starts_at'] <= $now && (int) $e['ends_at'] > $now));
$todayN = ((int) date('n') === $month && (int) date('Y') === $year) ? (int) date('j') : 0;
$firstDow = (int) $base->format('N'); // 1..7 Mon..Sun
$lead = $mondayFirst ? ($firstDow - 1) : ($firstDow % 7);
$maxChips = max(1, calendar_int('day_chips', 3));
$navUrl = static fn(int $o) => 'page.php?plugin=calendar&p=calendar&m=' . $o;
?>
<style>
.cal-wrap{--cal-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--cal-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--cal-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--cal-accent:var(--accent,var(--link,#f4c542));--cal-head-bg:var(--cal-accent);--cal-head-text:#151515;--cal-today:color-mix(in srgb,var(--cal-accent) 18%,transparent);--cal-muted:rgba(255,255,255,.35);color:var(--cal-text)}
.cal-wrap *{box-sizing:border-box}
.cal-wrap h1{font-size:26px;margin:0 0 4px}
.cal-lead{opacity:.8;margin:0 0 16px}
.cal-active{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 16px}
.cal-active__chip{display:inline-flex;align-items:center;gap:7px;padding:6px 12px;border-radius:999px;font-weight:700;font-size:12.5px;border:1px solid var(--k);background:color-mix(in srgb,var(--k) 14%,transparent);color:var(--k)}
.cal-bar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 12px}
.cal-bar__title{font-size:20px;font-weight:800;text-transform:uppercase;letter-spacing:.03em}
.cal-bar a,.cal-bar span.cal-nav{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;border:1px solid var(--cal-border);color:inherit;font-weight:800;text-decoration:none}
.cal-bar a:hover{border-color:var(--cal-accent);color:var(--cal-accent)}
.cal-bar span.cal-nav{opacity:.3}
.cal-grid{border:1px solid var(--cal-border);border-radius:12px;overflow:hidden;background:var(--cal-surface)}
.cal-dow{display:grid;grid-template-columns:repeat(7,1fr);background:var(--cal-head-bg);color:var(--cal-head-text)}
.cal-dow span{padding:8px 10px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;text-align:left}
.cal-days{display:grid;grid-template-columns:repeat(7,1fr)}
.cal-day{min-height:104px;padding:6px 8px;border-top:1px solid var(--cal-border);border-left:1px solid var(--cal-border);display:flex;flex-direction:column;gap:4px;cursor:default}
.cal-day:nth-child(7n+1){border-left:0}
.cal-day--pad{background:rgba(0,0,0,.12)}
.cal-day--today{background:var(--cal-today)}
.cal-day--has{cursor:pointer}
.cal-day--has:hover{background:rgba(255,255,255,.04)}
.cal-day__n{font-size:12px;font-weight:700;opacity:.75}
.cal-day--today .cal-day__n{color:var(--cal-accent);opacity:1}
.cal-chip{display:flex;align-items:center;gap:5px;font-size:11px;line-height:1.25;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.cal-chip__dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto;background:var(--k)}
.cal-chip__x{font-size:10px;font-weight:800;opacity:.7}
.cal-more{font-size:10.5px;opacity:.6;font-weight:700}
.cal-legend{display:flex;flex-wrap:wrap;gap:10px 16px;margin:16px 0 0;font-size:12.5px}
.cal-legend span{display:inline-flex;align-items:center;gap:7px}
.cal-legend i{width:10px;height:10px;border-radius:3px;background:var(--k);display:inline-block}
.cal-note{opacity:.55;font-size:12px;margin-top:12px}
.cal-modal{position:fixed;inset:0;z-index:900;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.55)}
.cal-modal.is-open{display:flex}
.cal-modal__box{max-width:460px;width:100%;max-height:80vh;overflow:auto;background:var(--cal-surface);border:1px solid var(--cal-border);border-radius:12px;padding:18px 20px;color:var(--cal-text)}
.cal-modal__box h3{margin:0 0 12px;font-size:16px}
.cal-ev{border:1px solid var(--k);border-left:4px solid var(--k);border-radius:8px;padding:10px 12px;margin:0 0 10px;background:color-mix(in srgb,var(--k) 8%,transparent)}
.cal-ev__t{font-weight:800;font-size:13.5px;display:flex;align-items:center;gap:7px}
.cal-ev__k{font-size:11px;font-weight:700;color:var(--k);text-transform:uppercase;letter-spacing:.04em}
.cal-ev__d{font-size:12.5px;opacity:.85;margin-top:5px;white-space:pre-wrap}
.cal-ev__when{font-size:11px;opacity:.6;margin-top:6px}
.cal-modal__close{float:right;background:none;border:0;color:inherit;font-size:20px;cursor:pointer;opacity:.6}
@media(max-width:640px){.cal-day{min-height:76px}.cal-chip{font-size:0}.cal-chip__dot{width:9px;height:9px}}
</style>

<div class="cal-wrap"<?= calendar_style_attr() ?>>
	<h1><?= $h(calendar_t('calendar.title', 'Event Calendar')) ?></h1>
	<p class="cal-lead"><?= $h(calendar_t('calendar.lead', 'Double EXP, loot and skill weekends, storage events and announcements.')) ?></p>

	<?php if ($activeNow): ?>
		<div class="cal-active">
			<?php foreach ($activeNow as $e): $k = calendar_css_val((string) $e['color']) ?: calendar_kind_color((string) $e['kind']); ?>
				<span class="cal-active__chip" style="--k:<?= $h($k) ?>">
					<?php if ((string) $e['icon'] !== ''): ?><?= $h($e['icon']) ?><?php endif; ?>
					<?= $h((string) $e['title'] !== '' ? $e['title'] : calendar_kind_label((string) $e['kind'])) ?>
					<?php if (in_array($e['kind'], array('double_exp','double_loot','double_skill','double_spawn'), true)): ?><b>&times;<?= rtrim(rtrim(number_format((float) $e['multiplier'], 2), '0'), '.') ?></b><?php endif; ?>
				</span>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<div class="cal-bar">
		<?php if ($off > -$range): ?><a href="<?= $h($navUrl($off - 1)) ?>" aria-label="prev">&#8249;</a><?php else: ?><span class="cal-nav">&#8249;</span><?php endif; ?>
		<div class="cal-bar__title"><?= $h($monthName) ?> <?= $year ?></div>
		<?php if ($off < $range): ?><a href="<?= $h($navUrl($off + 1)) ?>" aria-label="next">&#8250;</a><?php else: ?><span class="cal-nav">&#8250;</span><?php endif; ?>
	</div>

	<div class="cal-grid">
		<div class="cal-dow"><?php foreach ($dow as $d): ?><span><?= $h($d) ?></span><?php endforeach; ?></div>
		<div class="cal-days">
			<?php for ($i = 0; $i < $lead; $i++): ?><div class="cal-day cal-day--pad"></div><?php endfor; ?>
			<?php for ($d = 1; $d <= $daysInMonth; $d++):
				$ids = $byDay[$d];
				$has = (bool) $ids;
			?>
				<div class="cal-day<?= $has ? ' cal-day--has' : '' ?><?= $d === $todayN ? ' cal-day--today' : '' ?>"<?= $has ? ' data-cal-day="' . $d . '"' : '' ?>>
					<span class="cal-day__n"><?= $d ?></span>
					<?php foreach (array_slice($ids, 0, $maxChips) as $id): $e = $json[$id]; ?>
						<span class="cal-chip" style="--k:<?= $h($e['color']) ?>" title="<?= $h($e['title']) ?>">
							<span class="cal-chip__dot"></span><?= $h($e['icon'] !== '' ? $e['icon'] . ' ' : '') ?><?= $h($e['title']) ?>
							<?php if ($e['mult'] > 0): ?><span class="cal-chip__x">&times;<?= rtrim(rtrim(number_format($e['mult'], 2), '0'), '.') ?></span><?php endif; ?>
						</span>
					<?php endforeach; ?>
					<?php if (count($ids) > $maxChips): ?><span class="cal-more">+<?= count($ids) - $maxChips ?></span><?php endif; ?>
				</div>
			<?php endfor; ?>
		</div>
	</div>

	<div class="cal-legend">
		<?php foreach (calendar_kinds() as $key => $meta): ?>
			<span style="--k:<?= $h(calendar_kind_color($key)) ?>"><i></i><?= $h(calendar_kind_label($key)) ?></span>
		<?php endforeach; ?>
	</div>
	<p class="cal-note"><?= $h(calendar_t('calendar.note', 'Times are server time. Effects turn on and off automatically.')) ?></p>
</div>

<div class="cal-modal" id="calModal" aria-hidden="true">
	<div class="cal-modal__box">
		<button type="button" class="cal-modal__close" data-cal-close aria-label="close">&times;</button>
		<h3 id="calModalTitle"></h3>
		<div id="calModalBody"></div>
	</div>
</div>

<script>(function(){
	var E=<?= json_encode(array_values($json)) ?>,DAY=<?= json_encode($byDay) ?>,Y=<?= $year ?>,M=<?= $month ?>;
	var L=<?= json_encode(array('all_day' => calendar_t('calendar.all_day', 'All day'), 'from' => calendar_t('calendar.from', 'From'), 'to' => calendar_t('calendar.to', 'to'))) ?>;
	var byId={};E.forEach(function(e){byId[e.id]=e;});
	var modal=document.getElementById('calModal'),body=document.getElementById('calModalBody'),ttl=document.getElementById('calModalTitle');
	function fmt(ts){var d=new Date(ts*1000);return d.toLocaleString([], {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});}
	function open(day){
		var ids=DAY[day]||[];if(!ids.length)return;
		ttl.textContent=new Date(Y,M-1,day).toLocaleDateString([], {weekday:'long',day:'numeric',month:'long'});
		body.innerHTML=ids.map(function(id){var e=byId[id];if(!e)return'';
			var mult=e.mult>0?' <b>&times;'+(''+e.mult).replace(/\.?0+$/,'')+'</b>':'';
			var when=(e.to-e.from>=86400)?L.all_day:(L.from+' '+fmt(e.from)+' '+L.to+' '+fmt(e.to));
			return '<div class="cal-ev" style="--k:'+e.color+'"><div class="cal-ev__t">'+(e.icon?e.icon+' ':'')+escapeHtml(e.title)+mult+'</div>'+
				'<div class="cal-ev__k">'+escapeHtml(e.klabel)+'</div>'+
				(e.desc?'<div class="cal-ev__d">'+escapeHtml(e.desc)+'</div>':'')+
				'<div class="cal-ev__when">'+when+'</div></div>';
		}).join('');
		modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');
	}
	function escapeHtml(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}
	document.querySelectorAll('[data-cal-day]').forEach(function(c){c.addEventListener('click',function(){open(+c.getAttribute('data-cal-day'));});});
	modal.addEventListener('click',function(e){if(e.target===modal||e.target.hasAttribute('data-cal-close'))close();});
	document.addEventListener('keydown',function(e){if(e.key==='Escape')close();});
	function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');}
}());</script>
