<?php
/**
 * Calendar - a month calendar of server events under Community.
 *
 * The web side is read-only for players; the admin edits days in the ACP. A
 * downloadable Lua bundle (globalevent + EventCallback) reads znote_calendar_events
 * and turns the active kinds into global storages / rate multipliers in game.
 */
if (!function_exists('calendar_setting')) {

function calendar_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('calendar:' . $k, $d) : $d;
}
function calendar_int(string $k, int $d): int { $v = calendar_setting($k, ''); return $v === '' ? $d : (int) $v; }
function calendar_enabled(): bool { return calendar_setting('enabled', '1') === '1'; }
function calendar_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function calendar_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function calendar_tables_ok(): bool { return function_exists('znote_table_exists') && znote_table_exists('znote_calendar_events'); }

/** kind => [labelKey, defaultLabel, defaultColor, defaultStorageKey] */
function calendar_kinds(): array {
	return array(
		'double_exp'   => array('calendar.k.exp',   'Double EXP',   '#e8590c', 50100),
		'double_loot'  => array('calendar.k.loot',  'Double Loot',  '#2f9e44', 50101),
		'double_skill' => array('calendar.k.skill', 'Double Skill', '#1971c2', 50102),
		'double_spawn' => array('calendar.k.spawn', 'Double Spawn', '#8b3fc7', 50103),
		'storage'      => array('calendar.k.storage', 'Storage flag', '#868e96', 0),
		'info'         => array('calendar.k.info',  'Announcement', '#e6a817', 0),
	);
}
function calendar_kind_color(string $kind): string {
	$c = calendar_css_val(calendar_setting('color_' . $kind, ''));
	if ($c !== '') return $c;
	$k = calendar_kinds();
	return $k[$kind][2] ?? '#868e96';
}
function calendar_kind_label(string $kind): string {
	$k = calendar_kinds();
	return isset($k[$kind]) ? calendar_t($k[$kind][0], $k[$kind][1]) : ucfirst(str_replace('_', ' ', $kind));
}
function calendar_css_val(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}

/** Events overlapping [$from,$to). */
function calendar_events(int $from, int $to): array {
	if (!calendar_tables_ok()) return array();
	$from = (int) $from; $to = (int) $to;
	$rows = db()->fetchAll("SELECT `id`,`title`,`description`,`kind`,`multiplier`,`storage_key`,`storage_value`,`color`,`icon`,`starts_at`,`ends_at`,`active` FROM `znote_calendar_events` WHERE `active` = 1 AND `starts_at` < ? AND `ends_at` > ? ORDER BY `starts_at` ASC, `id` ASC;", [$to, $from]);
	return is_array($rows) ? $rows : array();
}
/** Distinct months (0 = current) that may be viewed. */
function calendar_range_months(): int { return max(1, min(6, calendar_int('range_months', 3))); }

function calendar_style_attr(): string {
	$map = array('page_bg' => '--cal-surface', 'border' => '--cal-border', 'text' => '--cal-text', 'accent' => '--cal-accent', 'head_bg' => '--cal-head-bg', 'head_text' => '--cal-head-text', 'today' => '--cal-today', 'muted' => '--cal-muted');
	$css = '';
	foreach ($map as $k => $var) { $v = calendar_css_val(calendar_setting('style_' . $k, '')); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	return $css !== '' ? ' style="' . calendar_h($css) . '"' : '';
}

// --- menu -----------------------------------------------------------
function calendar_ensure_menu(): void {
	static $done = false;
	if ($done) return;
	$done = true;
	if (!function_exists('setting')) return;
	$state = 'v1:' . (calendar_enabled() ? '1' : '0') . (calendar_setting('show_in_menu', '1') === '1' ? '1' : '0');
	if (setting('calendar:menu_v', '') === $state) return;
	if (function_exists('znote_table_exists') && znote_table_exists('znote_menu')) {
		db()->execute("DELETE FROM `znote_menu` WHERE `url` = 'page.php?plugin=calendar&p=calendar';");
		if (calendar_enabled() && calendar_setting('show_in_menu', '1') === '1') {
			$p = db()->fetchOne("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` LIKE '%communit%' ORDER BY `id` ASC LIMIT 1;");
			$parent = is_array($p) ? (int) $p['id'] : 0;
			if ($parent > 0) {
				$mx = db()->fetchOne("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = ?;", [$parent]);
				$so = is_array($mx) ? (int) $mx['s'] + 1 : 1;
			} else {
				$g = db()->fetchOne("SELECT `sort_order` FROM `znote_menu` WHERE `location` = 'main' AND `url` LIKE '%guild%' ORDER BY `sort_order` ASC LIMIT 1;");
				$so = is_array($g) ? (int) $g['sort_order'] + 4 : 58;
			}
			db()->execute("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main', ?, 'Calendar', 'page.php?plugin=calendar&p=calendar', 'fa-calendar', 'all', ?, 1);", [$parent, $so]);
		}
	}
	if (function_exists('setting_set')) setting_set('calendar:menu_v', $state);
}

// --- downloadable Lua bundle --------------------------------------
function calendar_distros(): array {
	return array('tfs_revscript' => 'TFS 1.3+ / OTX (revscripts)', 'canary' => 'Canary', 'tfs_legacy' => 'TFS 1.0-1.2 (legacy)');
}
function calendar_handle_download(): void {
	if (($_GET['calendar_dl'] ?? '') === '' || headers_sent()) return;
	$d = preg_replace('/[^a-z0-9_]/', '', (string) $_GET['calendar_dl']);
	if (!isset(calendar_distros()[$d])) { http_response_code(404); exit; }
	$dir = __DIR__ . '/assets/lua/' . $d;
	if (!is_dir($dir)) { http_response_code(404); exit; }
	while (function_exists('ob_get_level') && ob_get_level() > 0) ob_end_clean();
	header('Content-Type: text/plain; charset=utf-8');
	header('Content-Disposition: attachment; filename="calendar_' . $d . '.txt"');
	$files = glob($dir . '/*'); sort($files);
	foreach ($files as $f) {
		if (!is_file($f)) continue;
		echo "\n===== FILE: " . basename($f) . " =====\n\n" . file_get_contents($f) . "\n";
	}
	exit;
}

}

calendar_handle_download();
calendar_ensure_menu();
