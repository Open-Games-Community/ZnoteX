CREATE TABLE IF NOT EXISTS `znote_calendar_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `description` text,
  `kind` varchar(24) NOT NULL DEFAULT 'info',
  `multiplier` decimal(5,2) NOT NULL DEFAULT '2.00',
  `storage_key` int NOT NULL DEFAULT '0',
  `storage_value` bigint NOT NULL DEFAULT '1',
  `color` varchar(24) NOT NULL DEFAULT '',
  `icon` varchar(12) NOT NULL DEFAULT '',
  `starts_at` int NOT NULL DEFAULT '0',
  `ends_at` int NOT NULL DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '1',
  `created_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `window` (`active`, `starts_at`, `ends_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
