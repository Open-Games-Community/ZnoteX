-- ZnoteX Calendar - TFS 1.3+ / OTX revscript
-- Drop this file in data/scripts/ and reload (or restart).
--
-- It polls the website table `znote_calendar_events` and, for every event that
-- is active right now, sets a global storage. The EXP / Loot / Skill multipliers
-- are then applied by the EventCallbacks below while that storage is set.
--
-- Global storage keys (must match the ACP > Calendar > "Event kinds" table):
local CAL = {
	poll_seconds = 60,
	exp   = { storage = 50100, kind = "double_exp"   },
	loot  = { storage = 50101, kind = "double_loot"  },
	skill = { storage = 50102, kind = "double_skill" },
	spawn = { storage = 50103, kind = "double_spawn" },
}

-- current multiplier per kind (1 = off). storage value carries mult*100.
local function readMult(storage)
	local v = Game.getStorageValue(storage)
	if not v or v <= 0 then return 1.0 end
	return v / 100.0
end

local function refresh()
	for _, def in pairs(CAL) do
		if type(def) == "table" then
			Game.setStorageValue(def.storage, 0)
		end
	end

	local now = os.time()
	local q = db.storeQuery(
		"SELECT `kind`, `multiplier`, `storage_key`, `storage_value` FROM `znote_calendar_events` " ..
		"WHERE `active` = 1 AND `starts_at` <= " .. now .. " AND `ends_at` > " .. now)
	if q ~= false then
		repeat
			local kind = result.getString(q, "kind")
			local mult = tonumber(result.getString(q, "multiplier")) or 2.0
			local skey = result.getNumber(q, "storage_key")
			local sval = result.getNumber(q, "storage_value")

			if kind == "double_exp"   then Game.setStorageValue(CAL.exp.storage,   math.floor(mult * 100)) end
			if kind == "double_loot"  then Game.setStorageValue(CAL.loot.storage,  math.floor(mult * 100)) end
			if kind == "double_skill" then Game.setStorageValue(CAL.skill.storage, math.floor(mult * 100)) end
			if kind == "double_spawn" then Game.setStorageValue(CAL.spawn.storage, math.floor(mult * 100)) end

			if skey and skey ~= 0 then
				Game.setStorageValue(skey, sval)
			end
		until not result.next(q)
		result.free(q)
	end
end

local calTick = GlobalEvent("znote_calendar_tick")
function calTick.onThink(interval)
	refresh()
	return true
end
calTick:interval(CAL.poll_seconds * 1000)
calTick:register()

local calBoot = GlobalEvent("znote_calendar_boot")
function calBoot.onStartup()
	refresh()
	return true
end
calBoot:register()

local calExp = EventCallback
calExp.onGainExperience = function(self, source, exp, rawExp)
	if self:isPlayer() then
		local m = readMult(CAL.exp.storage)
		if m > 1.0 then return math.floor(exp * m) end
	end
	return exp
end
calExp:register(-500)

local calLoot = EventCallback
calLoot.onDropLoot = function(self, corpse)
	local m = readMult(CAL.loot.storage)
	if m <= 1.0 then return end
	local mType = self:getType()
	if not mType then return end
	local extra = math.floor(m) - 1
	for _ = 1, extra do
		mType:createLoot(corpse)
	end
end
calLoot:register(-500)

-- "Double Skill": onGainSkillTries multiplies skill/mana training.
local calSkill = EventCallback
calSkill.onGainSkillTries = function(self, skill, tries)
	if self:isPlayer() then
		local m = readMult(CAL.skill.storage)
		if m > 1.0 then return math.floor(tries * m) end
	end
	return tries
end
calSkill:register(-500)
