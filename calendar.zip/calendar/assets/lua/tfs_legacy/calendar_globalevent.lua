-- ZnoteX Calendar - TFS 1.0 - 1.2 (legacy)
--
-- 1. Put this file in data/globalevents/scripts/calendar.lua
-- 2. In data/globalevents/globalevents.xml add:
--      <globalevent name="ZnoteCalendar" interval="60000" script="calendar.lua" />
-- 3. In data/globalevents/scripts/startup.lua (or a login script) call refreshZnoteCalendar()
--
-- Legacy has no EventCallback, so this only sets the global storages. Read them
-- from your own EXP stage / loot / skill scripts, e.g.:
--    if getGlobalStorageValue(50100) > 100 then rate = rate * (getGlobalStorageValue(50100) / 100) end

CAL_STORAGE = {
	double_exp   = 50100,
	double_loot  = 50101,
	double_skill = 50102,
	double_spawn = 50103,
}

function refreshZnoteCalendar()
	for _, storage in pairs(CAL_STORAGE) do
		setGlobalStorageValue(storage, 0)
	end

	local now = os.time()
	local q = db.storeQuery(
		"SELECT `kind`, `multiplier`, `storage_key`, `storage_value` FROM `znote_calendar_events` " ..
		"WHERE `active` = 1 AND `starts_at` <= " .. now .. " AND `ends_at` > " .. now)
	if q ~= false then
		repeat
			local kind = result.getString(q, "kind")
			local mult = tonumber(result.getString(q, "multiplier")) or 2.0
			local skey = result.getNumber(q, "storage_key")
			local sval = result.getNumber(q, "storage_value")
			local packed = math.floor(mult * 100)

			if CAL_STORAGE[kind] then
				setGlobalStorageValue(CAL_STORAGE[kind], packed)
			end
			if skey and skey ~= 0 then
				setGlobalStorageValue(skey, sval)
			end
		until not result.next(q)
		result.free(q)
	end
end

function onThink(interval)
	refreshZnoteCalendar()
	return true
end
