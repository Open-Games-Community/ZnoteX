-- ZnoteX Calendar - Canary revscript
-- Drop this file in data/scripts/ and reload.
--
-- Polls the website table `znote_calendar_events` and sets global storages for
-- the events that are active right now. EventCallbacks apply the multipliers.

local CAL = {
	poll_seconds = 60,
	exp   = 50100,
	loot  = 50101,
	skill = 50102,
	spawn = 50103,
}

local function readMult(storage)
	local v = Game.getStorageValue(storage)
	if not v or v <= 0 then return 1.0 end
	return v / 100.0
end

local function refresh()
	Game.setStorageValue(CAL.exp, 0)
	Game.setStorageValue(CAL.loot, 0)
	Game.setStorageValue(CAL.skill, 0)
	Game.setStorageValue(CAL.spawn, 0)

	local now = os.time()
	local q = db.storeQuery(
		"SELECT `kind`, `multiplier`, `storage_key`, `storage_value` FROM `znote_calendar_events` " ..
		"WHERE `active` = 1 AND `starts_at` <= " .. now .. " AND `ends_at` > " .. now)
	if q ~= false then
		repeat
			local kind = result.getString(q, "kind")
			local mult = tonumber(result.getString(q, "multiplier")) or 2.0
			local skey = result.getNumber(q, "storage_key")
			local sval = result.getNumber(q, "storage_value")
			local packed = math.floor(mult * 100)

			if kind == "double_exp"   then Game.setStorageValue(CAL.exp, packed) end
			if kind == "double_loot"  then Game.setStorageValue(CAL.loot, packed) end
			if kind == "double_skill" then Game.setStorageValue(CAL.skill, packed) end
			if kind == "double_spawn" then Game.setStorageValue(CAL.spawn, packed) end

			if skey and skey ~= 0 then
				Game.setStorageValue(skey, sval)
			end
		until not result.next(q)
		result.free(q)
	end
end

local calTick = GlobalEvent("znote_calendar_tick")
function calTick.onThink(interval)
	refresh()
	return true
end
calTick:interval(CAL.poll_seconds * 1000)
calTick:register()

local calBoot = GlobalEvent("znote_calendar_boot")
function calBoot.onStartup()
	refresh()
	return true
end
calBoot:register()

local calExp = EventCallback("znoteCalendarExp")
function calExp.onPlayerGainExperience(player, target, exp, rawExp)
	local m = readMult(CAL.exp)
	if m > 1.0 then return math.floor(exp * m) end
	return exp
end
calExp:register()

local calLoot = EventCallback("znoteCalendarLoot")
function calLoot.onMonsterDropLoot(monster, corpse)
	local m = readMult(CAL.loot)
	if m <= 1.0 then return end
	local mType = monster:getType()
	if not mType then return end
	for _ = 1, math.floor(m) - 1 do
		mType:createLoot(corpse)
	end
end
calLoot:register()
