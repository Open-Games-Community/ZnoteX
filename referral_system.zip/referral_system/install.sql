CREATE TABLE IF NOT EXISTS `znote_referral_codes` (
  `account_id` int NOT NULL,
  `code` varchar(32) NOT NULL,
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `znote_referrals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `referrer_account_id` int NOT NULL,
  `referred_account_id` int NOT NULL,
  `code` varchar(32) NOT NULL,
  `ip` int NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT 'rewarded',
  `referrer_points` int NOT NULL DEFAULT '0',
  `referred_points` int NOT NULL DEFAULT '0',
  `referrer_premdays` int NOT NULL DEFAULT '0',
  `referred_premdays` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  `rewarded_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `referred_account_id` (`referred_account_id`),
  KEY `referrer_account_id` (`referrer_account_id`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
