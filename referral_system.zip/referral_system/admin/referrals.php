<?php
/**
 * Title: Referrals
 * Icon: fa-share-alt
 * Group: Installed Plugins
 * Order: 10
 * Description: Configure referral rewards and review invited accounts.
 */

if (!defined('ACP_ROOT')) {
	http_response_code(403);
	die('Direct access denied.');
}

function referral_admin_setting(string $key, string $default): string {
	return function_exists('setting') ? (string)setting('referral_system:' . $key, $default) : $default;
}

function referral_admin_save(string $key, string $value): void {
	if (function_exists('setting_set')) {
		setting_set('referral_system:' . $key, $value);
	}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	referral_admin_save('enabled', !empty($_POST['enabled']) ? '1' : '0');
	referral_admin_save('block_same_ip', !empty($_POST['block_same_ip']) ? '1' : '0');
	referral_admin_save('referrer_points', (string)max(0, (int)($_POST['referrer_points'] ?? 0)));
	referral_admin_save('referred_points', (string)max(0, (int)($_POST['referred_points'] ?? 0)));
	referral_admin_save('referrer_premdays', (string)max(0, (int)($_POST['referrer_premdays'] ?? 0)));
	referral_admin_save('referred_premdays', (string)max(0, (int)($_POST['referred_premdays'] ?? 0)));
	acp_log('plugin.referral_system.settings', 'Referral System');
	acp_flash_success('Referral settings saved.');
	acp_redirect('referral_system__referrals');
}

$enabled = referral_admin_setting('enabled', '1') === '1';
$blockSameIp = referral_admin_setting('block_same_ip', '1') === '1';
$referrerPoints = (int)referral_admin_setting('referrer_points', '25');
$referredPoints = (int)referral_admin_setting('referred_points', '10');
$referrerPremdays = (int)referral_admin_setting('referrer_premdays', '0');
$referredPremdays = (int)referral_admin_setting('referred_premdays', '0');

$total = acp_count("SELECT COUNT(*) AS `c` FROM `znote_referrals`;");
$points = mysql_select_single("SELECT COALESCE(SUM(`referrer_points` + `referred_points`), 0) AS `c` FROM `znote_referrals`;");
$premdays = mysql_select_single("SELECT COALESCE(SUM(`referrer_premdays` + `referred_premdays`), 0) AS `c` FROM `znote_referrals`;");
$recent = mysql_select_multi("
	SELECT `r`.*, `ra`.`name` AS `referrer_name`, `na`.`name` AS `referred_name`
	FROM `znote_referrals` AS `r`
	LEFT JOIN `accounts` AS `ra` ON `ra`.`id` = `r`.`referrer_account_id`
	LEFT JOIN `accounts` AS `na` ON `na`.`id` = `r`.`referred_account_id`
	ORDER BY `r`.`id` DESC
	LIMIT 50;
");
?>

<div class="acp-grid">
	<?php
	acp_stat('Total referrals', $total, 'fa-share-alt', null, 'green');
	acp_stat('Points rewarded', is_array($points) ? (int)$points['c'] : 0, 'fa-diamond', null, 'purple');
	acp_stat('Premium days', is_array($premdays) ? (int)$premdays['c'] : 0, 'fa-clock-o', null, 'amber');
	?>
</div>

<?php acp_card_open('Referral Settings', 'Rewards are granted when an account registers with a valid referral code.'); ?>
	<form method="post">
		<?= acp_csrf_field() ?>
		<div class="acp-field">
			<label><input type="checkbox" name="enabled" value="1" <?= $enabled ? 'checked' : '' ?>> Enabled</label>
		</div>
		<div class="acp-field">
			<label><input type="checkbox" name="block_same_ip" value="1" <?= $blockSameIp ? 'checked' : '' ?>> Block repeated rewards from the same IP for one referrer</label>
		</div>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field">
				<label class="acp-label" for="referrer_points">Referrer points</label>
				<input class="acp-input" id="referrer_points" name="referrer_points" type="number" min="0" value="<?= (int)$referrerPoints ?>">
			</div>
			<div class="acp-field">
				<label class="acp-label" for="referred_points">New account points</label>
				<input class="acp-input" id="referred_points" name="referred_points" type="number" min="0" value="<?= (int)$referredPoints ?>">
			</div>
			<div class="acp-field">
				<label class="acp-label" for="referrer_premdays">Referrer premium days</label>
				<input class="acp-input" id="referrer_premdays" name="referrer_premdays" type="number" min="0" value="<?= (int)$referrerPremdays ?>">
			</div>
			<div class="acp-field">
				<label class="acp-label" for="referred_premdays">New account premium days</label>
				<input class="acp-input" id="referred_premdays" name="referred_premdays" type="number" min="0" value="<?= (int)$referredPremdays ?>">
			</div>
		</div>
		<div class="acp-actions">
			<button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save settings</button>
		</div>
	</form>
<?php acp_card_close(); ?>

<?php acp_card_open('Recent Referrals', 'Newest accounts created with referral codes.'); ?>
	<?php if (!is_array($recent) || !$recent): ?>
		<?php acp_empty('No referrals yet.', 'fa-share-alt'); ?>
	<?php else: ?>
		<div class="acp-table-wrap">
			<table class="acp-table">
				<thead>
					<tr>
						<th>Date</th>
						<th>Referrer</th>
						<th>New account</th>
						<th>Code</th>
						<th class="is-num">Points</th>
						<th class="is-num">Premium</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($recent as $row): ?>
					<tr>
						<td><?= date('Y-m-d H:i', (int)$row['created_at']) ?></td>
						<td><?= h($row['referrer_name'] ?: ('#' . (int)$row['referrer_account_id'])) ?></td>
						<td><?= h($row['referred_name'] ?: ('#' . (int)$row['referred_account_id'])) ?></td>
						<td><code><?= h($row['code']) ?></code></td>
						<td class="is-num"><?= (int)$row['referrer_points'] + (int)$row['referred_points'] ?></td>
						<td class="is-num"><?= (int)$row['referrer_premdays'] + (int)$row['referred_premdays'] ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
<?php acp_card_close(); ?>
