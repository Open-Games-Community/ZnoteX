<?php

return array(
	'referral_system.reg_label' => 'Código de indicação',
	'referral_system.title' => 'Indicação',
	'referral_system.lead' => 'Convide um amigo e compartilhe seu código. Vocês dois são recompensados quando ele se registrar.',
	'referral_system.code' => 'Código',
	'referral_system.copy_code' => 'Copiar código',
	'referral_system.link' => 'Link',
	'referral_system.copy_link' => 'Copiar link',
	'referral_system.invited' => 'Você convidou <b>{count}</b> conta(s).',
	'referral_system.copied' => 'Copiado',
);
