<?php

return array(
	'referral_system.reg_label' => 'Código de referido',
	'referral_system.title' => 'Referidos',
	'referral_system.lead' => 'Invita a un amigo y comparte tu código. Ambos recibiréis recompensa cuando se registre.',
	'referral_system.code' => 'Código',
	'referral_system.copy_code' => 'Copiar código',
	'referral_system.link' => 'Enlace',
	'referral_system.copy_link' => 'Copiar enlace',
	'referral_system.invited' => 'Has invitado a <b>{count}</b> cuenta(s).',
	'referral_system.copied' => 'Copiado',
);
