<?php

return array(
	'referral_system.reg_label' => 'Referral code',
	'referral_system.title' => 'Referral',
	'referral_system.lead' => 'Invite a friend and share your code. You both get rewarded when they register.',
	'referral_system.code' => 'Code',
	'referral_system.copy_code' => 'Copy code',
	'referral_system.link' => 'Link',
	'referral_system.copy_link' => 'Copy link',
	'referral_system.invited' => 'You have invited <b>{count}</b> account(s).',
	'referral_system.copied' => 'Copied',
);
