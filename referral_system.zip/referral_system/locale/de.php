<?php

return array(
	'referral_system.reg_label' => 'Empfehlungscode',
	'referral_system.title' => 'Empfehlung',
	'referral_system.lead' => 'Lade einen Freund ein und teile deinen Code. Ihr werdet beide belohnt, wenn er sich registriert.',
	'referral_system.code' => 'Code',
	'referral_system.copy_code' => 'Code kopieren',
	'referral_system.link' => 'Link',
	'referral_system.copy_link' => 'Link kopieren',
	'referral_system.invited' => 'Du hast <b>{count}</b> Konto(s) eingeladen.',
	'referral_system.copied' => 'Kopiert',
);
