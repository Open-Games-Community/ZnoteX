<?php

return array(
	'referral_system.reg_label' => 'Kod polecający',
	'referral_system.title' => 'Polecenia',
	'referral_system.lead' => 'Zaproś znajomego i podziel się swoim kodem. Oboje otrzymacie nagrodę, gdy się zarejestruje.',
	'referral_system.code' => 'Kod',
	'referral_system.copy_code' => 'Kopiuj kod',
	'referral_system.link' => 'Link',
	'referral_system.copy_link' => 'Kopiuj link',
	'referral_system.invited' => 'Zaproszono <b>{count}</b> kont(a).',
	'referral_system.copied' => 'Skopiowano',
);
