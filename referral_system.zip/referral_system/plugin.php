<?php

if (!function_exists('referral_system_h')) {

function referral_system_h($value): string {
	return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function referral_system_setting(string $key, string $default): string {
	return function_exists('setting') ? (string)setting('referral_system:' . $key, $default) : $default;
}

function referral_system_enabled(): bool {
	return referral_system_setting('enabled', '1') === '1';
}

function referral_system_account_id_by_name_or_email(string $name, string $email): int {
	$name = mysql_znote_escape_string($name);
	$email = mysql_znote_escape_string($email);
	$row = mysql_select_single("SELECT `id` FROM `accounts` WHERE `name`='{$name}' OR `email`='{$email}' ORDER BY `id` DESC LIMIT 1;");
	return is_array($row) ? (int)$row['id'] : 0;
}

function referral_system_code_for_account(int $accountId): string {
	if ($accountId <= 0 || !function_exists('znote_table_exists') || !znote_table_exists('znote_referral_codes')) {
		return '';
	}

	$row = mysql_select_single("SELECT `code` FROM `znote_referral_codes` WHERE `account_id`={$accountId} LIMIT 1;");
	if (is_array($row) && !empty($row['code'])) {
		return (string)$row['code'];
	}

	for ($i = 0; $i < 8; $i++) {
		$code = strtoupper(substr(bin2hex(random_bytes(6)), 0, 10));
		$safe = mysql_znote_escape_string($code);
		$now = time();
		$ok = mysql_insert("INSERT IGNORE INTO `znote_referral_codes` (`account_id`, `code`, `created_at`) VALUES ({$accountId}, '{$safe}', {$now});");
		if ($ok !== false) {
			$row = mysql_select_single("SELECT `code` FROM `znote_referral_codes` WHERE `account_id`={$accountId} LIMIT 1;");
			if (is_array($row) && !empty($row['code'])) {
				return (string)$row['code'];
			}
		}
	}

	return '';
}

function referral_system_add_points(int $accountId, int $points): void {
	if ($accountId <= 0 || $points <= 0) {
		return;
	}
	mysql_update("UPDATE `znote_accounts` SET `points` = COALESCE(`points`, 0) + {$points} WHERE `account_id` = {$accountId};");
}

function referral_system_add_premdays(int $accountId, int $days): void {
	if ($accountId <= 0 || $days <= 0 || !function_exists('user_account_add_premdays')) {
		return;
	}
	user_account_add_premdays($accountId, $days);
}

function referral_system_apply_registration(array $data): void {
	if (!referral_system_enabled() || empty($_POST['referral_code'])) {
		return;
	}
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_referral_codes') || !znote_table_exists('znote_referrals')) {
		return;
	}

	$code = strtoupper(trim((string)$_POST['referral_code']));
	$code = preg_replace('/[^A-Z0-9]/', '', $code);
	if ($code === '') {
		return;
	}

	$safeCode = mysql_znote_escape_string($code);
	$ref = mysql_select_single("SELECT `account_id`, `code` FROM `znote_referral_codes` WHERE `code`='{$safeCode}' LIMIT 1;");
	if (!is_array($ref)) {
		return;
	}

	$referrerId = (int)$ref['account_id'];
	$referredId = referral_system_account_id_by_name_or_email((string)($data['name'] ?? ''), (string)($data['email'] ?? ''));
	if ($referrerId <= 0 || $referredId <= 0 || $referrerId === $referredId) {
		return;
	}

	$existing = mysql_select_single("SELECT `id` FROM `znote_referrals` WHERE `referred_account_id`={$referredId} LIMIT 1;");
	if (is_array($existing)) {
		return;
	}

	$ip = function_exists('getIPLong') ? (int)getIPLong() : 0;
	if (referral_system_setting('block_same_ip', '1') === '1') {
		$sameIp = mysql_select_single("SELECT `id` FROM `znote_referrals` WHERE `referrer_account_id`={$referrerId} AND `ip`={$ip} LIMIT 1;");
		if ($ip > 0 && is_array($sameIp)) {
			return;
		}
	}

	$referrerPoints = max(0, (int)referral_system_setting('referrer_points', '25'));
	$referredPoints = max(0, (int)referral_system_setting('referred_points', '10'));
	$referrerPrem = max(0, (int)referral_system_setting('referrer_premdays', '0'));
	$referredPrem = max(0, (int)referral_system_setting('referred_premdays', '0'));
	$now = time();

	mysql_insert("
		INSERT INTO `znote_referrals`
			(`referrer_account_id`, `referred_account_id`, `code`, `ip`, `status`, `referrer_points`, `referred_points`, `referrer_premdays`, `referred_premdays`, `created_at`, `rewarded_at`)
		VALUES
			({$referrerId}, {$referredId}, '{$safeCode}', {$ip}, 'rewarded', {$referrerPoints}, {$referredPoints}, {$referrerPrem}, {$referredPrem}, {$now}, {$now});
	");

	referral_system_add_points($referrerId, $referrerPoints);
	referral_system_add_points($referredId, $referredPoints);
	referral_system_add_premdays($referrerId, $referrerPrem);
	referral_system_add_premdays($referredId, $referredPrem);
}

/**
 * The "Referral" card injected into My Account. Self-contained styling with
 * class hooks (.referral-system-box, .referral-system-btn, …) and a
 * --referral-accent custom property a theme can override in its own CSS.
 * Injected as the first child of #myaccount so it reads as its own block.
 */
function referral_system_myaccount_block(string $code, string $link, int $count): string {
	$css = '.referral-system-box{--referral-accent:#e0a33e;margin:0 0 18px;padding:18px 20px;border:1px solid rgba(148,163,184,.22);border-radius:14px;background:rgba(15,23,42,.55);color:inherit;font-size:14px;line-height:1.55}'
		. '.referral-system-box *{box-sizing:border-box}'
		. '.referral-system-box__title{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:15px;font-weight:700;letter-spacing:.01em}'
		. '.referral-system-box__title::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--referral-accent)}'
		. '.referral-system-box__lead{margin:0 0 14px;opacity:.75;font-size:13px}'
		. '.referral-system-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 10px}'
		. '.referral-system-row:last-of-type{margin-bottom:0}'
		. '.referral-system-label{min-width:74px;opacity:.6;font-size:12px;text-transform:uppercase;letter-spacing:.06em}'
		. '.referral-system-field{flex:1 1 220px;min-width:0;padding:8px 12px;border:1px solid rgba(148,163,184,.28);border-radius:9px;background:rgba(2,6,23,.6);color:inherit;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px}'
		. '.referral-system-code{font-weight:700;letter-spacing:.08em;color:var(--referral-accent)}'
		. '.referral-system-btn{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1px solid rgba(148,163,184,.3);border-radius:9px;background:rgba(148,163,184,.12);color:inherit;font:inherit;font-size:12px;font-weight:600;cursor:pointer;transition:background .15s,border-color .15s,transform .05s;white-space:nowrap}'
		. '.referral-system-btn:hover{background:rgba(148,163,184,.2);border-color:rgba(148,163,184,.45)}'
		. '.referral-system-btn:active{transform:translateY(1px)}'
		. '.referral-system-btn.is-done{background:rgba(34,197,94,.16);border-color:rgba(34,197,94,.4);color:#22c55e}'
		. '.referral-system-btn--primary{background:var(--referral-accent);border-color:var(--referral-accent);color:#1a1200}'
		. '.referral-system-btn--primary:hover{filter:brightness(1.08);background:var(--referral-accent)}'
		. '.referral-system-count{margin:12px 0 0;font-size:13px;opacity:.8}'
		. '.referral-system-count b{color:var(--referral-accent)}';

	$block = '<div id="referralSystemBox" class="referral-system-box">'
		. '<div class="referral-system-box__title">Referral</div>'
		. '<p class="referral-system-box__lead">Invite a friend and share your code &mdash; you both get rewarded when they register.</p>'
		. '<div class="referral-system-row">'
			. '<span class="referral-system-label">Code</span>'
			. '<span class="referral-system-field referral-system-code" id="referralSystemCode">' . $code . '</span>'
			. '<button type="button" class="referral-system-btn referral-system-btn--primary" data-referral-copy="referralSystemCode">Copy code</button>'
		. '</div>'
		. '<div class="referral-system-row">'
			. '<span class="referral-system-label">Link</span>'
			. '<input type="text" class="referral-system-field" id="referralSystemLink" value="' . $link . '" readonly onfocus="this.select()">'
			. '<button type="button" class="referral-system-btn" data-referral-copy="referralSystemLink">Copy link</button>'
		. '</div>'
		. '<p class="referral-system-count">You have invited <b>' . $count . '</b> account(s).</p>'
		. '</div>';

	$js = '(function(){'
		. 'if(document.getElementById("referralSystemBox"))return;'
		. 'if(!document.getElementById("referralSystemCss")){var s=document.createElement("style");s.id="referralSystemCss";s.textContent=' . json_encode($css) . ';document.head.appendChild(s);}'
		. 'var root=document.getElementById("myaccount")||document.querySelector(".ec-content, main, #content, .content");'
		. 'if(!root)return;'
		. 'var w=document.createElement("div");w.innerHTML=' . json_encode($block) . ';var box=w.firstChild;'
		. 'root.insertBefore(box,root.firstChild);'
		. 'box.addEventListener("click",function(e){var b=e.target.closest("[data-referral-copy]");if(!b)return;'
		. 'var el=document.getElementById(b.getAttribute("data-referral-copy"));if(!el)return;'
		. 'var v=el.value!=null?el.value:el.textContent;'
		. 'var done=function(){var t=b.textContent;b.textContent="Copied";b.classList.add("is-done");setTimeout(function(){b.textContent=t;b.classList.remove("is-done");},1600);};'
		. 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(v).then(done,done);}else{try{var ta=document.createElement("textarea");ta.value=v;document.body.appendChild(ta);ta.select();document.execCommand("copy");document.body.removeChild(ta);done();}catch(err){}}'
		. '});'
		. '}());';

	return '<script>' . $js . '</script>';
}

function referral_system_footer(): string {
	if (!referral_system_enabled()) {
		return '';
	}

	$page = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
	if ($page === 'register.php') {
		$ref = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)($_GET['ref'] ?? '')));
		$label = 'Referral code';
		$html = '<li id="referralSystemField"><label>' . referral_system_h($label) . '<br><input type="text" name="referral_code" value="' . referral_system_h($ref) . '" maxlength="32" autocomplete="off"></label></li>';
		return '<script>(function(){var form=document.querySelector("form[action=\'\'][method=\'post\'],form[method=\'post\']");if(!form||document.getElementById("referralSystemField"))return;var submit=form.querySelector("input[type=submit]");var li=document.createElement("li");li.id="referralSystemField";li.innerHTML=' . json_encode(substr($html, strlen('<li id="referralSystemField">'), -5)) . ';if(submit&&submit.parentNode){submit.parentNode.parentNode.insertBefore(li,submit.parentNode);}else{form.appendChild(li);}}());</script>';
	}

	if ($page === 'myaccount.php' && !empty($GLOBALS['session_user_id'])) {
		$accountId = (int)$GLOBALS['session_user_id'];
		$code = referral_system_code_for_account($accountId);
		if ($code === '') {
			return '';
		}

		$countRow = mysql_select_single("SELECT COUNT(*) AS `c` FROM `znote_referrals` WHERE `referrer_account_id`={$accountId};");
		$count = is_array($countRow) ? (int)$countRow['c'] : 0;
		$link = rtrim((string)config('site_url'), '/') . '/register.php?ref=' . rawurlencode($code);

		return referral_system_myaccount_block(referral_system_h($code), referral_system_h($link), $count);
	}

	return '';
}

}

if (function_exists('znote_hook_register') && function_exists('referral_system_apply_registration') && function_exists('referral_system_footer')) {
	znote_hook_register('account.registered', 'referral_system_apply_registration');
	znote_hook_register('page.footer', 'referral_system_footer');
}
