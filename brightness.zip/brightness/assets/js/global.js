document.addEventListener('DOMContentLoaded', () => {
	const nextAll = element => {
		const nextElements = [];

		while (element.nextElementSibling) {
			nextElements.push(element.nextElementSibling);
			element = element.nextElementSibling;
		}

		return nextElements;
	}

	const menu = document.querySelector('.menu-main'),
				more = document.querySelector('.menu-more'),
				subMenu = document.querySelector('.menu-sub'),
				parent = document.querySelector('.menu-wrapper'),
				root = document.documentElement,
				moreWidth = getComputedStyle(root).getPropertyValue('--more-width'),
				moreMargin = getComputedStyle(root).getPropertyValue('--more-margin'),
				menuMargin = getComputedStyle(root).getPropertyValue('--menu-margin');
	
	let windowWidth = window.innerWidth;

	if (!menu || !parent || !more || !subMenu) {
		return;
	}

	const contract = () => {
		let w = 0,
				outerWidth = parent.offsetWidth - (parseInt(moreWidth) + parseInt(moreMargin) + parseInt(menuMargin) + 30);

		let menuItems = menu.querySelectorAll('li');

		for (let i = 0; i < menuItems.length; i++) {
			w += menuItems[i].offsetWidth;

			if (w > outerWidth) {
				let nextElements = nextAll(menuItems[i - 1]);

				let nextReverse = nextElements.reverse();

				nextReverse.forEach(el => {
					el.remove();
					subMenu.prepend(el);
				});

				break;
			}
		}
	};

	const expand = () => {
		let w = 0,
				outerWidth = parent.offsetWidth - (parseInt(moreWidth) + parseInt(moreMargin) + parseInt(menuMargin) + 30);

		let menuItems = menu.querySelectorAll('li');
		menuItems.forEach(el => {
			w += el.offsetWidth;
		});

		let submenuItems = subMenu.querySelectorAll('li');
		for (let i = 0; i < submenuItems.length; i++) {
			w += submenuItems[i].offsetWidth;
			if (w > outerWidth) {
				let a = 0;

				while(a < i) {
					submenuItems[a].remove();
					menu.appendChild(submenuItems[a]);

					a++;
				}

				break;
			}
		}

		if (submenuItems.length > 0) {
			let lastOffset = submenuItems[submenuItems.length - 1].offsetWidth;

			if ((menu.offsetWidth + lastOffset) <= outerWidth) {
				submenuItems[submenuItems.length - 1].remove();
				menu.appendChild(submenuItems[submenuItems.length - 1]);
			}
		}
	};

	const checkActive = () => {
		if (subMenu.querySelectorAll('li').length) {
			more.classList.add('active');
		} else {
			more.classList.remove('active');
		}
	};

	contract();
	checkActive();
	
	window.addEventListener('resize', () => {
		(window.innerWidth > windowWidth) ? expand() : contract();
		windowWidth = window.innerWidth;
		checkActive();
	});
});


$('.btn-tab').click(function(){
	$('.btn-tab').removeClass('active');
	$(this).addClass('active');
	$('.btn-block').removeClass('active');
	$('#'+$(this).attr('data-tab')).addClass('active');
  })
  
  // Click Drop Blocks — delegated so the mobile navigation remains reliable
  // even when the header is rendered/replaced after the initial script parse.
$(document).off('click.brightnessDrop', '.btn-drop').on('click.brightnessDrop', '.btn-drop', function(e){
	e.preventDefault();
	e.stopPropagation();

	var $trigger = $(this);
	var targetClass = $trigger.attr('data-class');
	if (!targetClass) {
		return;
	}

	var $target = $('.' + targetClass);
	var opening = !$target.hasClass('active');
	$trigger.toggleClass('active', opening);
	$target.toggleClass('active', opening);

	if ($trigger.hasClass('btn-mobile')) {
		$('body').toggleClass('brightness-mobile-nav-open', opening);
	}
});

$(document).on('click.brightnessDropClose', '.mobile-menu a', function(){
	$('.btn-mobile.btn-drop').removeClass('active');
	$('.topPanel-left').removeClass('active');
	$('body').removeClass('brightness-mobile-nav-open');
});


// brightness mobile navigation portal.
// The hero stage is an isolated/overflow-hidden stacking context. Moving the
// fixed mobile trigger and off-canvas panel to <body> keeps them above the
// content after the hero background ends, while restoring the original DOM
// positions automatically on desktop.
$(function(){
    var button = document.querySelector('.btn-mobile.btn-drop');
    var panel = document.querySelector('.topPanel-left');
    if (!button || !panel || !button.parentNode || !panel.parentNode) {
        return;
    }

    var buttonAnchor = document.createComment('brightness-mobile-button-anchor');
    var panelAnchor = document.createComment('brightness-mobile-panel-anchor');
    button.parentNode.insertBefore(buttonAnchor, button);
    panel.parentNode.insertBefore(panelAnchor, panel);

    function restoreAfter(anchor, element){
        if (!anchor || !anchor.parentNode || !element) return;
        anchor.parentNode.insertBefore(element, anchor.nextSibling);
    }

    function syncbrightnessMobileNavigationPortal(){
        var mobile = window.matchMedia && window.matchMedia('(max-width: 1080px)').matches;
        if (mobile) {
            if (panel.parentNode !== document.body) document.body.appendChild(panel);
            if (button.parentNode !== document.body) document.body.appendChild(button);
        } else {
            restoreAfter(buttonAnchor, button);
            restoreAfter(panelAnchor, panel);
            button.classList.remove('active');
            panel.classList.remove('active');
            document.body.classList.remove('brightness-mobile-nav-open');
        }
    }

    syncbrightnessMobileNavigationPortal();
    window.addEventListener('resize', syncbrightnessMobileNavigationPortal);
});
  
  $(".buttonDrop").click(function(){
	$(this).toggleClass("active");
	$('.'+$(this).attr('data-class')).slideToggle(400);
});

$(document).on('click', function(e) {
	if (!$(e.target).closest(".parent_block").length) {
	  $('.toggled_block').hide();
	}
	if (!$(e.target).closest(".parent_block_account").length) {
	  $('.toggled_block_account').hide();
	}
	e.stopPropagation();
});


//Tabs
(function($) {
	$(function() {
	  $("ul.tabs-caption").on("click", "li:not(.active)", function() {
		$(this)
		  .addClass("active")
		  .siblings()
		  .removeClass("active")
		  .closest("div.tabs")
		  .find("div.tabs-content")
		  .removeClass("active")
		  .eq($(this).index())
		  .addClass("active");
	  });
	});
})(jQuery);

$(document).ready(function() { 
	var overlay = $('#overlay'); 
	var open_modal = $('.open_modal'); 
	var close = $('.modal_close, #overlay'); 
	var modal = $('.modal_div'); 
  
	 open_modal.click( function(event){ 
		 event.preventDefault(); 
		 var div = $(this).attr('href'); 
		 overlay.fadeIn(400, 
			 function(){ 
				 $(div) 
					 .css('display', 'block') 
					 .animate({opacity: 1, top: '10%'}, 200); 
		 });
	 });
  
	 close.click( function(){ 
			modal 
			 .animate({opacity: 0, top: '15%'}, 200, 
				 function(){ 
					 $(this).css('display', 'none');
					 overlay.fadeOut(400); 
				 }
			 );
	 });
});

/* brightness common UI tooltips.
 * Normal web title hints use a standalone tooltip host and NEVER reuse
 * #tooltip, which belongs to MU item/game tooltips. This prevents size/style
 * leakage between normal navigation/footer hints and item tooltip rendering. */
(function ($) {
    'use strict';

    var TOOLTIP_DATA = 'data-brightness-tooltip';
    var tooltipEl = null;
    var activeTarget = null;

    function isbrightnessPublicTheme() {
        return document.body && document.body.classList.contains('brightness-v3-theme');
    }

    function isItemTooltipTarget(element) {
        var $element = $(element);
        if ($element.is('[data-info], [data-info2], .item-slot, .flame-muun-tooltip-item, .flame-pet-tooltip-item, .artifactIcon')) {
            return true;
        }
        return $element.closest('#tooltip, #flame-mobile-item-tooltip, #inventory, #inventoryc, .wh_items, .flame-extra-equipment-info, .item_info').length > 0;
    }

    function ensureTooltip() {
        if (tooltipEl) return tooltipEl;
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'brightness-ui-tooltip';
        tooltipEl.className = 'brightness-ui-tooltip-popover';
        tooltipEl.setAttribute('role', 'tooltip');
        tooltipEl.setAttribute('aria-hidden', 'true');
        document.body.appendChild(tooltipEl);
        return tooltipEl;
    }

    function prepareTarget(element) {
        if (!element || element.nodeType !== 1 || isItemTooltipTarget(element)) return;
        var title = element.getAttribute('title');
        if (!title || !title.trim()) return;

        if (!element.getAttribute('aria-label') && !element.getAttribute('aria-labelledby')) {
            element.setAttribute('aria-label', title);
        }
        element.setAttribute(TOOLTIP_DATA, title.trim());
        element.removeAttribute('title');
    }

    function prepareTooltips(root) {
        if (!isbrightnessPublicTheme()) return;
        var scope = root && root.nodeType === 1 ? root : document;
        if (scope.nodeType === 1 && scope.hasAttribute('title')) prepareTarget(scope);
        var nodes = scope.querySelectorAll ? scope.querySelectorAll('[title]') : [];
        for (var i = 0; i < nodes.length; i++) prepareTarget(nodes[i]);
    }

    function closestTarget(node) {
        if (!node || node.nodeType !== 1) return null;
        var target = node.closest('[' + TOOLTIP_DATA + ']');
        return target && !isItemTooltipTarget(target) ? target : null;
    }

    function positionTooltip(target) {
        if (!target || !tooltipEl) return;
        var rect = target.getBoundingClientRect();
        var tipRect = tooltipEl.getBoundingClientRect();
        var viewportWidth = document.documentElement.clientWidth;
        var viewportHeight = document.documentElement.clientHeight;
        var gap = 9;
        var edge = 8;

        var left = rect.left + (rect.width - tipRect.width) / 2;
        left = Math.max(edge, Math.min(left, viewportWidth - tipRect.width - edge));

        var top = rect.top - tipRect.height - gap;
        var placement = 'top';
        if (top < edge) {
            top = rect.bottom + gap;
            placement = 'bottom';
        }
        if (top + tipRect.height > viewportHeight - edge) {
            top = Math.max(edge, viewportHeight - tipRect.height - edge);
        }

        tooltipEl.style.left = Math.round(left) + 'px';
        tooltipEl.style.top = Math.round(top) + 'px';
        tooltipEl.setAttribute('data-placement', placement);
    }

    function isMobileNavigationTooltipTarget(target) {
        if (!target || !window.matchMedia || !window.matchMedia('(max-width: 1080px)').matches) return false;
        return !!target.closest('.mobile-menu, .topPanel-left, .btn-mobile, .brightness-nav-brand');
    }

    function showTooltip(target) {
        if (isMobileNavigationTooltipTarget(target)) {
            hideTooltip(target);
            return;
        }
        var text = target && target.getAttribute(TOOLTIP_DATA);
        if (!text) return;
        var tip = ensureTooltip();
        activeTarget = target;
        tip.textContent = text;
        tip.setAttribute('aria-hidden', 'false');
        tip.classList.add('is-visible');
        positionTooltip(target);
        requestAnimationFrame(function () {
            if (activeTarget === target) positionTooltip(target);
        });
    }

    function hideTooltip(target) {
        if (!tooltipEl || (target && activeTarget && target !== activeTarget)) return;
        activeTarget = null;
        tooltipEl.classList.remove('is-visible');
        tooltipEl.setAttribute('aria-hidden', 'true');
    }

    $(function () {
        if (!isbrightnessPublicTheme()) return;
        prepareTooltips(document);
        ensureTooltip();

        document.addEventListener('mouseover', function (event) {
            var target = closestTarget(event.target);
            if (!target || (event.relatedTarget && target.contains(event.relatedTarget))) return;
            showTooltip(target);
        }, true);

        document.addEventListener('mouseout', function (event) {
            var target = closestTarget(event.target);
            if (!target || (event.relatedTarget && target.contains(event.relatedTarget))) return;
            hideTooltip(target);
        }, true);

        document.addEventListener('focusin', function (event) {
            var target = closestTarget(event.target);
            if (target) showTooltip(target);
        });

        document.addEventListener('focusout', function (event) {
            var target = closestTarget(event.target);
            if (target) hideTooltip(target);
        });

        window.addEventListener('scroll', function () {
            if (activeTarget) positionTooltip(activeTarget);
        }, true);
        window.addEventListener('resize', function () {
            if (activeTarget && isMobileNavigationTooltipTarget(activeTarget)) {
                hideTooltip(activeTarget);
                return;
            }
            if (activeTarget) positionTooltip(activeTarget);
        });

        $(document).ajaxComplete(function () {
            prepareTooltips(document);
        });

        if (window.MutationObserver && document.body) {
            new MutationObserver(function (mutations) {
                for (var i = 0; i < mutations.length; i++) {
                    var mutation = mutations[i];
                    if (mutation.type === 'attributes' && mutation.attributeName === 'title') {
                        prepareTarget(mutation.target);
                    }
                    for (var j = 0; j < mutation.addedNodes.length; j++) {
                        if (mutation.addedNodes[j].nodeType === 1) prepareTooltips(mutation.addedNodes[j]);
                    }
                }
            }).observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['title']
            });
        }
    });
})(jQuery);
