/* Brightness theme - front-end behaviour.
   Vanilla replacements for the parts of the FlameCMS app.js this theme needs:
   the mobile nav, the opening countdown, the sidebar clock and the login
   modal. The original site API / analytics / validation engine were dropped. */
(function () {
	'use strict';

	// ---- mobile nav --------------------------------------------------
	var navToggle = document.querySelector('[data-b-nav-toggle]');
	var mobileMenu = document.querySelector('[data-b-mobile-menu]');
	var topLeft = document.querySelector('.topPanel-left');
	if (navToggle) {
		navToggle.addEventListener('click', function () {
			navToggle.classList.toggle('active');
			if (topLeft) topLeft.classList.toggle('active');
			if (mobileMenu) mobileMenu.classList.toggle('active');
			document.body.classList.toggle('brightness-mobile-nav-open');
		});
	}

	// ---- mobile drawer submenu toggles ---------------------------
	document.querySelectorAll('.mobile-menu .b-sub-toggle').forEach(function (btn) {
		btn.addEventListener('click', function (e) {
			e.preventDefault();
			var li = btn.closest('li.has-sub');
			if (li) li.classList.toggle('open');
		});
	});
	// on touch devices the desktop hover dropdown never opens - let a tap on a
	// parent link open it instead of navigating (second tap follows the link)
	document.querySelectorAll('.menu-main .menu__item.has-sub > .menu__link').forEach(function (a) {
		a.addEventListener('click', function (e) {
			if (window.matchMedia('(hover: none)').matches) {
				var li = a.parentNode;
				if (!li.classList.contains('is-tapped')) {
					e.preventDefault();
					document.querySelectorAll('.menu-main .menu__item.is-tapped').forEach(function (o) { if (o !== li) o.classList.remove('is-tapped'); });
					li.classList.add('is-tapped');
				}
			}
		});
	});

	// ---- login modal ----------------------------------------------
	var modal = document.getElementById('enter');
	var overlay = document.getElementById('overlay');
	function openModal(e) { if (modal) { e.preventDefault(); modal.classList.add('active'); if (overlay) overlay.classList.add('active'); } }
	function closeModal() { if (modal) { modal.classList.remove('active'); if (overlay) overlay.classList.remove('active'); } }
	document.querySelectorAll('[data-b-modal="enter"]').forEach(function (a) { a.addEventListener('click', openModal); });
	document.querySelectorAll('[data-b-modal-close]').forEach(function (a) { a.addEventListener('click', closeModal); });
	if (overlay) overlay.addEventListener('click', closeModal);
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

	// ---- opening countdown --------------------------------------
	var cd = document.getElementById('brightness_opening_countdown');
	if (cd && cd.getAttribute('data-b-countdown')) {
		var target = parseInt(cd.getAttribute('data-b-countdown'), 10) * 1000;
		var elDays = document.getElementById('days'),
			elHours = document.getElementById('hours'),
			elMin = document.getElementById('minutes'),
			elSec = document.getElementById('seconds');
		var pad = function (n) { return (n < 10 ? '0' : '') + n; };
		var tick = function () {
			var left = target - Date.now();
			if (left <= 0) { cd.style.display = 'none'; clearInterval(timer); return; }
			var s = Math.floor(left / 1000);
			if (elDays) elDays.textContent = Math.floor(s / 86400);
			if (elHours) elHours.textContent = pad(Math.floor(s % 86400 / 3600));
			if (elMin) elMin.textContent = pad(Math.floor(s % 3600 / 60));
			if (elSec) elSec.textContent = pad(s % 60);
		};
		tick();
		var timer = setInterval(tick, 1000);
	}

	// ---- sidebar clock ------------------------------------------
	var clock = document.querySelector('[data-b-clock]');
	if (clock) {
		var epoch = parseInt(clock.getAttribute('data-server-epoch'), 10) * 1000 || Date.now();
		var tz = clock.getAttribute('data-server-timezone') || 'UTC';
		var offset = Date.now() - epoch;
		var st = document.getElementById('ServerTime'), lt = document.getElementById('LocalTime');
		var fmt = function (d, opts) {
			try { return new Intl.DateTimeFormat([], opts).format(d); } catch (e) { return d.toTimeString().slice(0, 5); }
		};
		var run = function () {
			var now = new Date();
			if (st) st.textContent = fmt(new Date(now.getTime() - offset), { hour: '2-digit', minute: '2-digit', timeZone: tz });
			if (lt) lt.textContent = fmt(now, { hour: '2-digit', minute: '2-digit' });
		};
		run();
		setInterval(run, 1000 * 20);
	}
})();
