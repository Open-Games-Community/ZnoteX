/* 
 * JavaScript classes for CMS
 * Author: privatemuo@gmail.com
 *
 */

var App = {
	user_info: [],
	nameRegex: /^[0-9a-zA-Z_-]+$/,
	lc: null,
	item_slot: -1,
	first: true,
	page: false,
	clicks: 0,
	login: 0,
	isfirst: false,
	events_time: [],
	eventTooltipReady: false,
	eventTooltipElement: null,
	eventTooltipActiveId: null,
	eventTooltipMinuteKey: null,
	isSending: false,
	loginSending: false,
	securityRefreshStarted: false,
	loginType: 1,
	ajaxLocks: {},
	voteRewardTimers: {},
	voteRewardTimerInterval: null,
	voteRewardValidationTimers: {},
	voteRewardValidationRequests: {},
	voteRewardTabId: '',
	voteRewardStoragePrefix: 'flameVoteReward:',
	voteRewardStorageEventsBound: false,
	flameSelectGlobalEventsBound: false,
	loaderShowTimer: null,
	loaderDelay: 2000,
	ajaxLock: function (key) {
		if (App.ajaxLocks[key]) {
			return false;
		}
		App.ajaxLocks[key] = true;
		return true;
	},
	ajaxUnlock: function (key) {
		if (App.ajaxLocks[key]) {
			delete App.ajaxLocks[key];
		}
	},
	rankingTemplateVersion: (new Date()).getTime(),
	rankingTemplateCachePatchDone: false,
	isRankingTemplateUrl: function (url) {
		return (typeof url == 'string'
			&& url.indexOf('/js_templates/') !== -1
			&& url.indexOf('.ejs') !== -1
			&& (url.indexOf('/js_templates/rank_') !== -1 || url.indexOf('/js_templates/sidebar_rank_') !== -1));
	},
	addRankingTemplateVersion: function (url) {
		if (!App.isRankingTemplateUrl(url)) {
			return url;
		}

		url = url.replace(/([?&])flame_tpl_v=[^&]*/g, '');
		url = url.replace(/[?&]$/, '');

		return url + (url.indexOf('?') === -1 ? '?' : '&') + 'flame_tpl_v=' + App.rankingTemplateVersion;
	},
	patchRankingTemplateCache: function () {
		if (App.rankingTemplateCachePatchDone) {
			return;
		}

		App.rankingTemplateCachePatchDone = true;

		if (typeof jQuery != 'undefined' && typeof $.ajaxPrefilter == 'function') {
			$.ajaxPrefilter(function (options) {
				if (!options || typeof options.url != 'string' || !App.isRankingTemplateUrl(options.url)) {
					return;
				}

				options.url = App.addRankingTemplateVersion(options.url);
				options.cache = false;
			});
		}

		if (window.XMLHttpRequest) {
			var xhrOpen = XMLHttpRequest.prototype.open;
			XMLHttpRequest.prototype.open = function (method, url) {
				if (App.isRankingTemplateUrl(url)) {
					arguments[1] = App.addRankingTemplateVersion(url);
				}

				return xhrOpen.apply(this, arguments);
			};
		}
	},
	initialize: function () {
		App.ajaxSetup();
		App.patchRankingTemplateCache();
		App.configureValidationEngine();
		App.showStoredNotice();
		App.initializeFlameSelects();


		$(document)
			.off('submit.flameLogin', '#login_form')
			.on('submit.flameLogin', '#login_form', function (e) {
				e.preventDefault();
				e.stopPropagation();
				App.setUserInfo([$('#login_input').val(), $('#password_input').val()]);
				App.loginType = 1;
				App.loginAccount();
				return false;
			});
		
		$(document)
			.off('submit.flameLoginPage', '#login_form_page')
			.on('submit.flameLoginPage', '#login_form_page', function (e) {
				e.preventDefault();
				e.stopPropagation();
				App.setUserInfo([$('#login_input_page').val(), $('#password_input_page').val()]);
				App.loginType = 2;
				App.loginAccount();
				return false;
			});

		$("#password_change_form").validationEngine('attach', {
			scroll: false,
			onValidationComplete: function (form, status) {
				if (status == true) {
					App.changePass(form);
				}
			}
		});

		$("#email_change_form").validationEngine('attach', {
			scroll: false,
			onValidationComplete: function (form, status) {
				if (status == true) {
					App.changeEmail(form);
				}
			}
		});

		$("#set_new_email_form").validationEngine('attach', {
			scroll: false,
			onValidationComplete: function (form, status) {
				if (status == true) {
					App.setNewEmail(form);
				}
			}
		});

		$(".tabrow li").on('click', function () {
			$(this).addClass("selected").siblings().removeClass("selected");
			var id = $(this).parent().parent().find("li").index(this);
			$(this).parent().parent().parent().find(".rankings").css({
				display: "none"
			}).eq(id).css({
				display: "block"
			});
		});
		$('a[id^="lang_"]').on("click", function (e) {
			e.preventDefault();
			var lang = $(this).attr("id").split('_').slice(1).join('_');
			App.switchLanguage(lang);
		});
		$('a[id^="theme_"]').on("click", function (e) {
			e.preventDefault();
			var theme = $(this).attr("id").split('_').slice(1).join('_');
			App.switchTheme(theme);
		});
		$('div[id^="rankings_select_"] a').each(function () {
			$(this).on("click", function (e) {
				var href = $.trim($(this).attr("href"));
				if (href.indexOf("javascript:") !== -1) {
					e.preventDefault();
					var rankings = $(this).attr("id").split("_")[0],
						server = $(this).attr("id").split("_").slice(2).join('_');
					App.populateRanking(rankings, server);
				}
			});
		});
		$('a[id^="switch_top_"]').on("click", function (e) {
			e.preventDefault();
			var count = $(this).attr('data-count'),
				rank = $(this).attr('id').split('_')[2],
				server = $(this).attr('id').split('_').slice(3).join('_');
			App.populateSidebarRanking(rank, server, count);
		});

		$('button[id^="vote-"]').on('click', function () {
			App.vote($(this));
		});
		App.initVoteRewardTimers();
		$('a[id^="reset-char-"]').on('click', function (e) {
			e.preventDefault();
			App.resetCharacter($(this).attr("id").split("-")[2], 0);
		});
		$('a[id^="resetvip-char-"]').on('click', function (e) {
			e.preventDefault();
			App.resetCharacter($(this).attr("id").split("-")[2], 1);
		});
		$('a[id^="greset-char-"]').on('click', function (e) {
			e.preventDefault();
			App.gresetCharacter($(this).attr("id").split("-")[2]);
		});
		$('a[id^="reset-stats-char-"]').on('click', function (e) {
			e.preventDefault();
			var character = $(this).attr("id").split("-")[3];
			if (parseInt($('#new-stats-' + character).text()) == 0) {
				App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Your stats are already reseted.').fetch());
			}
			else {
				if (App.confirmMessage(App.lc.translate('This Function Will Transfer All Yout Stats To Free Points. Are you sure?').fetch())) {
					App.resetStats(character);
				}
			}
		});

		$('a[id^="reset-skilltree-char-"]').on('click', function (e) {
			e.preventDefault();
			if (App.confirmMessage(App.lc.translate('This Function Will Reset Your SkillTree. Are you sure?').fetch())) {
				App.resetSkillTree($(this).attr("id").split("-")[3]);
			}
		});
		$('a[id^="pkclear-char-"]').on('click', function (e) {
			e.preventDefault();
			App.pkClear($(this).attr("id").split("-")[2]);
		});
		$("#add_stats").validationEngine({scroll: false});

		$('a[id^="shop_item_title_"],img[id^="vote_image_"], a[id^="ref-reward-"], a[id^="level-reward-"]').each(function () {
			App.initializeTooltip($(this), false);
		});

		App.initializeModalBoxes();

		$('button[id^="buy_paypal_"]').on('click', function () {
			var div_data = $(this).attr('id').split('_'),
				reward = $('#reward_' + div_data[2]).text(),
				price = $('#price_' + div_data[2]).data("price-tax"),
				currency = $('#currency_' + div_data[2]).text();
			App.submit_paypal(div_data[2], reward, price, currency, div_data[3]);
		});

		$('button[id^="buy_paycall_"]').on('click', function () {
			App.submit_paycall($(this).attr('id').split('_')[2]);
		});

		var option_buttons_selector = $('#option_buttons'),
			sell_item_selector = $('#sell_item');

		$('.wh_items div[id^="item-slot-"]').on('mousedown', function (e) {
			App.item_slot = $(this).attr('id').split('-')[2];
			switch (e.which) {
				case 1:
					if (option_buttons_selector.is(":visible") == false) {
						option_buttons_selector.toggleClass("d-none");
						if (sell_item_selector.is(":visible") == true) {
							sell_item_selector.slideToggle('slow');
							$('#sell_item_form').get(0).reset();
						}
					}
					else if (option_buttons_selector.is(":visible") == true) {
						if (sell_item_selector.is(":visible") == true) {
							sell_item_selector.slideToggle('slow');
							$('#sell_item_form').get(0).reset();
						}
					}
					break;
				case 3:
					App.deleteItem();
					break;
			}
		});

		$('#sell_item_show').on('click', function () {
			if (sell_item_selector.is(":visible") == false) {
				sell_item_selector.slideToggle('slow');
			}

		});

		$('#sell_item_button').on('click', function (e) {
			e.preventDefault();
			App.sellItem($('#sell_item_form'));
		});

		$('#move_to_web_wh').on('click', function () {
			App.moveItemToWeb();
			if (sell_item_selector.is(":visible") == true) {
				sell_item_selector.slideToggle('slow');
				$('#sell_item_form').get(0).reset();
			}
		});

		$('a[id^="move_to_game_wh_"]').on('click', function (e) {
			e.preventDefault();
			App.moveItemToGame($(this).attr('data-id'));
		});

		$('#clear_inv_button').on('click', function (e) {
			e.preventDefault();
			App.clearInventory($('#clear_inventory_form'));
		});

		$('#buy_level_button').on('click', function (e) {
			e.preventDefault();
			App.buyLevel($('#buy_level_form'));
		});

		$('#buy_points_button').on('click', function (e) {
			e.preventDefault();
			App.buyPoints($('#buy_stats_form'));
		});

		$('#buy_gm_button').on('click', function (e) {
			e.preventDefault();
			App.buyGM($('#buy_gm_form'));
		});

		$('#select_char').on('change', function (e) {
			e.preventDefault();
			App.loadClassList($(this).val());
		});

		$('#buy_class_form').on('submit', function (e) {
			e.preventDefault();
			App.buyClass($(this));
		});

		$('#buy_class_button').on('click', function (e) {
			e.preventDefault();
			if ($(this).attr('aria-disabled') == 'true') {
				return false;
			}
			$('#buy_class_form').trigger('submit');
		});

		$('#switch_server').on('change', function () {
			if ($(this).val() != '') {
				App.switchServer($(this).val());
			}
		});
		$('#hide_chars_pk').on('click', function () {
			App.hideCharsPK();
		});
		$('#exchange_wcoins').on('click', function (e) {
			e.preventDefault();
			App.exchangeWCoins($('#credits').val());
		});

		$('a[id^="switch_items_"]').on('click', function (e) {
            var server = $(this).attr('id').split('_').slice(2).join('_'), 
                count = $(this).attr('data-count'),
                limit = $(this).attr('data-limit')
			e.preventDefault();
			App.loadLatestItems(server, count, limit);
		});

		$('ul.wallpapers li, ul.screens li').each(function () {
			$(this).hover(function () {
				$('img', this).fadeToggle(1000);
				$(this).find('.gallery-controls').remove();
				$(this).append('<div class="well gallery-controls"><p><a href="#" class="img-download btn">Download</a></p></div>');
				$(this).find('.gallery-controls').stop().animate({'margin-top': '-1'}, 400, 'easeInQuint');
			}, function () {
				$('img', this).fadeToggle(1000);
				$(this).find('.gallery-controls').stop().animate({'margin-top': '-30'}, 200, 'easeInQuint', function () {
					$(this).remove();
				});
			});
		});

		$('.thumbnails').on('click', '.img-download', function (e) {
			e.preventDefault();
			App.downloadImage($(this));
		});

		var rotate = setInterval(function () {
			App.rotateBanner();
		}, 5000);

		$(".rollingIcon button").on('click', function () {
			$("#col1").find(".items").animate({"left": $(this).attr("data-pic") * -617 + "px"}, 500);
			$(".rollingIcon button").removeClass();
			$(this).addClass("active");
			clearInterval(rotate);
		});

		serverTime.init("ServerTime", "LocalTime");

		$('#make_bet').on('click', function (e) {
			e.preventDefault();
			App.makeBet($('#auction_form').serialize());
		});

		$('button[id^="changename-"]').on("click", function () {
			var oldN = $(this).attr("id").split("-")[1],
				newN = $('#charname-'+oldN).val();
			App.changeName(oldN, newN);
		});
	},
	configureValidationEngine: function () {
		// ValidationEngine prompts are used on registration, account settings and service forms.
		// Desktop: keep the tooltip on the right side of the field, aligned inside the form.
		// Mobile: use inline prompts so errors do not cover inputs on small screens.
		if (typeof jQuery == 'undefined' || typeof $.validationEngine == 'undefined' || !$.validationEngine.defaults) {
			return;
		}

		var isMobileValidation = (window.matchMedia && window.matchMedia('(max-width: 767px)').matches) || $(window).width() <= 767;
		$.validationEngine.defaults.promptPosition = isMobileValidation ? 'inline' : 'topRight:-350,0';
		$.validationEngine.defaults.autoPositionUpdate = true;
	},

	ajaxSetup: function () {
		$.ajaxSetup({
			type: 'POST',
			dataType: 'json',
			error: function (jqXHR, exception) {
				if (jqXHR.status == 404) {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Requested page not found. [404]').fetch());
				}
				else if (jqXHR.status == 500) {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Internal Server Error [500]').fetch());
				}
				else if (exception === 'parsererror') {
					App.handleAjaxParserError(jqXHR);
				}
				else if (exception === 'timeout') {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Time out error.').fetch());
				}
				else if (exception === 'abort') {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Ajax request aborted.').fetch());
				}
			}
		});
		$(document).ajaxSuccess(function () {
			$('#exception').fadeOut();
		});
	},
	isHyperFilterResponse: function (text) {
		text = String(text || '');

		if (text == '') {
			return false;
		}

		return (
			(text.indexOf('__HFUID') !== -1
				|| text.indexOf('/hf-sys/') !== -1
				|| text.indexOf('hf-lib.php') !== -1
				|| text.indexOf('hf-help.php') !== -1
				|| text.indexOf('Protected by HyperFilter') !== -1)
			&& /<\/?(html|head|body|script)[\s>]/i.test(text)
		);
	},
	refreshAfterSecurityCheck: function () {
		if (App.securityRefreshStarted) {
			return;
		}

		App.securityRefreshStarted = true;
		App.loginSending = false;
		App.isSending = false;
		App.hideLoader();
		$('#exception').hide().empty();

		window.setTimeout(function () {
			window.location.reload();
		}, 650);

		App.notice(
			App.lc.translate('Security check').fetch(),
			'error',
			App.lc.translate('Security check expired. Refreshing page.').fetch(),
			true
		);
	},
	handleAjaxParserError: function (jqXHR) {
		var text = (jqXHR && typeof jqXHR.responseText != 'undefined') ? $.trim(String(jqXHR.responseText)) : '',
			parsed = null,
			plainText = '';

		if (text != '') {
			if (App.isHyperFilterResponse(text)) {
				App.refreshAfterSecurityCheck();
				return;
			}

			try {
				parsed = JSON.parse(text);
			}
			catch (e) {
				parsed = null;
			}

			if (parsed && parsed.error) {
				App.notice(App.lc.translate('Error').fetch(), 'error', parsed.error);
				return;
			}
			if (parsed && parsed.success) {
				App.notice(App.lc.translate('Success').fetch(), 'success', parsed.success);
				return;
			}

			plainText = $('<div>').html(text).text();
			plainText = $.trim(plainText.replace(/\s+/g, ' '));
			if (plainText != '') {
				if (/<\/?(html|head|body|title|script)[\s>]/i.test(text) || plainText.length > 700) {
					if (window.console && console.error) {
						console.error('Invalid AJAX response:', text);
					}
					$('#exception').hide().empty();
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Server returned an invalid response. Please try again.').fetch());
					return;
				}
				App.trowJsException(text);
				return;
			}
		}

		$('#exception').hide().empty();
		App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Server returned an invalid response. Please try again.').fetch());
	},
	trowJsException: function (text) {
		var exception = $('#exception'),
			container = $('#container'),
			cleanText = $.trim(String(text || ''));

		if (cleanText == '') {
			exception.hide().empty();
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Server returned an empty response. Please try again.').fetch());
			return;
		}

		exception.html(cleanText);
		if (container.find("p").length != 0) {
			exception.html(container.find("p").text()).fadeIn();
		}
		else {
			exception.find('br').remove();
			if ($.trim(exception.text()) == '') {
				exception.hide().empty();
				App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Server returned an invalid response. Please try again.').fetch());
				return;
			}
			exception.fadeIn();
		}

	},
	initLocalization: function(){
		App.lc = new Jed({
			'locale_data': App.locale,
			'domain': 'messages'
		});
	},
	showLoader: function () {
		if (App.loaderShowTimer !== null || $('#loading').is(':visible')) {
			return;
		}

		App.loaderShowTimer = window.setTimeout(function () {
			App.loaderShowTimer = null;
			$('#loading').stop(true, true).fadeIn(200);
		}, App.loaderDelay);
	},
	hideLoader: function () {
		if (App.loaderShowTimer !== null) {
			window.clearTimeout(App.loaderShowTimer);
			App.loaderShowTimer = null;
		}

		$('#loading').stop(true, true).fadeOut(150);
	},
	setUserInfo: function (params) {
		App.user_info[0] = params[0];
		App.user_info[1] = params[1];
	},
	loginAccount: function () {
		var $serverSelect = $('#switch_server'),
			serverValue = '';

		$('#exception').hide().empty();

		if ($.trim(App.user_info[0] || '') == '') {
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Please enter username.').fetch());
			return false;
		}

		if ($.trim(App.user_info[1] || '') == '') {
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Please enter password.').fetch());
			return false;
		}

		if ($serverSelect.length == 0) {
			if ($('#server').length > 0) {
				App.loginUser($('#server option:selected').val());
			}
			else {
				App.loginUser();
			}
			return false;
		}

		App.login = 1;
		serverValue = $.trim(String($serverSelect.val() || ''));

		// If there is only one real server option, login directly instead of opening the modal.
		if ($serverSelect.find('option:not(:disabled)').filter(function () { return $.trim(String($(this).val())) != ''; }).length <= 1 && serverValue != '') {
			App.loginUser(serverValue);
			return false;
		}

		App.openLoginServerSelect();
		return false;
	},
	openLoginServerSelect: function () {
		var $serverClick = $('#server_click'),
			$modal = $('#select_server');

		if ($serverClick.length) {
			$serverClick.trigger('click');
		}

		// Safety fallback: if the modal plugin did not bind for any reason, still show the server chooser instead of allowing a page refresh.
		setTimeout(function () {
			if (!$modal.length || $modal.is(':visible')) {
				return;
			}
			$modal.css({display: 'block', position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 10000});
			if (!$('#lean_overlay').length) {
				$('<div id="lean_overlay"></div>').css({display: 'block', position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', opacity: 0.7, zIndex: 9999}).appendTo(document.body);
			}
			else {
				$('#lean_overlay').css({display: 'block', position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: 9999}).show();
			}
		}, 120);
	},
	loginUser: function (data) {
		var dataToSend = {};

		dataToSend.username = App.user_info[0];
		dataToSend.password = App.user_info[1];
		dataToSend.ajax = 1;

		if (typeof(data) != "undefined" && $.trim(String(data)) != '') {
			dataToSend.server = data;
		}

		if(App.loginType == 1){
			if(typeof($("#captcha_input").val()) != "undefined"){
				dataToSend.captcha = $("#captcha_input").val();
			}
		}
		if(App.loginType == 2){
			if(typeof($("#captcha_input_page").val()) != "undefined"){
				dataToSend.captcha = $("#captcha_input_page").val();
			}
		}

		if(App.loginSending) {
			return false;
		}

		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/login',
			data: dataToSend,
			timeout: 20000,
			beforeSend: function () {
				$('#exception').hide().empty();
				App.showLoader();
				App.loginSending = true;
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.loginSending = false;
				App.setIsSending();
			},
			error: function (jqXHR, exception) {
				var parsed = null,
					text = (jqXHR && typeof jqXHR.responseText != 'undefined') ? $.trim(String(jqXHR.responseText)) : '';

				if (App.isHyperFilterResponse(text)) {
					App.refreshAfterSecurityCheck();
					return;
				}

				try {
					parsed = text != '' ? JSON.parse(text) : null;
				}
				catch (e) {
					parsed = null;
				}

				if (parsed && parsed.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', parsed.error);
					return;
				}

				if (exception === 'timeout') {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Login request timed out. Please try again.').fetch());
					return;
				}

				if (exception === 'parsererror') {
					App.handleAjaxParserError(jqXHR);
					return;
				}

				App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Login request failed. Please try again.').fetch());
			},
			success: function (data) {
				if (!data) {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Server returned an empty response. Please try again.').fetch());
					return false;
				}

				if (data.error) {
					if(data.error == 'error_captcha'){
						$('#captcha_image').removeAttr("src").attr('src', FlameCMSConfig.base_url + 'ajax/captcha?v'+(new Date()).getTime()+'');
						App.notice(App.lc.translate('Error').fetch(), 'error', 'Wrong Captcha', 0);
					}
					else{
						var stycky = 0;
						if(typeof data.stycky != 'undefined'){
							stycky = 1;
						}
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error, stycky);
					}
					return false;
				}

				if(data.tfa){
					location.href = FlameCMSConfig.base_url + 'account-panel/two-factor-auth';
					return false;
				}

				if (data.success) {
					var loginRedirectUrl = (typeof data.redirect_url != 'undefined' && data.redirect_url != '') ? data.redirect_url : (FlameCMSConfig.base_url + 'account-panel');

					// Login success must be a one-time popup after redirect only.
					// Do not use the shared page notice key here, because account-panel tabs can render it later inside the page.
					try {
						sessionStorage.setItem('flame_login_popup_notice', JSON.stringify({
							type: 'success',
							text: data.success,
							sticky: 0,
							ts: (new Date()).getTime()
						}));
						sessionStorage.removeItem('flame_change_class_notice');
						sessionStorage.removeItem('flame_change_class_page_notice');
					}
					catch (e) {}

					window.location.href = loginRedirectUrl;
					return false;
				}

				App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Login response was not recognized. Please try again.').fetch());
				return false;
			}
		});
	},
	switchServer: function (server) {
		if (App.login == 1) {
			if ($.trim(String(server || '')) == '') {
				App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Invalid server selected.').fetch());
				return false;
			}
			App.loginUser(server);
		}
		else {
			if(App.isSending) 
				return false;
			$.ajax({
				url: FlameCMSConfig.base_url + 'ajax/switch_server',
				data: {server: server},
				beforeSend: function () {
					App.showLoader();
					App.isSending = true;
				},
				complete: function () {
					App.hideLoader();
					App.setIsSending();
				},
				success: function (data) {
					if (data.error) {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
					else {
						App.notice(App.lc.translate('Success').fetch(), 'success', data.success, 1);
						setTimeout(function () {
							location.href = window.location.href;
						}, 1000);
					}
				}
			});
		}
	},
	registerAccount: function (form, ajax_message) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'registration/create_account',
			data: form.serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
					if (typeof FlameCMSConfig.use_recaptcha != 'undefined') {
						$("#recaptcha_reload").click();
					}
					if (typeof FlameCMSConfig.use_recaptcha_v2 != 'undefined') {
						grecaptcha.reset();
					}
				}
				else {
					if (typeof ajax_message != "undefined") {
						App.notice(App.lc.translate('Success').fetch(), 'success', App.lc.translate('You account has been successfully created').fetch());
					}
					else {
						var link = FlameCMSConfig.base_url + 'registration/success';
						if (FlameCMSConfig.ajax_page_load == 1) {
							if (App.loadPage(link) == true) {
								history.pushState('', 'New URL: ' + link, link);
								return false;
							}
							else {
								window.location = link;
							}
						}
						else {
							window.location = link;
						}
					}
				}
			}
		});
	},
	checkUserStatus: function () {
		var good = false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/status',
			async: false,
			success: function (data) {
				if (data.error) {
					good = false;
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					good = true;
				}
			}
		});
		return good;
	},
	checkCredits: function (payment_method, credits, gcredits) {
		var good = false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/checkcredits',
			async: false,
			data: {payment_method: payment_method, credits: credits, gcredits: gcredits},
			success: function (data) {
				if (data.error) {
					good = false;
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					good = true;
				}
			}
		});
		return good;
	},
	changePass: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/change_password',
			data: $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					if ($.isArray(data.success)) {
						$.each(data.success, function (key, val) {
							App.notice(App.lc.translate('Success').fetch(), 'success', val);
						});
					}
					else {
						App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					}
					setTimeout(function () {
						location.href = FlameCMSConfig.base_url;
					}, 3000);

				}
			}
		});
	},
	changeEmail: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/change_email',
			data: $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					if ($.isArray(data.success)) {
						$.each(data.success, function (key, val) {
							App.notice(App.lc.translate('Success').fetch(), 'success', val);
						});
					}
					else {
						App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					}
				}
			}
		});
	},
	setNewEmail: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/set_new_email',
			data: $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					if ($.isArray(data.success)) {
						$.each(data.success, function (key, val) {
							App.notice(App.lc.translate('Success').fetch(), 'success', val);
						});
					}
					else {
						App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					}
				}
			}
		});
	},
	addRefferalReward: function (char, id) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/add_ref_reward',
			data: {char: char, id: id},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);

				}
			}
		});
	},
	addLevelReward: function (char, id) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/add_level_reward',
			data: {char: char, id: id},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);

				}
			}
		});
	},
	populateRanking: function (rank, server, c_class, page) {
		var rankingSelector = document.getElementById('rankings_select_' + server);
		if (rankingSelector) {
			$(rankingSelector).find('a[id]').removeClass('is-active');
			$(rankingSelector).find('a[id^="' + rank + '_ranking_"]').addClass('is-active');
		}

		var dataToSend = '';
		if (typeof(c_class) != "undefined" && c_class != 'all') {
			dataToSend = '&' + $.param({'type': rank, 'server': server, 'class': c_class});
		}
		else {
			dataToSend = '&' + $.param({'type': rank, 'server': server});
		}
		
		var pg = '';
		
		if (typeof(page) != "undefined") {
			pg = '/' + page;
		}
		

		if(App.isSending){
			return false;
		}
		
		$.ajax({
			type: 'POST',
			url: FlameCMSConfig.base_url + 'rankings/load_ranking_data' + pg,
			data: dataToSend,
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					EJS.config({cache: false});
					var html = new EJS({url: FlameCMSConfig.base_url + 'assets/' + FlameCMSConfig.tmp_dir + '/js_templates/' + 'rank_' + rank}).render(data);
					$("#rankings_content_" + server).html(html);

				}
			}
		});
	},
	populateSidebarRanking: function (rank, server, top) {
		var cacheKey = rank + '|' + server + '|' + top;

		// Prevent duplicate/overlapping same sidebar ranking request only.
		// No cache here: every finished click/request can get fresh server data.
		if (!App.ajaxLock('sidebarRanking:' + cacheKey)) {
			return false;
		}

		var dataToSend = '&' + $.param({'type': rank, 'server': server, 'top': top});
		$.ajax({
			type: 'POST',
			url: FlameCMSConfig.base_url + 'rankings/load_ranking_data',
			data: dataToSend,
			beforeSend: function () {
				App.showLoader();
			},
			complete: function () {
				App.hideLoader();
				App.ajaxUnlock('sidebarRanking:' + cacheKey);
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
                    EJS.config({cache: false});
					var html = new EJS({url: FlameCMSConfig.base_url + 'assets/' + FlameCMSConfig.tmp_dir + '/js_templates/' + 'sidebar_rank_' + rank}).render(data);
					$("#top_" + rank).html(html);

				}
			}
		});
	},
	formatVoteRewardTime: function (seconds) {
		seconds = parseInt(seconds, 10);
		if (!isFinite(seconds) || seconds <= 0) {
			return '0 h 0 min';
		}

		var hours = Math.floor(seconds / 3600);
		var minutes = Math.floor((seconds % 3600) / 60);
		if (seconds > 0 && hours === 0 && minutes === 0) {
			minutes = 1;
		}

		return hours + ' h ' + minutes + ' min';
	},
	formatVoteRewardAvailableAt: function (targetTime) {
		targetTime = parseInt(targetTime, 10);
		if (!isFinite(targetTime) || targetTime <= 0) {
			return '';
		}

		if (targetTime < 100000000000) {
			targetTime = targetTime * 1000;
		}

		var targetDate = new Date(targetTime);
		if (isNaN(targetDate.getTime())) {
			return '';
		}

		var hours = targetDate.getHours();
		var minutes = targetDate.getMinutes();
		var timeText = (hours < 10 ? '0' : '') + hours + ':' + (minutes < 10 ? '0' : '') + minutes;

		return App.lc.translate('Available at').fetch() + ' ' + timeText;
	},
	getVoteRewardNextAvailableElement: function (button) {
		if (!button || !button.length) {
			return $();
		}

		return button.closest('li').find('.flame-vote-next-available').first();
	},
	updateVoteRewardNextAvailable: function (button, targetTime) {
		var element = App.getVoteRewardNextAvailableElement(button);
		if (!element.length) {
			return;
		}

		var label = App.formatVoteRewardAvailableAt(targetTime);
		if (!label) {
			App.clearVoteRewardNextAvailable(button);
			return;
		}

		if (element.text() !== label) {
			element.text(label);
		}
		element.addClass('is-active').attr('data-next-vote-at', Math.floor((parseInt(targetTime, 10) < 100000000000 ? parseInt(targetTime, 10) * 1000 : parseInt(targetTime, 10)) / 1000));
	},
	clearVoteRewardNextAvailable: function (button) {
		var element = App.getVoteRewardNextAvailableElement(button);
		if (!element.length) {
			return;
		}

		element.removeClass('is-active').removeAttr('data-next-vote-at').text('');
	},
	getVoteRewardNow: function () {
		if (window.performance && typeof window.performance.now === 'function' && typeof window.performance.timeOrigin === 'number') {
			return window.performance.timeOrigin + window.performance.now();
		}

		return Date.now();
	},
	getVoteRewardScope: function (button) {
		var scope = button && button.length ? button.attr('data-vote-scope') : '';
		return scope || 'default';
	},
	getVoteRewardStorageKey: function (buttonOrScope) {
		var scope = (typeof buttonOrScope === 'string') ? buttonOrScope : App.getVoteRewardScope(buttonOrScope);
		var baseUrl = (typeof FlameCMSConfig !== 'undefined' && FlameCMSConfig.base_url) ? FlameCMSConfig.base_url : window.location.host;
		return App.voteRewardStoragePrefix + baseUrl + ':' + scope;
	},
	getVoteRewardStorage: function () {
		try {
			return window.localStorage || null;
		} catch (e) {
			return null;
		}
	},
	getVoteRewardSessionStorage: function () {
		try {
			return window.sessionStorage || null;
		} catch (e) {
			return null;
		}
	},
	getVoteRewardTabId: function () {
		if (App.voteRewardTabId) {
			return App.voteRewardTabId;
		}

		var storage = App.getVoteRewardSessionStorage();
		var key = 'flameVoteRewardTabId';
		var tabId = '';

		if (storage) {
			try {
				tabId = storage.getItem(key) || '';
			} catch (e) {
				tabId = '';
			}
		}

		if (!tabId) {
			tabId = String(App.getVoteRewardNow()) + '-' + String(Math.random()).replace('.', '');
			if (storage) {
				try {
					storage.setItem(key, tabId);
				} catch (e) {
				}
			}
		}

		App.voteRewardTabId = tabId;
		return tabId;
	},
	readVoteRewardStates: function (buttonOrScope) {
		var storage = App.getVoteRewardStorage();
		if (!storage) {
			return {};
		}

		try {
			var raw = storage.getItem(App.getVoteRewardStorageKey(buttonOrScope));
			if (!raw) {
				return {};
			}

			var states = JSON.parse(raw);
			return (states && typeof states === 'object') ? states : {};
		} catch (e) {
			return {};
		}
	},
	writeVoteRewardStates: function (buttonOrScope, states) {
		var storage = App.getVoteRewardStorage();
		if (!storage) {
			return;
		}

		try {
			storage.setItem(App.getVoteRewardStorageKey(buttonOrScope), JSON.stringify(states || {}));
		} catch (e) {
		}
	},
	setVoteRewardSharedState: function (button, state) {
		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		var states = App.readVoteRewardStates(button);
		states[timerId] = state;
		App.writeVoteRewardStates(button, states);
	},
	clearVoteRewardSharedState: function (button) {
		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		var states = App.readVoteRewardStates(button);
		if (states[timerId]) {
			delete states[timerId];
			App.writeVoteRewardStates(button, states);
		}
	},
	finishVoteRewardCooldown: function (button, broadcast) {
		if (!button || !button.length) {
			return;
		}

		var timerId = button.attr('id');
		if (timerId && App.voteRewardTimers[timerId]) {
			delete App.voteRewardTimers[timerId];
		}
		if (timerId && App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}
		if (timerId && App.voteRewardValidationRequests[timerId]) {
			delete App.voteRewardValidationRequests[timerId];
		}

		button
			.removeAttr('disabled')
			.attr('data-info', 'nvoted')
			.removeAttr('data-next-vote-seconds')
			.removeAttr('data-next-vote-at')
			.text(App.lc.translate('Vote Now!').fetch());

		App.clearVoteRewardNextAvailable(button);

		if (broadcast !== false) {
			App.clearVoteRewardSharedState(button);
		}
	},
	syncVoteRewardTimers: function () {
		var activeTimers = 0;
		var now = App.getVoteRewardNow();

		for (var timerId in App.voteRewardTimers) {
			if (!Object.prototype.hasOwnProperty.call(App.voteRewardTimers, timerId)) {
				continue;
			}

			var timer = App.voteRewardTimers[timerId];
			var button = $('#' + timerId);
			if (!button.length) {
				delete App.voteRewardTimers[timerId];
				continue;
			}

			var secondsLeft = Math.ceil((timer.endTime - now) / 1000);
			if (typeof timer.lastSecondsLeft === 'number' && secondsLeft > timer.lastSecondsLeft) {
				secondsLeft = timer.lastSecondsLeft;
			}
			timer.lastSecondsLeft = secondsLeft;

			if (secondsLeft <= 0) {
				App.finishVoteRewardCooldown(button);
				continue;
			}

			button
				.attr('disabled', 'disabled')
				.attr('data-info', 'voted')
				.attr('data-next-vote-seconds', secondsLeft)
				.text(App.formatVoteRewardTime(secondsLeft));
			App.updateVoteRewardNextAvailable(button, timer.endTime);
			activeTimers++;
		}

		if (activeTimers === 0 && App.voteRewardTimerInterval) {
			clearInterval(App.voteRewardTimerInterval);
			App.voteRewardTimerInterval = null;
		}
	},
	startVoteRewardCooldown: function (button, seconds, nextVoteAt, broadcast, sharedEndTime) {
		seconds = parseInt(seconds, 10);
		if (!isFinite(seconds) || seconds <= 0) {
			App.finishVoteRewardCooldown(button, broadcast);
			return;
		}

		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		if (App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}
		if (timerId && App.voteRewardValidationRequests[timerId]) {
			delete App.voteRewardValidationRequests[timerId];
		}

		button
			.attr('disabled', 'disabled')
			.attr('data-info', 'voted')
			.attr('data-next-vote-seconds', seconds)
			.text(App.formatVoteRewardTime(seconds));

		if (nextVoteAt) {
			button.attr('data-next-vote-at', parseInt(nextVoteAt, 10));
		} else {
			button.removeAttr('data-next-vote-at');
		}

		var endTime = parseInt(sharedEndTime, 10);
		if (!isFinite(endTime) || endTime <= App.getVoteRewardNow()) {
			endTime = App.getVoteRewardNow() + (seconds * 1000);
		}

		App.voteRewardTimers[timerId] = {
			endTime: endTime,
			lastSecondsLeft: seconds
		};

		App.updateVoteRewardNextAvailable(button, endTime);

		if (broadcast !== false) {
			App.setVoteRewardSharedState(button, {
				status: 'cooldown',
				endTime: endTime,
				nextVoteAt: nextVoteAt ? parseInt(nextVoteAt, 10) : 0,
				updatedAt: App.getVoteRewardNow()
			});
		}

		App.setVoteRewardButtonsDisabled(false);

		if (!App.voteRewardTimerInterval) {
			App.voteRewardTimerInterval = setInterval(function () {
				App.syncVoteRewardTimers();
			}, 1000);
		}

		App.syncVoteRewardTimers();
	},
	isGtop100VoteButton: function (button) {
		if (!button || !button.length) {
			return false;
		}

		return parseInt(button.attr('data-api'), 10) === 3;
	},
	getVoteRewardPendingLabel: function () {
		return App.lc.translate('Pending').fetch();
	},
	scheduleVoteRewardButtonLockState: function (button, state) {
		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		if (App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}

		var now = App.getVoteRewardNow();
		var lockUntil = parseInt(state && state.lockUntil, 10);
		if (!isFinite(lockUntil) || lockUntil <= now) {
			App.clearVoteRewardButtonLock(button);
			return;
		}

		var delay = Math.max(100, Math.min(lockUntil - now, 2147483647));
		App.voteRewardValidationTimers[timerId] = setTimeout(function () {
			var states = App.readVoteRewardStates(button);
			var current = states[timerId];
			if (!current || current.status !== 'button_lock') {
				return;
			}

			var currentLockUntil = parseInt(current.lockUntil, 10);
			if (isFinite(currentLockUntil) && currentLockUntil > App.getVoteRewardNow()) {
				App.scheduleVoteRewardButtonLockState(button, current);
				return;
			}

			var currentOwnerId = current.ownerId || '';
			if (parseInt(current.autoValidate, 10) === 1 && current.voteId && currentOwnerId && currentOwnerId === App.getVoteRewardTabId()) {
				App.clearVoteRewardSharedState(button);
				App.sendVoteRewardValidation(button, current.voteId, current.rewardType, {gtop100AutoRetry: true});
				return;
			}

			App.clearVoteRewardButtonLock(button);
		}, delay);
	},
	startVoteRewardButtonLock: function (button, seconds, voteId, rewardType, autoValidate, broadcast, sharedLockUntil, sharedOwnerId) {
		seconds = parseInt(seconds, 10);
		if (!isFinite(seconds) || seconds <= 0) {
			App.clearVoteRewardButtonLock(button, broadcast);
			return;
		}

		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		var lockUntil = parseInt(sharedLockUntil, 10);
		if (!isFinite(lockUntil) || lockUntil <= App.getVoteRewardNow()) {
			lockUntil = App.getVoteRewardNow() + (seconds * 1000);
		}

		var state = {
			status: 'button_lock',
			lockUntil: lockUntil,
			voteId: voteId,
			rewardType: rewardType,
			autoValidate: autoValidate ? 1 : 0,
			ownerId: sharedOwnerId || App.getVoteRewardTabId(),
			updatedAt: App.getVoteRewardNow()
		};

		button
			.attr('disabled', 'disabled')
			.attr('data-info', 'locked')
			.text(App.getVoteRewardPendingLabel());

		App.clearVoteRewardNextAvailable(button);
		if (broadcast !== false) {
			App.setVoteRewardSharedState(button, state);
		}

		App.setVoteRewardButtonsDisabled(false);
		App.scheduleVoteRewardButtonLockState(button, state);
	},
	clearVoteRewardButtonLock: function (button, broadcast) {
		var timerId = button.attr('id');
		if (timerId && App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}
		if (timerId && App.voteRewardValidationRequests[timerId]) {
			delete App.voteRewardValidationRequests[timerId];
		}

		button
			.removeAttr('disabled')
			.attr('data-info', 'nvoted')
			.text(App.lc.translate('Vote Now!').fetch());

		App.clearVoteRewardNextAvailable(button);
		if (broadcast !== false) {
			App.clearVoteRewardSharedState(button);
		}
		App.setVoteRewardButtonsDisabled(false);
	},
	scheduleVoteRewardPendingState: function (button, state) {
		var timerId = button.attr('id');
		if (!timerId) {
			return;
		}

		if (App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}

		var now = App.getVoteRewardNow();
		var pendingUntil = parseInt(state && state.pendingUntil, 10);
		if (!isFinite(pendingUntil) || pendingUntil <= now) {
			App.clearVoteRewardPending(button);
			return;
		}

		var ownerId = state.ownerId || '';
		var canValidate = !!(state.voteId && ownerId && ownerId === App.getVoteRewardTabId());
		var validationAt = parseInt(state.validationAt, 10);
		var targetAt = canValidate && isFinite(validationAt) ? validationAt : pendingUntil;
		var delay = Math.max(100, Math.min(targetAt - now, 2147483647));

		App.voteRewardValidationTimers[timerId] = setTimeout(function () {
			var states = App.readVoteRewardStates(button);
			var current = states[timerId];
			if (!current || current.status !== 'pending') {
				return;
			}

			var currentPendingUntil = parseInt(current.pendingUntil, 10);
			if (!isFinite(currentPendingUntil) || currentPendingUntil <= App.getVoteRewardNow()) {
				App.clearVoteRewardPending(button);
				return;
			}

			var currentOwnerId = current.ownerId || '';
			if (current.voteId && currentOwnerId && currentOwnerId === App.getVoteRewardTabId()) {
				App.sendVoteRewardValidation(button, current.voteId, current.rewardType);
				return;
			}

			App.clearVoteRewardPending(button);
		}, delay);
	},
	startVoteRewardPending: function (button, seconds, voteId, rewardType, validationAt) {
		seconds = parseInt(seconds, 10);
		if (!isFinite(seconds) || seconds < 0) {
			seconds = 0;
		}

		validationAt = parseInt(validationAt, 10);
		if (!isFinite(validationAt) || validationAt <= 0) {
			validationAt = App.getVoteRewardNow() + (seconds * 1000);
		}

		var pendingUntil = validationAt + 15000;
		var state = {
			status: 'pending',
			pendingUntil: pendingUntil,
			validationAt: validationAt,
			voteId: voteId,
			rewardType: rewardType,
			ownerId: App.getVoteRewardTabId(),
			updatedAt: App.getVoteRewardNow()
		};

		button
			.attr('disabled', 'disabled')
			.attr('data-info', 'pending')
			.text(App.lc.translate('Validating').fetch());

		App.clearVoteRewardNextAvailable(button);
		App.setVoteRewardButtonsDisabled(true);
		App.setVoteRewardSharedState(button, state);
		App.scheduleVoteRewardPendingState(button, state);
	},
	clearVoteRewardPending: function (button, broadcast) {
		var timerId = button.attr('id');
		if (timerId && App.voteRewardValidationTimers[timerId]) {
			clearTimeout(App.voteRewardValidationTimers[timerId]);
			delete App.voteRewardValidationTimers[timerId];
		}
		if (timerId && App.voteRewardValidationRequests[timerId]) {
			delete App.voteRewardValidationRequests[timerId];
		}

		button
			.attr('data-info', 'nvoted')
			.text(App.lc.translate('Vote Now!').fetch());

		App.clearVoteRewardNextAvailable(button);

		if (broadcast !== false) {
			App.clearVoteRewardSharedState(button);
		}
		App.setVoteRewardButtonsDisabled(false);
	},
	applyVoteRewardSharedState: function (button, state) {
		if (!button || !button.length || !state || !state.status) {
			return;
		}

		if (state.status === 'cooldown') {
			var secondsLeft = Math.ceil((parseInt(state.endTime, 10) - App.getVoteRewardNow()) / 1000);
			if (secondsLeft > 0) {
				App.startVoteRewardCooldown(button, secondsLeft, state.nextVoteAt, false, state.endTime);
			} else {
				App.finishVoteRewardCooldown(button, false);
				App.clearVoteRewardSharedState(button);
			}
			return;
		}

		if (state.status === 'pending') {
			var pendingUntil = parseInt(state.pendingUntil, 10);
			if (isFinite(pendingUntil) && pendingUntil > App.getVoteRewardNow()) {
				button
					.attr('disabled', 'disabled')
					.attr('data-info', 'pending')
					.text(App.lc.translate('Validating').fetch());
				App.setVoteRewardButtonsDisabled(true);
				App.scheduleVoteRewardPendingState(button, state);
			} else {
				App.clearVoteRewardPending(button, false);
				App.clearVoteRewardSharedState(button);
			}
			return;
		}

		if (state.status === 'button_lock') {
			var lockUntil = parseInt(state.lockUntil, 10);
			if (isFinite(lockUntil) && lockUntil > App.getVoteRewardNow()) {
				button
					.attr('disabled', 'disabled')
					.attr('data-info', 'locked')
					.text(App.getVoteRewardPendingLabel());
				App.setVoteRewardButtonsDisabled(false);
				App.scheduleVoteRewardButtonLockState(button, state);
			} else {
				App.clearVoteRewardButtonLock(button, false);
				App.clearVoteRewardSharedState(button);
			}
		}
	},
	applyVoteRewardSharedStates: function () {
		$('button[id^="vote-"]').each(function () {
			var button = $(this);
			var timerId = button.attr('id');
			var states = App.readVoteRewardStates(button);
			if (timerId && states[timerId]) {
				App.applyVoteRewardSharedState(button, states[timerId]);
			}
		});
	},
	bindVoteRewardStorageEvents: function () {
		if (App.voteRewardStorageEventsBound || !App.getVoteRewardStorage()) {
			return;
		}

		App.voteRewardStorageEventsBound = true;
		window.addEventListener('storage', function (event) {
			if (!event.key || event.key.indexOf(App.voteRewardStoragePrefix) !== 0) {
				return;
			}
			App.applyVoteRewardSharedStates();
			App.syncVoteRewardTimers();
		});
	},
	initVoteRewardTimers: function () {
		$('button[id^="vote-"][data-info="voted"]').each(function () {
			var button = $(this);
			var seconds = parseInt(button.attr('data-next-vote-seconds'), 10);
			App.startVoteRewardCooldown(button, seconds, button.attr('data-next-vote-at'));
		});

		App.bindVoteRewardStorageEvents();
		App.applyVoteRewardSharedStates();
	},
	setVoteRewardButtonsDisabled: function (disabled) {
		$('button[id^="vote-"]').each(function () {
			var button = $(this);
			var info = button.attr('data-info');
			if (info === 'voted') {
				return;
			}

			if (disabled) {
				button.attr('disabled', 'disabled');
			} else if (info !== 'pending' && info !== 'locked') {
				button.removeAttr('disabled');
			}
		});
	},
	sendVoteRewardValidation: function (link, voteId, rewardType, options) {
		options = options || {};
		var timerId = link.attr('id');
		var isGtop100 = App.isGtop100VoteButton(link) || options.gtop100AutoRetry === true;
		if (timerId && App.voteRewardValidationRequests[timerId]) {
			return;
		}

		if (timerId) {
			App.voteRewardValidationRequests[timerId] = true;
		}

		if (isGtop100) {
			link
				.attr('disabled', 'disabled')
				.attr('data-info', 'pending')
				.text(App.lc.translate('Validating').fetch());
			App.setVoteRewardButtonsDisabled(false);
		}

		$.ajax({
			url: FlameCMSConfig.base_url + "ajax/vote",
			data: {vote: voteId},
			dataType: 'json',
			timeout: 30000,
			success: function (data) {
				if (!data || typeof data !== 'object') {
					if (!options.gtop100AutoRetry) {
						App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Unable to validate vote. Please try again after few minutes.').fetch());
					}
					if (isGtop100) {
						App.clearVoteRewardButtonLock(link);
					} else {
						App.clearVoteRewardPending(link);
					}
					return;
				}

				if (data.notice) {
					if (!options.gtop100AutoRetry) {
						App.notice(data.notice_title || App.lc.translate('Notice').fetch(), 'success', data.notice);
					}

					if (parseInt(data.pending_gtop100, 10) === 1 || parseInt(data.pending, 10) === 1) {
						if (options.gtop100AutoRetry) {
							App.clearVoteRewardButtonLock(link);
							return;
						}

						App.startVoteRewardButtonLock(
							link,
							parseInt(data.button_lock_seconds || data.retry_after_seconds || 60, 10),
							voteId,
							rewardType,
							true
						);
						return;
					}

					App.clearVoteRewardPending(link);
					return;
				}

				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);

					if (parseInt(data.next_vote_seconds, 10) > 0) {
						App.startVoteRewardCooldown(link, data.next_vote_seconds, data.next_vote_at);
						return;
					}

					if (isGtop100) {
						App.clearVoteRewardButtonLock(link);
					} else {
						App.clearVoteRewardPending(link);
					}
					return;
				}

				if (data.success_mmotop) {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success_mmotop);
					if (isGtop100) {
						App.clearVoteRewardButtonLock(link);
					} else {
						App.clearVoteRewardPending(link);
					}
					return;
				}

				App.notice(App.lc.translate('Success').fetch(), 'success', data.success);

				var credits = (rewardType == 1) ? $('#my_credits').text().replace(/,/g, '') : $('#my_gold_credits').text().replace(/,/g, '');
				var new_credits = App.formatMoney(parseInt(credits) + parseInt(data.reward), 0, ',', ',');
				if (rewardType == 1) {
					$('#my_credits').fadeOut('slow').html(new_credits).fadeIn('slow');
				} else {
					$('#my_gold_credits').fadeOut('slow').html(new_credits).fadeIn('slow');
				}

				App.startVoteRewardCooldown(link, data.next_vote_seconds, data.next_vote_at);
			},
			error: function () {
				if (!options.gtop100AutoRetry) {
					App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Unable to validate vote. Please try again after few minutes.').fetch());
				}
				if (isGtop100) {
					App.clearVoteRewardButtonLock(link);
				} else {
					App.clearVoteRewardPending(link);
				}
			},
			complete: function () {
				if (timerId && App.voteRewardValidationRequests[timerId]) {
					delete App.voteRewardValidationRequests[timerId];
				}
			}
		});
	},

	vote: function (link) {
		var butnum = link.attr('id').split("-")[1];
		var reward_type = link.attr('id').split("-")[2];
		var voteNowText = App.lc.translate('Vote Now!').fetch();

		if (link.attr('data-info') === 'voted' || link.attr('data-info') === 'pending' || link.attr('data-info') === 'locked' || link.text() !== voteNowText) {
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('You have already voted for this link.').fetch());
			return;
		}

		var voteLink = link.attr('data-link');
		if (!voteLink) {
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Voting link not found.').fetch());
			return;
		}

		window.open(voteLink, '_blank');

		var counterElement = $('#counter-' + butnum);
		var originalCounter = parseInt(counterElement.text(), 10);
		if (!isFinite(originalCounter) || originalCounter < 0) {
			originalCounter = 0;
		}

		var validationTarget = App.getVoteRewardNow() + (originalCounter * 1000);
		var validationInterval = null;
		var validationSent = false;

		App.startVoteRewardPending(link, originalCounter, butnum, reward_type, validationTarget);

		if (originalCounter > 0) {
			counterElement.text(originalCounter).fadeIn('slow');
		}

		var resetValidationState = function () {
			if (validationInterval) {
				clearInterval(validationInterval);
				validationInterval = null;
			}
			counterElement.text(originalCounter).fadeOut('fast');
		};

		var sendValidationRequest = function () {
			if (validationSent) {
				return;
			}

			validationSent = true;
			resetValidationState();

			App.sendVoteRewardValidation(link, butnum, reward_type);
		};

		if (originalCounter <= 0) {
			sendValidationRequest();
			return;
		}

		validationInterval = setInterval(function () {
			var secondsLeft = Math.ceil((validationTarget - App.getVoteRewardNow()) / 1000);
			if (secondsLeft <= 0) {
				sendValidationRequest();
				return;
			}

			counterElement.html(secondsLeft);
		}, 250);
	},
	resetCharacter: function (character, vip) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/reset_character',
			data: {character: character, vip: vip},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#resets-' + character).fadeOut('slow').html(parseInt($('#resets-' + character).text()) + 1).fadeIn('slow');
					$('#lvl-' + character).fadeOut('slow').html('<span style="color: red;">'+data.newlvl+'</span>').fadeIn('slow');
				}
			}
		});
	},
	gresetCharacter: function (character) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/greset_character',
			data: {character: character},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#resets-' + character).fadeOut('slow').html('<span style="color: red;">0</span>').fadeIn('slow');
					$('#lvl-' + character).fadeOut('slow').html('<span style="color: red;">1</span>').fadeIn('slow');
				}
			}
		});
	},
	resetStats: function (character) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/reset_stats',
			data: {character: character},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#new-stats-' + character).fadeOut('slow').html('0').fadeIn('slow');
				}
			}
		});
	},
	resetSkillTree: function (character) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/reset_skilltree',
			data: {character: character},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	pkClear: function (character) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/pk_clear',
			data: {character: character},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	calculateStats: function () {
		var points = $("#lvlup").val(),
			new_points = $(".stats_calc"),
			now_points = $(".stats_now"),
			s = [];

		for (i = 0; i < now_points.length; i++) {
			s[now_points.eq(i).attr('id')] = parseInt(now_points.eq(i).text());
		}

		new_points.bind('keyup keypress', function (e) {
			total = 0;

			for (i = 0; i < new_points.length; i++) {
				st = parseInt(new_points.eq(i).val());
				if (!isNaN(st)) {
					total += st;
				}
			}

			var stat = $(this).attr('name').split('_')[0],
				num = parseInt($(this).val());

			if (num < 0)
				$(this).val('');
			if (isNaN(num))
				num = 0;

			var output = points - total;

			if (output >= 0) {
				$("#lvlup").val(output);
				$("#" + stat).text(s[stat] + num);
			}
			else {
				$("#lvlup").val('0');
				$("#" + stat).text((s[stat] + num) + output);
				$(this).val(num + output);
			}
			if (parseInt($("#" + stat).text()) >= FlameCMSConfig.max_stats) {
				$("#" + stat).css("color", "red");
			}
			else {
				$("#" + stat).css("color", "");
			}
		});

	},
	sellItem: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'warehouse/sell_item',
			data: '&' + $.param({'slot': App.item_slot, 'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#option_buttons').toggleClass("d-none");
					$('#sell_item').slideToggle('fast');
					$('#sell_item_form').get(0).reset();
					$('#item-slot-' + App.item_slot).hide();
				}
			}
		});
	},
	moveItemToWeb: function () {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'warehouse/transfer-item/web',
			data: {'ajax': 1, 'slot': App.item_slot},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#option_buttons').toggleClass("d-none");
					$('#item-slot-' + App.item_slot).hide();
				}
			}
		});
	},
	moveItemToGame: function (id) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'warehouse/transfer-item/game',
			data: {'ajax': 1, 'slot': id},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#wh_items_' + id).hide();
				}
			}
		});
	},
	deleteItem: function () {
		if (App.confirmMessage(App.lc.translate('Are you sure you want to delete this item?').fetch())) {
			if(App.isSending) 
				return false;
			$.ajax({
				url: FlameCMSConfig.base_url + 'warehouse/del_item',
				data: {'ajax': 1, 'slot': App.item_slot},
				beforeSend: function () {
					App.showLoader();
					App.isSending = true;
				},
				complete: function () {
					App.hideLoader();
					App.setIsSending();
				},
				success: function (data) {
					if (data.error) {
						if ($.isArray(data.error)) {
							$.each(data.error, function (key, val) {
								App.notice(App.lc.translate('Error').fetch(), 'error', val);
							});
						}
						else {
							App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
						}
					}
					else {
						App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
						$('#item-slot-' + App.item_slot).hide();
					}
				}
			});
		}
	},
	clearInventory: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/clear_inventory',
			data: '&' + $.param({'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	buyLevel: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/buy_level',
			data: '&' + $.param({'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	buyPoints: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/buy_points',
			data: '&' + $.param({'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	buyGM: function (form) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/buy_gm',
			data: '&' + $.param({'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	loadClassList: function (name) {
		if (name != '') {
			$.ajax({
				url: FlameCMSConfig.base_url + 'ajax/load_class_list',
				data: '&' + $.param({'ajax': 1, 'character': name}),
				beforeSend: function () {
					App.showLoader();
				},
				complete: function () {
					App.hideLoader();
				},
				success: function (data) {
					if (data.error) {
						if ($.isArray(data.error)) {
							$.each(data.error, function (key, val) {
								App.notice(App.lc.translate('Error').fetch(), 'error', val);
							});
						}
						else {
							App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
						}
						$('#class_select').html('<option value="" disabled="disabled" selected="selected">'+App.lc.translate('--SELECT--').fetch()+'</option>');
						$('#class_change_price').html('Select Character');
						$('#required_items').html('');
					}
					else {
						if (typeof data.data != 'Undefined') {
							$('#class_select').html(data.data);
							$('#class_change_price').html(data.price+' '+data.price_type);
							if (typeof data.items != 'Undefined' && data.items != '') {
								$('#required_items').html(data.items);
								$('a[id^="skip_reset_item_"], a[id^="check_completed_reset_item_"]').each(function () {
									App.initializeTooltip($(this), false);
								});
								$('span[id^="reset_item_"]').each(function () {
									App.initializeTooltip($(this), true, 'warehouse/item_info_image');
								});
								
							}
						}
					}
				}
			});
		}
		else {
			$('#class_select').html('<option value="" disabled="disabled" selected="selected">'+App.lc.translate('--SELECT--').fetch()+'</option>');
			App.notice(App.lc.translate('Error').fetch(), 'error', App.lc.translate('Please select character').fetch());
			$('#required_items').html('');
		}
	},
	buyClass: function (form) {
		var button = $('#buy_class_button'),
			shouldReload = false,
			buttonWasDisabled = button.prop('disabled'),
			buttonOriginalStyle = {};

		if (!App.ajaxLock('buyClass')) {
			return false;
		}
		if(App.isSending || buttonWasDisabled){
			App.ajaxUnlock('buyClass');
			return false;
		}

		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/buy_class',
			data: '&' + $.param({'ajax': 1}) + '&' + $(form).serialize(),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;

				buttonOriginalStyle = {
					'background-color': button.css('background-color'),
					'border-color': button.css('border-top-color'),
					'color': button.css('color'),
					'box-shadow': button.css('box-shadow')
				};

				button
					.attr('aria-disabled', 'true')
					.addClass('change-class-submitting')
					.css($.extend({}, buttonOriginalStyle, {'pointer-events': 'none', 'opacity': '1'}));
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
				if (!shouldReload) {
					button
						.prop('disabled', buttonWasDisabled)
						.removeAttr('aria-disabled')
						.removeClass('change-class-submitting')
						.css({'pointer-events': '', 'opacity': '', 'background-color': '', 'border-color': '', 'color': '', 'box-shadow': ''});
					App.ajaxUnlock('buyClass');
				}
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', App.escapeHtml(val));
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', App.escapeHtml(data.error));
					}
				}
				else {
					var successMessage = data.notice || data.success || '';

					App.notice(App.lc.translate('Success').fetch(), 'success', App.escapeHtml(successMessage));
					if (data.reload === true) {
						shouldReload = true;
						App.storeNotice('success', successMessage);
						setTimeout(function () {
							location.href = window.location.href;
						}, 1000);
					}
				}
			}
		});
	},
	exchangeWCoins: function (credits) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/exchange_wcoins',
			data: {
				ajax: 1,
				credits: credits,
				exchange_type: (typeof $('#exchange_type') != 'undefined') ? $('#exchange_type').val() : 0
			},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	changeName: function (oldN, newN) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/change_name',
			data: {ajax: 1, old_name: oldN, new_name: newN},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				if (data.success) {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#charname-' + oldN).attr('id', 'charname-' + data.new_name);
				}
			}
		});
	},
	loadLatestItems: function (server, item_count, text_limit) {
		$.ajax({
            type: 'POST',
			url: FlameCMSConfig.base_url + 'market/latest-items',
			data: {ajax: 1, server: server, item_count: item_count, text_limit: text_limit},
			beforeSend: function () {
				App.showLoader();
			},
			complete: function () {
				App.hideLoader();
			},
			success: function (data) {
				if (data.error) {
					if ($.isArray(data.error)) {
						$.each(data.error, function (key, val) {
							App.notice(App.lc.translate('Error').fetch(), 'error', val);
						});
					}
					else {
						App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
					}
				}
				else {
                    EJS.config({cache: false});
					var html = new EJS({url: FlameCMSConfig.base_url + 'assets/' + FlameCMSConfig.tmp_dir + '/js_templates/' + 'sidebar_items'}).render(data);
					$('#lattest_items').html(html);
				}
			}
		});
	},
	checkSupportTickets: function () {
	
		// Do not check support tickets if support UI is not present
		if ($('#support-unreplied-tickets, .support-unreplied-tickets, [data-support-check="1"]').length === 0) {
			return false;
		}
	
		// Prevent overlapping support ticket checks only.
		// No time throttle here, so existing realtime behaviour stays the same.
		if (!App.ajaxLock('supportTickets')) {
			return false;
		}
	
		$.ajax({
			url: FlameCMSConfig.base_url + 'support/check-unreplied-tickets',
			data: {},
			complete: function () {
				App.ajaxUnlock('supportTickets');
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
	
				if (data.success) {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success, 1);
				}
			}
		});
	
	},
	changeServerInfo: function (key) {
		$('#sButton-' + key).animate({
			"opacity": "1",
			"filter": "alpha(opacity=100)"
		}, 500).siblings().animate({"opacity": "0.3", "filter": "alpha(opacity=30)"}, 200);
		$('#sStatus').text($('#status-' + key).text()).css("color", "#837E7E");
		$('#sOnline').text($('#online-' + key).text()).css("color", "#837E7E");
		$('#sVersion').text($('#version-' + key).text()).css("color", "#837E7E");


		App.topPlayer($('#online-' + key).attr('data-server'));
		App.topGuild($('#online-' + key).attr('data-server'));
	},
	topPlayer: function (server) {
		$.ajax({
			type: 'POST',
			url: FlameCMSConfig.base_url + 'rankings/top_player',
			data: {ajax: 1, server: server},
			success: function (data) {
				if (typeof data !== 'undefined') {
					if (data.error) {
						if ($.isArray(data.error)) {
							$.each(data.error, function (key, val) {
								App.notice(App.lc.translate('Error').fetch(), 'error', val);
							});
						}
						else {
							App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
						}

					}
					else {
						if (data != false) {
							$('#sPlayerLink').attr('href', FlameCMSConfig.base_url + 'info/character/' + data[0].name_hex + '/' + server);
							$('#sPlayer').html(data[0].name);
						}
						else{
							$('#sPlayer').html('&nbsp;');
						}
					}
				}
			}
		});
	},
	topGuild: function (server) {
		$.ajax({
			type: 'POST',
			url: FlameCMSConfig.base_url + 'rankings/top_guild',
			data: {ajax: 1, server: server},
			success: function (data) {
				if (typeof data !== 'undefined') {
					if (data.error) {
						if ($.isArray(data.error)) {
							$.each(data.error, function (key, val) {
								App.notice(App.lc.translate('Error').fetch(), 'error', val);
							});
						}
						else {
							App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
						}

					}
					else {
						if (data != false) {
							$('#sGuildLink').attr('href', FlameCMSConfig.base_url + 'info/guild/' + data[0].name_hex + '/' + server);
							$('#sGuild').html(data[0].name);
						}
						else{
							$('#sGuild').html('&nbsp;');
						}
					}
				}
			}
		});
	},
	hideCharsPK: function () {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/hide_chars_pk',
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
				}
			}
		});
	},
	switchLanguage: function (lang) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/switch_language',
			data: {lang: lang},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				setInterval(function () {
					App.hideLoader();
					App.setIsSending();
				}, 2000);
			},
			success: function (data) {
				setTimeout(function () {
					location.reload();
				}, 2000);
			}
		});
	},
	switchTheme: function (theme) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'ajax/switch_theme',
			data: {theme: theme},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				setInterval(function () {
					App.hideLoader();
					App.setIsSending();
				}, 2000);
			},
			success: function (data) {
				setTimeout(function () {
					location.reload();
				}, 2000);
			}
		});
	},
	removeItemFromCart: function (id, tr, div) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'shop/remove_item_from_cart',
			data: {id: id},
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					$('#' + div).find('[data-cart-item-id="' + id + '"]').remove();
					if (tr.length < 3) {
						$('#' + div).html('<div class="i_note">'+App.lc.translate('All items from card were removed.').fetch()+'</div>');
					}
				}
			}
		});
	},
	buyItems: function (form, div) {
		if(App.isSending) 
			return false;
		$.ajax({
			url: FlameCMSConfig.base_url + 'shop/senditems',
			data: form.serialize() + '&' + $.param({'ajax': 1}),
			beforeSend: function () {
				App.showLoader();
				App.isSending = true;
			},
			complete: function () {
				App.hideLoader();
				App.setIsSending();
			},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					App.notice(App.lc.translate('Success').fetch(), 'success', data.success);
					var credits = $('#my_credits').text().replace(/,/g, ''),
						gcredits = $('#my_gold_credits').text().replace(/,/g, '');
					if (data.payment_method == 1) {
						$('#my_credits').fadeOut('slow').html(App.formatMoney(parseInt(credits) - parseInt(data.price), 0, ',', ',')).fadeIn('slow');
					}
					else {
						$('#my_gold_credits').fadeOut('slow').html(App.formatMoney(parseInt(gcredits) - parseInt(data.price), 0, ',', ',')).fadeIn('slow');
					}

					if (data.left_items != "undefined") {
						var ids_checked = new Array();
						if (div == 'credits_items') {
							$('input[id^="add_to_warehouse_1_"]:checked').map(function () {
								ids_checked.push(parseInt($(this).attr('name').match(/\d+/)[0]));
							});
						}
						else {

							$('input[id^="add_to_warehouse_2_"]:checked').map(function () {
								ids_checked.push(parseInt($(this).attr('name').match(/\d+/)[0]));
							});
						}

						if (data.left_items.length > 0) {
							$.each(ids_checked, function (key, val) {
								if ($.inArray(val, data.left_items) === -1) {
									$('#' + div).find('[data-cart-item-id="' + val + '"]').remove();
									if (div == 'credits_items') {
										if ($('#credits_table tr').length <= 1) {
											$('#' + div).html('<div class="i_note">'+App.lc.translate('All items from card were removed.').fetch()+'</div>');
										}
									}
									else {
										if ($('#gcredits_table tr').length <= 1) {
											$('#' + div).html('<div class="i_note">'+App.lc.translate('All items from card were removed.').fetch()+'</div>');
										}
									}
								}
								else {
									$('input[id^="add_to_warehouse_"]').prop("checked", false);
									$('#total_price_c').html(0);
									$('#total_price_gc').html(0);
								}
							});
						}
						else {
							$.each(ids_checked, function (key, val) {
								$('#' + div).find('[data-cart-item-id="' + val + '"]').remove();
								if (div == 'credits_items') {
									if ($('#credits_table tr').length <= 1) {
										$('#' + div).html('<div class="i_note">'+App.lc.translate('All items from card were removed.').fetch()+'</div>');
									}
								}
								else {
									if ($('#gcredits_table tr').length <= 1) {
										$('#' + div).html('<div class="i_note">'+App.lc.translate('All items from card were removed.').fetch()+'</div>');
									}
								}
								$('input[id^="add_to_warehouse_"]').prop("checked", false);
								$('#total_price_c').html(0);
								$('#total_price_gc').html(0);
							});
						}
					}
				}
			}
		});
	},
	escapeHtml: function (text) {
		return $('<div>').text(text == null ? '' : String(text)).html();
	},
	storeNotice: function (type, text, sticky) {
		try {
			var notice = JSON.stringify({
				type: type,
				text: text,
				sticky: (typeof sticky == 'undefined') ? 1 : sticky
			});
			sessionStorage.setItem('flame_change_class_notice', notice);
			sessionStorage.setItem('flame_change_class_page_notice', notice);
		}
		catch (e) {}
	},
	showStoredNotice: function () {
		var notice = null,
			noticeType = 'success',
			noticeTitle = '',
			sticky = 1,
			storageKey = '',
			keys = ['flame_login_popup_notice', 'flame_change_class_notice'],
			now = (new Date()).getTime(),
			createdAt = 0,
			i = 0;
		try {
			for (i = 0; i < keys.length; i++) {
				storageKey = keys[i];
				notice = sessionStorage.getItem(storageKey);
				if (!notice) {
					continue;
				}

				// Remove before rendering, so the same message cannot appear again on later account-panel navigation.
				sessionStorage.removeItem(storageKey);
				notice = JSON.parse(notice);
				if (!notice || !notice.text) {
					break;
				}

				createdAt = parseInt(notice.ts || 0, 10);
				if (storageKey == 'flame_login_popup_notice' && createdAt > 0 && (now - createdAt) > 30000) {
					break;
				}

				noticeType = notice.type == 'error' ? 'error' : 'success';
				noticeTitle = App.lc.translate(noticeType == 'error' ? 'Error' : 'Success').fetch();
				sticky = (typeof notice.sticky == 'undefined') ? 1 : parseInt(notice.sticky, 10);

				setTimeout(function (storedNotice, storedTitle, storedType, storedSticky) {
					if (storedSticky > 0) {
						App.notice(storedTitle, storedType, App.escapeHtml(storedNotice.text), 1);
					}
					else {
						App.notice(storedTitle, storedType, App.escapeHtml(storedNotice.text));
					}
				}, 300, notice, noticeTitle, noticeType, sticky);

				break;
			}
		}
		catch (e) {}
	},
	confirmMessage: function (message) {
		var conf = confirm(message);
		return (conf == true);
	},
	notice: function (title, title_type, text, sticky) {
		var container, messageBox, messageBody, messageTextBox, closeButton;

		container = $('#notifier-box');
		if (!container.length) {
			container = $('<div>', {id: 'notifier-box'}).prependTo(document.body);
		}

		messageBox = $('<div>', {'class': 'message-box', css: {display: 'none'}});
		messageHeader = $('<div>', {'class': title_type, html: title});
		messageBody = $('<div>', {'class': 'message-body'});
		messageTextBox = $('<span>', {html: text});

		var noticeCloseType = title_type === 'error' ? 'error' : (title_type === 'success' ? 'success' : 'default');
		closeButton = $('<a>', {
			'class': 'message-close message-close-' + noticeCloseType,
			href: '#',
			role: 'button',
			'aria-label': App.lc.translate('Click for close this message').fetch(),
			click: function (e) {
				e.preventDefault();
				e.stopPropagation();
				$(this).closest('.message-box').stop(true, true).fadeOut(250, function () {
					$(this).remove();
				});
				return false;
			}
		});

		messageBox.appendTo(container).fadeIn(500);
		closeButton.appendTo(messageBox);
		messageHeader.appendTo(messageBox);
		messageBody.appendTo(messageBox);
		messageTextBox.appendTo(messageBody);
		if (typeof(sticky) == "undefined") {
			setTimeout(function () {
				$(messageBox).fadeOut(500, function () {
					$(this).remove();
				});
			}, 4000);
		}
		return this;
	},
	buildCaptcha: function (div, options) {
		var defaults = {
			txtLock: App.lc.translate('Move arrow to unlock form').fetch(),
			txtUnlock: App.lc.translate('Form can be submitted!').fetch(),
			disabledSubmit: true,
		};

		if (div.length > 0) {
			return $(div).each(function (i) {
				var opts = $.extend({}, defaults, options),
					form = $('form').has($(div)),
					clr = $('<div>', {'class': 'clr'}),
					bgSlider = $('<div>', {'class': 'bgSlider'}),
					slider = $('<div>', {'class': 'slider'}),
					txtStatus = $('<div>', {'class': ' txtStatus dropError', text: opts.txtLock}),
					input = $('<input>', {name: 'qaptcha_key', value: App.generateCaptchaKey(32), type: 'hidden'});

				if (opts.disabledSubmit) {
					form.find('button[type=\'submit\']').attr('disabled', 'disabled');
				}

				bgSlider.appendTo($(div));
				clr.insertAfter(bgSlider);
				txtStatus.insertAfter(clr);
				input.appendTo($(div));
				slider.appendTo(bgSlider);
				$(div).show();

				slider.draggable({
					containment: bgSlider,
					axis: 'x',
					stop: function (event, ui) {
						if (ui.position.left > 150) {
							$.ajax({
								url: FlameCMSConfig.base_url + 'ajax/checkcaptcha',
								data: {act: 'qaptcha', qaptcha_key: input.attr('value')},
								success: function (data) {
									if (!data.error) {
										slider.draggable('disable').css('cursor', 'default');
										txtStatus.text(opts.txtUnlock).addClass('dropSuccess').removeClass('dropError');
										form.find('button[type=\'submit\']').removeAttr('disabled');
									}
								}
							});
						}
					}
				});
			});
		}
	},
	generateCaptchaKey: function (len) {
		var chars = 'azertyupqsdfghjkmwxcvbn23456789AZERTYUPQSDFGHJKMWXCVBN_-#@';
		var pass = '';
		for (i = 0; i < len; i++) {
			var wpos = Math.round(Math.random() * chars.length);
			pass += chars.substring(wpos, wpos + 1);
		}
		return pass;
	},
	formatMoney: function (b, c, d, t) {
		var c = isNaN(c = Math.abs(c)) ? 2 : c,
			d = d == undefined ? "." : d,
			t = t == undefined ? "," : t,
			s = b < 0 ? "-" : "",
			i = parseInt(b = Math.abs(+b || 0).toFixed(c)) + "",
			j = (j = i.length) > 3 ? j % 3 : 0;
		return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(b - i).toFixed(c).slice(2) : "");
	},
	initializeRulesDialog: function (title, onReady) {
		var rules = $('<div id="rules_content" class="flame-rules-dialog-content"><p></p></div>'),
			resizeKey = 'resize.flameRulesDialog',
			getWindowHeight = function () {
				return $(window).height() || window.innerHeight || document.documentElement.clientHeight || 600;
			},
			getRulesTop = function () {
				return getWindowHeight() <= 520 ? 8 : 16;
			},
			resetRulesScroll = function (content) {
				if (!content || !content.length) {
					return;
				}
				content.scrollTop(0);
				if (content[0]) {
					content[0].scrollTop = 0;
				}
			},
			getDialogHeight = function () {
				var windowHeight = getWindowHeight(),
					top = getRulesTop();
				return Math.min(500, Math.max(280, windowHeight - top - 14));
			},
			fitRulesDialog = function (content) {
				var dialog = content.closest('.ui-dialog'),
					windowHeight = getWindowHeight(),
					top = getRulesTop(),
					headerHeight = dialog.find('.ui-dialog-titlebar').outerHeight() || 68,
					contentMaxHeight = Math.max(180, windowHeight - top - headerHeight - 22);

				if (!dialog.length) {
					return;
				}

				dialog.addClass('flame-rules-dialog-popup');
				dialog.css({
					position: 'fixed',
					top: top + 'px',
					bottom: 'auto',
					left: '50%',
					right: 'auto',
					margin: 0
				});

				content.css({
					maxHeight: contentMaxHeight + 'px',
					overflowY: 'auto'
				});
			},
			refitRulesDialog = function (content) {
				fitRulesDialog(content);
				setTimeout(function () { fitRulesDialog(content); }, 60);
				setTimeout(function () { fitRulesDialog(content); }, 220);
			};

		$.ajax({
			type: 'GET',
			dataType: 'html',
			cache: false,
			url: FlameCMSConfig.base_url + 'assets/rules.html',
			success: function (data) {
				rules.html(data);
				resetRulesScroll(rules);
				if (rules.hasClass('ui-dialog-content')) {
					rules.dialog('option', 'height', getDialogHeight());
					refitRulesDialog(rules);
					setTimeout(function () { resetRulesScroll(rules); }, 0);
					setTimeout(function () { resetRulesScroll(rules); }, 80);
				}

				if ($.isFunction(onReady)) {
					onReady.call(rules[0], rules);
				}
			}
		});
		rules.dialog({
			modal: true,
			width: 700,
			height: getDialogHeight(),
			title: title,
			dialogClass: 'flame-rules-dialog-popup',
			position: {my: 'center top', at: 'center top+' + getRulesTop(), of: window, collision: 'fit'},
			draggable: false,
			resizable: false,
			show: 'clip',
			hide: 'clip',
			open: function () {
				var content = $(this),
					dialog = content.closest('.ui-dialog');

				dialog.addClass('flame-rules-dialog-popup');
				dialog.find('.ui-dialog-titlebar').addClass('flame-rules-dialog-header');
				dialog.find('.ui-dialog-titlebar-close').addClass('flame-rules-dialog-close');
				$('.ui-widget-overlay').last().addClass('flame-rules-dialog-overlay');
				content.dialog('option', 'height', getDialogHeight());
				resetRulesScroll(content);
				refitRulesDialog(content);
				setTimeout(function () { resetRulesScroll(content); }, 0);

				$(window).off(resizeKey).on(resizeKey, function () {
					if (!content.closest('body').length || !dialog.is(':visible')) {
						$(window).off(resizeKey);
						return;
					}
					content.dialog('option', 'height', getDialogHeight());
					refitRulesDialog(content);
				});
			},
			focus: function () {
				/* jQuery UI focuses the first tabbable link after the clip animation.
				   In rules.html that link is below section 1, which makes the browser
				   scroll the content before the dialog is fully visible. Reset only
				   after jQuery UI has completed that focus step. */
				resetRulesScroll($(this));
			},
			close: function () {
				$(window).off(resizeKey);
				$('.ui-widget-overlay.flame-rules-dialog-overlay').removeClass('flame-rules-dialog-overlay');
				$(this).dialog('destroy').remove();
			}
		});
	},
	castleSiegeCountDown: function (id, end, start) {
		this.container = $('#' + id);
		this.endDate = new Date(end * 1000);
		this.startDate = new Date(start * 1000);
		if(new Date().getTime() > this.endDate){
			this.container.html(App.lc.translate('Battle Ended').fetch());
		}
		else{
			var context = this,
				update = function () {
					context.startDate.setSeconds(context.startDate.getSeconds() + 1);
					var timediff = (context.endDate - context.startDate) / 1000;
					if (timediff < 0) {
						context.container.html(App.lc.translate('Battle Now').fetch());
					}
					else {
						context.container.html(App.formatedTime(timediff));
						setTimeout(update, 1000);
					}
				};
			update();
		}
	},
	getTooltipViewerContext: function (element) {
		var context = {},
			$element = $(element),
			selectors = [
				$element,
				$element.closest('[data-viewer-class], [data-viewer-class-id], [data-character-class], [data-char-class], [data-character], [data-character-name], [data-server]'),
				$('body'),
				$('html'),
				$('#character-info, #char-info, .character-info, .char-info').first()
			];

		var readAttribute = function ($source, attrNames) {
			var value, i;
			if (!$source || !$source.length) {
				return '';
			}
			for (i = 0; i < attrNames.length; i++) {
				value = $source.attr(attrNames[i]);
				if (typeof(value) != 'undefined' && $.trim(String(value)) != '') {
					return $.trim(String(value));
				}
			}
			return '';
		};

		var firstValue = function (attrNames) {
			var i, value;
			for (i = 0; i < selectors.length; i++) {
				value = readAttribute(selectors[i], attrNames);
				if (value != '') {
					return value;
				}
			}
			return '';
		};

		var viewerClass = firstValue(['data-viewer-class', 'data-character-class', 'data-char-class', 'data-class']);
		var viewerClassId = firstValue(['data-viewer-class-id', 'data-character-class-id', 'data-char-class-id', 'data-class-id']);
		var viewerCharacter = firstValue(['data-viewer-character', 'data-character-name', 'data-character', 'data-char-name']);
		var viewerServer = firstValue(['data-viewer-server', 'data-server']);

		if (typeof(FlameCMSConfig) != 'undefined') {
			if (viewerClass == '' && typeof(FlameCMSConfig.viewer_class) != 'undefined') {
				viewerClass = $.trim(String(FlameCMSConfig.viewer_class));
			}
			if (viewerClassId == '' && typeof(FlameCMSConfig.viewer_class_id) != 'undefined') {
				viewerClassId = $.trim(String(FlameCMSConfig.viewer_class_id));
			}
			if (viewerCharacter == '' && typeof(FlameCMSConfig.viewer_character) != 'undefined') {
				viewerCharacter = $.trim(String(FlameCMSConfig.viewer_character));
			}
			if (viewerServer == '' && typeof(FlameCMSConfig.viewer_server) != 'undefined') {
				viewerServer = $.trim(String(FlameCMSConfig.viewer_server));
			}
		}

		if ((viewerCharacter == '' || viewerServer == '') && window.location && window.location.pathname) {
			var pathMatch = window.location.pathname.match(/\/info\/character\/([^\/]+)(?:\/([^\/]+))?/i);
			if (pathMatch) {
				if (viewerCharacter == '' && typeof(pathMatch[1]) != 'undefined') {
					viewerCharacter = decodeURIComponent(pathMatch[1]);
				}
				if (viewerServer == '' && typeof(pathMatch[2]) != 'undefined') {
					viewerServer = decodeURIComponent(pathMatch[2]);
				}
			}
		}

		if (viewerClass != '') {
			context.viewer_class = viewerClass;
		}
		if (viewerClassId != '') {
			context.viewer_class_id = viewerClassId;
		}
		if (viewerCharacter != '') {
			context.viewer_character = viewerCharacter;
		}
		if (viewerServer != '') {
			context.viewer_server = viewerServer;
		}

		return context;
	},
	initializeTooltip: function (elements, load_info, ajax_call) {
		if (load_info == false) {
			elements.tooltip({
				bodyHandler: function () {
					return elements.attr('data-info');
				},
				showURL: false,
				fade: 10
			});
		}
		else {
			elements.tooltip({
				track: true,

				bodyHandler: function () {
					var id = elements,
						tip = $("<div></div>"),
						hex = id.attr('data-info'),
						viewerContext = App.getTooltipViewerContext(id),
						viewerContextKey = $.param(viewerContext),
						info = id.attr('data-info2'),
						infoViewerContextKey = id.attr('data-info2-viewer-context'),
						loadErrorText = 'Could not load item info.<br />Please try again.';

					function getTooltipHost() {
						var $host = tip.closest('#tooltip');
						if (!$host.length) {
							var $globalHost = $('#tooltip');
							if ($globalHost.length && ($globalHost.find(tip).length || $.contains($globalHost[0], tip[0]))) {
								$host = $globalHost;
							}
						}
						return $host;
					}

					function restoreTooltipChrome() {
						var $host = getTooltipHost();
						if ($host.length && !$host.find('.flame-tooltip-spinner-only').length) {
							$host.removeClass('flame-tooltip-loader-transparent');
						}

						$('#tooltip.flame-tooltip-loader-transparent').each(function () {
							var $currentHost = $(this);
							if (!$currentHost.find('.flame-tooltip-spinner-only').length) {
								$currentHost.removeClass('flame-tooltip-loader-transparent');
							}
						});
					}

					if (typeof(info) != 'undefined' && info.length && infoViewerContextKey == viewerContextKey) {
						tip.html(info);
						setTimeout(restoreTooltipChrome, 0);
						return tip;
					}

					tip.html('<div class="flame-tooltip-spinner-only" aria-hidden="true"></div>');
					setTimeout(function () {
						var $tooltipBox = getTooltipHost();
						if ($tooltipBox.length && $tooltipBox.find('.flame-tooltip-spinner-only').length) {
							$tooltipBox.addClass('flame-tooltip-loader-transparent');
						}
					}, 0);

					$.ajax({
						url: FlameCMSConfig.base_url + ajax_call,
						data: $.extend({item_hex: hex, ajax: 1}, viewerContext),
						success: function (data) {
							var html = '';

							if (data && data.error) {
								html = loadErrorText;
							}
							else if (data && typeof(data.info) != 'undefined') {
								html = data.info;
								id.attr('data-info2', html);
								id.attr('data-info2-viewer-context', viewerContextKey);
							}
							else if (typeof(data) == 'string' && data.length) {
								html = data;
								id.attr('data-info2', html);
								id.attr('data-info2-viewer-context', viewerContextKey);
							}
							else {
								html = loadErrorText;
							}

							tip.html(html);
							restoreTooltipChrome();
							setTimeout(function () {
								if ($.tooltip && typeof $.tooltip.reposition === 'function') {
									$.tooltip.reposition();
								}
							}, 0);
						},
						error: function () {
							tip.html(loadErrorText);
							restoreTooltipChrome();
						}
					});

					return tip;
				},
				showURL: false,
				fade: 10
			});
		}
	},

	initializeModalBoxes: function () {
		$('button[data-modal-div*=buy_windows],button[data-modal-div*=add_to_card_windows], a[data-modal-div*=select_server], img[data-modal-div*=select_server], button[data-modal-div*=auction_bet]').leanModal({
			top: 200,
			closeButton: ".close"
		});
	},

	initializeFlameSelects: function (scope) {
		var root = (typeof(scope) != "undefined") ? $(scope) : $(document),
			selector = '.flame-modern-select, .flame-modern-form select.form-control, .registration_form.flame-registration-form select.form-control',
			selects = root.find(selector);

		if (root.is && root.is(selector)) {
			selects = selects.add(root);
		}

		selects.each(function () {
			App.buildFlameSelect($(this));
		});

		if (!App.flameSelectGlobalEventsBound) {
			App.flameSelectGlobalEventsBound = true;

			$(document).on('click.flameCustomSelect', function () {
				App.closeFlameSelects();
			});

			$(document).on('keydown.flameCustomSelect', function (e) {
				if (e.key === 'Escape') {
					App.closeFlameSelects();
				}
			});
		}
	},
	buildFlameSelect: function (select) {
		if (!select || !select.length || select.data('flame-select-ready')) {
			if (select && select.length) {
				App.refreshFlameSelect(select, true);
			}
			return;
		}

		var custom = $('<div>', {'class': 'flame-custom-select'}),
			trigger = $('<button>', {
				type: 'button',
				'class': 'flame-custom-select-trigger',
				'aria-haspopup': 'listbox',
				'aria-expanded': 'false'
			}),
			triggerText = $('<span>', {'class': 'flame-custom-select-current'}),
			arrow = $('<span>', {'class': 'flame-custom-select-arrow', 'aria-hidden': 'true'}),
			list = $('<ul>', {'class': 'flame-custom-select-options', role: 'listbox'});

		select.addClass('flame-custom-select-native').attr('tabindex', '-1');
		if (select.attr('id')) {
			trigger.attr('aria-controls', select.attr('id') + '-flame-options');
			list.attr('id', select.attr('id') + '-flame-options');
		}

		trigger.append(triggerText).append(arrow);
		custom.append(trigger).append(list);
		select.after(custom);

		select.data('flame-select-ready', true);
		select.data('flame-select-custom', custom);
		custom.data('flame-select-source', select);

		App.refreshFlameSelect(select, true);

		trigger.on('click.flameCustomSelect', function (e) {
			e.preventDefault();
			e.stopPropagation();
			if (select.prop('disabled')) {
				return false;
			}
			if (custom.hasClass('is-open')) {
				App.closeFlameSelects();
			}
			else {
				App.openFlameSelect(custom);
			}
			return false;
		});

		custom.on('click.flameCustomSelect', '.flame-custom-select-option', function (e) {
			e.preventDefault();
			e.stopPropagation();

			var option = $(this);
			if (option.hasClass('is-disabled')) {
				return false;
			}

			select.val(option.attr('data-value')).trigger('change');
			App.syncFlameSelect(select);
			App.closeFlameSelects();
			trigger.focus();
			return false;
		});

		custom.on('keydown.flameCustomSelect', function (e) {
			var current, next;

			if (select.prop('disabled')) {
				return;
			}

			if (e.key === 'Enter' || e.key === ' ') {
				e.preventDefault();
				if (custom.hasClass('is-open')) {
					current = list.find('.flame-custom-select-option.is-focused').first();
					if (!current.length) {
						current = list.find('.flame-custom-select-option.is-selected').first();
					}
					current.trigger('click');
				}
				else {
					App.openFlameSelect(custom);
				}
			}
			else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
				e.preventDefault();
				if (!custom.hasClass('is-open')) {
					App.openFlameSelect(custom);
					return;
				}

				current = list.find('.flame-custom-select-option.is-focused').first();
				if (!current.length) {
					current = list.find('.flame-custom-select-option.is-selected').first();
				}
				next = (e.key === 'ArrowDown') ? current.nextAll('.flame-custom-select-option:not(.is-disabled)').first() : current.prevAll('.flame-custom-select-option:not(.is-disabled)').first();
				if (!next.length) {
					next = (e.key === 'ArrowDown') ? list.find('.flame-custom-select-option:not(.is-disabled)').first() : list.find('.flame-custom-select-option:not(.is-disabled)').last();
				}
				list.find('.flame-custom-select-option').removeClass('is-focused');
				next.addClass('is-focused');
				App.scrollFlameSelectOptionIntoView(list, next);
			}
			else if (e.key === 'Escape') {
				App.closeFlameSelects();
				trigger.focus();
			}
		});

		select.on('change.flameCustomSelect', function () {
			App.syncFlameSelect(select);
		});
	},
	getFlameSelectSignature: function (select) {
		var data = [];
		select.find('option').each(function () {
			data.push([$(this).val(), $(this).text(), this.selected ? 1 : 0, this.disabled ? 1 : 0].join('|'));
		});
		return data.join('||');
	},
	refreshFlameSelect: function (select, force) {
		var custom = select.data('flame-select-custom'),
			list,
			signature,
			selectedValue;

		if (!custom || !custom.length) {
			return;
		}

		list = custom.find('.flame-custom-select-options').first();
		signature = App.getFlameSelectSignature(select);
		if (!force && custom.data('flame-select-signature') === signature) {
			App.syncFlameSelect(select);
			return;
		}

		custom.data('flame-select-signature', signature);
		selectedValue = select.val();
		list.empty();

		select.find('option').each(function (index) {
			var option = $(this),
				item = $('<li>', {
					'class': 'flame-custom-select-option',
					role: 'option',
					text: option.text(),
					'aria-selected': option.val() == selectedValue ? 'true' : 'false',
					'data-value': option.val(),
					'data-index': index
				});

			if (option.prop('disabled')) {
				item.addClass('is-disabled').attr('aria-disabled', 'true');
			}
			if (option.val() == selectedValue) {
				item.addClass('is-selected is-focused');
			}

			list.append(item);
		});

		App.syncFlameSelect(select);
	},
	syncFlameSelect: function (select) {
		var custom = select.data('flame-select-custom'),
			selected = select.find('option:selected').first(),
			selectedValue = select.val(),
			text = selected.length ? selected.text() : '';

		if (!custom || !custom.length) {
			return;
		}

		custom.toggleClass('is-disabled', select.prop('disabled'));
		custom.find('.flame-custom-select-current').text(text);
		custom.find('.flame-custom-select-option').removeClass('is-selected is-focused').attr('aria-selected', 'false');
		custom.find('.flame-custom-select-option').filter(function () {
			return $(this).attr('data-value') == selectedValue;
		}).addClass('is-selected is-focused').attr('aria-selected', 'true');
	},
	openFlameSelect: function (custom) {
		var select = custom.data('flame-select-source'),
			list = custom.find('.flame-custom-select-options').first(),
			selected;

		if (!select || !select.length) {
			return;
		}

		App.closeFlameSelects(custom);
		App.refreshFlameSelect(select, false);
		custom.addClass('is-open');
		custom.find('.flame-custom-select-trigger').attr('aria-expanded', 'true');

		selected = list.find('.flame-custom-select-option.is-selected').first();
		if (!selected.length) {
			selected = list.find('.flame-custom-select-option:not(.is-disabled)').first();
			selected.addClass('is-focused');
		}
		App.scrollFlameSelectOptionIntoView(list, selected);
	},
	closeFlameSelects: function (except) {
		$('.flame-custom-select.is-open').each(function () {
			var custom = $(this);
			if (except && custom.is(except)) {
				return;
			}
			custom.removeClass('is-open');
			custom.find('.flame-custom-select-trigger').attr('aria-expanded', 'false');
			custom.find('.flame-custom-select-option').removeClass('is-focused');
			custom.find('.flame-custom-select-option.is-selected').addClass('is-focused');
		});
	},
	scrollFlameSelectOptionIntoView: function (list, option) {
		if (!list || !list.length || !option || !option.length) {
			return;
		}

		var optionTop = option.position().top,
			optionBottom = optionTop + option.outerHeight(),
			listHeight = list.innerHeight(),
			scrollTop = list.scrollTop();

		if (optionTop < 0) {
			list.scrollTop(scrollTop + optionTop);
		}
		else if (optionBottom > listHeight) {
			list.scrollTop(scrollTop + optionBottom - listHeight);
		}
	},
	closeBuyWindows: function (type) {
		$('#lean_overlay').fadeOut(200);
		if (type == 1) {
			$('#buy_windows').css({"display": "none"});
		}
		else if (type == 2) {
			$('#add_to_card_windows').css({"display": "none"});
		}
		else {
			$('#auction_bet').css({"display": "none"});
		}
	},
	submit_paypal: function (id, reward, price, currency, sandbox) {
		$.ajax({
			url: FlameCMSConfig.base_url + "ajax/paypal",
			data: {proccess_paypal: id, reward: reward, price: price, currency: currency},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					var pp_url = (sandbox == 1) ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';
					var form = '<form action="' + pp_url + '" method="post">';
					form += '<input type="hidden" name="cmd" value="_xclick" />';
					form += '<input type="hidden" name="business" value="' + data.email + '" />';
					form += '<input type="hidden" name="item_name" value="Buy Virtual Currency" />';
					form += '<input type="hidden" name="item_number" value="' + data.item + '" />';
					form += '<input type="hidden" name="currency_code" value="' + currency + '" />';
					form += '<input type="hidden" name="amount" value="' + price + '" />';
					form += '<input type="hidden" name="no_shipping" value="1" />';
					form += '<input type="hidden" name="return" value="' + FlameCMSConfig.base_url + '" />';
					form += '<input type="hidden" name="cancel_return" value="' + FlameCMSConfig.base_url + '" />';
					form += '<input type="hidden" name="notify_url" value="' + FlameCMSConfig.base_url + 'payment/paypal" />';
					form += '<input type="hidden" name="custom" value="' + data.user + '-' + data.server + '" />';
					form += '<input type="hidden" name="no_note" value="1" />';
					form += '<input type="hidden" name="tax" value="0.00" />';
					form += '<input class="button" type="submit" value="Donate">';
					form += '</form>';
					$(form).appendTo('body').submit();
				}
			}
		});
	},
	submit_paycall: function (id) {
		$.ajax({
			url: FlameCMSConfig.base_url + "ajax/paycall",
			data: {proccess_paycall: id},
			success: function (data) {
				if (data.error) {
					App.notice(App.lc.translate('Error').fetch(), 'error', data.error);
				}
				else {
					var form = '<form name="purchase_form" action="http://cart.paycall.co.il/" method="post">';
					form += '<input type="hidden" name="charset" value="utf-8" />';
					form += '<input type="hidden" name="action" value="setPayCallDirect" />';
					form += '<input type="hidden" name="business_code" value="' + data.business_code + '" />';
					form += '<input type="hidden" name="business_name" value="' + data.business_name + '" />';
					form += '<input type="hidden" name="logo" value="http://paycall.co.il/images/logo.png" />';
					form += '<input type="hidden" name="custom_data" value="' + data.item + '" />';
					form += '<input type="hidden" name="shipping_form" value="0" />';
					form += '<input type="hidden" name="back_url" value="' + FlameCMSConfig.base_url + '" />';
					form += '<input type="hidden" name="ipn_url" value="' + FlameCMSConfig.base_url + 'payment/paycall" />';
					form += '<input type="hidden" name="item[1][number]" value="Package-' + id + '" />';
					form += '<input type="hidden" name="item[1][price]" value="' + data.price + '" />';
					form += '<input type="hidden" name="item[1][name]" value="' + data.reward + ' Virtual Currency" />';
					form += '<input type="hidden" name="item[1][quantity]" value="1" />';
					form += '<input type="hidden" name="item[1][digital]" value="1" />';
					form += '<input class="button" type="submit" value="Donate">';
					form += '</form>';
					//console.log(form);
					$(form).appendTo('body').submit();
				}
			}
		});
	},
	downloadImage: function (id) {
		$('<form action="' + FlameCMSConfig.base_url + 'ajax/download" method="POST"><input type="hidden" name="image" value="' + id.parent().parent().parent().attr('id').split("-")[1] + '" /></form>').appendTo('body').submit().remove();
	},
	showTime: function (div) {
		var currentTime = new Date();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		if (minutes < 10) {
			minutes = '0' + minutes;
		}
		if (seconds < 10) {
			seconds = '0' + seconds;
		}
		var v = hours + ':' + minutes + ':' + seconds;
		setTimeout(function () {
			App.showTime(div);
		}, 1000);
		$('#' + div).html(v);
	},
	tooltipImageShow: function (source) {
		var img = new Image();
		img.onload = function () {
			if (this.height > $(window).height()) {
				$(".tooltip-div-image").css("padding-top", 20 + "px");
				$(".tooltip-image").css("height", $(window).height() - 40 + "px");
			}
			else {
				$(".tooltip-div-image").css("padding-top", ($(window).height() - this.height) / 2 + "px");
				$(".tooltip-image").css("height", this.height + "px")
			}

			$(".tooltip-image").attr("src", this.src);
			$(".tooltip-div").css("height", $(document).height() + "px").fadeIn(400);
		}
		img.src = source;
	},
	rotateBanner: function () {
		var pic = parseInt($(".rollingIcon .active").attr("data-pic")) + 1;
		if (pic >= $(".rollingIcon button").length) pic = 0;
		$("#col1 .items").animate({"left": pic * -617 + "px"}, 500);
		$(".rollingIcon button").removeClass();
		$(".rollingIcon").find("button").eq(pic).addClass("active");
	},
// Gala drošā versija ar sarindošanu, "Started" 0s vietā, 10min vizuālo efektu un Next 5 tooltipiem.
getEventTimes: function () {
    App.events_time = FlameCMSConfig.timers || [];

    if (!App.isfirst) {
        App.prepareEventTimers();
        App.events();
        App.isfirst = true;

        setInterval(function () {
            App.syncEventTimersAfterWake();
        }, 30000);
    }
},

prepareEventTimers: function () {
    const now = Math.floor(Date.now() / 1000);

    App.events_time.forEach(function (event) {
        event.endTime = now + parseInt(event.left || 0, 10);

        if ($.isArray(event.occurrences)) {
            event.occurrences.forEach(function (occurrence) {
                occurrence.endTime = now + parseInt(occurrence.left || 0, 10);
            });
        }
    });
},

syncEventTimersAfterWake: function () {
    if (App.events_time && App.events_time.length && typeof App.updateEventTimes === 'function') {
        // endTime values are absolute, so a normal update is enough after a
        // throttled/sleeping tab. Do not rebuild the event DOM every 30s.
        App.updateEventTimes(false);
    }
},

events: function () {
    App.events_time.sort(function (a, b) {
        return a.left - b.left;
    });

    $('#events').empty();

    for (let i in App.events_time) {
        let eventData = App.events_time[i];
        let newDiv = $('<div/>')
            .attr({
                id: 'event-div-' + eventData.id,
                'aria-label': eventData.name + ' next event times'
            })
            .addClass('flame-event-tooltip-trigger')
            .data('event-id', String(eventData.id));

        newDiv.append(
            $('<span />').append(
                $('<i/>', {'class': 'flame-event-name-text'}).text(eventData.name)
            )
        );
        newDiv.append(
            $('<small />')
                .attr({id: 'event' + eventData.id})
                .text(App.formatedTime(eventData.left))
        );
        $('#events').append(newDiv);
    }

    App.initEventTooltip();

    if (!App.timerInterval) {
        App.timerInterval = setInterval(function () {
            App.updateEventTimes(false);
        }, 1000);
    }
},

// Reorder the existing event nodes without clearing #events. jQuery append()
// moves an existing node, so classes/hover state stay intact and no gold
// imminent marker disappears for a frame while the list is resorted.
resortEventRows: function () {
    App.events_time.sort(function (a, b) {
        return a.left - b.left;
    });

    const $events = $('#events');
    if (!$events.length) {
        return;
    }

    App.events_time.forEach(function (eventData) {
        const $row = $('#event-div-' + eventData.id);
        if ($row.length) {
            $events.append($row);
        }
    });

    if (App.eventTooltipActiveId !== null && App.eventTooltipElement && App.eventTooltipElement.hasClass('is-visible')) {
        const $trigger = $('#event-div-' + App.eventTooltipActiveId);
        if ($trigger.length) {
            App.positionEventTooltip($trigger);
        }
    }
},

updateEventTimes: function (forceResort) {
    const now = Math.floor(Date.now() / 1000);
    let resortNeeded = false;

    for (let i in App.events_time) {
        let eventData = App.events_time[i];
        eventData.left = eventData.endTime - now;

        const $el = $('#event' + eventData.id);
        const $div = $('#event-div-' + eventData.id);

        if ($el.length && $div.length) {
            if (eventData.left <= 0) {
                let nextOccurrence = App.getNextEventOccurrence(eventData, now);

                if (nextOccurrence) {
                    eventData.left = nextOccurrence.endTime - now;
                    eventData.endTime = nextOccurrence.endTime;
                    eventData.time = nextOccurrence.time || eventData.time;
                    resortNeeded = true;
                }
                else {
                    eventData.left = 0;
                    $el.text('Started');
                    $div.removeClass('is-imminent').addClass('is-live');
                    continue;
                }
            }

            $div.removeClass('is-live').toggleClass('is-imminent', eventData.left <= 900);
            $el.text(App.formatedTime(eventData.left));
        }
    }

    if (resortNeeded) {
        App.resortEventRows();
    }

    if (App.eventTooltipActiveId !== null) {
        let currentTooltipMinuteKey = Math.floor(now / 60);
        if (App.eventTooltipMinuteKey !== currentTooltipMinuteKey) {
            App.eventTooltipMinuteKey = currentTooltipMinuteKey;
            App.refreshVisibleEventTooltip();
        }
    }
},

getNextEventOccurrence: function (eventData, now) {
    if (!$.isArray(eventData.occurrences)) {
        return null;
    }

    for (let i = 0; i < eventData.occurrences.length; i++) {
        if (typeof eventData.occurrences[i].endTime == 'undefined') {
            eventData.occurrences[i].endTime = now + parseInt(eventData.occurrences[i].left || 0, 10);
        }

        if (eventData.occurrences[i].endTime > now) {
            return eventData.occurrences[i];
        }
    }

    return null;
},

findEventById: function (eventId) {
    eventId = String(eventId);
    for (let i = 0; i < App.events_time.length; i++) {
        if (String(App.events_time[i].id) === eventId) {
            return App.events_time[i];
        }
    }
    return null;
},

initEventTooltip: function () {
    if (App.eventTooltipReady) {
        return;
    }

    App.eventTooltipReady = true;
    App.eventTooltipElement = $('<div/>', {
        'class': 'flame-event-tooltip',
        'aria-hidden': 'true'
    })
        .on('click touchstart touchmove', function (event) {
            event.stopPropagation();
        })
        .appendTo('body');

    $(document)
        .on('mouseenter', '#events .flame-event-tooltip-trigger', function () {
            if (App.eventTooltipLastTouch && (Date.now() - App.eventTooltipLastTouch) < 800) {
                return;
            }
            App.showEventTooltip($(this));
        })
        .on('mouseleave', '#events .flame-event-tooltip-trigger', function () {
            if (App.eventTooltipLastTouch && (Date.now() - App.eventTooltipLastTouch) < 800) {
                return;
            }
            App.hideEventTooltip();
        })
        .on('touchstart', '#events .flame-event-tooltip-trigger', function (event) {
            App.eventTooltipLastTouch = Date.now();

            if (!$(event.target).closest('.flame-event-name-text').length) {
                App.hideEventTooltip();
                event.stopPropagation();
                return;
            }

            event.preventDefault();
            event.stopPropagation();
            this.blur();
            App.showEventTooltip($(this));
        })
        .on('click', '#events .flame-event-tooltip-trigger', function (event) {
            if (App.eventTooltipLastTouch && (Date.now() - App.eventTooltipLastTouch) < 800) {
                event.preventDefault();
                event.stopPropagation();
            }
        })
        .on('click touchstart', function (event) {
            if (!$(event.target).closest('#events .flame-event-tooltip-trigger, .flame-event-tooltip').length) {
                App.hideEventTooltip();
            }
        })
        .on('keydown', function (event) {
            if (event.key === 'Escape') {
                App.hideEventTooltip();
            }
        });

    $(window).on('resize scroll', function () {
        App.hideEventTooltip();
    });
},

showEventTooltip: function ($trigger) {
    let eventId = $trigger.data('event-id');
    let eventData = App.findEventById(eventId);

    if (!eventData || !App.eventTooltipElement) {
        return;
    }

    App.eventTooltipActiveId = String(eventId);
    App.eventTooltipMinuteKey = Math.floor(Date.now() / 60000);
    App.eventTooltipElement.empty().append(App.buildEventTooltip(eventData));
    App.eventTooltipElement.attr('aria-hidden', 'false').addClass('is-visible');
    App.positionEventTooltip($trigger);
},

refreshVisibleEventTooltip: function () {
    if (!App.eventTooltipElement || !App.eventTooltipElement.hasClass('is-visible')) {
        return;
    }

    let eventData = App.findEventById(App.eventTooltipActiveId);
    let $trigger = $('#event-div-' + App.eventTooltipActiveId);

    if (!eventData || !$trigger.length) {
        App.hideEventTooltip();
        return;
    }

    App.eventTooltipElement.empty().append(App.buildEventTooltip(eventData));
    App.positionEventTooltip($trigger);
},

hideEventTooltip: function () {
    if (!App.eventTooltipElement) {
        return;
    }

    App.eventTooltipActiveId = null;
    App.eventTooltipMinuteKey = null;
    App.eventTooltipElement.removeClass('is-visible').attr('aria-hidden', 'true');
},

positionEventTooltip: function ($trigger) {
    if (!App.eventTooltipElement || !$trigger.length) {
        return;
    }

    let rect = $trigger[0].getBoundingClientRect();
    let tooltip = App.eventTooltipElement;
    let width = tooltip.outerWidth();
    let height = tooltip.outerHeight();
    let gap = 12;
    let left = rect.left - width - gap;
    let top = rect.top + (rect.height / 2) - (height / 2);
    let rightSide = false;

    if (left < 10) {
        left = rect.right + gap;
        rightSide = true;
    }
    if (left + width > window.innerWidth - 10) {
        left = Math.max(10, window.innerWidth - width - 10);
    }
    if (top < 10) {
        top = 10;
    }
    if (top + height > window.innerHeight - 10) {
        top = Math.max(10, window.innerHeight - height - 10);
    }

    let arrowTop = (rect.top + (rect.height / 2)) - top;
    let arrowMin = 18;
    let arrowMax = Math.max(arrowMin, height - 18);
    arrowTop = Math.min(arrowMax, Math.max(arrowMin, arrowTop));

    tooltip.toggleClass('is-right-side', rightSide);
    tooltip.css({
        left: left + 'px',
        top: top + 'px',
        '--flame-event-tooltip-arrow-top': arrowTop + 'px'
    });
},

normalizeEventTooltipDay: function (value) {
    let label = String(value || '')
        .normalize('NFKC')
        .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
        .replace(/\u00A0/g, ' ')
        .replace(/[\u0254\u0275\u03BF\u043E\uFF4F]/g, 'o')
        .trim();

    // The helper on the server emits ASCII day names. Keep a defensive
    // fallback for stale/corrupted payloads, but do not rely on it for the
    // normal Today/Tomorrow path (see getEventTooltipDayLabel below).
    let compact = label.replace(/[^A-Za-z]/g, '');
    if (/^T.*day$/i.test(compact) && compact.length <= 7) {
        return 'Today';
    }
    if (/^Tomorrow$/i.test(compact)) {
        return 'Tomorrow';
    }
    return label || 'Today';
},

getEventTooltipDayLabel: function (occurrence) {
    occurrence = occurrence || {};
    let fallback = App.normalizeEventTooltipDay(occurrence.day);
    let timestamp = parseInt(occurrence.timestamp, 10);

    if (!isFinite(timestamp) || timestamp <= 0) {
        return fallback;
    }

    let serverNowMs = Date.now();
    let timeZone = '';

    if (typeof serverTime !== 'undefined') {
        if (typeof serverTime.getServerNowMs === 'function') {
            let syncedNow = serverTime.getServerNowMs();
            if (syncedNow !== null && isFinite(syncedNow)) {
                serverNowMs = syncedNow;
            }
        }
        timeZone = serverTime.serverTimeZone || '';
    }

    let makeParts = function (ms) {
        let options = {year: 'numeric', month: '2-digit', day: '2-digit'};
        if (timeZone) {
            options.timeZone = timeZone;
        }
        let parts = new Intl.DateTimeFormat('en-CA', options).formatToParts(new Date(ms));
        let out = {};
        parts.forEach(function (part) {
            if (part.type === 'year' || part.type === 'month' || part.type === 'day') {
                out[part.type] = parseInt(part.value, 10);
            }
        });
        return out;
    };

    try {
        let nowParts = makeParts(serverNowMs);
        let eventParts = makeParts(timestamp * 1000);
        let nowDay = Date.UTC(nowParts.year, nowParts.month - 1, nowParts.day) / 86400000;
        let eventDay = Date.UTC(eventParts.year, eventParts.month - 1, eventParts.day) / 86400000;
        let diffDays = Math.round(eventDay - nowDay);

        if (diffDays === 0) {
            return 'Today';
        }
        if (diffDays === 1) {
            return 'Tomorrow';
        }

        let weekdayOptions = {weekday: 'long'};
        if (timeZone) {
            weekdayOptions.timeZone = timeZone;
        }
        return new Intl.DateTimeFormat('en-US', weekdayOptions).format(new Date(timestamp * 1000));
    }
    catch (e) {
        return fallback;
    }
},
buildEventTooltip: function (eventData) {
    let now = Math.floor(Date.now() / 1000);
    let $wrap = $('<div/>');
    let $head = $('<div/>', {'class': 'flame-event-tooltip-head'});

    $head.append($('<span/>', {'class': 'flame-event-tooltip-dot'}));
    $head.append($('<strong/>').text(eventData.name));
    $wrap.append($head);

    let $title = $('<div/>', {'class': 'flame-event-tooltip-title'});
    $title.append($('<span/>').text('Next 5 Times'));
    $title.append($('<span/>').text('Server Time'));
    $wrap.append($title);

    let $list = $('<div/>', {'class': 'flame-event-tooltip-list'});
    let occurrences = $.isArray(eventData.occurrences) ? eventData.occurrences : [];
    let shown = 0;

    for (let i = 0; i < occurrences.length && shown < 5; i++) {
        let occurrence = occurrences[i];
        if (typeof occurrence.endTime == 'undefined') {
            occurrence.endTime = now + parseInt(occurrence.left || 0, 10);
        }

        let secondsLeft = occurrence.endTime - now;
        if (secondsLeft < 0) {
            continue;
        }

        let $row = $('<div/>', {'class': 'flame-event-tooltip-row'});
        if (shown === 0) {
            $row.addClass('is-next');
        }

        let $date = $('<span/>', {'class': 'flame-event-tooltip-date'});
        $date.append($('<span/>', {'class': 'flame-event-tooltip-day'}).text(App.getEventTooltipDayLabel(occurrence)));
        $date.append($('<span/>', {'class': 'flame-event-tooltip-time'}).text(occurrence.time || eventData.time || ''));

        $row.append($date);
        $row.append($('<span/>', {'class': 'flame-event-tooltip-left'}).text(App.formatEventTooltipDistance(secondsLeft)));
        $list.append($row);
        shown++;
    }

    if (shown === 0) {
        $list.append($('<div/>', {'class': 'flame-event-tooltip-empty'}).text('Refreshing soon'));
    }

    $wrap.append($list);
    return $wrap;
},

formatEventTooltipDistance: function (seconds) {
    seconds = Math.max(0, parseInt(seconds || 0, 10));

    if (seconds < 60) {
        return 'now';
    }

    let days = Math.floor(seconds / 86400);
    seconds = seconds % 86400;
    let hours = Math.floor(seconds / 3600);
    seconds = seconds % 3600;
    let minutes = Math.floor(seconds / 60);

    if (days > 0) {
        return 'in ' + days + 'd ' + (hours > 0 ? hours + 'h' : '');
    }
    if (hours > 0) {
        return 'in ' + hours + 'h' + (minutes > 0 ? ' ' + minutes + 'm' : '');
    }

    return 'in ' + minutes + 'm';
},

	sprintf: function (format) {
		for (var i = 1; i < arguments.length; i++) {
			format = format.replace(/%s|%d/, arguments[i]);
		}
		return format;
	},
	setCookie: function (key, value, days) {
		var expires = new Date();
		expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
		document.cookie = key + '=' + encodeURIComponent(String(value)) + ';expires=' + expires.toUTCString();
	},
	readCookie: function (key) {
		var result;
		return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? (result[1]) : null;
	},
	count_down: function (target) {
		var serverDate = new Date(FlameCMSConfig.currenttime);
		var targetDate = new Date(target);
		setInterval(function () {
			serverDate.setSeconds(serverDate.getSeconds() + 1);
			App.updateTime(serverDate, targetDate)
		}, 1000);
	},
	checkTime: function (i) {
		if (i < 10) {
			i = "0" + i;
		}
		return i;
	},
	timeDifference: function (begin, end) {
		if (end < begin) {
			return false;
		}
		var diff = {
			seconds: [end.getSeconds() - begin.getSeconds(), 60],
			minutes: [end.getMinutes() - begin.getMinutes(), 60],
			hours: [end.getHours() - begin.getHours(), 24],
			days: [end.getDate() - begin.getDate(), new Date(begin.getYear(), begin.getMonth() + 1, 0).getDate()],
		};
		var result = new Array();
		var flag = false;
		for (i in diff) {
			if (flag) {
				diff[i][0]--;
				flag = false;
			}
			if (diff[i][0] < 0) {
				flag = true;
				diff[i][0] += diff[i][1];
			}
			if (i == 'days' && !diff[i][0]) continue;
			result.push(App.checkTime(diff[i][0]));
		}
		return result.reverse().join(':');
	},
	updateTime: function (serverDate, targetDate) {
		var s = App.timeDifference(serverDate, targetDate);
		if (s.length) {
			var days, hours, minutes, seconds;
			var seconds_left = (targetDate.getTime() - serverDate.getTime()) / 1000;
			days = parseInt(seconds_left / 86400);
			seconds_left = seconds_left % 86400;
			hours = parseInt(seconds_left / 3600);
			seconds_left = seconds_left % 3600;
			minutes = parseInt(seconds_left / 60);
			seconds = parseInt(seconds_left % 60);
			$('#days').html(days);
			$('#hours').html(hours);
			$('#minutes').html(minutes);
			$('#seconds').html(seconds);
		}
		else {
			$('#brightness_opening_countdown').hide();
			$('#timer_div_title').hide();
			$('#timer_div_time').hide();
			clearInterval(App.updateTime(serverDate, targetDate));
		}
	},
	formatedTime: function (seconds) {
		second = seconds % 60;
		minutes = parseInt((seconds / 60) % 60);
		hour = parseInt((seconds / 3600) % 24);
		days = parseInt(seconds / (24 * 3600));
		html = '';
		if (days > 0)
			html += days + 'd ';
		if (hour > 0)
			html += hour + 'h ';
		if (days > 0 && hour <= 0)
			html += '0h ';
		if (minutes > 0)
			html += minutes + 'm ';
		if (minutes < 0)
			html += '0m ';
		if (second < 10)
			second = '0' + second;
		html += second + 's';
		return html;
	},
	setIsSending: function () {
		setTimeout(function () {
			App.isSending = false;
		}, 500);
	}
};

var serverTime = {
    serverStartMs: null,
    clientStartPerfMs: null,
    clientStartMs: null,
    eleServer: null,
    eleLocal: null,
    serverTimeZone: '',
    timerId: null,
    fallbackTimerId: null,
    init: function(e, c){
        this.eleServer = e;
        this.eleLocal = c;

        if ($('#' + this.eleServer).length === 0 && $('#' + this.eleLocal).length === 0) {
            return;
        }

        var $box = $('#' + this.eleServer).closest('.flame-sidebar-timebox');
        this.serverStartMs = this.parseServerEpoch($box.attr('data-server-epoch'));
        this.serverTimeZone = $box.attr('data-server-timezone') || '';

        if (this.serverStartMs === null && typeof FlameCMSConfig != 'undefined' && FlameCMSConfig.currenttime) {
            this.serverStartMs = this.parseServerDate(FlameCMSConfig.currenttime);
        }

        this.clientStartPerfMs = this.nowPerf();
        this.clientStartMs = Date.now();
        this.update();
        this.scheduleNextUpdate();

        var self = this;
        if (this.fallbackTimerId !== null) {
            clearInterval(this.fallbackTimerId);
        }
        this.fallbackTimerId = setInterval(function(){
            self.update();
        }, 30000);
    },
    parseServerEpoch: function(value){
        var epoch = parseInt(value, 10);
        if (isNaN(epoch) || epoch <= 0) {
            return null;
        }
        return epoch * 1000;
    },
    parseServerDate: function(value){
        var parsed = new Date(value);
        if (!isNaN(parsed.getTime())) {
            return parsed.getTime();
        }
        return null;
    },
    nowPerf: function(){
        if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
            return performance.now();
        }
        return Date.now();
    },
    elapsedMs: function(){
        if (this.clientStartPerfMs !== null) {
            return this.nowPerf() - this.clientStartPerfMs;
        }
        return Date.now() - this.clientStartMs;
    },
    getServerNowMs: function(){
        if (this.serverStartMs === null) {
            return null;
        }
        return this.serverStartMs + this.elapsedMs();
    },
    update: function(){
        var localNow = new Date();

        if ($('#' + this.eleLocal).length) {
            $('#' + this.eleLocal).html(this.dateTimeFormat(localNow));
        }

        if ($('#' + this.eleServer).length) {
            var serverNowMs = this.getServerNowMs();
            if (serverNowMs !== null) {
                $('#' + this.eleServer).html(this.dateTimeFormat(new Date(serverNowMs), this.serverTimeZone));
            }
        }
    },
    scheduleNextUpdate: function(){
        var self = this;
        if (this.timerId !== null) {
            clearTimeout(this.timerId);
        }

        var delay = this.nextMinuteDelay(Date.now());
        var serverNowMs = this.getServerNowMs();
        if (serverNowMs !== null) {
            delay = Math.min(delay, this.nextMinuteDelay(serverNowMs));
        }
        delay = Math.max(250, delay + 60);

        this.timerId = setTimeout(function(){
            self.update();
            self.scheduleNextUpdate();
        }, delay);
    },
    syncAfterWake: function(){
        this.update();
        this.scheduleNextUpdate();
    },
    nextMinuteDelay: function(ms){
        return 60000 - (ms % 60000);
    },
    dateTimeFormat: function(dateObj, timeZone){
        if (typeof Intl !== 'undefined' && typeof Intl.DateTimeFormat === 'function') {
            try {
                var options = {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: false,
                    hourCycle: 'h23'
                };

                if (timeZone) {
                    options.timeZone = timeZone;
                }

                var parts = new Intl.DateTimeFormat('en-GB', options).formatToParts(dateObj);
                var hour = '';
                var minute = '';

                for (var i = 0; i < parts.length; i++) {
                    if (parts[i].type === 'hour') {
                        hour = parts[i].value;
                    }
                    if (parts[i].type === 'minute') {
                        minute = parts[i].value;
                    }
                }

                if (hour === '24') {
                    hour = '00';
                }

                if (hour !== '' && minute !== '') {
                    return hour + ':' + minute;
                }
            }
            catch (e) {}
        }

        return this.digit(dateObj.getHours()) + ':' + this.digit(dateObj.getMinutes());
    },
    digit: function(b){
        b = String(b);
        return b.length == 1 ? '0' + b : b;
    }
};

// Keep visible timers accurate after browser throttles background tabs.
// This does not block any AJAX while tab is inactive; it only forces an immediate UI sync when user returns.
document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
        return;
    }
    if (typeof App !== 'undefined' && App.events_time && App.events_time.length && typeof App.updateEventTimes === 'function') {
        App.updateEventTimes();
    }
    if (typeof serverTime !== 'undefined' && typeof serverTime.syncAfterWake === 'function') {
        serverTime.syncAfterWake();
    }
    if (typeof App !== 'undefined' && typeof App.applyVoteRewardSharedStates === 'function') {
        App.applyVoteRewardSharedStates();
    }
    if (typeof App !== 'undefined' && typeof App.syncVoteRewardTimers === 'function') {
        App.syncVoteRewardTimers();
    }
});
window.addEventListener('focus', function () {
    if (typeof App !== 'undefined' && App.events_time && App.events_time.length && typeof App.updateEventTimes === 'function') {
        App.updateEventTimes();
    }
    if (typeof serverTime !== 'undefined' && typeof serverTime.syncAfterWake === 'function') {
        serverTime.syncAfterWake();
    }
    if (typeof App !== 'undefined' && typeof App.applyVoteRewardSharedStates === 'function') {
        App.applyVoteRewardSharedStates();
    }
    if (typeof App !== 'undefined' && typeof App.syncVoteRewardTimers === 'function') {
        App.syncVoteRewardTimers();
    }
});
window.addEventListener('pageshow', function () {
    if (typeof serverTime !== 'undefined' && typeof serverTime.syncAfterWake === 'function') {
        serverTime.syncAfterWake();
    }
});

// === VOTE WCoins PIEVIENOŠANA ===
$(document).ready(function() {
    $('ul.vote-options li').each(function() {
        var $li = $(this);
        var $img = $li.find('img[data-info]');
        var $h5 = $li.find('h5.float-left').first();
        if($img.length && $h5.length) {
            var info = $img.attr('data-info'); 
            var match = info.match(/Reward: (\d+)/);
            if(match) {
                var reward = match[1];
                var $span = $('<span>')
                    .css({'color':'#fbd181'})
                    .text(' +' + reward + ' WCoins');
                $h5.append($span);
            }
        }
    });
});
