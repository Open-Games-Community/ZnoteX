<?php
/**
 * Brightness - default shell.
 *
 * Converted from the "brightnessmu" FlameCMS scrape for the ZnoteX engine. The
 * copied stylesheets under assets/css keep the look; this file rebuilds the
 * chrome (top panel nav, realm monitor, opening countdown, hero header,
 * footer, login modal) and wires it to ZnoteX. The original site API,
 * analytics, jQuery-UI validation engine and language cookie were dropped.
 */

$B = static function (string $k, string $d = ''): string {
	if (!function_exists('theme_option')) return $d;
	$v = trim((string) theme_option($k));
	return $v !== '' ? $v : $d;
};
$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };

$bCrest    = function_exists('theme_image') ? theme_image('logo_crest', theme_asset('images/brightness-emblem-v4.png')) : theme_asset('images/brightness-emblem-v4.png');
$bWordmark = function_exists('theme_image') ? theme_image('logo_wordmark', theme_asset('images/brightness-wordmark-v4.png')) : theme_asset('images/brightness-wordmark-v4.png');
$bHeroLogo = function_exists('theme_image') ? theme_image('logo_hero', theme_asset('images/brightness-logo-v4.png')) : theme_asset('images/brightness-logo-v4.png');
$bFavicon  = function_exists('theme_image') ? theme_image('favicon', theme_asset('images/favicon-32x32.png')) : theme_asset('images/favicon-32x32.png');

$bLang     = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';
$bOnline   = (int) (function_exists('user_count_online') ? user_count_online() : 0);
$bLogged   = function_exists('user_logged_in')
	? user_logged_in()
	: (function_exists('getSession') && getSession('user_id') !== false);
$bIsAdmin  = $bLogged && function_exists('is_admin') && is_admin($user_data ?? null);
$bPage     = (string) ($page_filename ?? 'index');
$bName     = (string) ($user_data['name'] ?? '');

$bFacebook = $B('facebook_url');
$bDiscord  = $B('discord_url');
$bForum    = $B('forum_url');

// --- server status (short TCP probe, cached) -----------------------
$bServerOnline = null;
$bScfg = is_array($config['status'] ?? null) ? $config['status'] : array();
$bSip  = (string) ($bScfg['status_ip'] ?? ($config['ip'] ?? '127.0.0.1'));
$bSport = (int) ($bScfg['status_port'] ?? ($config['port'] ?? 7171));
if ($bSip !== '' && $bSport > 0) {
	$run = static function () use ($bSip, $bSport) {
		$s = @fsockopen($bSip, $bSport, $e, $x, 0.7);
		if ($s) { @fclose($s); return true; }
		return false;
	};
	if (class_exists('Cache')) {
		$c = new Cache('engine/cache/brightness_status');
		if ($c->hasExpired()) { $bServerOnline = $run(); $c->setContent($bServerOnline ? 1 : 0); $c->save(); }
		else { $bServerOnline = ((int) $c->load()) === 1; }
	} else {
		$bServerOnline = $run();
	}
}

// --- opening countdown -------------------------------------------
$bCountdownRaw = $B('countdown_target');
$bCountdownTs  = $bCountdownRaw !== '' ? (int) strtotime($bCountdownRaw) : 0;
$bCountdownOn  = $bCountdownTs > time();
$bCountdownTitle = $B('countdown_title', 'Time left until server opening');

// --- language selector ------------------------------------------
$bLangSel = function_exists('translate_selector') ? translate_selector() : '';
?>
<!DOCTYPE html>
<html lang="<?= $h($bLang) ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="color-scheme" content="light">
	<title><?= theme_title() ?></title>
	<link rel="icon" href="<?= $bFavicon ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/style.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/ui.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/notice.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/components.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/font-awesome.min.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/page-components.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/flamecms.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/brightness-polish.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/brightness-glue.css') ?>">
	<script src="<?= theme_asset('js/jquery-3.6.0.min.js') ?>"></script>
</head>
<body class="brightness-v3-theme <?= $bPage === 'index' ? 'brightness-home' : 'brightness-inner' ?> <?= $h(theme_body_class()) ?>">

<div class="smoke"></div>

<div class="brightness-shell wrapper">
	<section class="brightness-hero-stage">
		<div class="brightness-hero-backdrop" aria-hidden="true"></div>

		<div class="topPanel flex-s-c">
			<a class="brightness-nav-brand" href="index.php" aria-label="<?= theme_title() ?>">
				<img class="brightness-nav-crest" src="<?= $bCrest ?>" alt="">
				<img class="brightness-nav-wordmark" src="<?= $bWordmark ?>" alt="<?= theme_title() ?>">
			</a>

			<div class="btn-mobile btn-drop" data-b-nav-toggle><span></span><span></span><span></span></div>

			<div class="topPanel-left">
				<?php theme_menu(); ?>
			</div>

			<div class="topPanel-right">
				<?php if ($bLangSel !== ''): ?>
					<div class="b-lang"><?= $bLangSel ?></div>
					<?php if (function_exists('translate_selector_assets')) echo translate_selector_assets(); ?>
					<?php if (function_exists('translate_selector_rendered')) translate_selector_rendered(true); ?>
				<?php endif; ?>
				<?php if ($bLogged): ?>
					<a href="myaccount.php" class="user-enter brightness-hero-action brightness-hero-action-login">
						<span class="brightness-login-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M14.5 4H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3.5"/><path d="M10 7.5 14.5 12 10 16.5"/><path d="M14 12H4"/></svg></span>
						<span class="brightness-login-label"><?= $bName !== '' ? $h($bName) : t('brightness.header.account') ?></span>
					</a>
				<?php else: ?>
					<a href="login.php" class="user-enter brightness-hero-action brightness-hero-action-login" data-b-modal="enter">
						<span class="brightness-login-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M14.5 4H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3.5"/><path d="M10 7.5 14.5 12 10 16.5"/><path d="M14 12H4"/></svg></span>
						<span class="brightness-login-label"><?= t('brightness.header.login') ?></span>
					</a>
				<?php endif; ?>
			</div>
		</div>

		<div class="brightness-realm-monitor" aria-label="<?= t('brightness.status.title') ?>">
			<div class="brightness-realm-monitor-heading">
				<span class="brightness-realm-heading-mark" aria-hidden="true"></span>
				<strong><?= t('brightness.status.title') ?></strong>
			</div>
			<div class="online">
				<div class="online-flex <?= $bServerOnline === false ? 'brightness-server-red' : 'brightness-server-green' ?> brightness-server-tone-1">
					<div class="online-block online-block-active">
						<div class="brightness-server-main">
							<div class="brightness-server-info">
								<span class="brightness-server-name"><?= $h((string) ($config['site_title'] ?? theme_title())) ?></span>
								<div class="brightness-server-count">
									<span class="brightness-server-players <?= $bServerOnline === false ? 'color-red' : 'color-green' ?>"><?= $bOnline ?></span>
									<span class="brightness-server-caption"><?= t('brightness.status.players') ?></span>
								</div>
							</div>
							<div class="brightness-server-meta">
								<span class="brightness-server-state <?= $bServerOnline === false ? 'color-red' : 'color-green' ?>">
									<?= $bServerOnline === false ? t('brightness.status.offline') : t('brightness.status.online') ?>
								</span>
								<a class="brightness-server-stats-link" href="serverinfo.php"><?= t('brightness.status.stats') ?></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<a class="brightness-realm-monitor-link" href="highscores.php">
				<span class="brightness-rankings-copy"><span class="brightness-rankings-label"><?= t('brightness.status.rankings') ?></span></span>
				<span class="brightness-rankings-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M5 18V12"/><path d="M12 18V8"/><path d="M19 18V5"/><path d="M3 20h18"/></svg></span>
			</a>
		</div>

		<?php if ($bCountdownOn): ?>
		<div id="brightness_opening_countdown" class="brightness-opening-countdown" data-b-countdown="<?= (int) $bCountdownTs ?>" aria-label="<?= $h($bCountdownTitle) ?>">
			<div id="timer_div_title"><?= $h($bCountdownTitle) ?></div>
			<div id="timer_div_time">
				<div class="timmer_inner_block"><div class="title"><?= t('brightness.countdown.days') ?></div><div id="days" class="count">0</div></div>
				<div class="timmer_inner_block"><div class="title"><?= t('brightness.countdown.hours') ?></div><div id="hours" class="count">0</div></div>
				<div class="timmer_inner_block"><div class="title"><?= t('brightness.countdown.minutes') ?></div><div id="minutes" class="count">0</div></div>
				<div class="timmer_inner_block"><div class="title"><?= t('brightness.countdown.seconds') ?></div><div id="seconds" class="count">0</div></div>
			</div>
		</div>
		<?php endif; ?>

		<?php if ($bPage === 'index'): ?>
		<header class="header flex-s-c">
			<div class="logo">
				<a class="brightness-hero-brand" href="index.php">
					<span class="brightness-brand-copy">
						<img class="brightness-hero-logo-v4" src="<?= $bHeroLogo ?>" alt="<?= theme_title() ?>">
						<?php if ($B('hero_edition') !== ''): ?><small><?= $h($B('hero_edition')) ?></small><?php endif; ?>
					</span>
				</a>
			</div>
			<div class="headerInfo">
				<?php if ($B('hero_kicker') !== ''): ?><div class="brightness-hero-kicker"><?= $h($B('hero_kicker')) ?></div><?php endif; ?>
				<div class="headerInfo-title"><?= $B('hero_title', t('brightness.hero.title')) ?></div>
				<?php if ($B('hero_text') !== ''): ?><div class="headerInfo-text"><?= $h($B('hero_text')) ?></div><?php endif; ?>
			</div>
		</header>
		<?php endif; ?>
	</section>

	<?php
	$bAuth = array('login', 'register', 'lostaccount', 'lostaccountpassword', 'changepassword');
	$bAcct = array('myaccount', 'characters', 'createcharacter', 'twofa', 'changepassword', 'accountsettings', 'settings', 'paymentlog', 'changename', 'changesex', 'changecharacter');
	$bTitle = ucwords(str_replace(array('-', '_'), ' ', $GLOBALS['page_title'] ?? $bPage));
	?>

	<?php if ($bPage === 'index' || in_array($bPage, array('downloads'), true)): ?>
		<?php theme_content(); ?>

	<?php elseif ($bLogged && in_array($bPage, $bAcct, true)): ?>
		<?php
		$acc = is_array($user_data ?? null) ? $user_data : array();
		$accId = (int) ($acc['id'] ?? 0);
		$accZ = ($accId && function_exists('user_znote_account_data')) ? user_znote_account_data($accId, 'points', 'created') : false;
		$accPoints = is_array($accZ) ? (int) ($accZ['points'] ?? 0) : 0;
		$accPrem = !empty($acc['premdays']) ? (int) $acc['premdays']
			: (!empty($acc['premium_ends_at']) && $acc['premium_ends_at'] > time() ? (int) ceil(($acc['premium_ends_at'] - time()) / 86400) : 0);
		$accChars = ($accId && function_exists('user_character_list_count')) ? (int) user_character_list_count($accId) : 0;
		$bTabs = array(
			'myaccount' => array('user', t('brightness.account.overview')),
			'characters' => array('users', t('brightness.account.characters')),
			'createcharacter' => array('plus', t('brightness.account.create')),
			'twofa' => array('shield', '2FA'),
			'changepassword' => array('key', t('brightness.account.password')),
			'settings' => array('cog', t('brightness.account.settings')),
			'paymentlog' => array('credit-card', t('brightness.account.payments')),
		);
		?>
		<div class="main">
			<div class="flame-content">
				<div class="flame-page-box">
					<div class="flame-page-title"><h1><?= t('brightness.account.title') ?></h1></div>
					<div class="flame-page-content">
						<div class="b-acct-strip">
							<div><small><?= t('brightness.account.points') ?></small><strong><?= number_format($accPoints) ?></strong></div>
							<div><small><?= t('brightness.account.characters') ?></small><strong><?= $accChars ?></strong></div>
							<div><small><?= t('brightness.account.status') ?></small><strong><?= $accPrem > 0 ? t('brightness.account.vip') : t('brightness.account.free') ?></strong></div>
							<div><small><?= t('brightness.account.premium') ?></small><strong><?= $accPrem > 0 ? (int) $accPrem : '&mdash;' ?></strong></div>
						</div>
						<nav class="b-acct-tabs">
							<?php foreach ($bTabs as $tk => $tm): if (!is_file($tk . '.php')) continue; ?>
								<a class="b-acct-tab<?= $bPage === $tk ? ' is-active' : '' ?>" href="<?= $h($tk) ?>.php"><i class="fa fa-<?= $tm[0] ?>"></i> <?= $h($tm[1]) ?></a>
							<?php endforeach; ?>
							<a class="b-acct-tab" href="logout.php"><i class="fa fa-sign-out"></i> <?= t('brightness.header.logout') ?></a>
						</nav>
						<div class="b-core"><?php theme_content(); ?></div>
					</div>
				</div>
			</div>
			<?php require __DIR__ . '/../parts/sidebar.php'; ?>
		</div>

	<?php elseif (in_array($bPage, $bAuth, true)): ?>
		<div class="main">
			<div class="flame-content b-auth">
				<div class="flame-page-box">
					<div class="flame-page-title"><h1><?= $h($bTitle) ?></h1></div>
					<div class="flame-page-content"><div class="b-core"><?php theme_content(); ?></div></div>
				</div>
			</div>
		</div>

	<?php else: ?>
		<div class="main">
			<div class="flame-content b-generic">
				<div class="flame-page-box">
					<div class="flame-page-title"><h1><?= $h($bTitle) ?></h1></div>
					<div class="flame-page-content"><div class="b-core"><?php theme_content(); ?></div></div>
				</div>
			</div>
			<?php require __DIR__ . '/../parts/sidebar.php'; ?>
		</div>
	<?php endif; ?>

	<footer class="footer">
		<div class="footerInfo">
			<div class="footerInfo-title"><?= t('brightness.footer.copyright', array('year' => date('Y'), 'site' => $h((string) ($config['site_title'] ?? theme_title())))) ?></div>
			<?php if ($B('footer_disclaimer') !== ''): ?><div class="footerInfo-text"><?= $h($B('footer_disclaimer')) ?></div><?php endif; ?>
			<div class="footerInfo-buttons">
				<a href="rules.php"><?= t('brightness.footer.rules') ?></a>
				<a href="credits.php"><?= t('brightness.footer.credits') ?></a>
				<?php if ($bForum !== ''): ?><a href="<?= $h($bForum) ?>" target="_blank" rel="noopener"><?= t('brightness.nav.forum') ?></a><?php endif; ?>
			</div>
		</div>
		<div class="footerMenu flex">
			<ul>
				<li><a href="index.php"><?= t('nav.news') ?></a></li>
				<li><a href="register.php"><?= t('brightness.header.register') ?></a></li>
				<li><a href="downloads.php"><?= t('brightness.nav.download') ?></a></li>
				<li><a href="highscores.php"><?= t('nav.highscores') ?></a></li>
			</ul>
			<ul>
				<li><a href="serverinfo.php"><?= t('nav.serverinfo') ?></a></li>
				<li><a href="guilds.php"><?= t('nav.guilds') ?></a></li>
				<li><a href="onlinelist.php"><?= t('brightness.nav.online') ?></a></li>
				<?php if ($bForum !== ''): ?><li><a href="<?= $h($bForum) ?>" target="_blank" rel="noopener"><?= t('brightness.nav.forum') ?></a></li><?php endif; ?>
			</ul>
		</div>
		<div class="footerRight">
			<div class="socBlock brightness-footer-social">
				<?php if ($bFacebook !== ''): ?><a href="<?= $h($bFacebook) ?>" target="_blank" rel="noopener" class="fb brightness-footer-social-card" aria-label="Facebook"><svg class="brightness-facebook-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.397 21v-8.196h2.765l.414-3.203h-3.179V7.557c0-.927.258-1.559 1.59-1.559h1.7V3.133c-.294-.039-1.304-.127-2.479-.127-2.453 0-4.134 1.497-4.134 4.247v2.348H7.299v3.203h2.775V21h3.323Z"/></svg><span class="brightness-footer-social-name">Facebook</span></a><?php endif; ?>
				<?php if ($bDiscord !== ''): ?><a href="<?= $h($bDiscord) ?>" target="_blank" rel="noopener" class="fb brightness-footer-social-card" aria-label="Discord"><i class="fa fa-discord" style="font-size:20px;"></i><span class="brightness-footer-social-name">Discord</span></a><?php endif; ?>
			</div>
			<div class="footerInfo-text" style="margin-top:8px;font-size:11px;opacity:.7;">
				<?= t('brightness.footer.powered') ?> <a href="credits.php">ZnoteX</a> &middot; <?= function_exists('elapsedTime') ? elapsedTime() : '0' ?>s
			</div>
		</div>
	</footer>
</div>

<?php if (!$bLogged): ?>
<div id="enter" class="modal_div">
	<span class="modal_close" data-b-modal-close></span>
	<div class="modalContent">
		<div class="modal-title flex-s-c">
			<span><?= t('brightness.header.login') ?></span>
			<a href="register.php" class="button button-white button-small"><?= t('brightness.header.register') ?></a>
		</div>
		<form id="login_form" method="POST" action="login.php" autocomplete="on">
			<div class="formGroup"><p><?= t('brightness.auth.account') ?></p><input type="text" name="username" placeholder="<?= t('brightness.auth.account') ?>" autocomplete="username" required></div>
			<div class="formGroup"><p><?= t('brightness.auth.password') ?></p><input type="password" name="password" placeholder="<?= t('brightness.auth.password') ?>" autocomplete="current-password" required></div>
			<div class="formButtons">
				<button type="submit" class="brightness-login-submit"><?= t('brightness.header.login') ?></button>
				<a class="lost-pass forget" href="lostaccount.php"><?= t('brightness.auth.forgot') ?></a>
			</div>
		</form>
	</div>
</div>
<div id="overlay"></div>
<?php endif; ?>

<script src="<?= theme_asset('js/brightness.js') ?>" defer></script>
</body>
</html>
