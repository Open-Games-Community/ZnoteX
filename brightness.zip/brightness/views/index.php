<?php
/**
 * Brightness - front page (and the single news article view).
 *
 * Converted from the FlameCMS home route. The hero header is drawn by the
 * shell; this view outputs the news column (from $news) and the right sidebar.
 * Prepared by index.php: $news, $changelogs, $page, $view.
 */

$h  = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$bb = static function ($v): string { return function_exists('znote_bbcode_raw') ? znote_bbcode_raw((string) $v) : (string) $v; };
$plain = static function ($t) use ($bb): string { return trim(strip_tags($bb((string) $t))); };
$excerpt = static function ($t, int $n = 320) use ($bb): string {
	$s = trim(preg_replace('~\s+~', ' ', strip_tags($bb((string) $t))));
	if (function_exists('mb_strimwidth')) return mb_strimwidth($s, 0, $n, '…', 'UTF-8');
	return strlen($s) > $n ? substr($s, 0, $n - 1) . '…' : $s;
};
$items = is_array($news ?? null) ? array_values($news) : array();

if (($view ?? '') !== '') {
	$article = null;
	foreach ($items as $r) {
		if ((ctype_digit((string) $view) && (int) $view === (int) $r['id']) || urlencode($r['title']) === $view) { $article = $r; break; }
	}
	?>
	<div class="main">
		<div class="flame-content">
			<div class="flame-page-box">
				<div class="flame-page-title"><h1><?= $article ? $h($plain($article['title'])) : $h(t('news.not_found')) ?></h1></div>
				<div class="flame-page-content">
					<div class="b-core">
						<?php if ($article): ?>
							<p style="opacity:.65;font-size:13px;margin-bottom:12px;"><?= $h(getClock((int) $article['date'], true)) ?> &middot; <?= t('news.by') ?> <a href="characterprofile.php?name=<?= $h(urlencode($article['name'])) ?>"><?= $h($article['name']) ?></a></p>
							<?= $bb($article['text']) ?>
						<?php else: ?>
							<p><?= t('news.not_found_text') ?></p>
						<?php endif; ?>
						<p style="margin-top:18px;"><a class="brightness-news-read-more" href="index.php"><span class="brightness-news-read-more-label">&larr; <?= t('brightness.news.back') ?></span></a></p>
					</div>
				</div>
			</div>
		</div>
		<?php require __DIR__ . '/../parts/sidebar.php'; ?>
	</div>
	<?php
	return;
}
?>
<div class="main">
	<div class="news brightness-news-page">
		<div class="news-title"><?= t('brightness.section.news_pre') ?> <span><?= t('brightness.section.news') ?></span></div>

		<?php if ($items): ?>
			<?php $first = array_shift($items); ?>
			<div class="newsBlock newsBlockFeatured">
				<div class="newsBlock-title"><a href="index.php?view=<?= (int) $first['id'] ?>"><?= $h($plain($first['title'])) ?></a></div>
				<div class="newsBlock-text"><?= $bb($first['text']) ?></div>
				<div class="newsBlock-button">
					<a href="index.php?view=<?= (int) $first['id'] ?>" class="brightness-news-read-more">
						<span class="brightness-news-read-more-label"><?= t('brightness.section.read_more') ?></span>
						<svg class="brightness-news-read-more-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13"></path><path d="m13 6 6 6-6 6"></path></svg>
					</a>
				</div>
			</div>

			<?php if ($items): ?>
			<div class="newsBlockFlex">
				<?php foreach (array_slice($items, 0, 6) as $i => $n): ?>
					<div class="newsBlock newsBlockSmall newsBlockVariant-<?= ($i % 3) + 1 ?>">
						<div class="newsBlock-title"><a href="index.php?view=<?= (int) $n['id'] ?>"><?= $h($plain($n['title'])) ?></a></div>
						<div class="newsBlock-text"><p><?= $h($excerpt($n['text'])) ?></p></div>
						<div class="newsBlock-button">
							<a href="index.php?view=<?= (int) $n['id'] ?>" class="brightness-news-read-more">
								<span class="brightness-news-read-more-label"><?= t('brightness.section.read_article') ?></span>
								<svg class="brightness-news-read-more-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13"></path><path d="m13 6 6 6-6 6"></path></svg>
							</a>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>
		<?php else: ?>
			<div class="newsBlock newsBlockSmall"><div class="newsBlock-text"><p><?= t('news.none') ?></p></div></div>
		<?php endif; ?>

		<?php if (is_array($changelogs ?? null) && $changelogs): ?>
			<div class="newsBlock newsBlockSmall" style="margin-top:14px;">
				<div class="newsBlock-title"><a href="changelog.php"><?= t('brightness.section.changelog') ?></a></div>
				<div class="newsBlock-text"><ul style="margin:0;padding-left:18px;">
					<?php foreach (array_slice($changelogs, 0, 6) as $cl): ?>
						<li style="margin-bottom:6px;"><span style="opacity:.6;font-size:12px;"><?= $h(getClock((int) ($cl['time'] ?? 0), true, true)) ?></span> — <?= $bb((string) ($cl['text'] ?? '')) ?></li>
					<?php endforeach; ?>
				</ul></div>
			</div>
		<?php endif; ?>
	</div>

	<?php require __DIR__ . '/../parts/sidebar.php'; ?>
</div>
