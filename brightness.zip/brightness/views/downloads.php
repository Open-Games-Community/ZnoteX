<?php
/**
 * Brightness - Downloads.
 *
 * Converted from the FlameCMS downloads route (.brightness-downloads-page).
 * Client links come from the "Download links" theme option (Label | URL |
 * size | source per line); falls back to $config['client_download'] /
 * client_download_linux. The install-guide and font sections are editable
 * text options.
 */

$h = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$opt = static function (string $k) { return function_exists('theme_option') ? trim((string) theme_option($k)) : ''; };

$version = isset($config['client']) && (int) $config['client'] > 0
	? rtrim(rtrim(number_format($config['client'] / 100, 2, '.', ''), '0'), '.') : '';

$links = array();
foreach (preg_split('/\r\n|\r|\n/', $opt('download_links')) as $line) {
	$line = trim($line);
	if ($line === '' || strpos($line, '|') === false) continue;
	$p = array_map('trim', explode('|', $line));
	if (($p[1] ?? '') === '' || !preg_match('~^https?://~i', $p[1])) continue;
	$links[] = array('label' => $p[0] !== '' ? $p[0] : t('brightness.dl.client'), 'url' => $p[1], 'size' => $p[2] ?? '', 'src' => $p[3] ?? '');
}
if (!$links) {
	foreach (array($config['client_download'] ?? '', $config['client_download_linux'] ?? '') as $u) {
		$u = trim((string) $u);
		if ($u !== '') $links[] = array('label' => t('brightness.dl.client'), 'url' => $u, 'size' => '', 'src' => '');
	}
}
?>
<div class="main">
<div class="flame-content">
	<div class="flame-page-box">
		<div class="flame-page-title"><h1><?= $h(t('brightness.dl.title')) ?></h1></div>
		<div class="flame-page-content brightness-downloads-page">

			<section class="brightness-download-section brightness-download-client-section">
				<div class="brightness-download-section-head">
					<span class="brightness-download-step" aria-hidden="true">01</span>
					<div>
						<h3><?= $h(t('brightness.dl.client_head')) ?></h3>
						<p><?= $h($opt('download_intro') ?: t('brightness.dl.client_lead')) ?></p>
					</div>
				</div>
				<div class="brightness-download-section-body">
					<?php if ($links): ?>
						<div class="brightness-download-links" aria-label="<?= $h(t('brightness.dl.title')) ?>">
							<?php foreach ($links as $l): ?>
								<a href="<?= $h($l['url']) ?>" class="flame-download-button brightness-download-button" role="button" target="_blank" rel="noopener">
									<span class="brightness-download-icon-shell" aria-hidden="true">
										<svg class="brightness-download-icon" viewBox="0 0 24 24" focusable="false"><path d="M12 3v10"></path><path d="m8.5 10.5 3.5 3.5 3.5-3.5"></path><path d="M5 19h14"></path></svg>
									</span>
									<span class="brightness-download-copy">
										<span class="brightness-download-title"><?= $h($l['label']) ?></span>
										<?php if ($l['src'] !== ''): ?><span class="brightness-download-description"><?= $h($l['src']) ?></span><?php endif; ?>
										<?php if ($l['size'] !== '' || $version !== ''): ?>
											<span class="brightness-download-meta">
												<?php if ($version !== ''): ?><span>v<?= $h($version) ?></span><?php endif; ?>
												<?php if ($l['size'] !== ''): ?><span><?= $h($l['size']) ?></span><?php endif; ?>
											</span>
										<?php endif; ?>
									</span>
								</a>
							<?php endforeach; ?>
						</div>
					<?php else: ?>
						<div class="b-dl-empty"><?= $h(t('brightness.dl.none')) ?></div>
					<?php endif; ?>

					<?php if ($opt('download_notice') !== ''): ?>
						<div class="brightness-download-notice">
							<div class="brightness-download-notice-copy"><p><?= nl2br($h($opt('download_notice'))) ?></p></div>
						</div>
					<?php endif; ?>
				</div>
			</section>

			<?php if ($opt('download_guide') !== ''): ?>
			<section class="brightness-download-section brightness-download-guide-section">
				<div class="brightness-download-section-head">
					<span class="brightness-download-step" aria-hidden="true">02</span>
					<div><h3><?= $h(t('brightness.dl.guide_head')) ?></h3><p><?= $h(t('brightness.dl.guide_lead')) ?></p></div>
				</div>
				<div class="brightness-download-section-body brightness-installation-guide">
					<div class="b-core"><?= function_exists('znote_bbcode_raw') ? znote_bbcode_raw($opt('download_guide')) : nl2br($h($opt('download_guide'))) ?></div>
				</div>
			</section>
			<?php endif; ?>

			<section class="brightness-download-section brightness-download-font-section">
				<div class="brightness-download-section-head">
					<span class="brightness-download-step" aria-hidden="true"><?= $opt('download_guide') !== '' ? '03' : '02' ?></span>
					<div><h3><?= $h(t('brightness.dl.play_head')) ?></h3><p><?= $h(t('brightness.dl.play_lead')) ?></p></div>
				</div>
				<div class="brightness-download-section-body">
					<div class="brightness-font-fix">
						<h4><?= $h(t('brightness.dl.steps_title')) ?></h4>
						<ol class="b-core" style="padding-left:20px;line-height:2;">
							<li><?= $h(t('brightness.dl.step1')) ?></li>
							<li><?= $h(t('brightness.dl.step2')) ?></li>
							<li><?= $h(t('brightness.dl.step3', array('site' => (string) ($config['site_title'] ?? theme_title())))) ?></li>
						</ol>
					</div>
				</div>
			</section>

		</div>
	</div>
</div>
	<?php require __DIR__ . '/../parts/sidebar.php'; ?>
</div>
