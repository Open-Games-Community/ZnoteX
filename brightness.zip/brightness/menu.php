<?php
/**
 * Brightness top navigation.
 *
 * Managed via Admin Panel > Menus (theme_menu_items('main')); a default set is
 * drawn otherwise. Parent items with children become hover (desktop) / tap
 * (mobile) dropdowns - the FlameCMS menu was flat, so the dropdown styling
 * lives in brightness-glue.css and the tap handler in brightness.js.
 */

$bMenu    = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$bHasMenu = function_exists('theme_menu_available') ? theme_menu_available() : (bool) $bMenu;
$bCur     = (string) ($page_filename ?? 'index');
$bFacebook = function_exists('theme_option') ? trim(theme_option('facebook_url')) : '';
$bDiscord2 = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$bForum2   = function_exists('theme_option') ? trim(theme_option('forum_url')) : '';
$hh = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$ml = static function ($v): string {
	$label = function_exists('theme_menu_label') ? theme_menu_label((string) $v) : (string) $v;
	return htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
};
$active = static function (string $url) use ($bCur): bool {
	if ($url === '') return false;
	if ($bCur === 'index') return $url === 'index.php';
	return strpos($url, $bCur . '.php') === 0;
};

/* Build a uniform tree: array of [label, url, target, children[]] */
$tree = array();
if ($bHasMenu) {
	foreach ($bMenu as $it) {
		$kids = array();
		foreach ($it['children'] as $ch) {
			$kids[] = array($ml($ch['label']), $ch['url'] !== '' ? $ch['url'] : '#', $ch['target']);
		}
		$url = $it['url'] !== '' ? $it['url'] : ($kids ? $kids[0][1] : '#');
		$tree[] = array($ml($it['label']), $url, $it['target'], $kids);
	}
} else {
	$tree[] = array(t('nav.news'), 'index.php', '', array());
	$tree[] = array(t('brightness.header.register'), 'register.php', '', array());
	$tree[] = array(t('brightness.nav.download'), 'downloads.php', '', array());
	$tree[] = array(t('nav.highscores'), 'highscores.php', '', array(
		array(t('nav.highscores'), 'highscores.php', ''),
		array(t('brightness.nav.online'), 'onlinelist.php', ''),
		array(t('nav.guilds'), 'guilds.php', ''),
	));
	$tree[] = array(t('nav.serverinfo'), 'serverinfo.php', '', array());
	$tree[] = array(t('brightness.footer.rules'), 'rules.php', '', array());
	if ($bForum2 !== '') $tree[] = array(t('brightness.nav.forum'), $bForum2, '_blank', array());
}
?>
<div class="mobile-menu" data-b-mobile-menu>
	<ul>
		<?php foreach ($tree as $it): $hasSub = !empty($it[3]); ?>
			<li class="<?= $hasSub ? 'has-sub' : '' ?>">
				<a href="<?= $hh($it[1]) ?>"<?= $it[2] !== '' ? ' target="' . $hh($it[2]) . '" rel="noopener"' : '' ?>><?= $hh($it[0]) ?></a>
				<?php if ($hasSub): ?>
					<button type="button" class="b-sub-toggle" aria-label="expand"><i class="fa fa-chevron-down"></i></button>
					<ul class="b-sub">
						<?php foreach ($it[3] as $ch): ?>
							<li><a href="<?= $hh($ch[1]) ?>"<?= $ch[2] !== '' ? ' target="' . $hh($ch[2]) . '" rel="noopener"' : '' ?>><?= $hh($ch[0]) ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</div>

<nav class="menu-wrapper">
	<ul class="menu menu-main">
		<?php foreach ($tree as $it): $hasSub = !empty($it[3]); ?>
			<li class="menu__item<?= $hasSub ? ' has-sub' : '' ?>">
				<a class="menu__link<?= $active($it[1]) ? ' active' : '' ?>" href="<?= $hh($it[1]) ?>"<?= $it[2] !== '' ? ' target="' . $hh($it[2]) . '" rel="noopener"' : '' ?>>
					<?= $hh($it[0]) ?><?php if ($hasSub): ?> <i class="fa fa-chevron-down b-caret"></i><?php endif; ?>
				</a>
				<?php if ($hasSub): ?>
					<ul class="b-sub">
						<?php foreach ($it[3] as $ch): ?>
							<li><a href="<?= $hh($ch[1]) ?>"<?= $ch[2] !== '' ? ' target="' . $hh($ch[2]) . '" rel="noopener"' : '' ?>><?= $hh($ch[0]) ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
		<?php if ($bFacebook !== ''): ?>
			<li class="menu__item brightness-nav-social-item"><a class="menu__link brightness-nav-social-link brightness-nav-social-facebook" href="<?= $hh($bFacebook) ?>" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 22v-9h3l.45-3.5H13.5V7.26c0-1.01.28-1.7 1.73-1.7H17V2.44c-.31-.04-1.38-.13-2.62-.13-2.6 0-4.38 1.59-4.38 4.5V9.5H7v3.5h3v9h3.5Z"/></svg></a></li>
		<?php endif; ?>
		<?php if ($bDiscord2 !== ''): ?>
			<li class="menu__item brightness-nav-social-item"><a class="menu__link brightness-nav-social-link brightness-nav-social-discord" href="<?= $hh($bDiscord2) ?>" target="_blank" rel="noopener" aria-label="Discord"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19.54 5.34A16.4 16.4 0 0 0 15.44 4l-.5 1.02a15.2 15.2 0 0 0-5.87 0L8.56 4a16.6 16.6 0 0 0-4.11 1.35C1.85 9.19 1.15 12.94 1.5 16.64a16.5 16.5 0 0 0 5.04 2.54l1.24-1.68a10.7 10.7 0 0 1-1.95-.93l.48-.37c3.77 1.72 7.84 1.72 11.57 0l.49.37c-.63.37-1.28.68-1.96.93l1.24 1.68a16.4 16.4 0 0 0 5.04-2.54c.42-4.29-.72-8-3.15-11.3ZM8.52 14.42c-1.13 0-2.06-1.04-2.06-2.31 0-1.28.91-2.32 2.06-2.32 1.16 0 2.08 1.05 2.06 2.32 0 1.27-.91 2.31-2.06 2.31Zm6.96 0c-1.13 0-2.06-1.04-2.06-2.31 0-1.28.91-2.32 2.06-2.32 1.16 0 2.08 1.05 2.06 2.32 0 1.27-.9 2.31-2.06 2.31Z"/></svg></a></li>
		<?php endif; ?>
	</ul>
</nav>
