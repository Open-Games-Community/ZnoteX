<?php
/**
 * Brightness - right sidebar: server / local clock and the Discord card.
 * Rebuilt from the FlameCMS "brightness-events-widget" markup; the events feed
 * was dropped (no API) and replaced with the top players list.
 */
if (!isset($config)) return;

$bh = static function ($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
$bDiscord = function_exists('theme_option') ? trim(theme_option('discord_url')) : '';
$bTz = date_default_timezone_get() ?: 'UTC';

$bIgnore = (int) ($config['highscore']['ignoreGroupId'] ?? 2);
$bTop = array();
if (function_exists('db')) {
	$c = new Cache('engine/cache/brightness_top');
	if ($c->hasExpired()) {
		$bTop = db()->fetchAll("SELECT `name`, `level` FROM `players` WHERE `group_id` < ? ORDER BY `level` DESC, `experience` DESC LIMIT 8;", [$bIgnore]);
		$bTop = is_array($bTop) ? $bTop : array();
		$c->setContent($bTop);
		$c->save();
	} else {
		$bTop = is_array($c->load()) ? $c->load() : array();
	}
}
?>
<div class="sidebar">
	<div class="top">
		<section class="brightness-events-widget" aria-label="<?= t('brightness.sidebar.clock') ?>">
			<header class="brightness-events-widget-header"><strong><?= t('brightness.sidebar.clock') ?></strong></header>
			<div class="brightness-events-widget-body">
				<div class="flame-sidebar-timebox" data-b-clock data-server-epoch="<?= time() ?>" data-server-timezone="<?= $bh($bTz) ?>">
					<div class="flame-sidebar-timebox-row">
						<div class="flame-sidebar-timebox-item"><span><?= t('brightness.sidebar.server_time') ?></span><strong id="ServerTime">--:--</strong></div>
						<div class="flame-sidebar-timebox-separator"></div>
						<div class="flame-sidebar-timebox-item"><span><?= t('brightness.sidebar.your_time') ?></span><strong id="LocalTime">--:--</strong></div>
					</div>
				</div>

				<div class="brightness-events-list-heading">
					<span><?= t('brightness.sidebar.top_players') ?></span>
					<small><a href="highscores.php" style="color:inherit;"><?= t('brightness.section.view_all') ?></a></small>
				</div>
				<div class="brightness-events-list">
					<?php if ($bTop): foreach ($bTop as $i => $p): ?>
						<div class="brightness-events-list-item" style="display:flex;justify-content:space-between;gap:10px;padding:7px 10px;">
							<span style="opacity:.6;font-weight:700;width:18px;"><?= $i + 1 ?></span>
							<a href="characterprofile.php?name=<?= $bh(urlencode($p['name'])) ?>" style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= $bh($p['name']) ?></a>
							<strong><?= (int) $p['level'] ?></strong>
						</div>
					<?php endforeach; else: ?>
						<div style="padding:14px;opacity:.6;"><?= t('common.nothing') ?></div>
					<?php endif; ?>
				</div>
			</div>
		</section>

		<?php if ($bDiscord !== ''): ?>
		<a class="brightness-discord-community" href="<?= $bh($bDiscord) ?>" target="_blank" rel="noopener noreferrer" aria-label="Discord">
			<div class="brightness-discord-community-top">
				<span class="brightness-discord-community-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M19.54 5.34A16.4 16.4 0 0 0 15.44 4l-.5 1.02a15.2 15.2 0 0 0-5.87 0L8.56 4a16.6 16.6 0 0 0-4.11 1.35C1.85 9.19 1.15 12.94 1.5 16.64a16.5 16.5 0 0 0 5.04 2.54l1.24-1.68a10.7 10.7 0 0 1-1.95-.93l.48-.37c3.77 1.72 7.84 1.72 11.57 0l.49.37c-.63.37-1.28.68-1.96.93l1.24 1.68a16.4 16.4 0 0 0 5.04-2.54c.42-4.29-.72-8-3.15-11.3ZM8.52 14.42c-1.13 0-2.06-1.04-2.06-2.31 0-1.28.91-2.32 2.06-2.32 1.16 0 2.08 1.05 2.06 2.32 0 1.27-.91 2.31-2.06 2.31Zm6.96 0c-1.13 0-2.06-1.04-2.06-2.31 0-1.28.91-2.32 2.06-2.32 1.16 0 2.08 1.05 2.06 2.32 0 1.27-.9 2.31-2.06 2.31Z"/></svg></span>
				<span class="brightness-discord-community-title"><small><?= t('brightness.sidebar.community') ?></small><strong>Discord</strong></span>
				<span class="brightness-discord-community-arrow" aria-hidden="true"><span class="brightness-discord-community-arrow-icon"></span></span>
			</div>
			<div class="brightness-discord-community-copy"><?= t('brightness.sidebar.discord_copy') ?></div>
			<div class="brightness-discord-community-meta">
				<span class="brightness-discord-community-live"><i class="brightness-discord-status-dot"></i> <?= t('brightness.sidebar.community_online') ?></span>
				<strong><?= t('brightness.sidebar.join_now') ?></strong>
			</div>
		</a>
		<?php endif; ?>
	</div>
</div>
