<?php
/**
 * Custom Leaderboards - admin-defined ranked lists on their own page.
 *
 * Read-only against the game DB. A board ranks by a players column, a
 * player_storage key, PvP kills or deaths, with filters. Optional weekly /
 * monthly reset snapshots the winners and pays prizes (GET_LOCK guarded so a
 * reset never double-pays). Menu entry is added next to Guilds on install.
 */
if (!function_exists('custom_leaderboards_setting')) {

function custom_leaderboards_setting(string $k, string $d = ''): string {
	return function_exists('setting') ? (string) setting('custom_leaderboards:' . $k, $d) : $d;
}
function custom_leaderboards_enabled(): bool { return custom_leaderboards_setting('enabled', '1') === '1'; }
function custom_leaderboards_h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function custom_leaderboards_t(string $k, string $f, array $v = array()): string {
	$s = function_exists('t_default') ? t_default($k, $f, $v) : $f;
	foreach ($v as $a => $b) $s = str_replace('{' . $a . '}', (string) $b, $s);
	return $s;
}
function custom_leaderboards_ident(string $v): string { $v = trim($v); return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : ''; }
function custom_leaderboards_int(string $k, int $d): int { $v = custom_leaderboards_setting($k, ''); return $v === '' ? $d : (int) $v; }
function custom_leaderboards_css(string $v): string {
	$v = trim($v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function custom_leaderboards_color(string $k): string { return custom_leaderboards_css(custom_leaderboards_setting('style_' . $k, '')); }
function custom_leaderboards_url(string $v): string {
	$v = trim($v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function custom_leaderboards_asset(string $file): string {
	$file = preg_replace('/[^a-zA-Z0-9_.\/-]/', '', $file);
	if ($file === '' || strpos($file, '..') !== false) return '';
	$p = __DIR__ . '/assets/img/' . $file;
	return is_file($p) ? znote_plugin_asset('custom_leaderboards', 'img/' . $file) : '';
}
function custom_leaderboards_medal(int $rank): string {
	$u = custom_leaderboards_url(custom_leaderboards_setting('medal_' . $rank, ''));
	if ($u !== '') return $u;
	return custom_leaderboards_asset('medal-' . $rank . '.svg');
}
function custom_leaderboards_prize_icon(string $which): string {
	$key = $which === 'premium' ? 'prize_icon_premium' : 'prize_icon_points';
	$u = custom_leaderboards_url(custom_leaderboards_setting($key, ''));
	if ($u !== '') return $u;
	return custom_leaderboards_asset($which === 'premium' ? 'vip.png' : 'points.png');
}
function custom_leaderboards_style_attr(): string {
	$map = array('box_bg' => '--lb-surface', 'border' => '--lb-border', 'text' => '--lb-text', 'accent' => '--lb-accent',
		'row_bg' => '--lb-row', 'you_bg' => '--lb-you', 'head_bg' => '--lb-head-bg', 'head_text' => '--lb-head-text',
		'gold' => '--lb-gold', 'silver' => '--lb-silver', 'bronze' => '--lb-bronze');
	$css = '';
	foreach ($map as $k => $var) { $v = custom_leaderboards_color($k); if ($v !== '') $css .= $var . ':' . $v . ';'; }
	return $css !== '' ? ' style="' . custom_leaderboards_h($css) . '"' : '';
}

// --- board definitions ----------------------------------------------
function custom_leaderboards_tables_ok(): bool {
	return function_exists('znote_table_exists') && znote_table_exists('znote_leaderboards');
}
function custom_leaderboards_sources(): array {
	return array(
		'players_col'  => 'Players column',
		'storage'      => 'player_storage key',
		'pvp_kills'    => 'PvP kills (player_deaths)',
		'deaths'       => 'Deaths taken (player_deaths)',
	);
}
function custom_leaderboards_formats(): array { return array('number', 'gold', 'time', 'raw'); }
function custom_leaderboards_boards(bool $activeOnly = false): array {
	if (!custom_leaderboards_tables_ok()) return array();
	$w = $activeOnly ? ' WHERE `active` = 1' : '';
	$rows = mysql_select_multi("SELECT * FROM `znote_leaderboards`{$w} ORDER BY `sort_order` ASC, `id` ASC;");
	return is_array($rows) ? $rows : array();
}
function custom_leaderboards_board(int $id): ?array {
	if ($id <= 0 || !custom_leaderboards_tables_ok()) return null;
	$r = mysql_select_single("SELECT * FROM `znote_leaderboards` WHERE `id` = {$id} LIMIT 1;");
	return is_array($r) ? $r : null;
}

// --- game-table column resolution --------------------------------
function custom_leaderboards_tbl(string $k, string $def): string { return custom_leaderboards_ident(custom_leaderboards_setting($k, '')) ?: $def; }
function custom_leaderboards_col(string $table, string $setting, array $cands): string {
	$o = custom_leaderboards_ident(custom_leaderboards_setting($setting, ''));
	if ($o !== '') return $o;
	foreach ($cands as $c) if (function_exists('znote_column_exists') && znote_column_exists($table, $c)) return $c;
	return $cands[0] ?? '';
}
function custom_leaderboards_vocation_ids(int $f): array {
	$m = array(1 => array(1, 5, 9), 2 => array(2, 6, 10), 3 => array(3, 7, 11), 4 => array(4, 8, 12));
	return $m[$f] ?? array();
}

// --- the ranked query -------------------------------------------
function custom_leaderboards_rows(array $b, int $limit = 0, string $youName = ''): array {
	$pt = custom_leaderboards_tbl('players_table', 'players');
	if (!function_exists('znote_table_exists') || !znote_table_exists($pt)) return array();
	$nc  = custom_leaderboards_col($pt, 'players_name_col', array('name'));
	$ic  = custom_leaderboards_col($pt, 'players_id_col', array('id'));
	$lc  = custom_leaderboards_col($pt, 'players_level_col', array('level'));
	$vc  = custom_leaderboards_col($pt, 'players_voc_col', array('vocation'));
	$gc  = custom_leaderboards_col($pt, 'players_group_col', array('group_id', 'group'));
	$limit = $limit > 0 ? $limit : max(3, min(200, (int) $b['row_limit']));
	$dir = (strtolower((string) $b['direction']) === 'asc') ? 'ASC' : 'DESC';
	$src = (string) $b['source'];
	$periodStart = ($b['period'] !== 'none') ? (int) $b['period_start'] : 0;

	$filters = array();
	if ((int) $b['min_level'] > 0) $filters[] = "`p`.`{$lc}` >= " . (int) $b['min_level'];
	if ((int) $b['vocation_filter'] > 0) {
		$ids = custom_leaderboards_vocation_ids((int) $b['vocation_filter']);
		if ($vc !== '' && $ids) $filters[] = "`p`.`{$vc}` IN (" . implode(',', array_map('intval', $ids)) . ")";
	}
	if ((int) $b['exclude_staff'] === 1 && $gc !== '') {
		$filters[] = "COALESCE(`p`.`{$gc}`,1) < " . max(2, custom_leaderboards_int('staff_group_min', 3));
	}
	$hiddenJoin = '';
	if ((int) $b['exclude_hidden'] === 1 && znote_table_exists('znote_players')) {
		$hiddenJoin = " LEFT JOIN `znote_players` `zp` ON `zp`.`player_id` = `p`.`{$ic}`";
		$filters[] = "COALESCE(`zp`.`hide_char`,0) = 0";
	}
	$where = $filters ? ' WHERE ' . implode(' AND ', $filters) : '';

	if ($src === 'pvp_kills' || $src === 'deaths') {
		$dt = custom_leaderboards_tbl('deaths_table', 'player_deaths');
		if (!znote_table_exists($dt)) return array();
		$tc = custom_leaderboards_col($dt, 'deaths_time_col', array('time', 'date'));
		$kc = custom_leaderboards_col($dt, 'deaths_killedby_col', array('killed_by'));
		$pc = custom_leaderboards_col($dt, 'deaths_player_col', array('player_id'));
		$ip = custom_leaderboards_col($dt, 'deaths_isplayer_col', array('is_player'));
		$since = $periodStart > 0 ? " AND `d`.`{$tc}` > {$periodStart}" : '';
		if ($src === 'pvp_kills') {
			$sql = "SELECT `p`.`{$nc}` AS `name`, COUNT(*) AS `v` FROM `{$dt}` `d` JOIN `{$pt}` `p` ON `p`.`{$nc}` = `d`.`{$kc}`{$hiddenJoin} WHERE `d`.`{$ip}` = 1{$since}"
				. ($filters ? ' AND ' . implode(' AND ', $filters) : '')
				. " GROUP BY `p`.`{$nc}` ORDER BY `v` DESC LIMIT {$limit};";
		} else {
			$sql = "SELECT `p`.`{$nc}` AS `name`, COUNT(*) AS `v` FROM `{$dt}` `d` JOIN `{$pt}` `p` ON `p`.`{$ic}` = `d`.`{$pc}`{$hiddenJoin} WHERE 1=1{$since}"
				. ($filters ? ' AND ' . implode(' AND ', $filters) : '')
				. " GROUP BY `p`.`{$nc}` ORDER BY `v` DESC LIMIT {$limit};";
		}
	} elseif ($src === 'storage') {
		$key = (int) $b['source_param'];
		$st = custom_leaderboards_tbl('storage_table', 'player_storage');
		if (!znote_table_exists($st)) return array();
		$val = "`ps`.`value`";
		$baselineJoin = ''; $baselineSel = $val;
		if ($b['period'] !== 'none' && $b['period_mode'] === 'delta') {
			$baselineJoin = " LEFT JOIN `znote_lb_baseline` `bl` ON `bl`.`board_id` = " . (int) $b['id'] . " AND `bl`.`player_name` = `p`.`{$nc}`";
			$baselineSel = "({$val} - COALESCE(`bl`.`value`,0))";
		}
		$sql = "SELECT `p`.`{$nc}` AS `name`, {$baselineSel} AS `v` FROM `{$st}` `ps` JOIN `{$pt}` `p` ON `p`.`{$ic}` = `ps`.`player_id`{$hiddenJoin}{$baselineJoin} WHERE `ps`.`key` = {$key}"
			. ($filters ? ' AND ' . implode(' AND ', $filters) : '')
			. " ORDER BY `v` {$dir} LIMIT {$limit};";
	} else { // players_col
		$col = custom_leaderboards_ident((string) $b['source_param']);
		if ($col === '' || !znote_column_exists($pt, $col)) return array();
		$val = "`p`.`{$col}`";
		$baselineJoin = ''; $baselineSel = $val;
		if ($b['period'] !== 'none' && $b['period_mode'] === 'delta') {
			$baselineJoin = " LEFT JOIN `znote_lb_baseline` `bl` ON `bl`.`board_id` = " . (int) $b['id'] . " AND `bl`.`player_name` = `p`.`{$nc}`";
			$baselineSel = "({$val} - COALESCE(`bl`.`value`,0))";
		}
		$sql = "SELECT `p`.`{$nc}` AS `name`, {$baselineSel} AS `v` FROM `{$pt}` `p`{$hiddenJoin}{$baselineJoin}{$where} ORDER BY `v` {$dir} LIMIT {$limit};";
	}

	$rows = mysql_select_multi($sql);
	if (!is_array($rows)) return array();
	$out = array(); $rank = 0;
	$you = strtolower(trim($youName));
	foreach ($rows as $r) {
		$rank++;
		$out[] = array('rank' => $rank, 'name' => (string) $r['name'], 'value' => (int) $r['v'], 'you' => $you !== '' && strtolower((string) $r['name']) === $you);
	}
	return $out;
}
function custom_leaderboards_fmt(int $v, string $format): string {
	if ($format === 'raw') return (string) $v;
	if ($format === 'gold') return number_format($v) . ' gp';
	if ($format === 'time') {
		$d = intdiv($v, 86400); $h = intdiv($v % 86400, 3600); $m = intdiv($v % 3600, 60);
		if ($d > 0) return $d . 'd ' . $h . 'h';
		if ($h > 0) return $h . 'h ' . $m . 'm';
		return $m . 'm';
	}
	return number_format($v);
}

// --- periodic reset + prizes --------------------------------
function custom_leaderboards_next_reset(string $period, int $from = 0): int {
	$from = $from > 0 ? $from : time();
	if ($period === 'weekly') return (int) strtotime('next monday 00:00', $from);
	if ($period === 'monthly') return (int) strtotime('first day of next month 00:00', $from);
	return 0;
}
function custom_leaderboards_award(string $playerName, array $prize): string {
	$pt = custom_leaderboards_tbl('players_table', 'players');
	$nc = custom_leaderboards_col($pt, 'players_name_col', array('name'));
	$ac = custom_leaderboards_col($pt, 'players_acc_col', array('account_id'));
	$row = mysql_select_single("SELECT `{$ac}` AS acc FROM `{$pt}` WHERE `{$nc}` = '" . mysql_znote_escape_string($playerName) . "' LIMIT 1;");
	if (!is_array($row)) return '';
	$acc = (int) $row['acc'];
	$parts = array(); $now = time();
	$pts = max(0, (int) ($prize['points'] ?? 0));
	if ($pts > 0) { mysql_update("UPDATE `znote_accounts` SET `points` = COALESCE(`points`,0) + {$pts} WHERE `account_id` = {$acc};"); $parts[] = $pts . ' points'; }
	$prem = max(0, (int) ($prize['premium'] ?? 0));
	if ($prem > 0 && function_exists('user_account_add_premdays')) { user_account_add_premdays($acc, $prem); $parts[] = $prem . ' prem'; }
	$itemid = max(0, (int) ($prize['itemid'] ?? 0)); $count = max(0, (int) ($prize['count'] ?? 0));
	if ($itemid > 0 && $count > 0 && znote_table_exists('znote_shop_orders')) {
		mysql_insert("INSERT INTO `znote_shop_orders` (`account_id`,`type`,`itemid`,`count`,`time`) VALUES ({$acc},1,{$itemid},{$count},{$now});");
		$parts[] = $count . 'x ' . $itemid;
	}
	return implode(', ', $parts);
}
function custom_leaderboards_item_image(int $itemid): string {
	if ($itemid <= 0) return '';
	global $config;
	$srv = trim((string) custom_leaderboards_setting('item_image_server', ''));
	$ext = trim((string) custom_leaderboards_setting('item_image_type', ''));
	// No plugin override -> use the site-wide resolver (URL / /items / disk folder).
	if ($srv === '' && function_exists('znote_item_image_url')) {
		return znote_item_image_url($itemid, $ext !== '' ? $ext : null);
	}
	if ($srv === '') $srv = trim((string) ($config['shop']['imageServer'] ?? ''));
	if ($srv === '') return '';
	if ($ext === '') $ext = trim((string) ($config['shop']['imageType'] ?? 'gif'));
	if ($ext === '') $ext = 'gif';
	if (function_exists('znote_media_base')) { $b = znote_media_base($srv); return $b === '' ? '' : $b . '/' . $itemid . '.' . $ext; }
	if (!preg_match('#^([a-z][a-z0-9+.\-]*:)?//#i', $srv)) $srv = 'http://' . $srv;
	return rtrim($srv, '/') . '/' . $itemid . '.' . $ext;
}
function custom_leaderboards_prize_cells($prizes): array {
	$p = is_array($prizes) ? $prizes : (json_decode((string) $prizes, true) ?: array());
	if (!$p) return array();
	$top = max(0, (int) ($p['top'] ?? 0));
	$defs = array(
		'1' => custom_leaderboards_t('custom_leaderboards.rank_1', 'Top 1'),
		'2' => custom_leaderboards_t('custom_leaderboards.rank_2', 'Top 2'),
		'3' => custom_leaderboards_t('custom_leaderboards.rank_3', 'Top 3'),
	);
	if ($top > 3) {
		$defs['rest'] = custom_leaderboards_t('custom_leaderboards.rank_rest', 'Ranks 4-{n}', array('n' => $top));
	}
	$cells = array();
	$any = false;
	foreach ($defs as $key => $label) {
		$s = is_array($p[$key] ?? null) ? $p[$key] : array();
		$points  = max(0, (int) ($s['points'] ?? 0));
		$premium = max(0, (int) ($s['premium'] ?? 0));
		$itemid  = max(0, (int) ($s['itemid'] ?? 0));
		$count   = max(0, (int) ($s['count'] ?? 0));
		$has = $points > 0 || $premium > 0 || ($itemid > 0 && $count > 0);
		if ($has) $any = true;
		$cells[] = array(
			'label'      => $label,
			'points'     => $points,
			'premium'    => $premium,
			'itemid'     => $itemid,
			'count'      => $count,
			'empty'      => !$has,
			'item_image' => ($itemid > 0 && $count > 0) ? custom_leaderboards_item_image($itemid) : '',
		);
	}
	return $any ? $cells : array();
}
function custom_leaderboards_maybe_reset(array $b): void {
	if ((string) $b['period'] === 'none' || (int) $b['next_reset'] <= 0 || (int) $b['next_reset'] > time()) return;
	$id = (int) $b['id'];
	$lock = mysql_select_single("SELECT GET_LOCK('znx_lb_{$id}', 2) AS l;");
	if (!is_array($lock) || (int) $lock['l'] !== 1) return;
	try {
		$fresh = custom_leaderboards_board($id);
		if (!$fresh || (string) $fresh['period'] === 'none' || (int) $fresh['next_reset'] > time()) return;
		$b = $fresh;
		$now = time();
		$season = (int) $b['season'];
		$prizes = json_decode((string) $b['prizes'], true);
		$prizes = is_array($prizes) ? $prizes : array();
		$topN = max(0, (int) ($prizes['top'] ?? 0));

		$rows = custom_leaderboards_rows($b, max(10, $topN));
		foreach ($rows as $r) {
			if ($r['value'] <= 0) continue;
			$rank = $r['rank'];
			$spec = $prizes[(string) $rank] ?? ($rank <= $topN ? ($prizes['rest'] ?? null) : null);
			$given = '';
			if (is_array($spec)) $given = custom_leaderboards_award($r['name'], $spec);
			if ($rank <= 10 || $given !== '') {
				mysql_insert("INSERT INTO `znote_lb_history` (`board_id`,`season`,`rank`,`player_name`,`value`,`prize`,`closed_at`) VALUES ({$id},{$season},{$rank},'" . mysql_znote_escape_string($r['name']) . "'," . (int) $r['value'] . ",'" . mysql_znote_escape_string($given) . "',{$now});");
			}
		}

		// new period
		mysql_delete("DELETE FROM `znote_lb_baseline` WHERE `board_id` = {$id};");
		if ((string) $b['period_mode'] === 'delta') {
			$snap = custom_leaderboards_rows(array_merge($b, array('period' => 'none', 'row_limit' => 5000)), 5000);
			foreach ($snap as $s) {
				mysql_insert("INSERT INTO `znote_lb_baseline` (`board_id`,`player_name`,`value`) VALUES ({$id},'" . mysql_znote_escape_string($s['name']) . "'," . (int) $s['value'] . ") ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);");
			}
		}
		$next = custom_leaderboards_next_reset((string) $b['period'], $now);
		mysql_update("UPDATE `znote_leaderboards` SET `season` = {$season} + 1, `period_start` = {$now}, `next_reset` = {$next}, `updated_at` = {$now} WHERE `id` = {$id};");
		if (function_exists('znote_hook')) znote_hook('leaderboard.reset', array('board_id' => $id, 'season' => $season));
	} catch (Throwable $e) {
		error_log('[custom_leaderboards] reset #' . $id . ' failed: ' . $e->getMessage());
	} finally {
		mysql_select_single("SELECT RELEASE_LOCK('znx_lb_{$id}');");
	}
}

// --- schema + menu -----------------------------------------
function custom_leaderboards_ensure_schema(): void {
	static $done = false;
	if ($done) return;
	$done = true;
	if (!function_exists('setting')) return;
	$state = 'v3:' . (custom_leaderboards_enabled() ? '1' : '0') . (custom_leaderboards_setting('show_in_menu', '1') === '1' ? '1' : '0');
	if (setting('custom_leaderboards:setup_v', '') === $state) return;
	custom_leaderboards_sync_menu();
	if (function_exists('setting_set')) setting_set('custom_leaderboards:setup_v', $state);
}

function custom_leaderboards_sync_menu(): void {
	if (!function_exists('znote_table_exists') || !znote_table_exists('znote_menu')) return;
	mysql_delete("DELETE FROM `znote_menu` WHERE `url` = 'page.php?plugin=custom_leaderboards&p=board';");
	if (custom_leaderboards_enabled() && custom_leaderboards_setting('show_in_menu', '1') === '1') {
		custom_leaderboards_insert_menu();
	}
}

function custom_leaderboards_insert_menu(): void {
	$p = mysql_select_single("SELECT `id` FROM `znote_menu` WHERE `location` = 'main' AND `parent_id` = 0 AND `label` LIKE '%communit%' ORDER BY `id` ASC LIMIT 1;");
	$parent = is_array($p) ? (int) $p['id'] : 0;
	if ($parent > 0) {
		$mx = mysql_select_single("SELECT MAX(`sort_order`) AS s FROM `znote_menu` WHERE `parent_id` = {$parent};");
		$so = is_array($mx) ? (int) $mx['s'] + 1 : 1;
	} else {
		$g = mysql_select_single("SELECT `sort_order` FROM `znote_menu` WHERE `location` = 'main' AND `url` LIKE '%guild%' ORDER BY `sort_order` ASC LIMIT 1;");
		$so = is_array($g) ? (int) $g['sort_order'] + 1 : 55;
	}
	mysql_insert("INSERT INTO `znote_menu` (`location`,`parent_id`,`label`,`url`,`icon`,`visibility`,`sort_order`,`active`) VALUES ('main',{$parent},'Leaderboards','page.php?plugin=custom_leaderboards&p=board','fa-trophy','all',{$so},1);");
}

// --- cached data ------------------------------------------
function custom_leaderboards_clear_cache(): void {
	if (function_exists('setting_set')) { setting_set('custom_leaderboards:cache', ''); setting_set('custom_leaderboards:cache_at', '0'); }
}
function custom_leaderboards_view(string $youName = ''): array {
	custom_leaderboards_ensure_schema();
	$boards = array();
	foreach (custom_leaderboards_boards(true) as $b) {
		try { custom_leaderboards_maybe_reset($b); } catch (Throwable $e) {}
		$b = custom_leaderboards_board((int) $b['id']) ?: $b;
		$boards[] = array(
			'id'       => (int) $b['id'],
			'title'    => (string) $b['title'],
			'subtitle' => (string) $b['subtitle'],
			'icon'     => custom_leaderboards_url((string) $b['icon']),
			'format'   => (string) $b['value_format'],
			'period'   => (string) $b['period'],
			'season'   => (int) $b['season'],
			'prizes'   => custom_leaderboards_prize_cells($b['prizes'] ?? ''),
			'rows'     => custom_leaderboards_rows($b, 0, $youName),
		);
	}
	return $boards;
}

function custom_leaderboards_page_title(): string {
	$t = trim((string) custom_leaderboards_setting('page_title', ''));
	return $t !== '' ? $t : custom_leaderboards_t('custom_leaderboards.title', 'Leaderboards');
}

}

custom_leaderboards_ensure_schema();

if (function_exists('znote_hook_register')) {
	znote_hook_register('page.title', function ($title, array $data) {
		return (($data['plugin'] ?? '') === 'custom_leaderboards')
			? custom_leaderboards_page_title()
			: $title;
	});
}
