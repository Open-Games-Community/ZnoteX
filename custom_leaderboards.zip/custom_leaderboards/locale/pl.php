<?php

return array(
	'custom_leaderboards.title' => 'Rankingi',
	'custom_leaderboards.lead' => 'Najlepsi na serwerze.',
	'custom_leaderboards.none' => 'Nie skonfigurowano jeszcze rankingów.',
	'custom_leaderboards.empty' => 'Brak wpisów.',
	'custom_leaderboards.alltime' => 'Wszech czasów',
	'custom_leaderboards.season' => 'Sezon {n}',
	'custom_leaderboards.history' => 'Poprzednie sezony',
	'custom_leaderboards.past_seasons' => 'poprzednie sezony',
	'custom_leaderboards.back' => 'Powrót do rankingów',
	'custom_leaderboards.no_history' => 'Brak zakończonych sezonów.',
	'custom_leaderboards.rank_1' => 'Miejsce 1',
	'custom_leaderboards.rank_2' => 'Miejsce 2',
	'custom_leaderboards.rank_3' => 'Miejsce 3',
	'custom_leaderboards.rank_rest' => 'Miejsca 4-{n}',
	'custom_leaderboards.rank_rest_top' => 'Top {n}',
	'custom_leaderboards.pts' => '{n} punktów',
	'custom_leaderboards.premd' => '{n} dni premium',
	'custom_leaderboards.rewards' => 'Nagrody',
);
