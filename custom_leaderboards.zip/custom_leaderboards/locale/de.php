<?php

return array(
	'custom_leaderboards.title' => 'Bestenlisten',
	'custom_leaderboards.lead' => 'Die Besten des Servers.',
	'custom_leaderboards.none' => 'Noch keine Bestenlisten konfiguriert.',
	'custom_leaderboards.empty' => 'Noch keine Einträge.',
	'custom_leaderboards.alltime' => 'Allzeit',
	'custom_leaderboards.season' => 'Saison {n}',
	'custom_leaderboards.history' => 'Vergangene Saisons',
	'custom_leaderboards.past_seasons' => 'vergangene Saisons',
	'custom_leaderboards.back' => 'Zurück zu den Bestenlisten',
	'custom_leaderboards.no_history' => 'Noch keine abgeschlossenen Saisons.',
	'custom_leaderboards.rank_1' => 'Platz 1',
	'custom_leaderboards.rank_2' => 'Platz 2',
	'custom_leaderboards.rank_3' => 'Platz 3',
	'custom_leaderboards.rank_rest' => 'Plätze 4-{n}',
	'custom_leaderboards.rank_rest_top' => 'Top {n}',
	'custom_leaderboards.pts' => '{n} Punkte',
	'custom_leaderboards.premd' => '{n} Premium-Tage',
	'custom_leaderboards.rewards' => 'Belohnungen',
);
