<?php

return array(
	'custom_leaderboards.title' => 'Classificações',
	'custom_leaderboards.lead' => 'Os melhores do servidor.',
	'custom_leaderboards.none' => 'Nenhuma classificação configurada ainda.',
	'custom_leaderboards.empty' => 'Nenhuma entrada ainda.',
	'custom_leaderboards.alltime' => 'Histórico',
	'custom_leaderboards.season' => 'Temporada {n}',
	'custom_leaderboards.history' => 'Temporadas anteriores',
	'custom_leaderboards.past_seasons' => 'temporadas anteriores',
	'custom_leaderboards.back' => 'Voltar às classificações',
	'custom_leaderboards.no_history' => 'Nenhuma temporada concluída ainda.',
	'custom_leaderboards.rank_1' => 'Top 1',
	'custom_leaderboards.rank_2' => 'Top 2',
	'custom_leaderboards.rank_3' => 'Top 3',
	'custom_leaderboards.rank_rest' => 'Posições 4-{n}',
	'custom_leaderboards.rank_rest_top' => 'Top {n}',
	'custom_leaderboards.pts' => '{n} pontos',
	'custom_leaderboards.premd' => '{n} dias premium',
	'custom_leaderboards.rewards' => 'Recompensas',
);
