<?php

return array(
	'custom_leaderboards.title' => 'Leaderboards',
	'custom_leaderboards.lead' => 'The best of the server.',
	'custom_leaderboards.none' => 'No leaderboards configured yet.',
	'custom_leaderboards.empty' => 'No entries yet.',
	'custom_leaderboards.alltime' => 'All-time',
	'custom_leaderboards.season' => 'Season {n}',
	'custom_leaderboards.history' => 'Past seasons',
	'custom_leaderboards.past_seasons' => 'past seasons',
	'custom_leaderboards.back' => 'Back to leaderboards',
	'custom_leaderboards.no_history' => 'No finished seasons yet.',
	'custom_leaderboards.rank_1' => 'Top 1',
	'custom_leaderboards.rank_2' => 'Top 2',
	'custom_leaderboards.rank_3' => 'Top 3',
	'custom_leaderboards.rank_rest' => 'Ranks 4-{n}',
	'custom_leaderboards.rank_rest_top' => 'Top {n}',
	'custom_leaderboards.pts' => '{n} points',
	'custom_leaderboards.premd' => '{n} premium days',
	'custom_leaderboards.rewards' => 'Rewards',
);
