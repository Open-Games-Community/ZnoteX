<?php

return array(
	'custom_leaderboards.title' => 'Clasificaciones',
	'custom_leaderboards.lead' => 'Lo mejor del servidor.',
	'custom_leaderboards.none' => 'Aún no hay clasificaciones configuradas.',
	'custom_leaderboards.empty' => 'Aún no hay entradas.',
	'custom_leaderboards.alltime' => 'Histórico',
	'custom_leaderboards.season' => 'Temporada {n}',
	'custom_leaderboards.history' => 'Temporadas pasadas',
	'custom_leaderboards.past_seasons' => 'temporadas pasadas',
	'custom_leaderboards.back' => 'Volver a las clasificaciones',
	'custom_leaderboards.no_history' => 'Aún no hay temporadas terminadas.',
	'custom_leaderboards.rank_1' => 'Top 1',
	'custom_leaderboards.rank_2' => 'Top 2',
	'custom_leaderboards.rank_3' => 'Top 3',
	'custom_leaderboards.rank_rest' => 'Puestos 4-{n}',
	'custom_leaderboards.rank_rest_top' => 'Top {n}',
	'custom_leaderboards.pts' => '{n} puntos',
	'custom_leaderboards.premd' => '{n} días premium',
	'custom_leaderboards.rewards' => 'Recompensas',
);
