<?php
/**
 * Title: Leaderboards
 * Icon: fa-trophy
 * Group: Installed Plugins
 * Order: 37
 * Description: Define ranked boards, their reset period and prizes, and the styling.
 */
if (!defined('ACP_ROOT')) { http_response_code(403); die('Direct access denied.'); }

$module = 'custom_leaderboards__boards';
if (function_exists('custom_leaderboards_ensure_schema')) custom_leaderboards_ensure_schema();

function custom_leaderboards_admin_color($v): string {
	$v = trim((string) $v);
	if (preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|transparent|currentColor)$/', $v)) return $v;
	return preg_match('/^(linear|radial)-gradient\([a-zA-Z0-9#%.,\s()-]+\)$/', $v) ? $v : '';
}
function custom_leaderboards_admin_url($v): string {
	$v = trim((string) $v);
	return (preg_match('#^(https?:)?//[^\s"\'()]+$#i', $v) || preg_match('#^/[^\s"\'()]+$#', $v)) ? $v : '';
}
function custom_leaderboards_admin_ident($v): string {
	$v = trim((string) $v);
	return preg_match('/^[A-Za-z0-9_]{1,64}$/', $v) ? $v : '';
}
function custom_leaderboards_prize_from_post(string $p): array {
	return array(
		'points'  => max(0, intv($_POST[$p . '_points'] ?? 0)),
		'premium' => max(0, intv($_POST[$p . '_premium'] ?? 0)),
		'itemid'  => max(0, intv($_POST[$p . '_itemid'] ?? 0)),
		'count'   => max(0, intv($_POST[$p . '_count'] ?? 0)),
	);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$do = (string) ($_POST['do'] ?? '');
	$id = intv($_POST['id'] ?? 0);

	if ($do === 'delete' && $id > 0) {
		db()->execute("DELETE FROM `znote_leaderboards` WHERE `id` = ? LIMIT 1;", [$id]);
		db()->execute("DELETE FROM `znote_lb_baseline` WHERE `board_id` = ?;", [$id]);
		custom_leaderboards_clear_cache();
		acp_flash_success('Board deleted.');
		acp_redirect($module);
	}
	if ($do === 'reset_now' && $id > 0) {
		db()->execute("UPDATE `znote_leaderboards` SET `next_reset` = ? WHERE `id` = ?;", [time(), $id]);
		$b = custom_leaderboards_board($id);
		if ($b) custom_leaderboards_maybe_reset($b);
		acp_flash_success('Board reset processed.');
		acp_redirect($module);
	}
	if ($do === 'config') {
		setting_set('custom_leaderboards:enabled', !empty($_POST['enabled']) ? '1' : '0');
		setting_set('custom_leaderboards:staff_group_min', (string) max(2, intv($_POST['staff_group_min'] ?? 3)));
		setting_set('custom_leaderboards:page_title', trim((string) ($_POST['page_title'] ?? '')));
		setting_set('custom_leaderboards:page_lead', trim((string) ($_POST['page_lead'] ?? '')));
		setting_set('custom_leaderboards:item_image_server', trim((string) ($_POST['item_image_server'] ?? '')));
		$pc = (string) ($_POST['prize_cols'] ?? 'auto');
		setting_set('custom_leaderboards:prize_cols', in_array($pc, array('auto', '1', '2', '3', '4'), true) ? $pc : 'auto');
		setting_set('custom_leaderboards:prize_min', (string) max(56, min(240, intv($_POST['prize_min'] ?? 96))));
		setting_set('custom_leaderboards:prize_scale', (string) max(60, min(200, intv($_POST['prize_scale'] ?? 100))));
		setting_set('custom_leaderboards:prize_icon_points', custom_leaderboards_admin_url($_POST['prize_icon_points'] ?? ''));
		setting_set('custom_leaderboards:prize_icon_premium', custom_leaderboards_admin_url($_POST['prize_icon_premium'] ?? ''));
		foreach (array('players_table', 'players_name_col', 'players_id_col', 'players_acc_col', 'players_level_col', 'players_voc_col', 'players_group_col', 'deaths_table', 'storage_table') as $k)
			setting_set('custom_leaderboards:' . $k, custom_leaderboards_admin_ident($_POST[$k] ?? ''));
		foreach (array('box_bg', 'border', 'text', 'accent', 'row_bg', 'you_bg', 'head_bg', 'head_text', 'gold', 'silver', 'bronze') as $k)
			setting_set('custom_leaderboards:style_' . $k, custom_leaderboards_admin_color($_POST['style_' . $k] ?? ''));
		foreach (array('1', '2', '3') as $n)
			setting_set('custom_leaderboards:medal_' . $n, custom_leaderboards_admin_url($_POST['medal_' . $n] ?? ''));

		setting_set('custom_leaderboards:show_in_menu', !empty($_POST['show_in_menu']) ? '1' : '0');
		setting_set('custom_leaderboards:setup_v', '');
		if (function_exists('custom_leaderboards_sync_menu')) custom_leaderboards_sync_menu();
		custom_leaderboards_clear_cache();
		acp_flash_success('Settings saved.');
		acp_redirect($module);
	}
	if ($do === 'create' || $do === 'update') {
		$src = array_key_exists(($_POST['source'] ?? ''), custom_leaderboards_sources()) ? $_POST['source'] : 'players_col';
		$param = $src === 'storage' ? (string) max(0, intv($_POST['source_param'] ?? 0)) : custom_leaderboards_admin_ident($_POST['source_param'] ?? '');
		if ($src === 'pvp_kills' || $src === 'deaths') $param = '';
		$period = in_array(($_POST['period'] ?? ''), array('none', 'weekly', 'monthly'), true) ? $_POST['period'] : 'none';
		$prizes = array(
			'top'  => max(0, intv($_POST['prize_top'] ?? 0)),
			'1'    => custom_leaderboards_prize_from_post('p1'),
			'2'    => custom_leaderboards_prize_from_post('p2'),
			'3'    => custom_leaderboards_prize_from_post('p3'),
			'rest' => custom_leaderboards_prize_from_post('prest'),
		);
		$f = array(
			'title'          => trim((string) ($_POST['title'] ?? '')),
			'subtitle'       => trim((string) ($_POST['subtitle'] ?? '')),
			'icon'           => custom_leaderboards_admin_url($_POST['icon'] ?? ''),
			'source'         => $src,
			'source_param'   => $param,
			'direction'      => ($_POST['direction'] ?? 'desc') === 'asc' ? 'asc' : 'desc',
			'value_format'   => in_array(($_POST['value_format'] ?? ''), custom_leaderboards_formats(), true) ? $_POST['value_format'] : 'number',
			'row_limit'      => max(3, min(200, intv($_POST['row_limit'] ?? 25))),
			'min_level'      => max(0, intv($_POST['min_level'] ?? 0)),
			'vocation_filter' => in_array(intv($_POST['vocation_filter'] ?? 0), array(0, 1, 2, 3, 4), true) ? intv($_POST['vocation_filter']) : 0,
			'exclude_hidden' => !empty($_POST['exclude_hidden']) ? 1 : 0,
			'exclude_staff'  => !empty($_POST['exclude_staff']) ? 1 : 0,
			'period'         => $period,
			'period_mode'    => ($_POST['period_mode'] ?? 'raw') === 'delta' ? 'delta' : 'raw',
			'prizes'         => json_encode($prizes),
			'active'         => !empty($_POST['active']) ? 1 : 0,
			'sort_order'     => intv($_POST['sort_order'] ?? 0),
			'updated_at'     => time(),
		);
		if (trim((string) ($_POST['title'] ?? '')) === '') { acp_flash_error('Title is required.'); acp_redirect($module, array('action' => $do === 'update' ? 'edit' : 'add', 'id' => $id)); }

		if ($do === 'update' && $id > 0) {
			$cur = custom_leaderboards_board($id);
			if ($cur && ($cur['period'] === 'none') && $period !== 'none') {
				$f['period_start'] = time();
				$f['next_reset'] = custom_leaderboards_next_reset($period);
			} elseif ($period === 'none') {
				$f['next_reset'] = 0;
			}
			$set = array(); $params = array();
			foreach ($f as $k => $v) { $set[] = "`{$k}` = ?"; $params[] = $v; }
			$params[] = $id;
			db()->execute("UPDATE `znote_leaderboards` SET " . implode(',', $set) . " WHERE `id` = ? LIMIT 1;", $params);
			$msg = 'Board updated.';
		} else {
			$f['created_at'] = time();
			$f['season'] = 1;
			if ($period !== 'none') { $f['period_start'] = time(); $f['next_reset'] = custom_leaderboards_next_reset($period); }
			$cols = array_keys($f);
			$placeholders = implode(',', array_fill(0, count($cols), '?'));
			db()->execute("INSERT INTO `znote_leaderboards` (`" . implode('`,`', $cols) . "`) VALUES ({$placeholders});", array_values($f));
			$msg = 'Board created.';
		}
		custom_leaderboards_clear_cache();
		acp_flash_success($msg);
		acp_redirect($module);
	}
}

$action  = (string) ($_GET['action'] ?? 'list');
$editId  = intv($_GET['id'] ?? 0);
$editing = ($action === 'edit' && $editId > 0) ? custom_leaderboards_board($editId) : null;
if ($action === 'edit' && !$editing) { acp_flash_error('Board not found.'); acp_redirect($module); }
$g = static fn(string $k, $d = '') => $editing !== null && isset($editing[$k]) ? $editing[$k] : $d;
$get = static fn(string $k, string $d = '') => (string) setting('custom_leaderboards:' . $k, $d);
$prz = $editing ? (json_decode((string) $editing['prizes'], true) ?: array()) : array();
$pv = static fn(string $slot, string $key) => (int) ($prz[$slot][$key] ?? 0);
?>
<?php acp_card_open('Leaderboards', 'Each board is a ranked query against the game DB (read-only). "Delta" period mode ranks by the gain since the period started (needs a baseline snapshot taken on each reset); "raw" ranks the value as-is. Prizes are paid to the top ranks when the period resets.'); ?>

<?php if ($action === 'add' || $editing !== null): ?>
	<form method="post">
		<?= acp_csrf_field() ?><input type="hidden" name="do" value="<?= $editing ? 'update' : 'create' ?>">
		<?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>
		<div class="acp-grid acp-grid--2">
			<div class="acp-field"><label class="acp-label">Title *</label><input class="acp-input" name="title" value="<?= h($g('title')) ?>" placeholder="Top Level" required></div>
			<div class="acp-field"><label class="acp-label">Subtitle</label><input class="acp-input" name="subtitle" value="<?= h($g('subtitle')) ?>"></div>
			<div class="acp-field"><label class="acp-label">Header icon URL</label><input class="acp-input" name="icon" value="<?= h($g('icon')) ?>" placeholder="https://…/icon.png"></div>
			<div class="acp-field"><label class="acp-label">Source</label>
				<select class="acp-select" name="source">
					<?php foreach (custom_leaderboards_sources() as $k => $lbl): ?><option value="<?= h($k) ?>" <?= $g('source', 'players_col') === $k ? 'selected' : '' ?>><?= h($lbl) ?></option><?php endforeach; ?>
				</select>
			</div>
			<div class="acp-field"><label class="acp-label">Source param <span class="acp-muted">(players column name, or player_storage key number)</span></label><input class="acp-input" name="source_param" value="<?= h($g('source_param', 'level')) ?>" placeholder="level / experience / 12345"></div>
			<div class="acp-field"><label class="acp-label">Direction</label><select class="acp-select" name="direction"><option value="desc" <?= $g('direction', 'desc') !== 'asc' ? 'selected' : '' ?>>High → low</option><option value="asc" <?= $g('direction') === 'asc' ? 'selected' : '' ?>>Low → high</option></select></div>
			<div class="acp-field"><label class="acp-label">Value format</label><select class="acp-select" name="value_format"><?php foreach (custom_leaderboards_formats() as $ff): ?><option value="<?= h($ff) ?>" <?= $g('value_format', 'number') === $ff ? 'selected' : '' ?>><?= h($ff) ?></option><?php endforeach; ?></select></div>
			<div class="acp-field"><label class="acp-label">Rows shown</label><input class="acp-input" type="number" min="3" max="200" name="row_limit" value="<?= (int) $g('row_limit', 25) ?>"></div>
			<div class="acp-field"><label class="acp-label">Min level</label><input class="acp-input" type="number" min="0" name="min_level" value="<?= (int) $g('min_level', 0) ?>"></div>
			<div class="acp-field"><label class="acp-label">Vocation</label><select class="acp-select" name="vocation_filter"><option value="0">Any</option><option value="1" <?= (int) $g('vocation_filter') === 1 ? 'selected' : '' ?>>Sorcerer</option><option value="2" <?= (int) $g('vocation_filter') === 2 ? 'selected' : '' ?>>Druid</option><option value="3" <?= (int) $g('vocation_filter') === 3 ? 'selected' : '' ?>>Paladin</option><option value="4" <?= (int) $g('vocation_filter') === 4 ? 'selected' : '' ?>>Knight</option></select></div>
			<div class="acp-field"><label class="acp-label"><input type="checkbox" name="exclude_hidden" value="1" <?= (int) $g('exclude_hidden', 1) === 1 ? 'checked' : '' ?>> Exclude hidden characters</label></div>
			<div class="acp-field"><label class="acp-label"><input type="checkbox" name="exclude_staff" value="1" <?= (int) $g('exclude_staff', 1) === 1 ? 'checked' : '' ?>> Exclude staff</label></div>
			<div class="acp-field"><label class="acp-label">Reset period</label><select class="acp-select" name="period"><option value="none" <?= $g('period', 'none') === 'none' ? 'selected' : '' ?>>None (all-time)</option><option value="weekly" <?= $g('period') === 'weekly' ? 'selected' : '' ?>>Weekly (Monday)</option><option value="monthly" <?= $g('period') === 'monthly' ? 'selected' : '' ?>>Monthly (1st)</option></select></div>
			<div class="acp-field"><label class="acp-label">Period mode</label><select class="acp-select" name="period_mode"><option value="raw" <?= $g('period_mode', 'raw') !== 'delta' ? 'selected' : '' ?>>Raw value</option><option value="delta" <?= $g('period_mode') === 'delta' ? 'selected' : '' ?>>Gain since reset (delta)</option></select></div>
			<div class="acp-field"><label class="acp-label">Sort order</label><input class="acp-input" type="number" name="sort_order" value="<?= (int) $g('sort_order', 0) ?>"></div>
			<div class="acp-field"><label class="acp-label"><input type="checkbox" name="active" value="1" <?= (int) $g('active', 1) === 1 ? 'checked' : '' ?>> Active</label></div>
		</div>

		<h3>Prizes on reset</h3>
		<div class="acp-field"><label class="acp-label">Pay prizes to the top N ranks (0 = none)</label><input class="acp-input" type="number" min="0" max="100" name="prize_top" value="<?= (int) ($prz['top'] ?? 0) ?>"></div>
		<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>Rank</th><th>Points</th><th>Premium days</th><th>Item ID</th><th>Count</th></tr></thead><tbody>
			<?php foreach (array('p1' => '1', 'p2' => '2', 'p3' => '3', 'prest' => 'rest') as $slot => $lbl): ?>
				<tr><td><?= h($lbl) ?></td>
					<td><input class="acp-input" type="number" min="0" name="<?= $slot ?>_points" value="<?= $pv($lbl, 'points') ?>"></td>
					<td><input class="acp-input" type="number" min="0" name="<?= $slot ?>_premium" value="<?= $pv($lbl, 'premium') ?>"></td>
					<td><input class="acp-input" type="number" min="0" name="<?= $slot ?>_itemid" value="<?= $pv($lbl, 'itemid') ?>"></td>
					<td><input class="acp-input" type="number" min="0" name="<?= $slot ?>_count" value="<?= $pv($lbl, 'count') ?>"></td>
				</tr>
			<?php endforeach; ?>
		</tbody></table></div>

		<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> <?= $editing ? 'Save board' : 'Create board' ?></button>
		<a class="acp-btn acp-btn--ghost" href="<?= h(acp_url($module)) ?>">Cancel</a></div>
	</form>
<?php else: ?>
	<div class="acp-actions"><a class="acp-btn" href="<?= h(acp_url($module, array('action' => 'add'))) ?>"><i class="fa fa-plus"></i> New board</a></div>
	<?php $boards = custom_leaderboards_boards(false); if (!$boards): ?><p class="acp-muted">No boards yet.</p><?php else: ?>
	<div class="acp-table-wrap"><table class="acp-table"><thead><tr><th>#</th><th>Title</th><th>Source</th><th>Period</th><th>Rows</th><th></th></tr></thead><tbody>
		<?php foreach ($boards as $b): $rid = (int) $b['id']; $n = count(custom_leaderboards_rows($b, 3)); ?>
			<tr>
				<td><?= $rid ?></td>
				<td><strong><?= h($b['title']) ?></strong></td>
				<td><?= h($b['source']) ?><?php if ($b['source_param'] !== ''): ?> <span class="acp-muted">(<?= h($b['source_param']) ?>)</span><?php endif; ?></td>
				<td><?= h($b['period']) ?><?php if ($b['period'] !== 'none'): ?> · S<?= (int) $b['season'] ?><?php endif; ?></td>
				<td><?= $n ?><?= $n === 0 ? ' <span class="acp-muted">(check source)</span>' : '' ?></td>
				<td style="white-space:nowrap">
					<a class="acp-btn acp-btn--ghost acp-btn--sm" href="<?= h(acp_url($module, array('action' => 'edit', 'id' => $rid))) ?>"><i class="fa fa-pencil"></i></a>
					<?php if ($b['period'] !== 'none'): ?><form class="acp-inline-form" method="post" data-confirm="Process a reset now (pays prizes)?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="reset_now"><input type="hidden" name="id" value="<?= $rid ?>"><button class="acp-btn acp-btn--sm" type="submit"><i class="fa fa-refresh"></i></button></form><?php endif; ?>
					<form class="acp-inline-form" method="post" data-confirm="Delete this board?"><?= acp_csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $rid ?>"><button class="acp-btn acp-btn--red acp-btn--sm" type="submit"><i class="fa fa-trash"></i></button></form>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody></table></div>
	<?php endif; ?>
<?php endif; ?>
<?php acp_card_close(); ?>

<?php if ($action === 'list'): ?>
<?php acp_card_open('Style &amp; setup', 'Colours empty = inherit the theme. Medal icons are shown for ranks 1-3.'); ?>
<form method="post"><?= acp_csrf_field() ?><input type="hidden" name="do" value="config">
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="enabled" value="1" <?= $get('enabled', '1') === '1' ? 'checked' : '' ?>> Enabled</label></div>
		<div class="acp-field"><label class="acp-label"><input type="checkbox" name="show_in_menu" value="1" <?= $get('show_in_menu', '1') === '1' ? 'checked' : '' ?>> Show "Leaderboards" in the Community menu</label></div>
		<div class="acp-field"><label class="acp-label">Staff group id from (exclude group_id &gt;= this)</label><input class="acp-input" type="number" min="2" name="staff_group_min" value="<?= (int) $get('staff_group_min', '3') ?>"></div>
		<div class="acp-field"><label class="acp-label">Page title</label><input class="acp-input" name="page_title" value="<?= h($get('page_title', '')) ?>" placeholder="Leaderboards"></div>
		<div class="acp-field"><label class="acp-label">Page subtitle</label><input class="acp-input" name="page_lead" value="<?= h($get('page_lead', '')) ?>" placeholder="The best of the server."></div>
		<div class="acp-field"><label class="acp-label">Item image server (blank = shop setting)</label><input class="acp-input" name="item_image_server" value="<?= h($get('item_image_server', '')) ?>" placeholder="<?= h((string) ($GLOBALS['config']['shop']['imageServer'] ?? '')) ?>"></div>
	</div>

	<h3>Reward boxes</h3>
	<div class="acp-grid acp-grid--2">
		<div class="acp-field"><label class="acp-label">Boxes per row</label><select class="acp-select" name="prize_cols">
			<?php foreach (array('auto' => 'Auto (wrap to fit)', '4' => '4', '3' => '3', '2' => '2', '1' => '1') as $ov => $ol): ?>
			<option value="<?= $ov ?>" <?= $get('prize_cols', 'auto') === $ov ? 'selected' : '' ?>><?= h($ol) ?></option>
			<?php endforeach; ?>
		</select></div>
		<div class="acp-field"><label class="acp-label">Min box width when Auto (px)</label><input class="acp-input" type="number" min="56" max="240" name="prize_min" value="<?= (int) $get('prize_min', '96') ?>"></div>
		<div class="acp-field"><label class="acp-label">Content scale (%)</label><input class="acp-input" type="number" min="60" max="200" name="prize_scale" value="<?= (int) $get('prize_scale', '100') ?>"></div>
		<div class="acp-field"><label class="acp-label">Points icon URL (blank = bundled <code>assets/img/points.png</code>)</label><input class="acp-input" name="prize_icon_points" value="<?= h($get('prize_icon_points', '')) ?>" placeholder="https://.../points.png"></div>
		<div class="acp-field"><label class="acp-label">Premium days icon URL (blank = bundled <code>assets/img/vip.png</code>)</label><input class="acp-input" name="prize_icon_premium" value="<?= h($get('prize_icon_premium', '')) ?>" placeholder="https://.../vip.png"></div>
	</div>
	<h3>Medal icons (ranks 1 / 2 / 3)</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('1', '2', '3') as $n): ?><div class="acp-field"><label class="acp-label">Rank <?= $n ?> icon URL</label><input class="acp-input" name="medal_<?= $n ?>" value="<?= h($get('medal_' . $n)) ?>" placeholder="blank = built-in medal"></div><?php endforeach; ?>
	</div>
	<h3>Colours</h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('box_bg' => 'Box background', 'border' => 'Border', 'text' => 'Text', 'accent' => 'Accent / value', 'row_bg' => 'Odd row', 'you_bg' => 'Your row', 'head_bg' => 'Header background', 'head_text' => 'Header text', 'gold' => 'Rank 1', 'silver' => 'Rank 2', 'bronze' => 'Rank 3') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><?php acp_color_field('style_' . $k, $get('style_' . $k), '#1a1d24'); ?></div>
		<?php endforeach; ?>
	</div>
	<h3>Game tables <span class="acp-muted">(blank = autodetect)</span></h3>
	<div class="acp-grid acp-grid--2">
		<?php foreach (array('players_table' => 'players table', 'players_name_col' => 'players: name', 'players_id_col' => 'players: id', 'players_acc_col' => 'players: account_id', 'players_level_col' => 'players: level', 'players_voc_col' => 'players: vocation', 'players_group_col' => 'players: group id', 'deaths_table' => 'player_deaths table', 'storage_table' => 'player_storage table') as $k => $lbl): ?>
			<div class="acp-field"><label class="acp-label"><?= h($lbl) ?></label><input class="acp-input" name="<?= h($k) ?>" value="<?= h($get($k)) ?>" placeholder="auto"></div>
		<?php endforeach; ?>
	</div>
	<div class="acp-actions"><button class="acp-btn acp-btn--green" type="submit"><i class="fa fa-check"></i> Save</button></div>
</form>
<?php acp_card_close(); ?>
<?php endif; ?>
