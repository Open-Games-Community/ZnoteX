<?php
/**
 * Public page: page.php?plugin=custom_leaderboards&p=board
 */
if (!isset($config)) { http_response_code(403); die('Direct access denied.'); }

$h = 'custom_leaderboards_h';

$youName = '';
$accountId = !empty($GLOBALS['session_user_id']) ? (int) $GLOBALS['session_user_id']
	: ((function_exists('user_logged_in') && user_logged_in() === true) ? (int) getSession('user_id') : 0);
if ($accountId > 0 && function_exists('user_character_list')) {
	foreach ((array) user_character_list($accountId) as $c) { $youName = (string) ($c['name'] ?? ''); break; }
}

$boards = custom_leaderboards_enabled() ? custom_leaderboards_view($youName) : array();
$sel = (int) ($_GET['b'] ?? 0);
$hist = null;
if ($sel > 0 && ($hb = custom_leaderboards_board($sel)) && function_exists('znote_table_exists') && znote_table_exists('znote_lb_history')) {
	$rows = mysql_select_multi("SELECT * FROM `znote_lb_history` WHERE `board_id` = {$sel} ORDER BY `season` DESC, `rank` ASC LIMIT 60;");
	$hist = array('board' => $hb, 'rows' => is_array($rows) ? $rows : array());
}

$pCols  = custom_leaderboards_setting('prize_cols', 'auto');
if (!in_array($pCols, array('auto', '1', '2', '3', '4'), true)) $pCols = 'auto';
$pMin   = max(56, min(240, (int) custom_leaderboards_setting('prize_min', '96')));
$pScale = max(60, min(200, (int) custom_leaderboards_setting('prize_scale', '100')));
$prizeGrid = $pCols === 'auto' ? "repeat(auto-fit,minmax({$pMin}px,1fr))" : "repeat({$pCols},minmax(0,1fr))";
$lbIconPts  = custom_leaderboards_prize_icon('points');
$lbIconPrem = custom_leaderboards_prize_icon('premium');
?>
<style>
.lb-wrap{--lbp-scale:<?= number_format($pScale / 100, 2, '.', '') ?>}
.lb-prizes{grid-template-columns:<?= $prizeGrid ?>}
</style>
<style>
.lb-wrap{--lb-surface:var(--box-inner-bg,var(--box-bg,var(--nz-panel,var(--wc-bg-2,var(--z-panel-2,var(--s-panel,var(--primary,rgb(26,29,36))))))));--lb-text:var(--font-color,var(--text,var(--nz-text,var(--wc-text,var(--z-text,var(--s-text,rgb(224,228,238)))))));--lb-border:var(--border,var(--box-inner-border,var(--box-border,var(--nz-border-soft,var(--wc-line,var(--z-border,var(--s-border2,rgb(19,20,23))))))));--lb-accent:var(--accent,var(--link,#f4c542));--lb-row:rgba(255,255,255,.03);--lb-you:rgba(244,197,66,.14);--lb-head-bg:var(--lb-accent);--lb-head-text:#151515;--lb-gold:#f4c542;--lb-silver:#c9d1d9;--lb-bronze:#cd7f45;color:var(--lb-text)}
.lb-wrap *{box-sizing:border-box}
.lb-wrap h1{font-size:26px;margin:0 0 4px}
.lb-lead{opacity:.8;margin:0 0 20px}
.lb-grid{display:grid;gap:20px;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
.lb-card{border:1px solid var(--lb-border);border-radius:12px;background:var(--lb-surface);overflow:hidden}
.lb-card__head{display:flex;align-items:center;gap:10px;padding:12px 14px;background:var(--lb-head-bg);color:var(--lb-head-text)}
.lb-card__head img{width:26px;height:26px;object-fit:contain}
.lb-card__head b{font-size:15px;display:block;line-height:1.15}
.lb-card__head span{font-size:11px;opacity:.8}
.lb-table{width:100%;border-collapse:collapse;font-size:14px}
.lb-table td{padding:8px 12px;border-top:1px solid var(--lb-border)}
.lb-table tr:nth-child(odd) td{background:var(--lb-row)}
.lb-table tr.is-you td{background:var(--lb-you);font-weight:700}
.lb-rank{width:44px;text-align:center;font-weight:800;font-variant-numeric:tabular-nums}
.lb-rank img{width:22px;height:22px;vertical-align:middle}
.lb-val{text-align:right;font-variant-numeric:tabular-nums;color:var(--lb-accent);font-weight:700;white-space:nowrap}
.lb-name a{color:inherit;text-decoration:none}.lb-name a:hover{color:var(--lb-accent)}
tr.r1 .lb-rank{color:var(--lb-gold)}tr.r2 .lb-rank{color:var(--lb-silver)}tr.r3 .lb-rank{color:var(--lb-bronze)}
.lb-foot{padding:8px 12px;font-size:12px;opacity:.7;border-top:1px solid var(--lb-border);display:flex;justify-content:space-between}
.lb-foot a{color:var(--lb-accent);text-decoration:none}
.lb-empty{opacity:.6;padding:14px}
.lb-wrap{--lbp-scale:1}
.lb-prizes{display:grid;grid-template-columns:repeat(auto-fit,minmax(96px,1fr));gap:calc(8px * var(--lbp-scale));padding:12px;border-bottom:1px solid var(--lb-border)}
.lb-prize{border:1px solid var(--lb-border);border-radius:9px;overflow:hidden;background:var(--lb-row);display:flex;flex-direction:column;min-width:0}
.lb-prize.is-empty{opacity:.5}
.lb-prize__tier{background:var(--lb-head-bg);color:var(--lb-head-text);font-weight:800;font-size:calc(10.5px * var(--lbp-scale));text-align:center;padding:calc(4px * var(--lbp-scale)) 6px;text-transform:uppercase;letter-spacing:.03em}
.lb-prize__body{padding:calc(9px * var(--lbp-scale)) 6px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:calc(3px * var(--lbp-scale));font-size:calc(11px * var(--lbp-scale));text-align:center;flex:1;overflow-wrap:anywhere}
.lb-prize__item{position:relative;display:inline-block;margin-bottom:2px}
.lb-prize__item img{width:calc(34px * var(--lbp-scale));height:calc(34px * var(--lbp-scale));object-fit:contain;image-rendering:pixelated}
.lb-prize__item em{position:absolute;right:-5px;bottom:-5px;font-style:normal;font-weight:800;font-size:calc(10px * var(--lbp-scale));background:var(--lb-surface);border:1px solid var(--lb-border);border-radius:4px;padding:0 3px;line-height:1.4}
.lb-prize__line{color:var(--lb-accent);font-weight:700;line-height:1.3;display:inline-flex;align-items:center;gap:4px;justify-content:center}
.lb-prize__ico{width:calc(14px * var(--lbp-scale));height:calc(14px * var(--lbp-scale));object-fit:contain;vertical-align:middle}
.lb-prize__none{opacity:.6;font-size:calc(16px * var(--lbp-scale))}
.lb-back{display:inline-block;margin-bottom:14px;color:var(--lb-accent);text-decoration:none}
</style>

<div class="lb-wrap" <?= custom_leaderboards_style_attr() ?>>

<?php if ($hist !== null): ?>
	<a class="lb-back" href="<?= $h(znote_plugin_url('custom_leaderboards', 'board')) ?>">&larr; <?= $h(custom_leaderboards_t('custom_leaderboards.back', 'Back to leaderboards')) ?></a>
	<h1><?= $h($hist['board']['title']) ?> — <?= $h(custom_leaderboards_t('custom_leaderboards.past_seasons', 'past seasons')) ?></h1>
	<?php if (!$hist['rows']): ?>
		<p class="lb-empty"><?= $h(custom_leaderboards_t('custom_leaderboards.no_history', 'No finished seasons yet.')) ?></p>
	<?php else: ?>
		<div class="lb-card"><table class="lb-table"><tbody>
		<?php $cs = null; foreach ($hist['rows'] as $r): ?>
			<?php if ($cs !== (int) $r['season']): $cs = (int) $r['season']; ?>
				<tr><td colspan="3" style="background:var(--lb-head-bg);color:var(--lb-head-text);font-weight:800"><?= $h(custom_leaderboards_t('custom_leaderboards.season', 'Season {n}', array('n' => $cs))) ?></td></tr>
			<?php endif; ?>
			<tr class="r<?= (int) $r['rank'] ?>">
				<td class="lb-rank"><?= (int) $r['rank'] ?></td>
				<td class="lb-name"><?= $h($r['player_name']) ?><?= $r['prize'] !== '' ? ' <span style="opacity:.6;font-size:12px">(' . $h($r['prize']) . ')</span>' : '' ?></td>
				<td class="lb-val"><?= $h(custom_leaderboards_fmt((int) $r['value'], (string) $hist['board']['value_format'])) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody></table></div>
	<?php endif; ?>

<?php else: ?>
	<h1><?= $h(custom_leaderboards_page_title()) ?></h1>
	<?php $lbLead = trim((string) custom_leaderboards_setting('page_lead', '')); ?>
	<p class="lb-lead"><?= $h($lbLead !== '' ? $lbLead : custom_leaderboards_t('custom_leaderboards.lead', 'The best of the server.')) ?></p>

	<?php if (!$boards): ?>
		<p class="lb-empty"><?= $h(custom_leaderboards_t('custom_leaderboards.none', 'No leaderboards configured yet.')) ?></p>
	<?php else: ?>
		<div class="lb-grid">
			<?php foreach ($boards as $bd): ?>
				<div class="lb-card">
					<div class="lb-card__head">
						<?php if ($bd['icon'] !== ''): ?><img src="<?= $h($bd['icon']) ?>" alt=""><?php endif; ?>
						<div><b><?= $h($bd['title']) ?></b><?php if ($bd['subtitle'] !== ''): ?><span><?= $h($bd['subtitle']) ?></span><?php endif; ?></div>
					</div>
					<?php if (!empty($bd['prizes'])): ?>
						<div class="lb-prizes">
						<?php foreach ($bd['prizes'] as $pz): ?>
							<div class="lb-prize<?= $pz['empty'] ? ' is-empty' : '' ?>">
								<div class="lb-prize__tier"><?= $h($pz['label']) ?></div>
								<div class="lb-prize__body">
									<?php if ($pz['empty']): ?>
										<span class="lb-prize__none">&mdash;</span>
									<?php else: ?>
										<?php if ($pz['item_image'] !== ''): ?>
											<span class="lb-prize__item"><img src="<?= $h($pz['item_image']) ?>" alt=""><?php if ($pz['count'] > 1): ?><em><?= (int) $pz['count'] ?>&times;</em><?php endif; ?></span>
										<?php endif; ?>
										<?php if ($pz['points'] > 0): ?><span class="lb-prize__line"><?php if ($lbIconPts !== ''): ?><img class="lb-prize__ico" src="<?= $h($lbIconPts) ?>" alt=""><?php endif; ?><?= $h(custom_leaderboards_t('custom_leaderboards.pts', '{n} points', array('n' => $pz['points']))) ?></span><?php endif; ?>
										<?php if ($pz['premium'] > 0): ?><span class="lb-prize__line"><?php if ($lbIconPrem !== ''): ?><img class="lb-prize__ico" src="<?= $h($lbIconPrem) ?>" alt=""><?php endif; ?><?= $h(custom_leaderboards_t('custom_leaderboards.premd', '{n} premium days', array('n' => $pz['premium']))) ?></span><?php endif; ?>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<?php if (!$bd['rows']): ?>
						<p class="lb-empty"><?= $h(custom_leaderboards_t('custom_leaderboards.empty', 'No entries yet.')) ?></p>
					<?php else: ?>
						<table class="lb-table"><tbody>
						<?php foreach ($bd['rows'] as $r): ?>
							<tr class="r<?= (int) $r['rank'] ?><?= $r['you'] ? ' is-you' : '' ?>">
								<td class="lb-rank"><?php $medal = $r['rank'] <= 3 ? custom_leaderboards_medal($r['rank']) : ''; ?><?= $medal !== '' ? '<img src="' . $h($medal) . '" alt="' . (int) $r['rank'] . '">' : (int) $r['rank'] ?></td>
								<td class="lb-name"><a href="characterprofile.php?name=<?= $h(urlencode($r['name'])) ?>"><?= $h($r['name']) ?></a></td>
								<td class="lb-val"><?= $h(custom_leaderboards_fmt((int) $r['value'], $bd['format'])) ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody></table>
					<?php endif; ?>
					<div class="lb-foot">
						<span><?php if ($bd['period'] !== 'none'): ?><?= $h(custom_leaderboards_t('custom_leaderboards.season', 'Season {n}', array('n' => $bd['season']))) ?> · <?= $h(ucfirst($bd['period'])) ?><?php else: ?><?= $h(custom_leaderboards_t('custom_leaderboards.alltime', 'All-time')) ?><?php endif; ?></span>
						<?php if ($bd['period'] !== 'none'): ?><a href="?plugin=custom_leaderboards&p=board&b=<?= (int) $bd['id'] ?>"><?= $h(custom_leaderboards_t('custom_leaderboards.history', 'Past seasons')) ?> &rarr;</a><?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
<?php endif; ?>
</div>
