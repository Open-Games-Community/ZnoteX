﻿CREATE TABLE IF NOT EXISTS `znote_leaderboards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `subtitle` varchar(180) NOT NULL DEFAULT '',
  `icon` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(24) NOT NULL DEFAULT 'players_col',
  `source_param` varchar(64) NOT NULL DEFAULT 'level',
  `direction` varchar(4) NOT NULL DEFAULT 'desc',
  `value_format` varchar(12) NOT NULL DEFAULT 'number',
  `row_limit` int NOT NULL DEFAULT '25',
  `min_level` int NOT NULL DEFAULT '0',
  `vocation_filter` int NOT NULL DEFAULT '0',
  `exclude_hidden` tinyint NOT NULL DEFAULT '1',
  `exclude_staff` tinyint NOT NULL DEFAULT '1',
  `period` varchar(10) NOT NULL DEFAULT 'none',
  `period_mode` varchar(6) NOT NULL DEFAULT 'raw',
  `next_reset` int NOT NULL DEFAULT '0',
  `period_start` int NOT NULL DEFAULT '0',
  `season` int NOT NULL DEFAULT '1',
  `prizes` text,
  `active` tinyint NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  `updated_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active_sort` (`active`, `sort_order`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_lb_baseline` (
  `board_id` int NOT NULL,
  `player_name` varchar(64) NOT NULL,
  `value` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`board_id`, `player_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `znote_lb_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `board_id` int NOT NULL,
  `season` int NOT NULL DEFAULT '1',
  `rank` int NOT NULL DEFAULT '0',
  `player_name` varchar(64) NOT NULL DEFAULT '',
  `value` bigint NOT NULL DEFAULT '0',
  `prize` varchar(120) NOT NULL DEFAULT '',
  `closed_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `board_season` (`board_id`, `season`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
