<?php
/**
 * Void - default shell.
 *
 * Plain HTML around theme_content(). The look lives in assets/css/; this file
 * lays out the frame: an animated header scene, the managed navigation, a logo,
 * and a three-column body (left sidebar / page / rankings).
 */

$voidVideo   = function_exists('theme_option') ? theme_option('header_video') : '';
$voidLogo    = function_exists('theme_image')
	? theme_image('logo_image', theme_asset('img/images/ui/void-logo.png'))
	: theme_asset('img/images/ui/void-logo.png');
$voidFavicon = function_exists('theme_image') ? theme_image('favicon', 'assets/img/znoteX.png') : 'assets/img/znoteX.png';
$voidDiscord = function_exists('theme_option') ? theme_option('discord_url') : '';
$voidFooter  = function_exists('theme_option') ? theme_option('footer_html') : '';
$voidHeadline = !empty($GLOBALS['page_title'])
	? (string)$GLOBALS['page_title']
	: ucwords(str_replace(array('-', '_'), ' ', (string)($page_filename ?? 'index')));
$voidLang = function_exists('translate_active') ? explode('_', translate_active())[0] : 'en';

// Account cluster: myaccount + the pages reached from it get a profile header
// and a shared sub-nav so they read as one section.
$voidPage      = (string)($page_filename ?? 'index');
$voidLoggedIn  = function_exists('user_logged_in') && user_logged_in() === true;
$voidAccPages  = array('myaccount', 'createcharacter', 'changepassword', 'settings', 'twofa', 'accountsettings', 'paymentlog', 'changename', 'changesex');
$voidIsAccount = $voidLoggedIn && in_array($voidPage, $voidAccPages, true);
$voidAcc = $voidIsAccount && is_array($user_data ?? null) ? $user_data : array();
if ($voidIsAccount) {
	$voidAccId    = (int)($voidAcc['id'] ?? 0);
	$voidAccName  = (string)($voidAcc['name'] ?? '');
	$voidAccZ     = ($voidAccId && function_exists('user_znote_account_data'))
		? user_znote_account_data($voidAccId, 'points', 'created') : false;
	$voidAccPts   = is_array($voidAccZ) ? (int)($voidAccZ['points'] ?? 0) : 0;
	$voidAccSince = (is_array($voidAccZ) && !empty($voidAccZ['created']))
		? max(0, (int)floor((time() - (int)$voidAccZ['created']) / 86400)) : null;
	$voidAccPrem  = !empty($voidAcc['premdays']) ? (int)$voidAcc['premdays']
		: (!empty($voidAcc['premium_ends_at']) && $voidAcc['premium_ends_at'] > time()
			? (int)ceil(($voidAcc['premium_ends_at'] - time()) / 86400) : 0);
	$voidIsStaff  = function_exists('is_admin') && is_admin($voidAcc);
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($voidLang, ENT_QUOTES, 'UTF-8') ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?= theme_title() ?></title>
	<?php if ($voidFavicon !== ''): ?><link rel="icon" href="<?= $voidFavicon ?>"><?php endif; ?>
	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= theme_asset('css/bootstrap-select.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/shadow-theme.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/shadow-ui.css') ?>">
	<link rel="stylesheet" href="<?= theme_asset('css/contract.css') ?>">
	<script>(function(){try{if(!window.matchMedia||!matchMedia('(prefers-reduced-motion: reduce)').matches)document.documentElement.classList.add('sn-anim');}catch(e){}})();</script>
</head>
<body class="<?= theme_body_class() ?>">

<header class="sh-header" id="sh-header">
	<div class="sh-header-top-line"></div>

	<div class="sh-scene" aria-hidden="true">
		<div class="sh-scene-sky"></div>
		<div class="sh-scene-stars"></div>
		<div class="sh-scene-aurora"></div>
		<div class="sh-scene-moon"></div>
		<div class="sh-scene-mtn sh-mtn-back"></div>
		<div class="sh-scene-mtn sh-mtn-mid"></div>
		<div class="sh-scene-mtn sh-mtn-front"></div>
		<div class="sh-scene-fog sh-fog-1"></div>
		<div class="sh-scene-fog sh-fog-2"></div>
	</div>

	<?php if ($voidVideo !== ''): ?>
		<video class="sh-header-video" autoplay muted loop playsinline id="shVideo"
		       data-src="<?= htmlspecialchars($voidVideo, ENT_QUOTES, 'UTF-8') ?>"></video>
	<?php endif; ?>
	<div class="sh-header-overlay"></div>
	<canvas id="sh-canvas"></canvas>

	<nav class="sh-nav" role="navigation">
		<div class="sh-nav-frame">
			<?php theme_menu(); ?>
			<?php
			if (function_exists('translate_selector')) {
				$voidSelector = translate_selector();
				if ($voidSelector !== '') {
					echo '<div class="void-lang">' . $voidSelector . '</div>' . translate_selector_assets();
					translate_selector_rendered(true);
				}
			}
			?>
		</div>
	</nav>

	<div class="sh-logo">
		<a href="index.php" class="sh-logo-link">
			<img src="<?= $voidLogo ?>" alt="<?= theme_title() ?>" class="sh-logo-img">
		</a>
	</div>

	<div class="sh-header-bottom">
		<div class="sh-server-block">
			<div class="sh-server-label"><?= t('void.header.players_online') ?></div>
			<div class="sh-server-count">
				<span class="sh-online-dot"></span>
				<?= (int) (function_exists('user_count_online') ? user_count_online() : 0) ?>
			</div>
		</div>

		<a href="downloads.php" class="sh-download-block">
			<div class="sh-dl-icon"><i class="fa fa-download"></i></div>
			<div class="sh-dl-title"><?= t('void.header.download') ?></div>
			<div class="sh-dl-meta"><?= t('void.header.download_meta') ?></div>
		</a>

		<?php if ($voidDiscord !== ''): ?>
			<a href="<?= htmlspecialchars($voidDiscord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" class="sh-download-block void-discord-block">
				<div class="sh-dl-icon"><?php theme_include('parts/discord-icon.php'); ?></div>
				<div class="sh-dl-title">Discord</div>
				<div class="sh-dl-meta"><?= t('void.header.discord_meta') ?></div>
			</a>
		<?php endif; ?>
	</div>
</header>

<div id="sh-content">
<div class="sh-page-wrap">

	<aside class="sh-sidebar sh-sidebar-left">
		<?php theme_sidebar(); ?>
	</aside>

	<main class="sh-main" role="main">
		<?php if ($voidIsAccount): ?>
			<?php
			$voidH = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
			$voidAccNav = array(
				'myaccount'      => array('fa-id-card-o',   t('nav.account')),
				'createcharacter'=> array('fa-plus-circle', t('account.create_character')),
				'changepassword' => array('fa-key',         t('account.change_password')),
				'settings'       => array('fa-cog',         t('settings.title')),
			);
			?>
			<div class="sh-panel void-acc-hero">
				<div class="sh-panel-body">
					<div class="void-acc-hero__id">
						<div class="void-acc-avatar"><?= $voidH(function_exists('mb_substr') ? mb_strtoupper(mb_substr($voidAccName, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($voidAccName, 0, 1))) ?></div>
						<div>
							<div class="void-acc-name"><?= $voidH($voidAccName) ?> <span class="void-acc-tag">#<?= (int)$voidAccId ?></span></div>
							<div class="void-acc-badges">
								<span class="void-acc-badge<?= $voidIsStaff ? ' void-acc-badge--staff' : '' ?>"><?= $voidH($voidIsStaff ? t('void.user.staff') : t('void.user.member')) ?></span>
								<span class="void-acc-badge"><?= $voidAccPrem > 0 ? $voidH(t('acc.premium_days', ['days' => $voidAccPrem])) : $voidH(t('acc.free_account')) ?></span>
								<?php if ($voidAccSince !== null): ?><span class="void-acc-badge"><i class="fa fa-clock-o"></i> <?= (int)$voidAccSince ?>d</span><?php endif; ?>
							</div>
						</div>
					</div>
					<div class="void-acc-stats">
						<div class="void-acc-stat"><span><?= number_format($voidAccPts) ?></span><small><?= $voidH(t('common.points')) ?></small></div>
						<div class="void-acc-stat"><span><?= $voidAccPrem > 0 ? (int)$voidAccPrem : '&mdash;' ?></span><small><?= $voidH(t('void.user.member')) ?></small></div>
					</div>
				</div>
			</div>
			<div class="sh-tabs void-acc-tabs">
				<?php foreach ($voidAccNav as $vk => $vm): ?>
					<?php if (!is_file($vk . '.php')) continue; ?>
					<a href="<?= $voidH($vk) ?>.php" class="sh-tab-btn<?= $voidPage === $vk ? ' active' : '' ?>"><i class="fa <?= $voidH($vm[0]) ?>"></i> <?= $voidH($vm[1]) ?></a>
				<?php endforeach; ?>
				<a href="logout.php" class="sh-tab-btn void-acc-tabs__logout"><i class="fa fa-sign-out"></i> <?= $voidH(t('nav.logout')) ?></a>
			</div>
			<div class="bd-c void-acc-body">
				<?php theme_content(); ?>
			</div>
		<?php else: ?>
			<div class="sh-tabs">
				<span class="sh-tab-btn active"><?= htmlspecialchars($voidHeadline, ENT_QUOTES, 'UTF-8') ?></span>
				<a href="highscores.php" class="sh-tab-btn"><?= t('nav.highscores') ?></a>
				<a href="downloads.php" class="sh-tab-btn"><?= t('void.header.download') ?></a>
			</div>
			<div class="bd-c">
				<?php theme_content(); ?>
			</div>
		<?php endif; ?>
	</main>

	<aside class="sh-sidebar sh-sidebar-right">
		<?php theme_include('parts/rankings.php'); ?>
	</aside>

</div>
</div>

<footer class="sh-footer">
	<div class="sh-footer-inner">
		<div class="sh-footer-brand">
			<div class="sh-footer-logo"><img src="<?= $voidLogo ?>" alt="<?= theme_title() ?>"></div>
			<?php if ($voidFooter !== ''): ?><p><?= $voidFooter ?></p><?php endif; ?>
		</div>
		<div class="sh-footer-col">
			<h4><?= t('void.footer.quick_links') ?></h4>
			<a href="register.php"><?= t('nav.register') ?></a>
			<a href="downloads.php"><?= t('void.header.download') ?></a>
			<a href="highscores.php"><?= t('nav.highscores') ?></a>
			<a href="shop.php"><?= t('nav.shop') ?></a>
			<?php if ($voidDiscord !== ''): ?><a href="<?= htmlspecialchars($voidDiscord, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><?php theme_include('parts/discord-icon.php'); ?> Discord</a><?php endif; ?>
		</div>
		<div class="sh-footer-col">
			<h4><?= t('void.footer.information') ?></h4>
			<a href="serverinfo.php"><?= t('nav.serverinfo') ?></a>
			<a href="onlinelist.php"><?= t('nav.community') ?></a>
			<a href="credits.php"><?= t('void.footer.credits') ?></a>
		</div>
		<div class="sh-footer-clock">
			<h4><?= t('void.footer.server_time') ?></h4>
			<div class="sh-clock" id="sh-clock">00:00:00</div>
			<div class="sh-clock-date" id="sh-clock-date">-</div>
		</div>
	</div>
	<div class="sh-copyright">
		<?= t('void.footer.copyright', ['year' => date('Y'), 'site' => htmlspecialchars((string)($config['site_name'] ?? theme_title()), ENT_QUOTES, 'UTF-8')]) ?>
		&middot; <?= t('void.footer.powered_by') ?> <a href="credits.php">ZnoteX</a>
		&middot; <?= elapsedTime() ?>s
	</div>
</footer>

<script src="<?= theme_asset('js/jquery-2.2.4.min.js') ?>"></script>
<script src="<?= theme_asset('js/tether.min.js') ?>"></script>
<script src="<?= theme_asset('js/bootstrap.min.js') ?>"></script>
<script src="<?= theme_asset('js/shadow-particles.js') ?>" defer></script>
<script src="<?= theme_asset('js/shadow-cursor.js') ?>" defer></script>
<script>
(function(){
	var d=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
	    m=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	function tick(){
		var n=new Date();
		var p=function(x){return String(x).padStart(2,'0');};
		var ct=document.getElementById('sh-clock'), cd=document.getElementById('sh-clock-date');
		if(ct) ct.textContent=p(n.getHours())+':'+p(n.getMinutes())+':'+p(n.getSeconds());
		if(cd) cd.textContent=d[n.getDay()]+', '+n.getDate()+' '+m[n.getMonth()]+' '+n.getFullYear();
	}
	tick(); setInterval(tick,1000);
})();
(function(){
	function init(){
		var items=document.querySelectorAll('.sh-has-drop');
		if(!items.length) return;
		items.forEach(function(li){
			var link=li.querySelector(':scope > a');
			if(!link) return;
			link.addEventListener('click', function(e){
				e.preventDefault(); e.stopPropagation();
				var wasOpen=li.classList.contains('open');
				items.forEach(function(o){ o.classList.remove('open'); });
				if(!wasOpen) li.classList.add('open');
			});
		});
		document.addEventListener('click', function(e){
			if(!e.target.closest('.sh-has-drop')) items.forEach(function(o){ o.classList.remove('open'); });
		});
	}
	if(document.readyState!=='loading') init();
	else document.addEventListener('DOMContentLoaded', init);
})();
<?php if ($voidVideo !== ''): ?>
(function(){
	var v=document.getElementById('shVideo');
	if(!v||!v.dataset.src) return;
	if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
	var s=document.createElement('source'); s.src=v.dataset.src; s.type='video/mp4';
	v.appendChild(s); v.load();
	var p=v.play(); if(p&&p.catch) p.catch(function(){});
	v.addEventListener('playing', function(){ v.classList.add('is-playing'); var h=document.getElementById('sh-header'); if(h) h.classList.add('sh-video-on'); }, {once:true});
	document.addEventListener('visibilitychange', function(){ if(document.hidden) v.pause(); else v.play().catch(function(){}); });
})();
<?php endif; ?>
(function(){
	var de=document.documentElement;
	if(!de.classList.contains('sn-anim')) return;
	try{
		var items=[].slice.call(document.querySelectorAll('.sh-panel,.sh-feat,.sh-news-item'));
		if(!('IntersectionObserver' in window)){ items.forEach(function(e){ e.classList.add('sn-in'); }); return; }
		var io=new IntersectionObserver(function(en){
			en.forEach(function(x){ if(x.isIntersecting){ x.target.classList.add('sn-in'); io.unobserve(x.target); } });
		}, { rootMargin:'0px 0px -6% 0px', threshold:0.06 });
		items.forEach(function(e){ io.observe(e); });
		setTimeout(function(){ items.forEach(function(e){ e.classList.add('sn-in'); }); }, 1800);
	}catch(e){ de.classList.remove('sn-anim'); }
})();
</script>
</body>
</html>
