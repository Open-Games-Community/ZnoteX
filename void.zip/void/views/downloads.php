<?php
/**
 * Void - Downloads.
 *
 * Matches the Oblivion "index.php?p=download" layout (page title, a hero panel
 * with the animated download badge and the client buttons, then an install
 * guide panel). Uses the shell's own .sh-* components, so no extra CSS.
 *
 * Data from downloads.php: $config['client'], client_download,
 * client_download_linux.
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$version   = isset($config['client']) ? rtrim(rtrim(number_format($config['client'] / 100, 2, '.', ''), '0'), '.') : '';
$winUrl    = trim((string)($config['client_download'] ?? ''));
$linuxUrl  = trim((string)($config['client_download_linux'] ?? ''));
$ipcUrl    = 'https://github.com/jo3bingham/tibia-ip-changer/releases/latest';
$serverIp  = (string)($config['server_ip'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost'));

$buttons = array();
if ($winUrl !== '') {
	$buttons[] = array('url' => $winUrl, 'label' => t('downloads.win', ['version' => $version]), 'icon' => 'windows');
}
if ($linuxUrl !== '') {
	$buttons[] = array('url' => $linuxUrl, 'label' => t('downloads.linux', ['version' => $version]), 'icon' => 'linux');
}
$buttons[] = array('url' => $ipcUrl, 'label' => t('downloads.ipchanger'), 'icon' => 'random');
?>
<div class="sh-page-title"><i class="fa fa-download"></i> <?= $h(t('downloads.title')) ?></div>

<div class="sh-panel" style="margin-bottom:20px;">
	<div class="sh-panel-body">
		<div style="text-align:center;padding:20px 0 10px;">
			<div class="sh-download-hero">
				<span class="sh-download-hero-pulse" aria-hidden="true"></span>
				<span class="sh-download-hero-pulse sh-download-hero-pulse--2" aria-hidden="true"></span>
				<span class="sh-download-hero-ring" aria-hidden="true"></span>
				<div class="sh-dl-icon sh-download-hero-icon"><i class="fa fa-download"></i></div>
			</div>
			<h2 style="font-size:24px;font-weight:800;color:#ede0ff;margin-bottom:6px;letter-spacing:2px;">
				<?= $h(t('void.download.hero_title')) ?>
			</h2>
			<p style="color:var(--s-muted);font-size:13px;margin-bottom:4px;">
				<?= $h(t('downloads.intro')) ?>
			</p>
		</div>
		<div style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-top:16px;">
			<?php foreach ($buttons as $b): ?>
				<a href="<?= $h($b['url']) ?>" class="sh-btn sh-btn-primary sh-btn-lg" target="_blank" rel="noopener">
					<i class="fa fa-<?= $h($b['icon']) ?>"></i> <?= $h($b['label']) ?>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-book"></i> <?= $h(rtrim(t('downloads.howto'), ':')) ?></div>
	<div class="sh-panel-body">
		<ol style="padding-left:20px;color:var(--s-text);font-size:13px;line-height:2;">
			<li><?= $h(t('void.download.step1')) ?></li>
			<li><?= $h(t('void.download.step2')) ?></li>
			<li><?= $h(t('downloads.step3')) ?></li>
			<li><?= t('downloads.step4') ?> <strong><?= $h($serverIp) ?></strong></li>
			<li><?= $h(t('void.download.step5')) ?></li>
		</ol>
	</div>
</div>
