<?php
/**
 * Void - Item Shop.
 *
 * Same data and purchase flow as the default view; laid out as a compact card
 * grid with a category filter. In scope from shop.php: $shop, $shop_list,
 * $loggedin, $user_znote_data, $config, $buy (on a POST).
 */

$h = static function ($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

if (empty($shop['enabled'])) {
	echo '<div class="sh-page-title"><i class="fa fa-shopping-cart"></i> ' . $h(t('shop.offers')) . '</div>'
		. '<div class="sh-panel"><div class="sh-panel-body"><p>' . $h(t('buypoints.disabled_text')) . '</p></div></div>';
	return;
}

$points  = $loggedin ? (int)($user_znote_data['points'] ?? 0) : 0;
$imgSrv  = (string)($shop['imageServer'] ?? 'items.znote.eu');
$imgType = (string)($shop['imageType'] ?? 'gif');
$outSrv  = (string)($config['show_outfits']['imageServer'] ?? '');
$showOut = !empty($config['show_outfits']['shop']);
$confirm = !empty($shop['enableShopConfirmation']);
$sess    = time();

$catSlug = array(1 => 'items', 2 => 'premium', 3 => 'misc', 4 => 'misc', 5 => 'outfits', 6 => 'mounts');

$itemImageUrl = static function (int $itemId) use ($imgSrv, $imgType): string {
	$server = rtrim($imgSrv, '/');
	$ext = ltrim($imgType, '.');
	if ($server === '' || $itemId <= 0) {
		return '';
	}
	if (preg_match('~^https?://~i', $server)) {
		return $server . '/' . $itemId . '.' . $ext;
	}
	if (strpos($server, '.') !== false) {
		return 'http://' . $server . '/' . $itemId . '.' . $ext;
	}
	return '/' . ltrim($server, '/') . '/' . $itemId . '.' . $ext;
};

$offerImage = static function (array $o) use ($itemImageUrl, $outSrv, $showOut): string {
	$id = $o['itemid'];
	if (is_array($id)) { $id = reset($id); }
	if ((int)$o['type'] === 5 && $showOut && $outSrv !== '') {
		return $outSrv . '?id=' . (int)$id . '&addons=' . (int)$o['count'] . '&head=0&body=0&legs=0&feet=0';
	}
	if ((int)$o['type'] === 6 && $outSrv !== '') {
		return $outSrv . '?id=128&addons=0&mount=' . (int)$id;
	}
	return $itemImageUrl((int)$id);
};

$offerCount = static function (array $o): string {
	$type = (int)$o['type'];
	if ($type === 2) { return t('shop.days', ['count' => (int)$o['count']]); }
	if ($type === 5 || $type === 6) { return ''; }
	return (int)$o['count'] . 'x';
};

$grouped = array();
foreach (($shop_list ?? array()) as $key => $offer) {
	$grouped[$catSlug[(int)$offer['type']] ?? 'misc'][$key] = $offer;
}
$usedCats = array();
foreach (array('items' => 'shop.cat_items', 'premium' => 'shop.cat_premium', 'outfits' => 'shop.cat_outfits', 'mounts' => 'shop.cat_mounts', 'misc' => 'shop.cat_misc') as $slug => $lk) {
	if (!empty($grouped[$slug])) { $usedCats[$slug] = t($lk); }
}
?>
<div class="sh-page-title"><i class="fa fa-shopping-cart"></i> <?= $h(t('shop.offers')) ?></div>

<?php if ($loggedin): ?>
	<div class="sh-panel void-shop-pointsbar">
		<div class="sh-panel-body">
			<span class="void-shop-points"><i class="fa fa-money"></i> <strong><?= number_format($points) ?></strong> <?= $h(t('common.points')) ?></span>
			<a href="buypoints.php" class="sh-btn sh-btn-primary"><i class="fa fa-plus"></i> <?= $h(t('shop.buy_points')) ?></a>
		</div>
	</div>
<?php else: ?>
	<div class="sh-panel"><div class="sh-panel-body"><p><?= $h(t('shop.need_login')) ?> <a href="login.php"><?= $h(t('nav.login')) ?></a></p></div></div>
<?php endif; ?>

<?php if (count($usedCats) > 1): ?>
	<div class="void-shop-filter">
		<button type="button" class="sh-tab-btn active" data-shop-cat="all"><?= $h(t('shop.cat_all')) ?></button>
		<?php foreach ($usedCats as $slug => $label): ?>
			<button type="button" class="sh-tab-btn" data-shop-cat="<?= $h($slug) ?>"><?= $h($label) ?></button>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php if (empty($shop_list)): ?>
	<div class="sh-panel"><div class="sh-panel-body"><p><?= $h(t('common.nothing')) ?></p></div></div>
<?php else: ?>
	<div class="void-shop-grid" data-shop-grid>
		<?php foreach ($grouped as $slug => $offers): ?>
			<?php foreach ($offers as $key => $o): ?>
				<?php $cost = (int)$o['points']; $count = $offerCount($o); ?>
				<div class="void-shop-card" data-shop-item="<?= $h($slug) ?>">
					<div class="void-shop-card__img">
						<img src="<?= $h($offerImage($o)) ?>" alt="" loading="lazy">
						<?php if ($count !== ''): ?><span class="void-shop-card__count"><?= $h($count) ?></span><?php endif; ?>
					</div>
					<div class="void-shop-card__name"><?= $h(strip_tags((string)$o['description'])) ?></div>
					<div class="void-shop-card__cost"><i class="fa fa-money"></i> <?= number_format($cost) ?></div>
					<?php if ($loggedin): ?>
						<form action="" method="POST" class="void-shop-card__buy">
							<input type="hidden" name="buy" value="<?= (int)$key ?>">
							<input type="hidden" name="session" value="<?= $sess ?>">
							<button type="submit" class="sh-btn sh-btn-primary sh-btn-full<?= $confirm ? ' needconfirmation' : '' ?>"
								<?= $points < $cost ? 'disabled' : '' ?>
								data-item-name="<?= $h(strip_tags((string)$o['description'])) ?>" data-item-cost="<?= $cost ?>">
								<?= $h(t('shop.purchase')) ?>
							</button>
						</form>
					<?php else: ?>
						<a class="sh-btn sh-btn-full" href="login.php"><?= $h(t('nav.login')) ?></a>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<script>
(function(){
	var grid=document.querySelector('[data-shop-grid]');
	if(grid){
		var cards=[].slice.call(grid.querySelectorAll('[data-shop-item]'));
		document.querySelectorAll('[data-shop-cat]').forEach(function(b){
			b.addEventListener('click',function(){
				var c=b.getAttribute('data-shop-cat');
				document.querySelectorAll('[data-shop-cat]').forEach(function(x){x.classList.toggle('active',x===b);});
				cards.forEach(function(card){card.hidden=(c!=='all'&&card.getAttribute('data-shop-item')!==c);});
			});
		});
	}
	var pts=<?= json_encode(t('common.points')) ?>;
	document.querySelectorAll('.needconfirmation').forEach(function(btn){
		btn.addEventListener('click',function(e){
			var n=btn.getAttribute('data-item-name')||'', p=btn.getAttribute('data-item-cost')||'';
			if(!window.confirm(n+' — '+p+' '+pts+'?')) e.preventDefault();
		});
	});
})();
</script>

<?php $_SESSION['shop_session'] = $sess; ?>
