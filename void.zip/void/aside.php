<?php
/**
 * Left sidebar. Included because shells/default.php calls theme_sidebar().
 */

if (user_logged_in() === true) {
	widget('account');
	if (isset($user_data) && is_admin($user_data)) {
		widget('admin');
	}
} else {
	widget('login');
}

widget('statistics');
widget('follow');
