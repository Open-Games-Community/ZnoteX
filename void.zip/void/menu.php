<?php
/**
 * Top navigation. Entries come from Admin Panel > Menus
 * (theme_menu_items('main')); this file only renders them.
 */

$voidMenu = function_exists('theme_menu_items') ? theme_menu_items('main') : array();
$voidMenuLive = function_exists('theme_menu_available') ? theme_menu_available() : (bool)$voidMenu;
$voidCurrent = (string)($page_filename ?? 'index');
?>
<ul class="sh-nav-list">
	<?php if ($voidMenuLive): ?>
		<?php foreach ($voidMenu as $item): ?>
			<?php
			$hasDrop = !empty($item['children']);
			$isActive = ($item['url'] !== '' && strpos($item['url'], $voidCurrent . '.php') === 0);
			$classes = trim(($isActive ? 'active ' : '') . ($hasDrop ? 'sh-has-drop' : ''));
			$href = $item['url'] !== '' ? $item['url'] : '#';
			?>
			<li class="<?= $classes ?>">
				<a href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>" class="sh-nav-btn"<?= $item['target'] !== '' ? ' target="' . htmlspecialchars($item['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
					<span class="sh-nav-btn-text">
						<?php if ($item['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i> <?php endif; ?>
						<?= htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') ?><?php if ($hasDrop): ?> <i class="fa fa-caret-down"></i><?php endif; ?>
					</span>
				</a>
				<?php if ($hasDrop): ?>
					<ul class="sh-dropdown">
						<?php foreach ($item['children'] as $child): ?>
							<li>
								<a href="<?= htmlspecialchars($child['url'], ENT_QUOTES, 'UTF-8') ?>"<?= $child['target'] !== '' ? ' target="' . htmlspecialchars($child['target'], ENT_QUOTES, 'UTF-8') . '" rel="noopener"' : '' ?>>
									<?php if ($child['icon'] !== ''): ?><i class="fa <?= htmlspecialchars($child['icon'], ENT_QUOTES, 'UTF-8') ?>"></i><?php endif; ?>
									<?= htmlspecialchars($child['label'], ENT_QUOTES, 'UTF-8') ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	<?php else: ?>
		<li class="active"><a href="index.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('nav.home')) ?></span></a></li>
		<li><a href="register.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('nav.register')) ?></span></a></li>
		<li><a href="downloads.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('void.header.download')) ?></span></a></li>
		<li><a href="highscores.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('nav.highscores')) ?></span></a></li>
		<li><a href="guilds.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('nav.guilds')) ?></span></a></li>
		<li><a href="shop.php" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t('nav.shop')) ?></span></a></li>
		<li><a href="<?= user_logged_in() ? 'myaccount.php' : 'login.php' ?>" class="sh-nav-btn"><span class="sh-nav-btn-text"><?= h(t(user_logged_in() ? 'nav.account' : 'nav.login')) ?></span></a></li>
	<?php endif; ?>
</ul>
