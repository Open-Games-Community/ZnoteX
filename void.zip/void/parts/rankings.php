<?php
/**
 * Right sidebar - player and guild rankings. Read-only, cached, the same
 * pattern the default theme's widgets use.
 */

$voidIgnoreGroup = (int)($config['highscore']['ignoreGroupId'] ?? 2);

$voidPlayersCache = new Cache('engine/cache/voidTopPlayers');
if ($voidPlayersCache->hasExpired()) {
	$voidTopPlayers = db()->fetchAll("
		SELECT `name`, `level`, `vocation`, `looktype`, `lookhead`, `lookbody`, `looklegs`, `lookfeet`
		FROM `players`
		WHERE `group_id` < ?
		ORDER BY `level` DESC, `experience` DESC
		LIMIT 10;
	", [$voidIgnoreGroup]);
	$voidPlayersCache->setContent($voidTopPlayers);
	$voidPlayersCache->save();
} else {
	$voidTopPlayers = $voidPlayersCache->load();
}

$voidGuildsCache = new Cache('engine/cache/voidTopGuilds');
if ($voidGuildsCache->hasExpired()) {
	$voidTopGuilds = db()->fetchAll("
		SELECT `g`.`name` AS `name`, COUNT(`gm`.`player_id`) AS `members`
		FROM `guilds` `g`
		LEFT JOIN `guild_membership` `gm` ON `gm`.`guild_id` = `g`.`id`
		GROUP BY `g`.`id`
		ORDER BY `members` DESC, `g`.`name` ASC
		LIMIT 10;
	");
	$voidGuildsCache->setContent($voidTopGuilds);
	$voidGuildsCache->save();
} else {
	$voidTopGuilds = $voidGuildsCache->load();
}

$voidRankClass = static fn (int $i): string => 'sh-rank-' . ($i <= 3 ? $i : 'n');
$voidJobIcon = static function (int $vocation): string {
	$file = ($vocation >= 0 && $vocation <= 7) ? (string)$vocation : '0';
	return theme_asset('img/job/' . $file . '.png');
};

$voidOutfitServer = trim((string)($config['show_outfits']['imageServer'] ?? ''));
$voidOutfitImg = static function (array $p) use ($voidOutfitServer): string {
	if ($voidOutfitServer === '') {
		return '';
	}
	return $voidOutfitServer . '?' . http_build_query(array(
		'id'     => (int)($p['looktype'] ?? 0),
		'addons' => 3,
		'head'   => (int)($p['lookhead'] ?? 0),
		'body'   => (int)($p['lookbody'] ?? 0),
		'legs'   => (int)($p['looklegs'] ?? 0),
		'feet'   => (int)($p['lookfeet'] ?? 0),
	));
};
?>
<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-trophy"></i> <?= t('void.rank.players') ?></div>
	<ul class="sh-player-list" style="padding:8px 12px 2px;">
		<?php if ($voidTopPlayers): foreach ($voidTopPlayers as $idx => $p): $rank = $idx + 1; ?>
			<li>
				<span class="sh-rank-num <?= $voidRankClass($rank) ?>"><?= $rank ?></span>
				<?php $voidOutfit = $voidOutfitImg($p); ?>
				<div class="sh-rank-avatar<?= $voidOutfit !== '' ? ' sh-rank-outfit' : '' ?>">
					<img src="<?= $voidOutfit !== '' ? htmlspecialchars($voidOutfit, ENT_QUOTES, 'UTF-8') : $voidJobIcon((int)$p['vocation']) ?>" alt="" loading="lazy" title="<?= htmlspecialchars(vocation_id_to_name((int)$p['vocation']), ENT_QUOTES, 'UTF-8') ?>">
				</div>
				<span class="sh-rank-name" title="<?= htmlspecialchars((string)$p['name'], ENT_QUOTES, 'UTF-8') ?>">
					<a href="characterprofile.php?name=<?= urlencode((string)$p['name']) ?>"><?= htmlspecialchars((string)$p['name'], ENT_QUOTES, 'UTF-8') ?></a>
				</span>
				<span class="sh-rank-level"><?= (int)$p['level'] ?></span>
			</li>
		<?php endforeach; else: ?>
			<li><span class="sh-rank-name"><?= t('common.nothing') ?></span></li>
		<?php endif; ?>
	</ul>
	<a href="highscores.php" class="sh-see-more"><i class="fa fa-list"></i> <?= t('void.rank.view_full') ?></a>
</div>

<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-shield"></i> <?= t('void.rank.guilds') ?></div>
	<div style="padding:8px 12px 2px;">
		<?php if ($voidTopGuilds): foreach ($voidTopGuilds as $idx => $g): $rank = $idx + 1; ?>
			<div class="sh-guild-item">
				<span class="sh-rank-num <?= $voidRankClass($rank) ?>"><?= $rank ?></span>
				<div class="sh-guild-badge">
					<img src="<?= theme_asset('img/images/ui/guild-emblem.png') ?>" alt="" title="<?= htmlspecialchars((string)$g['name'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy">
				</div>
				<div class="sh-guild-info">
					<div class="sh-guild-name" title="<?= htmlspecialchars((string)$g['name'], ENT_QUOTES, 'UTF-8') ?>">
						<a href="guilds.php?name=<?= urlencode((string)$g['name']) ?>"><?= htmlspecialchars((string)$g['name'], ENT_QUOTES, 'UTF-8') ?></a>
					</div>
					<div class="sh-guild-sub"><?= t('void.rank.members') ?></div>
				</div>
				<div class="sh-guild-pts"><?= (int)$g['members'] ?></div>
			</div>
		<?php endforeach; else: ?>
			<div class="sh-guild-item"><span class="sh-guild-name"><?= t('common.nothing') ?></span></div>
		<?php endif; ?>
	</div>
	<a href="topguilds.php" class="sh-see-more"><i class="fa fa-list"></i> <?= t('void.rank.view_full') ?></a>
</div>
