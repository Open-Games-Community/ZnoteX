(function(){
  /* Respect reduced-motion: skip the whole effect */
  if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var canvas = document.getElementById('sh-canvas');
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  var W = 0, H = 0, raf, running = false;

  function resize(){
    var hdr = document.getElementById('sh-header');
    W = canvas.width  = hdr ? hdr.offsetWidth  : window.innerWidth;
    H = canvas.height = hdr ? hdr.offsetHeight : window.innerHeight;
  }
  resize();
  /* Debounced resize so dragging the window doesn't thrash the canvas */
  var rT; window.addEventListener('resize', function(){ clearTimeout(rT); rT = setTimeout(resize, 200); });

  function rnd(a,b){ return a + Math.random()*(b-a); }

  function moteGradient(size, hue){
    var g = ctx.createRadialGradient(0,0,0,0,0,size*3);
    g.addColorStop(0,   'hsla('+hue+',100%,90%,1)');
    g.addColorStop(0.35,'hsla('+hue+',100%,68%,0.8)');
    g.addColorStop(0.7, 'hsla('+hue+',90%,50%,0.3)');
    g.addColorStop(1,   'hsla('+hue+',90%,45%,0)');
    return g;
  }
  function orbGradient(r, hue){
    var g = ctx.createRadialGradient(0,0,0,0,0,r);
    g.addColorStop(0,  'hsla('+hue+',90%,72%,1)');
    g.addColorStop(0.5,'hsla('+hue+',85%,52%,0.5)');
    g.addColorStop(1,  'hsla('+hue+',80%,40%,0)');
    return g;
  }

  /* ── Drifting spirit motes (fewer on small screens) ── */
  var POOL = window.innerWidth < 760 ? 22 : 38;
  var motes = [];
  function makeMote(spawnAnywhere){
    var big = Math.random() < 0.22;
    var size = big ? rnd(2.4, 4.6) : rnd(0.7, 1.9);
    var hue = rnd(255, 300);          /* violet → magenta */
    return {
      x: rnd(0, W),
      y: spawnAnywhere ? rnd(0, H) : H + rnd(0, 50),
      vx: rnd(-0.35, 0.35),
      vy: rnd(-0.9, -0.25),
      size: size,
      baseAlpha: rnd(0.35, 0.85),
      life: 0,
      maxLife: rnd(260, 520),
      hue: hue,
      wob: rnd(0.006, 0.022),
      wobOff: rnd(0, Math.PI*2),
      twinkle: rnd(0.02, 0.06),
      grad: moteGradient(size, hue)
    };
  }
  for(var i=0;i<POOL;i++){ motes.push(makeMote(true)); motes[i].life = rnd(0, motes[i].maxLife); }

  /* ── Slow rising glowing orbs (rare, larger) ── */
  var orbs = [];
  function makeOrb(){
    var r = rnd(14,30);
    var hue = rnd(265,295);
    orbs.push({
      x: rnd(W*0.1, W*0.9), y: H + rnd(10,80),
      vy: rnd(-0.45,-0.2), r: r,
      alpha: 0, maxAlpha: rnd(0.10,0.22),
      hue: hue, life: 0, maxLife: rnd(420,760),
      grad: orbGradient(r, hue)
    });
  }
  setInterval(function(){ if(orbs.length < 3 && !document.hidden) makeOrb(); }, 3200);

  function tick(){
    ctx.clearRect(0,0,W,H);

    /* Orbs (behind) */
    for(var o=orbs.length-1;o>=0;o--){
      var orb=orbs[o]; orb.life++; orb.y+=orb.vy;
      var t=orb.life/orb.maxLife;
      orb.alpha = t<0.25 ? (t/0.25)*orb.maxAlpha : (1-t)*orb.maxAlpha;
      if(orb.life>=orb.maxLife||orb.y<-40){ orbs.splice(o,1); continue; }
      ctx.save();
      ctx.globalAlpha = orb.alpha;
      ctx.translate(orb.x, orb.y);
      ctx.beginPath(); ctx.arc(0,0,orb.r,0,Math.PI*2);
      ctx.fillStyle=orb.grad; ctx.fill();
      ctx.restore();
    }

    /* Motes */
    for(var i=0;i<motes.length;i++){
      var p=motes[i]; p.life++;
      p.x += p.vx + Math.sin(p.life*p.wob + p.wobOff)*0.45;
      p.y += p.vy;
      p.vy -= 0.0015;
      var t=p.life/p.maxLife;
      var fade = t<0.15 ? (t/0.15) : (t>0.8 ? (1-t)/0.2 : 1);
      var tw = 0.65 + 0.35*Math.sin(p.life*p.twinkle + p.wobOff);
      var a = Math.max(0, p.baseAlpha*fade*tw);

      if(p.life>=p.maxLife || p.y<-20 || p.x<-20 || p.x>W+20){ motes[i]=makeMote(false); continue; }

      var r=p.size;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.translate(p.x, p.y);
      ctx.beginPath(); ctx.arc(0,0,r*3,0,Math.PI*2);
      ctx.fillStyle=p.grad; ctx.fill();

      /* bright core for big motes */
      if(p.size>2.3){
        ctx.beginPath(); ctx.arc(0,0,r*0.6,0,Math.PI*2);
        ctx.fillStyle='hsla('+p.hue+',100%,96%,1)'; ctx.fill();
      }
      ctx.restore();
    }

    raf=requestAnimationFrame(tick);
  }

  function start(){ if(!running){ running=true; tick(); } }
  function stop(){ running=false; cancelAnimationFrame(raf); }

  setTimeout(start, 250);
  document.addEventListener('visibilitychange', function(){ document.hidden ? stop() : start(); });
})();
