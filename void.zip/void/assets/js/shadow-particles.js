(function(){
  /* Respect reduced-motion: skip the whole effect */
  if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var canvas = document.getElementById('sh-canvas');
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  var W = 0, H = 0, raf, running = false;

  function resize(){
    var hdr = document.getElementById('sh-header');
    W = canvas.width  = hdr ? hdr.offsetWidth  : window.innerWidth;
    H = canvas.height = hdr ? hdr.offsetHeight : window.innerHeight;
  }
  resize();
  /* Debounced resize so dragging the window doesn't thrash the canvas */
  var rT; window.addEventListener('resize', function(){ clearTimeout(rT); rT = setTimeout(resize, 200); });

  function rnd(a,b){ return a + Math.random()*(b-a); }

  /* ── Drifting spirit motes (fewer on small screens) ── */
  var POOL = window.innerWidth < 760 ? 22 : 38;
  var motes = [];
  function makeMote(spawnAnywhere){
    var big = Math.random() < 0.22;
    return {
      x: rnd(0, W),
      y: spawnAnywhere ? rnd(0, H) : H + rnd(0, 50),
      vx: rnd(-0.35, 0.35),
      vy: rnd(-0.9, -0.25),
      size: big ? rnd(2.4, 4.6) : rnd(0.7, 1.9),
      baseAlpha: rnd(0.35, 0.85),
      life: 0,
      maxLife: rnd(260, 520),
      hue: rnd(255, 300),          /* violet → magenta */
      wob: rnd(0.006, 0.022),
      wobOff: rnd(0, Math.PI*2),
      twinkle: rnd(0.02, 0.06)
    };
  }
  for(var i=0;i<POOL;i++){ motes.push(makeMote(true)); motes[i].life = rnd(0, motes[i].maxLife); }

  /* ── Slow rising glowing orbs (rare, larger) ── */
  var orbs = [];
  function makeOrb(){
    orbs.push({
      x: rnd(W*0.1, W*0.9), y: H + rnd(10,80),
      vy: rnd(-0.45,-0.2), r: rnd(14,30),
      alpha: 0, maxAlpha: rnd(0.10,0.22),
      hue: rnd(265,295), life: 0, maxLife: rnd(420,760)
    });
  }
  setInterval(function(){ if(orbs.length < 3 && !document.hidden) makeOrb(); }, 3200);

  function tick(){
    ctx.clearRect(0,0,W,H);

    /* Orbs (behind) */
    for(var o=orbs.length-1;o>=0;o--){
      var orb=orbs[o]; orb.life++; orb.y+=orb.vy;
      var t=orb.life/orb.maxLife;
      orb.alpha = t<0.25 ? (t/0.25)*orb.maxAlpha : (1-t)*orb.maxAlpha;
      if(orb.life>=orb.maxLife||orb.y<-40){ orbs.splice(o,1); continue; }
      var g=ctx.createRadialGradient(orb.x,orb.y,0,orb.x,orb.y,orb.r);
      g.addColorStop(0,'hsla('+orb.hue+',90%,72%,'+orb.alpha+')');
      g.addColorStop(0.5,'hsla('+orb.hue+',85%,52%,'+(orb.alpha*0.5)+')');
      g.addColorStop(1,'hsla('+orb.hue+',80%,40%,0)');
      ctx.beginPath(); ctx.arc(orb.x,orb.y,orb.r,0,Math.PI*2);
      ctx.fillStyle=g; ctx.fill();
    }

    /* Motes */
    for(var i=0;i<motes.length;i++){
      var p=motes[i]; p.life++;
      p.x += p.vx + Math.sin(p.life*p.wob + p.wobOff)*0.45;
      p.y += p.vy;
      p.vy -= 0.0015;
      var t=p.life/p.maxLife;
      var fade = t<0.15 ? (t/0.15) : (t>0.8 ? (1-t)/0.2 : 1);
      var tw = 0.65 + 0.35*Math.sin(p.life*p.twinkle + p.wobOff);
      var a = Math.max(0, p.baseAlpha*fade*tw);

      if(p.life>=p.maxLife || p.y<-20 || p.x<-20 || p.x>W+20){ motes[i]=makeMote(false); continue; }

      var r=p.size;
      var grad=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,r*3);
      grad.addColorStop(0,  'hsla('+p.hue+',100%,90%,'+a+')');
      grad.addColorStop(0.35,'hsla('+p.hue+',100%,68%,'+(a*0.8)+')');
      grad.addColorStop(0.7,'hsla('+p.hue+',90%,50%,'+(a*0.3)+')');
      grad.addColorStop(1,  'hsla('+p.hue+',90%,45%,0)');
      ctx.beginPath(); ctx.arc(p.x,p.y,r*3,0,Math.PI*2);
      ctx.fillStyle=grad; ctx.fill();

      /* bright core for big motes */
      if(p.size>2.3){
        ctx.beginPath(); ctx.arc(p.x,p.y,r*0.6,0,Math.PI*2);
        ctx.fillStyle='hsla('+p.hue+',100%,96%,'+a+')'; ctx.fill();
      }
    }

    raf=requestAnimationFrame(tick);
  }

  function start(){ if(!running){ running=true; tick(); } }
  function stop(){ running=false; cancelAnimationFrame(raf); }

  setTimeout(start, 250);
  document.addEventListener('visibilitychange', function(){ document.hidden ? stop() : start(); });
})();
