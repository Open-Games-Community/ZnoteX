(function () {
  if (window.__snCursor) return;
  window.__snCursor = true;

  var fine = window.matchMedia && window.matchMedia('(pointer: fine)').matches;
  var ok   = window.matchMedia && !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!fine || !ok) return;

  var INTERACTIVE = "a,button,summary,select,label.sh-inv-sel,.sh-btn,.sh-tab-btn,.sh-inv-tab,.sh-has-drop>a,.sh-lang-picker a,.sh-news-item,.sh-feat,.sh-char-card,.sh-inv-item,[role='button'],input[type='submit'],input[type='button']";

  function start() {
    var glow = document.createElement('div');
    glow.className = 'sn-glow';
    glow.setAttribute('aria-hidden', 'true');
    document.body.appendChild(glow);

    var x = -100, y = -100, tx = x, ty = y, raf = 0, visible = false;

    function loop() {
      x += (tx - x) * 0.22;
      y += (ty - y) * 0.22;
      glow.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)';
      raf = requestAnimationFrame(loop);
    }

    document.addEventListener('mousemove', function (e) {
      tx = e.clientX; ty = e.clientY;
      if (!visible) { x = tx; y = ty; glow.classList.add('on'); visible = true; }
      glow.classList.toggle('link', !!(e.target.closest && e.target.closest(INTERACTIVE)));
    }, { passive: true });

    document.addEventListener('mousedown', function () { glow.classList.add('down'); }, { passive: true });
    document.addEventListener('mouseup',   function () { glow.classList.remove('down'); }, { passive: true });
    document.addEventListener('mouseleave',function () { glow.classList.remove('on'); visible = false; }, { passive: true });

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { cancelAnimationFrame(raf); raf = 0; }
      else if (!raf) loop();
    });

    loop();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
