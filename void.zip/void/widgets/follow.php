<?php
$voidDiscordUrl = function_exists('theme_option') ? theme_option('discord_url') : '';
$voidVotingOn = !empty($config['otservers_eu_voting']['enabled']) || !empty($config['voting']['enabled']);
if ($voidDiscordUrl === '' && !$voidVotingOn) {
	return;
}
?>
<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-globe"></i> <?= t('void.follow.title') ?></div>
	<div class="sh-panel-body">
		<div class="sh-fast-links">
			<?php if ($voidDiscordUrl !== ''): ?>
				<a href="<?= htmlspecialchars($voidDiscordUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><?php theme_include('parts/discord-icon.php'); ?> Discord</a>
			<?php endif; ?>
			<?php if ($voidVotingOn): ?>
				<a href="voting.php"><i class="fa fa-star"></i> <?= t('void.follow.vote') ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>
