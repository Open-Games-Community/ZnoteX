<div class="sh-panel" id="loginContainer">
	<div class="sh-panel-title"><i class="fa fa-user"></i> <?= t('void.user.panel') ?></div>
	<div class="sh-panel-body">
		<form class="loginForm" method="post" action="login.php">
			<div class="sh-form-group">
				<input type="text" name="username" class="sh-input" placeholder="<?= htmlspecialchars(t('widget.login.username'), ENT_QUOTES, 'UTF-8') ?>" maxlength="64" autocomplete="off" required>
			</div>
			<div class="sh-form-group">
				<input type="password" name="password" class="sh-input" placeholder="<?= htmlspecialchars(t('widget.login.password'), ENT_QUOTES, 'UTF-8') ?>" maxlength="64" required>
			</div>
			<?php if (!empty($config['twoFactorAuthenticator'])): ?>
				<div class="sh-form-group">
					<input type="password" name="authcode" class="sh-input" placeholder="<?= htmlspecialchars(t('widget.login.token'), ENT_QUOTES, 'UTF-8') ?>">
				</div>
			<?php endif; ?>
			<?php Token::create(); ?>
			<button type="submit" class="sh-btn sh-btn-primary sh-btn-full">
				<i class="fa fa-sign-in"></i> <?= t('widget.login.submit') ?>
			</button>
		</form>
		<div class="sh-form-links">
			<a href="recovery.php"><i class="fa fa-key"></i> <?= t('widget.login.lost') ?></a>
			<a href="register.php"><i class="fa fa-user-plus"></i> <?= t('widget.login.new_account') ?></a>
		</div>
	</div>
</div>
