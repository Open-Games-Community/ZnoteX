<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-user"></i> <?= t('void.user.panel') ?></div>
	<div class="sh-panel-body">
		<div class="sh-user-info">
			<div class="sh-user-avatar"><?= htmlspecialchars(strtoupper(substr((string)($user_data['name'] ?? '?'), 0, 1)), ENT_QUOTES, 'UTF-8') ?></div>
			<div>
				<div class="sh-user-name"><?= htmlspecialchars((string)($user_data['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
				<div class="sh-user-role"><?= is_admin($user_data ?? array()) ? t('void.user.staff') : t('void.user.member') ?></div>
			</div>
		</div>
		<div class="sh-user-links">
			<a href="myaccount.php"><i class="fa fa-id-card"></i> <?= t('widget.account.my_account') ?></a>
			<a href="createcharacter.php"><i class="fa fa-plus"></i> <?= t('widget.account.create_character') ?></a>
			<a href="changepassword.php"><i class="fa fa-key"></i> <?= t('widget.account.change_password') ?></a>
			<a href="settings.php"><i class="fa fa-cog"></i> <?= t('widget.account.settings') ?></a>
		</div>
		<a href="logout.php" class="sh-btn sh-btn-full sh-logout-btn"><i class="fa fa-sign-out"></i> <?= t('widget.account.logout') ?></a>
	</div>
</div>
