<?php
$voidFeedbackNew = 0;
$voidFeedbackCache = new Cache('engine/cache/asideFeedbackCount');
if ($voidFeedbackCache->hasExpired()) {
	$cat = 4;
	$threads = db()->fetchAll("SELECT `id`, `player_id` FROM `znote_forum_threads` WHERE `forum_id`=? AND `closed`='0';", [$cat]);
	if ($threads !== false) {
		$staffs = db()->fetchAll("SELECT `id` FROM `players` WHERE `group_id` > '1';");
		foreach ($threads as $thread) {
			$response = false;
			$posts = db()->fetchAll("SELECT `id`, `player_id` FROM `znote_forum_posts` WHERE `thread_id`=?;", [$thread['id']]);
			if ($posts !== false && is_array($staffs)) {
				foreach ($posts as $post) {
					foreach ($staffs as $staff) {
						if ($post['player_id'] == $staff['id']) {
							$response = true;
						}
					}
				}
			}
			if (!$response) {
				$voidFeedbackNew++;
			}
		}
	}
	$voidFeedbackCache->setContent($voidFeedbackNew);
	$voidFeedbackCache->save();
} else {
	$voidFeedbackNew = (int)$voidFeedbackCache->load();
}
?>
<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-shield"></i> <?= t('widget.admin.title') ?></div>
	<div class="sh-panel-body">
		<a href="admin/index.php" class="sh-btn sh-btn-primary sh-btn-full" style="margin-bottom:8px;">
			<i class="fa fa-sliders"></i> <?= t('widget.admin.panel') ?>
		</a>
		<a href="forum.php?cat=4" class="sh-btn sh-btn-outline sh-btn-full">
			<i class="fa fa-comments"></i> <?= t('widget.admin.feedback', ['count' => $voidFeedbackNew]) ?>
		</a>
	</div>
</div>
