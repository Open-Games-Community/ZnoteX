<?php
$voidStatCache = new Cache('engine/cache/voidStats');
if ($voidStatCache->hasExpired()) {
	$voidStats = mysql_select_single("
		SELECT
			(SELECT COUNT(`id`) FROM `accounts`) AS `accounts`,
			(SELECT COUNT(`id`) FROM `players`) AS `players`,
			(SELECT COUNT(`id`) FROM `guilds`) AS `guilds`,
			(SELECT COUNT(`player_id`) FROM `players_online`) AS `online`
	");
	$voidStatCache->setContent($voidStats);
	$voidStatCache->save();
} else {
	$voidStats = $voidStatCache->load();
}
$voidStats = is_array($voidStats) ? $voidStats : array('accounts' => 0, 'players' => 0, 'guilds' => 0, 'online' => 0);
?>
<div class="sh-panel">
	<div class="sh-panel-title"><i class="fa fa-bar-chart"></i> <?= t('void.stats.title') ?></div>
	<div class="sh-panel-body">
		<table class="sh-stats-table">
			<tbody>
				<tr><th><?= t('void.stats.players_online') ?></th><td><?= number_format((int)$voidStats['online']) ?></td></tr>
				<tr><th><?= t('void.stats.accounts') ?></th><td><?= number_format((int)$voidStats['accounts']) ?></td></tr>
				<tr><th><?= t('void.stats.characters') ?></th><td><?= number_format((int)$voidStats['players']) ?></td></tr>
				<tr><th><?= t('void.stats.guilds') ?></th><td><?= number_format((int)$voidStats['guilds']) ?></td></tr>
			</tbody>
		</table>
	</div>
</div>
